@call display-horizontal-divider %*
