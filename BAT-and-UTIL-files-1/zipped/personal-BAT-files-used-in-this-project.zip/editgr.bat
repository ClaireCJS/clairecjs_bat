@call editgrep %*
