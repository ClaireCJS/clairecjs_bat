@call clipboard %*
