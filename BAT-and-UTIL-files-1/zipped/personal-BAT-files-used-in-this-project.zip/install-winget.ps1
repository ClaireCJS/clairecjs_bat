Add-AppxPackage -Path "https://aka.ms/getwinget"
