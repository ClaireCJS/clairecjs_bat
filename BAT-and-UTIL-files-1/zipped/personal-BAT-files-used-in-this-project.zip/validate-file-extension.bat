@call validate-is-extension %*
