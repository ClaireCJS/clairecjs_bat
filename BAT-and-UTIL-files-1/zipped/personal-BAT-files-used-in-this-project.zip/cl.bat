@call clipboard.bat %*
