##### This package is to validate ASP logins that have been inserted into the database

##### It does make the assumption that all cookies are stored in the %cookies hashtable
##### This is usually done by: use Clio::Cookie; &read_cookies; 
##### However, if %cookies is not defined it will attempt to read them automatically.


use Clio::Database;					#&DoQuery
use Clio::Cookie;						#&read_cookies
use Clio::Date;						#&gettimeinfo
use Clio::Constants;
use strict;
use vars qw(%cookies $NOWSQLSERVERTIMESTAMP $NOWYYYY $NOWMM $NOWDD $NOWhh $NOWmm $NOWss
		$DATABASE_SESSION_TABLE $ADMIN $userid $dbh &URL_USERVIEW);

##### DEFAULT USER SESSION STUFF:
my $SESSION_MINUTES = 40;						#HOW LONG OUR SESSION SHOULD LAST!
my $SESSION_TABLE = $DATABASE_SESSION_TABLE;		#from Clio::Constants

##### DEFAULT USER SECURITY (SORRY ABOUT THE DUAL DECLARATIONS -- CHANGED MIND):
use constant SECURITY_LEVEL_DEFAULT     => 250;		#this is the default security level in the database. 250=Stranger. Nothing is below 250. If it ever is, we probably need to change that.
use constant SECURITY_LEVEL_REQUIRE_SSL => 777;
use constant SECURITY_LEVEL_ADMIN       => 1000;



##### REDUNDANT BUT NECESSARY:
my $SECURITY_LEVEL_DEFAULT     = 250;		#this is the default security level in the database. 250=Stranger. Nothing is below 250. If it ever is, we probably need to change that.
my $SECURITY_LEVEL_REQUIRE_SSL = 777;
my $SECURITY_LEVEL_ADMIN       = 1000;

##### NEW USER RECORD STRUCTURE IS VERY SIMPLE:
my $DEFAULT_USER_DATA = {security_level=>SECURITY_LEVEL_DEFAULT};

##### RELATION TO USEROPTIONS.ASP:
my $USEROPTIONS_ASP_HAS_ANYTHING = 0;		#until userOptions.ASP is developed, set this to 0

1;

########################################################################################################################
BEGIN {					#static variables

my %validated=();		#key=$id$ip$NOWSQLSERVERTIMESTAMP		#value=1 if validated
my %usernames=();		#key=$id							#value=username
my @rows=();

sub ValidateUser {
	##### USAGE: ($valid,$username,$userid,$admin,$familyorfriend,$nickname)=&ValidateUser({userid=>$id,$IP=>$ip,getusername=>0});
	#####		both inputs are optional, and are retrieved automatically if not specified
	##### RETURNS: a hash table of user data

	##### ASSUMES:  	$SESSION_TABLE is the table in the database to use
	##### ASSUMES:		using Clio::Cookie and Clio::Database functions
	##### ASSUMES:		SECURITY_LEVEL_DEFAULT constant

	my $options 		= $_[0];
	my $id			= $options->{userid}		|| "";
	my $ip			= $options->{IP}			|| "";
	my $getusername		= $options->{getusername}	|| "";
	my $valid			= $options->{valid}		|| "";
	my $username		= $options->{username}		|| "";
	my $public_description = "";

	##### Set options:
	if ($getusername eq "") { $getusername=1; }		#By default, we DO get username.

	##### Try to get userid from cookie:
	if ($id eq "") {
		## Read cookies in if not already:
		if (!defined %cookies) { &read_cookies; }
		$id = $cookies{userid};
		if ($id eq "") { 
			print "\n<!-- ValidateUser: no ID exists -->\n";
			return($DEFAULT_USER_DATA);
		}
	}

	##### Try to get IP from variable:
	##my ($name,$aliases,$addrtype,$length,@addrs) = gethostbyaddr
	if ($ip eq "") { $ip=$ENV{'REMOTE_HOST'}; }
	if ($ip eq "") {
			print "\n<!-- ValidateUser: no IP exists -->\n";
			return($DEFAULT_USER_DATA);		
	}

	##### Get current datetime in stringform needed:
	if ($NOWSQLSERVERTIMESTAMP eq "") { &gettimeinfo; }
	my $nowstring = $NOWSQLSERVERTIMESTAMP;

	#DEBUG:print "Checking if ((\$validated{$id$ip} == 1) || (valid=$valid==1))..<BR>";#print &tabledump("validated",\%validated);

	my $already_validated=0;
	if (($validated{"$id$ip"} == 1) || ($valid==1)) {
		$valid=1; $already_validated=1;
	} else {	
		##### Query database for sessions:
		my $sql = "select * from $SESSION_TABLE S, WEBUSERS U, WEBUSERS_SECURITY_LEVELS LEVELS where S.id=$id and S.IP='$ip' and '$nowstring' < S.expires and S.id=U.id and LEVELS.security_level=U.security_level";

		#print "\n<!-- ValidateUser: Validating: userid=$id,ip=$ip,sql=$sql -->\n";
		@rows = &DoQuery($sql);
		#print "\n<!-- returned rows: ".@rows." -->\n";	

		#DEBUG:print &tabledump($sql,\@rows);#

		##### See if any rows were returned:
		if (@rows > 0) { 
			$valid=1; 
			$validated{"$id$ip"}=1;
			$public_description=$rows[0]->{public_description};
		}#endif
	}#endif static validation check

	##### If we're supposed to get the username, do that too:
	my $user = $rows[0];
	if ($getusername && $valid && ($username eq "")) {
		print "\n<!-- Getting username for id $id -->\n";
		if ($usernames{id} ne "") { $username = $usernames{id}; }
		else 				  { 
			$username = $user->{username};
		}
		if ($username eq "") {
			print "\n<!-- ValidateUser: WARNING: Could not get username for id $id -->\n";
		} else {
			$usernames{id}=$username;
		}#endif
	}

	##### Get if they are an admin/trusted:
	my $security_level=SECURITY_LEVEL_DEFAULT;
	if ($user->{security_level} ne "") { $security_level=$user->{security_level}; }

	##### Get the nickname:
	my $nickname="";
	if ($user->{nickname} ne "") { $nickname=$user->{nickname}; }

	##### If they are valid, we should update the session value to keep it from expiring:
	if (($valid) && (!$already_validated)) {
		my $expires = &AddDateTime({datetime=>"$NOWSQLSERVERTIMESTAMP",minutes=>$SESSION_MINUTES});
		my $sql  = "UPDATE $SESSION_TABLE set expires='$expires' where id=$id and IP='$ip'";
		@rows = &DoQuery($sql);
		#DEBUG:print &tabledump("$sql",\@rows);
	}#endif

	##### Set up our return hash:
	my $hashref={};
	$hashref->{user_id}		= $id;
	$hashref->{valid}			= $valid;
	$hashref->{username}		= $username;
	$hashref->{nickname}		= $nickname;
	$hashref->{security_level}	= $security_level;
	$hashref->{security_level_description}	= $public_description;

	#print "\n<!-- ValidateUser: Return Values: valid=$valid,username=$username,id=$id,admin=$admin,getusername=$getusername -->\n";
	#return($valid,$username,$id,$admin,$trusted,$nickname);
	return($hashref);
}#endsub ValidateUser
}#end static variable block
########################################################################################################################

######################################################################################
sub GetUserNameFromUserID {
	my $id = $_[0];

	if ($id eq "") { 
		print "\n<!-- GetUserNameFromUserID called with no id -->\n";
		return ""; 
	}

	my $sql = "select * from WEBUSERS where id='" . $id . "'";
	my @rows = &DoQuery($sql);

	if (@rows == 0) {
		print "\n<!-- GetUserNameFromUserID: userid of $id not found ... sql was [[[$sql]]] -->\n";
		return ""; 
	}
	
	my $hashref = @rows[0];
	my $username = $hashref->{username};
	
	return($username);
}#endsub GetUserNameFromUserID
######################################################################################

##################################################################################################
sub showLoginOrLogoutLink {
	my $options 	= $_[0];
	my $valid		= "";
	my $username	= "";

	if (defined $options) {
		$valid 		= $options->{"valid"} 		|| "";
		$username 	= $options->{"username"} 	|| "";
	}#endif

	if (($valid eq "") || ($username eq "")) {
		my $hashref = &ValidateUser({valid=>$valid,username=>$username});
		$valid 	= $hashref->{valid};
		$username	= $hashref->{username};
		#($valid,$username)=&ValidateUser({valid=>$valid,username=>$username});
	}#endif

	if ($valid) {
		print "You may <a href=\"/home/logout.asp\">logout</a>";
		if ($USEROPTIONS_ASP_HAS_ANYTHING) { print ", <a href=\"/home/userOptions.asp\">view</a> your options,"; }
		print " or <a href=\"/home/login.asp\">switch</a> from \"$username\" to another account.<BR>";
	} else {
		print "Login or apply for an account <a href=\"/home/login.asp\">HERE</a>.<BR>";
	}#endif
}#EndSub	showLoginOrLogoutLink
##################################################################################################


###########################################################################
sub showNewUsers {
	my $tmp;
	my @rows;
	my $tmphashref;

	#USAGE: &showNewUsers($ADMIN);
 
	#ASSUMES $DATABASE_TABLE_USER_ACCOUNTS			
	#ASSUMES $DATABASE_TABLE_USER_ACCOUNTS_DATE	
	#ASSUMES $userid = current user id
	#ASSUMES $ADMIN if they are an admin.
	#ASSUMES $tmp	which is just used to hold our sql queries

	if (!$ADMIN) { return; }

	$tmp = "select count(*) as count from WEBUSERS U, WEBUSERS_LAST_VIEW LV where LV.user_id=$userid and U.date_added > LV.last_viewed";
	@rows = &DoQuery({dbh=>$dbh,sql=>$tmp});
	if (@rows > 0) {
		$tmphashref = $rows[0];
		if ($tmphashref->{"count"} > 0) {
			print "New users have signed up since you last checked.  Please review them <a href=\"" . URL_USERVIEW . "?id=all&edit=1\">HERE</a>.<BR>"
		}#endif
	}#endif
	#if ($verbose) { print &tabledump($tmp,\@rows); }

}#endsub 	
###########################################################################



