
#USAGE: use Clio::Cookie; &read_cookies; 	#places cookies into %cookies hash

use Clio::TabledDataDumper;
use Clio::String;



### EXPORT ATTEMPT -- didn't seem to work...remove this if photoalbum breaks etc
require Exporter;
@ISA = qw(Exporter);
@EXPORT    = qw(&read_cookies read_cookies);
@EXPORT_OK = qw(&read_cookies read_cookies);
###

#package Clio::Cookie;

#################################################################################################
sub read_cookies {
	#USAGE: &read_cookies({verbose=>0,showcookies=>0});
	my $options = $_[0];
	my @nvpairs=split(/;/, $ENV{'HTTP_COOKIE'});
	foreach $pair (@nvpairs) {
	    ($name, $value) = split(/=/, $pair);
	    $name = &remove_leading_and_trailing_spaces($name);
	    $cookies{$name} = $value;
	    if ($options->{verbose}) { print "<BR>Cookie found: name=\"$name\",value=\"$value\"<BR>\n\n"; }
	}#endforeach
	if ($options->{showcookies}) { print &tabledump(%cookies); }
}#endsub
#################################################################################################
#################################################################################################
sub give_simple_cookie {
	#ASSUMES %COOKIES always holds cookies -- so it updates that too.

	#USAGE: &give_simple_cookie({name=>"name",value=>"clio"});
	my $options = $_[0];
	my $name    = $options->{name};
	my $value   = $options->{value};
	my $verbose = $options->{verbose};

	if ($name eq "") { print "ERROR: Can't assign cookie with value of \"$value\" when no name is given!\n"; }

	$value =~ s/;/:/g;	#we can't have semicolons in cookies so we'll sub it into a colon -- the closet match

	my $cookietext=&give_complex_cookie_perl({name=>$name,value=>$value,path=>"/",
		expires=>"Fri, 31-Dec-2099 00:00:00 GMT",verbose=>$verbose});

	$cookies{$name}=$value;

	return $cookietext;		##### NOT TYPICALLY USED
}#endsub give_simple_cookie give_cookie_simple 
#################################################################################################
#################################################################################################
sub give_complex_cookie_perl {
	#Content-type: text/html
	#Set-Cookie: foo=bar; path=/; expires=Fri, 01-Jan-98 00:00:00 GMT
	#Here, an HTML page would follow after a cookie has been set.
	#Another very popular HTTP header used in PERL is Location. Be aware that location is best placed as the last header in a group:
	#Content-type: text/html
	#Set-Cookie: foo=bar; path=/; expires=Fri, 01-Jan-98 00:00:00 GMT
	#Location: http://www.mysever.com
	my $options   = $_[0];

	my $name      = $options->{name};
	my $value     = $options->{value};
	my $path      = $options->{path};
	my $expires   = $options->{expires};
	#my $location = $options->{location};#no location support for this version
	my $verbose   = $options->{verbose};
	my $cookie    = "";
                
	$name  = &remove_leading_and_trailing_spaces($name);
	$value = &remove_leading_and_trailing_spaces($value);
                
	 $cookie  = "Content-type: text/html\r\n";
	 $cookie .= "Set-Cookie:$name=$value; expires=$expires; path=$path;\n";
	#$cookie .= "Location: $location\n"; #no location support for this version

	print  $cookie;
	return $cookie;
}#endsub give_complex_cookie_perl
#################################################################################################




1;