#!/usr/local/bin/perl


#########################################################
BEGIN {
	my $HEADER_PRINTED=0;		#static variable
	sub Print_Header {
		if ($HEADER_PRINTED) { return; }
		print "Content-type: text/html\n\n";
		$HEADER_PRINTED=1;
	}#endsub Print_Header
}
#########################################################

# ALIAS:
sub header { &Print_Header(@_); }


1;
