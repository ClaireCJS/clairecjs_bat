use HTTP::Date;	#used with GetFileDate
use Clio::Date;
use File::Find;	#used with GetSubdirsInDir
use strict;

##### Module for dealing with various filesystem issues.

#USAGE:	@FILES = &ReturnListOfFilesInDirectoryAsArray($PATH_TO_LISTS);
#USAGE: 	($pathonly,$fileonly)=&GetPathAndFileFromFullFilename($tmpfile);
#USAGE:	$extension = &GetExtension($fullfilename);
#USAGE:	$name_without_extension = &TrimExtension($fullfilename);
#USAGE: 	$size_or_other_info = &GetFileInfo($fullpath,"size"[or other info name]);
#USAGE: 	my $bytes = &GetFileSize($fullpath);
#USAGE:	print &NiceFileSize($bytes);
#USAGE: $fileWithoutExtension = &remove_extension($full_file_name);

my $DEBUG_TOTALS=0;
1;

######################################################################################################
sub GetContentsOfDirectory {
	#USAGE:	($filesArrayRef,$subdirsArrayRef) = &GetContentsOfDirectory($dir);
	my $dirname 	= $_[0];
	my $options 	= $_[1];
	my @extensions	= ();
	if (defined($options->{extensions})) { @extensions = @{$options->{extensions}}; }
	my @files 	= ();
	my @subdirs	= ();
	my $entity	= "";
	my $tmp		= "";
	my $tmp2		= "";


	#DEBUG:print &tabledump("extensions",\@extensions);#


	opendir(DIR, $dirname) or die "FATAL ERROR: can't open directory \"$dirname\": $!";
	while (defined($entity = readdir(DIR))) { 
		next if ($entity =~ /^\.{1,2}/);
		$tmp = "$dirname/$entity";
		#DEBUG:print "tmp is $tmp<BR>";	#
		if  (-f $tmp) { 
			if (@extensions > 0) {
				$tmp2 = &GetExtension($tmp);
				foreach my $tmpext (@extensions) {
					#DEBUG:print "Checking $tmp2 for $tmpext . . . ";#
					if ($tmp2 =~ /^$tmpext$/i) { push(@files,$tmp); last; }
				}
			} else {
				push(@files,$tmp); 
			}#endif
		}
		elsif (-d $tmp) { push(@subdirs,$tmp); }
		else {
			print "WARNING: unknown entity of $tmp in dir $dirname \n";
		}#endeif
	}#endwhile
	closedir(DIR);
	return \@files, \@subdirs;
}#endsub GetContentsOfADirectory
######################################################################################################


###############################################################################################
sub GetSubdirsInDir {
	my $dir = $_[0];

	##### Check for bad input:
	if (!-d $dir) { 
		print "ERROR: &GetSubdirsInDir in Clint::File called with nonexistent dir of $dir";
		return;
	}#endif

	##### Get list of stuff in dir:
	opendir(DIR, $dir);
	my @stuff = readdir(DIR);
	closedir(DIR);

	##### Suck out directories only:
	my @retval=();
	foreach my $thing (@stuff) {
		if ($thing =~ /^..?$/) { next; }
		if (-d "$dir/$thing") { push(@retval,"$dir/$thing"); } 
	}#endforeach

	##### Return list:
	return(@retval);

}#endsub GetSubdirsInDir
###############################################################################################

###################################################################################
sub GetFileSize {
	#USAGE: my $bytes = &GetFileSize($fullpath);
	my $fullpath = $_[0];
	return &GetFileInfo($fullpath,"size");
}#endsub GetFileSize
###################################################################################
###############################################################################################################
sub NiceFileSize {
	#USAGE: print &NiceFileSize($bytes);
	my $rate    = $_[0];
	my $options = $_[1];
	my $lprecision = $options->{lprecision};
	my $nice_size;
	if ($lprecision eq "") {$lprecision = 8;}
	if ($rate >= (1024*1024*1024*1024*1024)) {
		--$lprecision;
		$nice_size = sprintf ("%${lprecision}.1fP", ($rate/(1024*1024*1024*1024*1024)));       #petabyte
	} elsif ($rate >= (1024*1024*1024*1024)) {
		--$lprecision;
		$nice_size = sprintf ("%${lprecision}.1fT", ($rate/(1024*1024*1024*1024)));            #terabyte
	} elsif ($rate >= (1024*1024*1024)) {
		--$lprecision;
		$nice_size = sprintf ("%${lprecision}.1fG", ($rate/(1024*1024*1024)));                 #gigabyte
	} elsif ($rate >= (1024*1024)) {
		--$lprecision;
		$nice_size = sprintf ("%${lprecision}.1fM", ($rate/(1024*1024)));                      #megabyte
	} elsif ($rate >= 1024) {
		--$lprecision;
		$nice_size = sprintf ("%${lprecision}.1fK", ($rate/1024));                             #terabyte
	} else {
		$nice_size = sprintf ("%${lprecision}.1f", $rate );                                    #byte
	}#endif
	if ($DEBUG_TOTALS >= 3) { print "short_number($rate)=\"$nice_size\"...<BR>\n"; }
	if ($nice_size =~ /\s+0\.0$/) { $nice_size=sprintf("%${lprecision}s","0"); }
	if ($options->{notrailingzeroes}) { $nice_size =~ s/\.0+//; }
	return ($nice_size);
}#endsub NiceFileSize
###############################################################################################################

########################################################################################
sub GetFileInfo {
	#USAGE: $size = &GetFileInfo($fullpath,"size"[or other info name]);
	my $tmpfile = $_[0];
	my $which   = $_[1];

      #($mtime is number of seconds since epoch)
      my ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,
            $blksize,$blocks) = stat($tmpfile);

	if ($which eq "size") { return $size; }
	elsif (($which eq "mtime") || ($which eq "age") || ($which eq "date")) { return $mtime; }
	elsif ($which eq "mode") { return $mode; }
	elsif ($which eq "atime") { return $atime; }
	elsif ($which eq "ctime") { return $ctime; }
	elsif ($which eq "dev") { return $dev; }
	elsif ($which eq "ino") { return $ino; }
	elsif ($which eq "nlink") { return $nlink; }
	elsif ($which eq "uid") { return $uid; }
	elsif ($which eq "gid") { return $gid; }
	elsif ($which eq "rdev") { return $rdev; }
	elsif (($which eq "blksize")||($which eq "blocksize")) { return $blksize; }
	elsif ($which eq "blocks") { return $blocks; }
	else { return 0; }
}#endsub GetFileInfo
########################################################################################

#########################################################################
sub TypeOfFile {
	#USAGE: $type = &TypeOfFile($filename); 
	#RETURNS: "audio", "video", "image", "text"
	#COPIED into generate-attribute-filelists -- may need to periodically recopy

	my $file = $_[0];
	my $extension = &GetExtension($file);

	if ($extension eq "jpg") { return "image"; }
	if ($extension eq "avi") { return "video"; }

	if ($extension eq "gif") { return "image"; }
	if ($extension eq "bmp") { return "image"; }

	if ($extension eq "mp3") { return "audio"; }

	if ($extension eq "wav") { return "audio"; }
	if ($extension eq "qt")  { return "video"; }

	if ($extension =~ /^mpe?g$/i) { return "video"; }
	if ($extension eq "jpeg")    { return "image"; }

	if ($extension eq "doc") { return "text"; }
	if ($extension =~ /html?/) { return "text"; }
	if ($extension =~ /txt/) { return "text"; }
	if ($extension =~ /mht/) { return "text"; }

	return "unknown";
}#endsub TypeOfFile
#########################################################################

####################################################################
sub GetExtension {
	#USAGE:	$extension = &GetExtension($fullfilename);	#returns "AVI" for example
	my $fullfilename = $_[0];
	my $returnvalue = $fullfilename;
	$returnvalue =~ s/^.*\.([^\.]+)$/$1/;
	$returnvalue =~ tr/[A-Z]/[a-z]/;
	return $returnvalue;
}#endsub GetExtension
####################################################################

##########################################
sub remove_extension {
	my     $s =  $_[0];
	       $s =~ s/\.[^\.]{1,8}$//;
	return($s);
}
##########################################
##########################################
sub get_extension {
	my     $s =  $_[0];
	if ($s !~ /\./) { return ""; }
	$s =~ s/^.*\.(.{1,8})$/$1/;
	return($s);
}
##########################################

########################################################
sub TrimExtension {
	#USAGE:	$name_without_extension = &TrimExtension($fullfilename);
	my $fullfilename = $_[0];
	my $returnvalue = $fullfilename;
	$returnvalue =~ s/^(.*)\.[^\.]+$/$1/;
	return $returnvalue;
}#endsub GetExtension
########################################################
#############################################################################################################
sub GetPathAndFileFromFullFilename {
	#USAGE: ($pathonly,$fileonly)=&GetPathAndFileFromFullFilename($tmpfile);
	my $fullfilename = $_[0];
	my $pathonly     = $fullfilename;
	my $fileonly     = $fullfilename;

	$pathonly =~ s/[\\\/][^\\\/]*$//;
	$fileonly =~ s/^.*[\\\/](.*)$/$1/;

	return($pathonly,$fileonly);
}#endsub GetPathAndFileFromFullFilename
#############################################################################################################

######################################################################################################
sub ReturnListOfFilesInDirectoryAsArray {
	#USAGE:	@FILES = ReturnListOfFilesInDirectoryAsArray($PATH_TO_LISTS);
	my $dirname = $_[0];
	my @retval = ();
	my $file = "";
	opendir(DIR, $dirname) or die "FATAL ERROR: can't open directory \"$dirname\": $!";
	while (defined($file = readdir(DIR))) { push(@retval,$dirname ."/". $file); }
	closedir(DIR);
	return @retval;
}#endsub ReturnListOfFilesInDirectoryAsArray
######################################################################################################


###############################################################################################
sub GetFileDate {
	#USAGE: $date = &GetFileDate("filename","Optional-Format-String",{optionname=>value});
	#		Format string EX: "YYYY-MM-DD HOUR:MIN:SEC"	
	#		(currently only YYYY,MM,DD,CIVILIANHOUR,HOUR,MIN,SEC,AMPM supported)
	#			* HH support started but not finished
	#		OPTIONS: use_this_time=>$ctime	<-- use that time instead.

	#$date = &GetFileDate("filename","YYYY-MM-DD");		
	my $tmpfile = $_[0];
	my $format  = $_[1];
	my $options = $_[2];
	my $retval = "";
	my $mtime = 0;
	my ($YYYY,$MM,$DD);

	if ($options->{use_this_time} ne "") { $mtime=$options->{use_this_time}; }
	else { $mtime = &GetFileInfo($tmpfile,"mtime"); }

#8:25:26
#$format="HOUR:MIN:SEC";

	if ($format eq "") { 
		$retval = time2str($mtime);
	} else {
		my ($civilianhour,$AMPM);
		my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($mtime);
		my $HH="";
		$year += 1900; $mon++;
		if ($min  < 10) { $min="0$mon";  } 
		if ($mon  < 10) { $MM="0$mon";  } else { $MM=$mon; }
		if ($mday < 10) { $DD="0$mday"; } else { $DD=$mday; }
		if ($hour>12) { $civilianhour = $hour-12; } else { $civilianhour = $hour; }
		if ($hour==0) { 
			$civilianhour = 12; $HH="00"; 
		}
		if ($hour>11) { $AMPM="PM"; } else { $AMPM="AM"; }
		my $wday4print = &convert_dow_number_to_DOW($wday);
		my $nicemonth  = &convert_mm_to_MON($mon);

		$retval = $format;
		$retval =~ s/DOW/$wday4print/;
		$retval =~ s/YYYY/$year/;
		$retval =~ s/MM/$MM/;
		$retval =~ s/DD/$DD/;
		$retval =~ s/CIVILIANHOUR/$civilianhour/;
		$retval =~ s/HOUR/$hour/;
		$retval =~ s/MIN/$min/;
		$retval =~ s/SEC/$sec/;
		$retval =~ s/AMPM/$AMPM/;
		$retval =~ s/MONTH/$nicemonth/;
	}#endif

	return($retval);
}#endsub GetFileDate
###############################################################################################
