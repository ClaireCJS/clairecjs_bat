use strict;
1;

sub deep_copy {
    my $this = shift;
	#print qq[ref this is ... "] . (ref $this) . qq["...<BR>\n];
	#use Clio::TabledDataDumper;
	#print &tabledump("this",$this);
	if (not ref $this) { $this; } 
	elsif (ref $this eq "ARRAY") { [map deep_copy($_), @$this]; } 
	elsif (ref $this eq "HASH") { +{map { $_ => deep_copy($this->{$_}) } keys %$this}; } 
	else { die "ERROR: Clint::DataManipulation: What type is \"$_?\"\n"; }
}#endsub deep_copy

