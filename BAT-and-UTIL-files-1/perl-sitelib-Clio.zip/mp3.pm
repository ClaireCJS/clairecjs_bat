use MP3::Tag;

##### Including PCM bitrates like 174:
my @AUDIO_BITRATES=(8,16,24,32,48,56,64,80,88,96,112,128,160,174,192,224,256,320);


###########################################################################
sub get_genre_for_one_mp3 {
	###################### UNTESTED
	my $filename = $_[0];

	my ($genrev1,$genrev2)=("","");
	my $id3v2;
	my $tag = MP3::Tag->new($filename); 
	$tag->get_tags();
	if ($tag->{ID3v2} ne "") {
		$id3v2 = $tag->{ID3v2};
		$genrev2 = $id3v2->get_frame(TCON); #no clue what TCON is
	}
	if ($tag->{ID3v1} ne "") { $genrev1 = $tag->{ID3v1}->genre; }
	return($genrev1,$genrev2);
}
###########################################################################

##############################################################################
sub round_audio_kbps {
	my $kbps = $_[0];
	my $ugly = $kbps;
	#ASSUMES @AUDIO_BITRATES is a list of valid bitrates
	$kbps = int($kbps);
	my $THRESHOLD=5;

	my $lastkbps=0;
	foreach my $tmpkbps (@AUDIO_BITRATES) {
		#print "kbps=$kbps,tmpkbps=$tmpkbps,lastkbps=$lastkbps<BR>\n";
		if (($kbps > $lastkbps) && ($kbps < $tmpkbps)) {
			if (($kbps - $lastkbps) > ($tmpkbps - $kbps)) { 
				if (abs($tmpkbps - $kbps) < $THRESHOLD) { return $tmpkbps; }
			} else {
				if (abs($tmpkbps - $lastkbps) < $THRESHOLD) { return $lastkbps; }
			}
		}
		$lastkbps = $tmpkbps;
	}
	return (&round($ugly));
}#endsub round_audio_kbps
##############################################################################

1;