#!/usr/local/bin/perl

##### Global web-affecting stuff:
use CGI::Carp qw(fatalsToBrowser warningsToBrowser);

##### OS stuff:
$WINDOWS=1;			#to tell it is windows

##### DATABASE STUFF:
$DATABASE_SESSION_TABLE = "WEBSESSIONS";

##### IP/HOSTNAME STUFF:
#IP_CURRENT should contain all NUMERICAL ips .. plus IP_HOMEWWW which is okay if it's a name one
$IP_HOMEWWW	= "clint1.dsl.patriot.net";
@IP_CURRENT	= ($IP_HOMEWWW,"216.200.103.193","216.200.103.194","216.200.103.195");
@IP_OLD		= ("206.161.92.52","206.161.92.53","206.161.92.54","63.102.109.222","64.50.179.160","64.50.179.161","64.50.179.162"	);
@IP_ALL		= (@IP_CURRENT,@IP_OLD);

##### USERNAME STUFF:
$USERNAME 		    = "clint";					$USER_NAME=$USERNAME;
$ACMUSERNAME 		= $USERNAME;	#for now
$USERNAME_CAROLYN	= "carolyn";

##### MACHINENAME STUFF:
$MACHINE  		= "acm.vt.edu";				$MACHINENAME=$MACHINE; $MACHINE_NAME=$MACHINE;
$WWWMACHINENAME	= "www." . $MACHINE;

##### EMAIL STUFF:
$MAILTO   		= "$USERNAME\@$MACHINE";
$MAILTO_CAROLYN 	= "$USERNAME_CAROLYN\@$MACHINE";

##### DIRECTORY STUFF:
$HOMEDIR   		= "/home/$USERNAME";
$WWWDIR    		= "/home/$USERNAME/WWW";
$VCRDIR    		= "$WWWDIR/media";				$WWWVCRDIR=$VCRDIR;
#$PUBWWWDIR		= "/home/$USERNAME/WWW/pub";			
$WWWROOT 		= "c:/inetpub/wwwroot";
$WWWIMAGES		= "$WWWROOT/Images";
$WWWIMAGESURL	= "/Images";

$PUBWWWDIR 	= "$WWWROOT/pub";				$WWWPUBDIR=$PUBWWWDIR; $PUBDIR=$PUBWWWDIR;
$MACHINECGIDIR= "$WWWROOT/cgi";			$CGIMACHINEDIR=$MACHINECGIDIR;
$BASECGIDIR   = "$MACHINECGIDIR";				$CGIBASEDIR=$BASECGIDIR;
$LOGDIR		= $PUBWWWDIR . "/log";			$LOG_DIR=$LOGDIR;

##### FILE STUFF:
$COUNTER_DIR	= "$LOGDIR/counter";

##### These 2 are deprecated:
$COUNTER_NAME_ONLY	= "access_count";
$COUNTER_LOG		= "$COUNTER_DIR/$COUNTER_NAME_ONLY";		$COUNTERLOG=$COUNTER_LOG;

##### URL STUFF:
$ACMMACHINEURL		= "http://www.$MACHINE";			$URLMACHINE=$MACHINEURL;
$MACHINEURL			= "http://$IP_HOMEWWW";				$BASEURL=$MACHINEURL;
$ALBUMURL				= "$MACHINEURL/Album";
$BASEACMURL			= "$ACMMACHINEURL/~$USERNAME";		$ACMURL=$BASEACMURL;
$BASEACMURL_CAROLYN	= "$ACMMACHINEURL/~$USERNAME_CAROLYN";		
$BASEVCRURL			= "$ACMMACHINEURL/~$USERNAME/media";	$VCRURL=$BASEVCRURL;
$ACMMACHINECGIURL		= "$ACMMACHINEURL/pub-cgi-bin";		$ACMCGIMACHINEURL=$ACMMACHINECGIURL;
$MACHINECGIURL 		= "$MACHINEURL/cgi";				$CGIMACHINEURL=$MACHINECGIURL;
$BASEACMCGIURL		= "$ACMMACHINECGIURL/$ACMUSERNAME";		$ACMCGIBASEURL=$ACMBASECGIURL;
$BASECGIURL			= $MACHINECGIURL;					$CGIBASEURL=$BASECGIURL;
$COUNTER_STATS_URL 	= "$BASECGIURL/counter/counterstats.pl";

##### GENERIC WEB APPLICATION CONSTANTS:
$MULTI_VALUE_FORM_DELIMITER="::::";





###########################################################################################################
###################### STUFF TO DEAL WITH MICROSOFT IIS VIRTUAL DRIVE MAPPINGS ..... ######################

### When adding new virtual directories that need to be perl-mappable, add to both hashes; one is an inverse:
%VIRTUAL_MAPPINGS     = (
	"album/"	=> "d:/www/",					#use lowercase on both sides here--FOLLOW FORMAT
	#"cgi/"	=> "c:/inetpub/wwwroot/cgi/",
);		
%VIRTUAL_MAPPINGS_INV = (
	"d:/www/" 				=> "/Album/",		#okay to use uppercase on right side--harmless
	#"c:/inetpub/wwwroot/cgi/"	=> "/cgi/",
);		
### TAKE SPECIAL NOTE -- the DOSPATH part is all lowercase!

### Virtual mappings go from URL to REAL.
### INVERSE mappings go from REAL to URL.

sub remap_virtual_directory {
	#USAGE: &remap_virtual_directory("Album/a.txt" ,{inverse=>0}) returns "d:/www/a.txt"
	#USAGE: &remap_virtual_directory("d:/www/a.txt",{inverse=>1}) returns "Album/a.txt"
	my $file      = $_[0];
	my $options   = $_[1];
	my $inverse   = $options->{inverse} || 0;
	my $DEBUG     = $options->{verbose} || 0;

	if ($DEBUG) { print "<U><B>&Remap_Virtual_Directory</B></u>(file=[$file],inverse=$inverse,debug=$DEBUG)<BR>\n"; }

	if (!$inverse) { $file =~ s/^\///; }
	$file =~ s/\\/\//g;
	my $firstpath = $file;
	my $restpath  = $file;

	#DEBUG: foreach my $tmpkey (sort keys %VIRTUAL_MAPPINGS_INV) { print "key=$tmpkey,value=$virtual_mappings_inv{$tmpkey}<BR>\n"; }
	###### Suck out everything up to the first slash (Second if we're inverse since first slash is after driveletter only):
	if ($inverse) 	{ 
		$firstpath =~ s/^([a-z]:[\\\/][^\\\/]+[\\\/]).*/$1/; 
		$firstpath =~ tr/[A-Z]/[a-z]/;
	} else { 
		$firstpath =~ s/(\/).*$/$1/; 
	}
	my $originalfirstpath = $firstpath;

	if ($DEBUG>1) { 
		print "<nobr>[C]Attempting to find remapping of file (INVERSE=$inverse): $file .. firstpath is $firstpath</nobr><BR>\n";
		#if ($inverse)	{ 
			print "<nobr>[CC]virtualmappings_INV{$firstpath}=$VIRTUAL_MAPPINGS_INV{$firstpath}</nobr><BR>\n"; 
		#} else { 
			print "<nobr>[CCC]virtualmappings{$firstpath}=$VIRTUAL_MAPPINGS{$firstpath}</nobr><BR>\n"; 
		#}
	}

	if ($DEBUG>1) { print "<nobr>[O]firstpath is \"$firstpath\" </nobr><BR>\n"; }

	if ($inverse) 	{ $firstpath =~ s/$firstpath/$VIRTUAL_MAPPINGS_INV{$firstpath}/; }
	else			{ 
		##### Check default mapping (off of $WWWROOT ie c:/inetpub/wwwroot) first, so that
		##### our hash table is only used for exceptions!
		my $test = $file;
		$test =~ s/$firstpath/$WWWROOT\/$firstpath/i;
		if ($DEBUG>1) { print "Test is $test ..."; if (-e $test) {print "And it exists!<BR>";} print "<BR>\n"; }
		if (-e $test) { return $test; }

		#DEBUG:print "$firstpath =~ s/$firstpath/$VIRTUAL_MAPPINGS{$firstpath}/";
		my $mapping = $VIRTUAL_MAPPINGS{$firstpath};
		if ($mapping eq "") {
			$firstpath =~ tr/[A-Z]/[a-z]/;	#try lowercasing it
		}
		$firstpath =~ s/$firstpath/$VIRTUAL_MAPPINGS{$firstpath}/; 
	}
	$restpath  =~ s/$originalfirstpath//i;

	if ($DEBUG>1) { print "<nobr>[P]firstpath is \"$firstpath\" </nobr><BR>\n"; }
	if ($DEBUG>1) { print "<nobr>[Q]Restpath is $restpath </nobr><BR>\n"; }

	$retval = $firstpath . $restpath;
	if ($DEBUG>1) { print "<nobr>[Z]Virtual_mapping for $file is $retval</nobr><BR><BR>\n"; }
	return $retval;
}
###########################################################################################################

1;

