#!/usr/local/bin/perl
use Clio::Constants;			#for MultiValueFormDelimiter only, really.
use Clio::Header;			#only really used during debugging

############################################################################################
sub Parse_Data {
	my $MultiValueFormDelimiter	= $MULTI_VALUE_FORM_DELIMITER 	|| "::::";
	my $options 			= $_[0];
	my $forced_query_data		= $options->{forced_query_data}	|| "";	#to use this instead of query string
	my $overwrite  			= $options->{overwrite};
	my $multivalue 			= $options->{multivalue};
	my @pairs=();
	my $buffer=();
	my $name="";
	my $value="";
	
	if (($multivalue) && ($options->{MultiValueFormDelimiter})) { $MultiValueFormDelimiter=$options->{MultiValueFormDelimiter}; }
	

	##### Verbosity:
	#$verbose=3;#
	if (($options->{verbose}) || ($verbose)) { 
		&Print_Header;
		if (!$verbose) { $verbose=$options->{verbose}; }
		print "Parse_Data called in verbose mode...<BR>\n"; 
		if ($options->{verbose} > 4) { &dump_environment; }
		print "REMOTE_HOST is $ENV{'REMOTE_HOST'}<BR>";#
	}#endif vebose

	
	##### Get query data, regardless of source:
	if ($forced_query_data ne "") {
		$buffer=$forced_query_data;
		$FORM{form_method}="manual";
	} elsif ($ENV{REQUEST_METHOD} eq "POST") {
		if ($verbose) { print "Getting query info from buffer (POST)<BR>\n"; }
		read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
		$FORM{form_method}="post";
	} elsif ($ENV{QUERY_STRING} ne "") {
		if ($verbose) { print "Getting query info from \$ENV{QUERY_STRING} (GET)<BR>\n"; }
		$buffer=$ENV{QUERY_STRING};
		$FORM{form_method}="get";
	} else { 
		if ($verbose) { print "Getting query info from \@ARGV (command-line)<BR>\n"; }
		$buffer="@ARGV"; 
		if ($buffer ne "") {
			$FORM{form_method}="command line";
		} else {
			$FORM{method}="none";
		}#endif
	}#endif
	@pairs = split(/&/, $buffer);
	
	
	##### Split, decode, and hash up query data:
	if ($verbose) { print "Form method is $FORM{method}\n"; }
	foreach my $pair (@pairs) {
		($name, $value) = split(/=/, $pair);

		$value =~ tr/+/ /;
		#$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/egi;
		$value =~ s/\%([A-F0-9]{2})/pack("C", hex($1))/egi;
		if ($name eq "form_method") { next; }		#internally set!
		if (($multivalue) && ($value ne "")) { 
			##### If multiple values are allowed, stack them using our multivalueformdelimeter defined in Clio::Constants:
			if ($FORM{$name} eq "") { $FORM{$name} = $value; } 
			##### But only stack them if the second value is different:
			elsif ($FORM{$name} ne $value) { 
				##### And only if the value is not already in there . . . 
				if (grep(/$value/,split($MultiValueFormDelimiter,$FORM{$name}))==0) {
					$FORM{$name} = $FORM{$name} . $MultiValueFormDelimiter . $value; 
				}
			}
		} elsif ($overwrite == 0) {
			if ($FORM{$name} eq "") { $FORM{$name} = $value; }
		} else {
			$FORM{$name}=$value;
		}#endif
		if ($verbose) { print "\$FORM{$name} is now \"$value\"<BR>"; }
	}#endforeach pair
}#endsub parse_data
############################################################################################

1;
