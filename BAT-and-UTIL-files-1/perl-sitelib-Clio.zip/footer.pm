#!/usr/local/bin/perl

#require "$LIB_DIR/counter.pl";
use Clio::Counter;
use Clio::HTML;
use Clio::Math;
use strict;

use vars qw($MAILTO $BASEVCRURL $tmp $tmp2 $table $position $ALBUMURL); 

my @DEFAULTLINKS=(
	{url=>"mailto:$MAILTO",	text=>"Clio's mail", 					target=>""     },
	{url=>"$BASEVCRURL", 	text=>"Clio's media catalogs", 			target=>"acm"  },
	{url=>"$ALBUMURL",		text=>"Clio & Carolyn's Photo Album",	target=>"album"}
);




########################################################
sub footer {
#USAGE: &footer({
#		nocounterlinks=>1, counteronly=>1, linksonly=>1, footerlinktarget=>"targname",
#		nocounter=>1,
#		linkssize=>3,	table=>1,
#		additionallinks   => [ 
#						  {url=>"/Album",	text=>"Back to photo alubm",	position=>1,target=>"targname"},
#						  {url=>"/Guestbook",text=>"Guestbook",			position=>3,target=>"targname"} 
#						],
#		});
my $criteria = $_[0];
my $counter  = 1;
my $links    = 1;
my $defaultbegintext = "</font><B>You are visitor number";
my $defaultendtext = ".</b>";
my $nocounterlinks=0;
my $begintext;
my $endtext;
my $target;
local $tmp=0;
local $tmp2=0;
my @addiotionallinks=();
my $linkssize=2;
local $table=0;
my $num_additional_links=@addiotionallinks;
my @additionallinks=();

##### Option flags:
if ($criteria->{nocounterlinks}) { $nocounterlinks=1; }
if ($criteria->{counteronly}) { $counter=1; $links=0; }
if ($criteria->{nocounter} || ($criteria->{counter}==0)) { $counter=0; }
if ($criteria->{linksonly} || $criteria->{nocounter})   { $counter=0; $links=1; }
if ($criteria->{footerlinktarget}) { $target=" target=\"_$criteria->{footerlinktarget}\""; }
if ($criteria->{additionallinks}) { @additionallinks=@{$criteria->{additionallinks}}; }
if ($criteria->{linkssize}) { $linkssize=$criteria->{linkssize}; }
if ($criteria->{table}) { $table=$criteria->{table}; }

#DEBUG: print "==> criteria->{addtionallinks} is $criteria->{additionallinks}<BR>\n";#
#DEBUG: print "crit->{table} is $criteria->{table} ... table is $table<BR>\n";

##### Determine leading text (uses an option flag):
if ($criteria->{counterbegintext})	{ $begintext=$criteria->{counterbegintext}; } 
else 						{ $begintext=$defaultbegintext; }
##### Determine trailing text (uses an option flag):
if ($criteria->{counterendtext})	{ $endtext=$criteria->{counterendtext}; }
else						{ $endtext=$defaultendtext; }
##### Spit out our counter if we are supposed to have one:
if ($counter) {	print &counter({begintext=>$begintext,
			nolinks=>$nocounterlinks,
			endtext=>$endtext}); };
if ($counter && $links) { print "<BR>"x2; };

##### Supplemental links if we are supposed to have them:
if ($links) {
	#DEBUG: 
	#print "\@addtionallinks is ".\@additionallinks." ( ".@additionallinks." total)<BR>\n";
	#foreach my $tmplink (@additionalinks) { 
	#	#my $tmplink = $additionallinks->{$key};
	#	#print "key=$key<BR>";
	#	print "position=$$positionref,key is $key,tmplink is $tmplink,tmplink->position/target/text/url is $tmplink->{position},$tmplink->{target},$tmplink->{text},$tmplink->{url}<BR>"; 
	#}

	local $position=1;

	#NEW:
	my $num_links = @DEFAULTLINKS;
	my $add = @additionallinks;
	#DEBUG: print "num_links is $num_links, add is $add<BR>\n";

	$num_links += $add;
	$tmp2 = &round($num_links / 2)+1;
	if ($table) { 
		print qq[<table border=0 align=center width=100%>
				<TR valign=center><TD align=left>]; 
	}
	foreach my $defaultlink (@DEFAULTLINKS) {
		#DEBUG: print "Defaultlink is ". \%$defautlink ."\n [[ ". %$defautlink->{title} ."]]<BR>";#
		#DEBUG: my %d=%$defaultlink; 	foreach my $tmpkey (sort keys %d) { print "key=$tmpkey,val=%d{$tmpkey}<BR>\n"; }
		do { 	
			$tmp=&footer_process_additional_links(\@additionallinks,\$position); 
			&maybebreeakfootertable;
		} while ($tmp);
		print &link({url=>%$defaultlink->{url},linktext=>%$defaultlink->{text},
				target=>%$defaultlink->{target}}) . "<BR>";
		$position++;
		#DEBUG: print "position incremented to $position by url %$defaultlink->{url} ...<BR>\n";#
		&maybebreeakfootertable;
	}
	if ($table) { print qq[</TD></TR>]; }
	if ($table) { print qq[</table>]; }


	#OLD:
	#print qq[<font size=$linkssize>];
	#&footer_process_additional_links(\@additionallinks,\$position);
	#print qq[<a href="mailto:$MAILTO">Clio's mail</a><br>\n];
	#$position++;
	#&footer_process_additional_links(\@additionallinks,\$position);
	#print qq[<a $target href="$BASEVCRURL">Clio's media catalogs</a><br>\n];
	#$position++;
	#&footer_process_additional_links(\@additionallinks,\$position);
	#print qq[</font>\n];
}#endif
}#endsub footer
########################################################

############################################################################################################
sub maybebreeakfootertable {
	#DEBUG: print "\$tmp2=$tmp2 (position=$position)<BR>\n";#
	if (($table) && ($position==$tmp2)) { print qq[</TD><TD ALIGN=right>]; }
}#endsub maybebreeakfootertable
############################################################################################################

###################################################################
sub footer_process_additional_links {
	#returns 1 if a link was spit out, so we can try again until 0
	my @links       = @{$_[0]};
	my $positionref = $_[1];

	#DEBUG:
	#foreach my $tmplink (@links) { print "tmplink is $tmplink -- url=$tmplink->{url},linktext=$tmplink->{text},target=$tmplink->{target},position=$tmplink->{position}<BR>\n"; }
	foreach my $tmplink (@links) {
		if ($tmplink->{position} == $$positionref) {
			print &link({url=>$tmplink->{url},linktext=>$tmplink->{text},target=>$tmplink->{target}});
			print "<BR>\n";
			$$positionref++;
			#DEBUG: print "\npositionref++ to $$positionref by url $tmplink->{text}<BR>\n";#
			return(1);
		}
	}#endforeach
	return(0);
}#endsub footer_process_additional_links
###################################################################

1;
