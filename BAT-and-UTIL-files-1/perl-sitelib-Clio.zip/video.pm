use Clio::Math;
use Video::Info;

my @VIDEO_THUMBNAIL_EXTENSIONS=("THM","TNB");	#used by our digital camera, and ThumbsPlus, respectively

1;


################################################################################################################################################
sub GetVideoInfo {
	my $real = $_[0];		#the filename to our video
	my %attributes=();

	eval { $info = Video::Info->new(-file=>$real); };
	if ($info ne "") {
		my ($fps,$vcodec,$acodec,$length,$achans,$arate,$width,$height,$vframes,$vrate)
			=("","","","","","","","","","");
		eval {
			$fps    	= $info->fps();		#|| warn("asdf");
			$vcodec 	= $info->vcodec();	#|| warn("asdf"); 
			$acodec 	= $info->acodec();
			$vframes	= $info->vframes();
			$achans 	= $info->achans();
			$arate  	= $info->arate();
			$width  	= $info->width();
			$height	= $info->height();
			#$vrate	= $info->vrate();		#vrate doesn't work right
		};
		warn $@ if $@;
		#print "<BR>length is $length";
		if ($height>0) { $attributes{height}=$height; }
		if ($width >0) { $attributes{width} =$width; }
		#if ($vrate>0) { $attributes{vrate}= $vrate; }
		#print "vrate is $vrate";
		if (($fps>0) && ($vframes>0)) { $length = &round($vframes / $fps); }
		if ($vcodec ne "") { $attributes{vcodec}=&nicecodec($vcodec); }
		if ($acodec ne "") { 
			$attributes{acodec}=&nicecodec($acodec); 
			if (($achans ne "") || ($arate ne "")) {
				if ($arate ne "") { $attributes{arate} = &round_audio_kbps($arate / 1024) . "kbps"; }
				if ($achans ne "") {
					if ($achans == 0) { $attributes{achans}="broken"; }		#theoretically should not happen
					if ($achans == 1) { $attributes{achans}="mono"; }
					if ($achans == 2) { $attributes{achans}="stereo"; }
					if ($achans >  2) { $attributes{achans}="$achans" . "-channel"; }
				}
			}
		}
		if ($length ne "") { $attributes{length}=&convert_seconds_to_readable_length($length); }
		if ($fps > 0) { $attributes{fps}=&nicefps($fps); }
	}

	return(%attributes);
}#endsub GetVideoInfo
################################################################################################################################################

###############################################################################################
sub nicecodec {
	my $codec = $_[0];

	if ($codec =~ /^DIV([0-9])/) { $codec = "DivX $1"; }
	if ($codec =~ /MPEG Layer ([2-4])/) { $codec = "MP$1"; }
	if ($codec =~ /Uncompressed PCM/) { $codec = "PCM (Uncompressed)"; }

	return $codec;
}#endsub nicecodec
###############################################################################################

################################################
sub nicefps {
	my $fps=$_[0];
	if ($fps =~ /29.97/) { return "29.97"; }
	return &round($fps);
}#endsub nicefps
################################################

#my $video_thumbnail = &find_video_thumbnail($real);
#if ($video_thumbnail ne "") { $representativeimage=$video_thumbnail; }

############################################################################################################
sub find_video_thumbnail {
	#Returns the thumbnail to a video, if it exists.
	#ASSUMES @VIDEO_THUMBNAIL_EXTENSION=(xxx,yyy)
	my $video = $_[0];
	my $thumbnailbase = &TrimExtension($video);
	my $testthumbnail = "";
	foreach my $thumbext (@VIDEO_THUMBNAIL_EXTENSIONS) {
		$testthumbnail = $thumbnailbase . "." . $thumbext;
		if (-e $testthumbnail) { return &remap_virtual_directory($testthumbnail,{inverse=>1,verbose=>0}); } 
	}
	return "";
}#endsub
#############################################################################################################
