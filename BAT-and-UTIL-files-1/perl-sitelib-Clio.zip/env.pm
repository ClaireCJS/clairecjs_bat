#!/usr/local/bin/perl

#Prints out the environment much like the unix `env` command

sub dump_environment {
	foreach $key (sort keys %ENV) { print "\%$key=$ENV{$key}<BR>\n"; }
}

1;