#### I originally made this package to validate ASP logins.
#### But I realized these logins are really just user logins, the concept, while
#### implemented by ASP, is not really an ASP-specific concept, so I renamed the
#### package from Clio::ASP to Clio::user;

use Clio::user;
1;
