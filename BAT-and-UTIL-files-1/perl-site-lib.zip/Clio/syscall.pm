#!/usr/local/bin/perl5
########## SYSTEM CALL FUNCTION LIBRARY: USAGE: require /syscall.pl; ##########


#($retval_incl_stderr)=&do_system_call("some unix command");


###############################################################################################################################
###############################################################################################################################
###############################################################################################################################
$PROBLEMS = "ClioCJS\@gmail.com";

return 1;	#is an error when running date.pl, but required to use library
###############################################################################################################################
###############################################################################################################################
###############################################################################################################################



##########################################################################################################################
sub do_system_call {			#USAGE: ($return_value)=&do_system_call("some unix command");
$syscall = $_[0];
$retval="";  #return valueB
$temp="";
if (($DEBUG_VERBOSE_SYSTEM_CALLS) && (!$DEBUG_NO_ACTION)) {
        print "SYSTEM CALL: \"$syscall\"\n";
}#endif

if ($DEBUG_NO_ACTION) {
        if ($syscall =~ /grep/i) {                              #GREPs are harmless!
                $retval=`$syscall 2>&1`;
        }#endif
        print "SYSTEM CALL: \"$syscall\"\n";
} else {
        $retval=`$syscall 2>&1`;
}#endif action or no action

if ($retval =~ /core dumped/i) {
        $temp  = "\nINTERNAL SYSTEM ERROR!!!: System call \"$syscall\" resulted in a core dump.\n";
        $temp .= "This is the output:\n";
        $temp .= "\"$retval\"\n\n";
        print $temp;
}#endif
return($retval);
}#endsub do_system_call
##########################################################################################################################


1;
