#USAGE:  $tmpInteger = &round($tmpFloat);
#USAGE:  








########################################################
sub round {
	my ($number) = shift;
	return(int($number + .5 * ($number <=> 0)));
}#endif
########################################################


1;