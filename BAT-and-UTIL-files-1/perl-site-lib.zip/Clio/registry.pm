
use Win32::TieRegistry;
#use strict;				#will not work
1;

################################################################################################################
sub GetValueFromRegistryByFullKeyName {
	#USAGE: my $s = &GetValueFromRegistryByFullKeyName("HKEY_CLASSES_ROOT\\MSWC.PageCounter\\File_Location");
	my $key 		= $_[0];
	my $options	= $_[1];
	my $verbose	= $options->{verbose} || 0;
	my $s		= "";		#return value
	my $delimiter	= "\\";
	my @alltokens	= split(/\\/,$key);
	my $allbutlast	= "";
	my $last		= "";
	my $i;

	##### Separate the very last value from the rest:
	for ($i=0; $i<(@alltokens-1); $i++) { $allbutlast .= $alltokens[$i] . $delimiter; }
	$last = $delimiter . $alltokens[$i];
	if ($verbose) { print "key is $key<BR>allbutlast is $allbutlast<BR>last=$last<BR>"; }

	##### Get the value from the registry, and Expand any environment variables
	$s = $Registry->Open($allbutlast,{Access=>KEY_READ});
	my $t = $s->{$last};
	$t =~ s/\%([^\%]+)\%/$ENV{$1}/g;

	##### Return the value:
	if ($verbose) { print "\$s is [[[$s]]]<BR>t is [[[$t]]]<BR>" . &tabledump("s",$s); }
	return($t);
}#endsub GetValueFromRegistryByFullKeyName
################################################################################################################

1;

 