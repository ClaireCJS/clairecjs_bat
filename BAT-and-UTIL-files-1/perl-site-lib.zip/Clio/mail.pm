1;

################################################################################
sub SpamProtectEmailAddress {
	my $email = $_[0];
	my $original_email = $email;

	$email =~ s/\@/NOSPAM\@NOSPAM/;

	if ($email eq $original_email) {
		$email = "NOSPAM_$email_THIS_PART_ADDED_TO_STOP_SPAMBOTS";
	}

	return($email);
}#endsub SpamProtectEmailAddress {
################################################################################