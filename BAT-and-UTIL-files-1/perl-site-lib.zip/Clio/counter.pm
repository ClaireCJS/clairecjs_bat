my $USE_IGNORE_LIST=0;		#turn this to 0 for debug purposes			

##### It is assumed that all counter directories are subdirectories of the
##### $DEFAULT_DATA_DIR defined in &executecounter, which for me only is 
##### set to $COUNTER_DIR (defined in Clio::Consants) which is my base
##### counter dir.  There can be several subdirectories of various breeds
##### of counters.  This hash table is full of keys that should match
##### each of those subdirectories.  The values of those keys are hash 
##### references in and of themselves that contain the various options
##### for that particular directory:
my $DEFAULT_COUNTER_DIR	= $COUNTER_DIR . "/default";			#from Clio::Constants
my %STATDIR_REGEX_OPTIONLIST=(
	"photo-album-stats-single" => {
		treat_titles_as_attributes	=> 1,
		counterstatstitle			=> "Media Viewer Statistics<BR>(single attributes only)",
		linktitle				    => "Media Viewer Stats (single attributes)",
	},
	"photo-album-stats-combinations" => {
		treat_titles_as_attributes	=> 1,
		counterstatstitle			=> "Media Viewer Statistics<BR>(combinations only)",
		linktitle				    => "Media Viewer Stats (combination attributes)",
	},
	"default" => {
		counterstatstitle			=> "Clio's Usage Stats",
		linktitle				    => "Global Usage Stats",
	},
);
#NOTE: If new options are added, one may need to go to MARKER X1 and update them.

##### Set up URL aliases:
my %Aliases=	(	
				#OLD ACM ALIASES:
				"/~claire/index.htm",        "/~claire/index.html",
				"/~claire/voices/index.htm", "/~claire/voices/index.html",
				"/~claire/dl/index.html",    "/~claire/download/index.html",

				#NEW ALIASES ON PERSONAL WEBSERVER:
				"/Default.asp",			"/home/Default.asp",
				"/Album/viewdev.pl", 		"/Album/view.pl",
			);









##### used for the counter
use Clio::Constants;
use Clio::Syscall;
use Clio::String;
use Clio::File;
use Clio::TabledDataDumper;
use Clio::DataManipulation;
use File::CounterFile;				#let's try the new way

##### used for counterstats:
use Clio::Header;
use Clio::Footer;
use Clio::Parse_Data;
use Clio::Counter;
use Clio::MediaLibrary;
use Clio::Registry;
use CGI::Carp qw(fatalsToBrowser warningsToBrowser);

##### Variables imported/used locally/needed to be declared as strict:
#use strict;
use vars qw($COUNTER_DIR $COUNTER_STATS_URL $COUNTER_NAME_ONLY $retval @IP_ALL $verbose 
	%FORM $LOG_DIR $MAILTO $USERNAME $WWWDIR $BASECGIDIR $DEBUG $WWWMACHINENAME
	$MACHINEURL @DO_NOT_CHECK_FOR_EXISTENCE_OF_FILES_WITH_THESE_REGULAR_EXPRESSIONS_IN_NAME
	@valid_url @invalid_url $THIS_COUNTER $data_dir $lock_file
	$URL_TO_THIS_PROGRAM $counterdir
	);

##### Should our counter use the ignore IP list?? (usually a list of our own IPs so we don't increment our own counters...)
my $counter_extension="counter";
my $MAX_STAT_GATHER_TIME	= 2;		#TIME IN SECONDS, approximately, to refresh a counterstats page when it has to index the stats
my $MAX_COUNTER_INDEX_AGE 	= 2;		#TIME IN SECONDS, maximum, for our stat index. The stat index is updated everytime someone hits the page unless it is younger than these many seconds. For instance if your stat page was being hit constantly, setting this to 30 would make it only regneerate every 30 seconds instead of constantly.



#####		Here is how to make a counterstats page, using this package:
#####
#####     #!/usr/local/bin/perl
#####     #<META TITLE="Clio's Usage Stats">
#####     #^^^^ DO NOT REMOVE!  This is read by other scripts even though it is a Perl comment.
#####     use Clio::Counter
#####     &counterstats({title=>"Clio's Usage Stats"});

my $DARKEST	= "d4d4d4";
my $MID		= "DDDDDD";
my $LIGHTEST	= "F3F3F3";

1;






###################################################################
#USAGE: print &counter({forced_url=>"guestbook",
#				begintext=>"You are victim number",endtext=>" to enter these gates.",
#				usesuffix=>0,nolinks=>1}
#				#use suffix will put the "th" after 4 to make "4th"
#				#forced_url uses a specified "url" that might not actually be a URL
sub counter (;$) {
	my $criteria = $_[0];	#hashref
	my %options_to_pass = ();
	my $retval="";
	my $suffix="";
	my $debug = $criteria->{debug} || 0;		#0	#:0
	my $realcount;

	##### First get the count:
	#$debug=2;#
	#my $count = &remove_leading_and_trailing_spaces(&executecounter($criteria));
	my ($count,$realcount) = &executecounter($criteria);
	if ($count eq "") { return; }		#in case it died for some reason

	if ($debug >= 1) { print "<BR>count is [A] \"$count\", realcount is \"$realcount\"<BR>\n"; }
	
	##### Then, clean up the count:
	$count =~ s/Content-type: text\/html//;  
	if ($debug >= 1) { print "<BR>count/realcount is [B] \"$count\"<BR>\n"; }

	#OLD:
	#my $realcount = $count;
	#$realcount =~ s/\<a[^>]*\>//gi;  
	#if ($debug >= 1) { print "<BR>(real)count is [B2] \"$realcount\"<BR>\n"; }
	#$realcount =~ s/\%[0-9]+//g;
	if ($debug >= 1) { print "<BR>(real)count is [C] \"$realcount\"<BR>\n"; }
	
	##### Then wrap the count according to our criteria:
	my $begintext=$criteria->{begintext} || "You are visitor number ";
	my $endtext  =$criteria->{endtext}   || ".";
	if ($criteria->{usesuffix}) { $suffix = &digitsuffix($realcount); }
	if ($criteria->{nolinks}) { $count=$realcount; }
	
	##### Format our return value and return it:
	$retval .= "$begintext$count$suffix$endtext";
	if ($debug >= 2) { map { $retval .= "<BR>$_,$ENV{$_}" } keys %ENV; }
	return($retval);
}#endsub counter
###################################################################


########################################################################################################################
sub executecounter {
	my $options					= $_[0];						#|| 1 does not work!
	my $DEFAULT_DATA_DIR			= $DEFAULT_COUNTER_DIR;				#from top of file
	#DEBUG:print "\n\$DEFAULT_DATA_DIR is $DEFAULT_DATA_DIR<BR>\n";
	my $counterstatstitle			= $options->{counterstatstitle}		|| "";
	my $fake_urls				= $options->{fake_urls}				|| "";
	local $data_dir				= $options->{data_dir}				|| $DEFAULT_DATA_DIR;
	#my $Fil e N ame				= $options->{force d _ f i lename}		|| $COUNTER_NAME_ONLY;
	my $forced_url 				= $options->{forced_url}			|| "";
	my $increment				= $options->{increment};
	my $URLCOUNTERSHOULDLINKTO 		= $options->{linkto}				|| $COUNTER_STATS_URL;
	my $logurl					= $options->{logurl}				|| "";
	my $logtitle				= $options->{logtitle}				|| "";
	my $pad_size 				= $options->{pad_size}				|| "0";			#how many numbers to be shown in count (ie 5 = "00001")
	my $show_date 				= $options->{show_date}				|| "0";
	my $treat_titles_as_attributes	= $options->{treat_titles_as_attributes} 	|| 0;
	local $verbose				= $options->{verbose} 				|| 0;
	#my $counter				= "";
	local $retval				= "";
	my @IgnoreIP=();

	##### Process options:
	if ($increment eq "") { $increment=1; }		#can't say || "1" above because that would make it always 1 due to the way || works

	#$verbose=3; 	

	#MARKER X1
	my ($querystringbydir,$optionsbydir)=&GetDefaultQueryStringOptionsFromStatDirName($data_dir);
	#print &tabledump("query string by dir",$querystringbydir);
	#print &tabledump("options by dir",$optionsbydir);
	if (ref $optionsbydir) {
		if ($optionsbydir->{treat_titles_as_attributes}) { $treat_titles_as_attributes=1; }
		#if ($optionsbydir->{stat_dir}) { print "Stat dir!<BR>"; } else { print "Poop"; }
		if (($counterstatstitle eq "") && ($optionsbydir->{counterstatstitle})) { $counterstatstitle=$optionsbydir->{counterstatstitle}; }
	}

	##### Set up our query string for counterstats link:	
	if (($fake_urls) || ($counterstatstitle) || ($treat_titles_as_attributes)) {
		$URLCOUNTERSHOULDLINKTO .= "?";
		if ($data_dir ne $DEFAULT_DATA_DIR) 	{ $URLCOUNTERSHOULDLINKTO .= "?&stat_dir=$data_dir"; }
		if ($fake_urls) 					{ $URLCOUNTERSHOULDLINKTO .= "&fake_urls=1"; }
		if ($counterstatstitle) 			{ $URLCOUNTERSHOULDLINKTO .= "&title=" . &urlencode($counterstatstitle); }
		if ($treat_titles_as_attributes)		{ $URLCOUNTERSHOULDLINKTO .= "&treat_titles_as_attributes=1"; }
	}#endif

	##### Determine IP addresses to ignore:
	if ($USE_IGNORE_LIST) { @IgnoreIP = @IP_ALL; }

	##### DEBUG:
	if (($verbose) || (0)) { 	#
		print "\n\$increment is $increment<BR>";
		print "\n\$forced_url is $forced_url<BR>";
		print "\n\$fake_urls is $fake_urls<BR>";
		print "\n\$counterstatstitle is $counterstatstitle<BR>\n";
		print "\n\$data_dir is $data_dir<BR>\n";
		print "\n\$logurl is $logurl<BR>\n";
		##print "\n\$Fi l e N a me is $Fi l e N ame<BR>\n";
	}#endif






	# Valid-URI allows you to set up the counter to only work under specific 
	# directories on your server.  Include any of these directories as they 
	# appear in a URI, into this array.  More information on URI's available in 
	# README. 
	# Leave it empty to disable.
	
	#local @valid_url = ('/');
	local @valid_url = ();
	
	# Invalid-URI allows the owner of this script to set up the counter so 
	# that certain portions of the web server that may be included in Valid-URI 
	# cannot use the program.  Leave this commented out if you wish not to 
	# block out certain parts.
	
	#@invalid_url = ('.shtml/','.html/');
	local @invalid_url = ();
	
	
	##############################################################################
	# Set Options
	
	# Show Link allows you to add a link around the counter to point to 
	# either instructions explaining to users how to set this up on the system 
	# (useful if a system administrator wants to allow anyone to set things up 
	# themselves).  Setting it to 0 will make no link, otherwise put the URL
	# you want linked to the count here.
	
	#my $show_link = "http://www.scriptarchive.com/";
	my $show_link = $URLCOUNTERSHOULDLINKTO;
	
	# When Auto-Create is enabled, users will be able to auto-create the 
	# count on their home pages by simply imbedding the Server Side Includes 
	# call.  Setting auto_create to 1 enables it, 0 will disable it. Only 
	# users in @valid_url will be allowed to auto create.
	
	my $auto_create = "1";
	
	
	# Lock Seconds will define the number of seconds the script should sit 
	# and wait for the lock file to be gone before it will overwrite it if it 
	# is still there.  Every now and then a user will interrupt a page, causing 
	# the script to halt and leave a lock file in place before the lock file 
	# could be removed.  This defines how long it waits.
	
	my $LockTimeInSeconds = "3";
	
	
	##############################################################################
	
	# Print Content Type Header For Browser
	$retval .=  "Content-type: text/html\n\n";
	
	# Get the page location from the environment variable
	# (MS IIS=PATH_INFO, UNIX=DOCUMENT_URI)
	my $counter_page;
	if ($forced_url eq "") {
		$counter_page = "$ENV{'PATH_INFO'}";

		if ($counter_page eq "") {
			$counter_page = "$ENV{'DOCUMENT_URI'}";
		}
	} else {
		$counter_page = $forced_url;
	}#endif
	
	
	if ($logurl eq "") { $logurl = $counter_page; }
	#OH copy cleanup part . . . 
	
	if ($verbose) { 
		if ($verbose>5) { print &tabledump("environment",\%ENV); }
		print "<BR>\ncount_page is \"$counter_page\"...\n"; 
	}
	
	# Check Valid-URI to make sure user can use this program.
	&check_uri;
	
	# Chop off any trailing /'s
	if ($counter_page =~ /\/$/) { chop($counter_page); }
	
	# Any characters that are not letters or numbers are turned into an underscore
	$counter_page =~ s/[^\w]/_/g;
	local $lock_file = "$counter_page\.lock";
	
	# Check to see if file is locked by program already in use.
	&check_lock($LockTimeInSeconds);

	##### We will have to abort gracefully if the filename is simply too long:	
	if (length("$counter_page.$counter_extension")>255) { return(""); }

	local $THIS_COUNTER = "$data_dir/$counter_page.$counter_extension";

	if ($counter_page eq "") { print "<BR>WARNING: Will not create counter of null name... (this_counter=$THIS_COUNTER)"; return; }

	if ($verbose) { print "<BR>\n\$THIS_COUNTER = \"$THIS_COUNTER\""; }


	my ($date,$count)=("","");
	# If the file exists, get the date and count out of it.  Otherwise, if 
	# auto_create is allowed, create a new account.  If neither of these are 
	# true, return an error.
	my $line="";
	if (-e "$THIS_COUNTER") {
	   open(COUNT,"$THIS_COUNTER");
	   $line = <COUNT>;
	   chop($line) if $line =~ /\n$/;
	   close(COUNT);
	   ($date,$count) = split(/\|\|/,$line);
	}
	elsif ($auto_create == 1) { &create; }
	else { &error('url_does_not_exist');}

	if ($verbose>3) { print "\n[MADE IT TO X5]"; }

	##### Increment Count.
	if ($increment) { $count++; }
	my $print_count = $count;
	
	##### Get Count Length for use in padding.
	my $count_length = length($count);
	
	##### Pad the number if it is smaller than $pad_size.
	for (my $i = $pad_size;$i > $count_length;$i--) { $print_count = "0$print_count"; }
	
	##### Print the Count, Link and Date depending on what user has specified they wish to print.
	if ($show_date == 1) {
	   if ($show_link =~ /http:\/\//)	{ $retval .=  "<a href=\"$show_link\">$print_count</a> hits since $date"; }
	   else 						{ $retval .=  "$print_count hits since $date"; }
	} else {
	   if ($show_link =~ /http:\/\//)	{ $retval .=  "<a href=\"$show_link\">$print_count</a>"; }
	   else 						{ $retval .=  "$print_count"; }
	}
	my $retval2=$print_count;
	if ($verbose>3) { print "\n[MADE IT TO X15]"; }


	##### Open the count file and write the new count that has been incremented.
	if ($increment) {
		open(COUNT,">$THIS_COUNTER") || &error('inc_failed');
		print COUNT "$date\|\|$count";
		print COUNT "\nURL=$logurl";
		print COUNT "\nTITLE=$logtitle";
		close(COUNT);
	}#endif
	
	##### Remove Lock File for next time script is run on that HTML page.
	if ($verbose>3) { print "\n[MADE IT TO X20]"; }
	&clean_up;
	
	##### Return the value:
	print "<!-- counter returning retval2=$retval2 -->";
	return($retval,$retval2);
}#endsub ExecuteCounter
########################################################################################################################







##################################################################################################
sub check_uri {
	my $url_check = "0";
	my $url;
	if ($verbose>5) { print "<BR>\nCalling &Check_URI..."; }

	if (@valid_url > 0) {
		if ($verbose>5) { print "<BR>\nCycling through \@valid_url..."; }	
		foreach $url (@valid_url) {
			if ($ENV{'DOCUMENT_URI'} =~ /$url/) {
				$url_check = "1"; last;
			}#endif
		}#endforeach
	} else {
		$url_check="1";
	}#endif

	foreach $url (@invalid_url) {
		if ($ENV{'DOCUMENT_URI'} =~ /$url/) {
			$url_check = "0"; last;
		}#endif
	}#endforeach

	if ($url_check==0) { &error('uri_invalid'); }
}#endsub
##################################################################################################

####################################################################################
sub create {
   my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
   my @monthnames = ("January","February","March","April","May","June","July",
	      "August","September","October","November","December");
   $year += 1900;
   my $date = "$monthnames[$mon] $mday, $year";
   my $count = "0";
   open(COUNT,">$THIS_COUNTER") || &error('counter_file_creation_failed');
   print COUNT "$date\|\|$count";
   close(COUNT);
}#endsub create
####################################################################################

#############################################################################################
sub error {
   my $error = $_[0];
   if ($error eq 'url_does_not_exist') {
      print "[Counter Error 1: Page Not Found\; Auto-Create Disabled]";
   } elsif ($error eq 'uri_invalid') {
      print "[Counter Error 2: Page Not Valid URI]";
   } elsif ($error eq 'counter_file_creation_failed') {
      print "[Counter Error 3: couldn't write file $THIS_COUNTER]";
   } elsif ($error eq 'inc_failed') {
      print "[Counter Error 4: couldn't increment counter \"$THIS_COUNTER\"]";
   }
   ### Let's not exit out on error, since there may be more page below:
   #exit;
}
#############################################################################################

################################################################
sub check_lock {
   my $time = $_[0];
   my $i;
   for ($i=1; $i<=$time; $i++) {
      if (-e "$data_dir$lock_file") {
         sleep 1;
      } else {
         open(LOCK,">$data_dir$lock_file");
         print LOCK "0";
         close(LOCK);
         last;
      }#endif
   }#endfor
}#endsub
################################################################

############################################################
sub clean_up { unlink("$data_dir$lock_file"); }
############################################################



######################################################################################################################
sub IgnoreTheFactThatItDoesNotExist {
	my ($file) = $_[0];

	foreach my $regex (@DO_NOT_CHECK_FOR_EXISTENCE_OF_FILES_WITH_THESE_REGULAR_EXPRESSIONS_IN_NAME) {
		if ($DEBUG > 1) { print "Checking file $file for regex $regex<BR>\n"; }
		if ($file =~ /$regex/i) { return 1; }
	}#endforeach

	return 0;
}#endsub IgnoreTheFactThatItDoesNotExist 
######################################################################################################################

############################################################################################################
sub GetMetaTitleFromFile {
	#grab the file from the script
	#1) either the script has a <meta title> in a commented line already (script knows about us method)
	#2) if it has $META_TITLE (with 0 or more underscores) and = "something" it will extract the something out (doesn't know about us method)
	#		more methods can be added as needed

	my $file = $_[0];
	my $title;
	my $verbose=0;	#
	my $linenum=0;
	my $nonmetatitle = "";

	if ($verbose) { print "\nOpening file \"$file\"...<BR>"; }
	if (open(FILE,"$file")) {
		while (<FILE>) {
			$linenum++;
			chomp;
			if ($_ =~ /<META TITLE=/i) {
				if ($verbose) { "Found title in line: [[[[[$_]]]]]<br>"; }
				$title = $_;
				if ($verbose) { print "\n[2][$linenum]Title is now: [[[[[$title]]]]]<br>\t\t"; }
				$title =~ s/^.*<META TITLE=\"//i;
				if ($verbose) { print "\n[3]Title is now: [[[[[$title]]]]]<br>\t\t"; }
				$title =~ s/\".*$//;;
				if ($verbose) { print "\n[4]Title is now: [[[[[$title]]]]]<br>\t\t"; }
				last;
			} elsif ($_ =~ /\$META_*TITLE\s+\=/i) {
				if ($verbose) { "Found title in line: [[[[[$_]]]]]<br>"; }
				$title = $_;
				if ($verbose) { print "\n[2][$linenum]Title is now: [[[[[$title]]]]]<br>\t\t"; }
				$title =~ s/^.*META.*TITLE.*\"(.*)\".*$/$1/i;
				if ($verbose) { print "\n[3]Title is now: [[[[[$title]]]]]<br>\t\t"; }
				last;
			} elsif ($_ =~ /<title>(.*)<\/title>/i) {
				$nonmetatitle = $1;
			} else {
				$title="";
			}#endif
		}#enwhile
	}#endif
	close(FILE);

	##### If we got a nonmeta title instead of a meta title, return that instead:
	if (($title eq "") && ($nonmetatitle ne "")) { $title=$nonmetatitle; }

	##### Clean ASP crap out of it:
	if ($file =~ /.asp$/i) { $title =~ s/<\%.*\%>//g; }

	##### Clean my 'visitor #' stuff out:
	$title =~ s/\s?\-?\s?Visitor #//;

	return($title);
}#endsub GetMetaTitleFromFile 
############################################################################################################

######################################################################################################################
sub counterstats {
	my $options = $_[0];
	my $verbose 				= $options->{verbose} 				|| 0;#
	my $USAGE_STATS_TITLE 			= $options->{title} 				|| "Usage Statistics";
	my $treat_titles_as_attributes	= $options->{treat_titles_as_attributes} 	|| 0;
	my $use_asp_counter			= $options->{use_asp_counter}			|| "";
	my $USE_ASP_COUNTER_DEFAULT		= 1;
	my $ASP_counter_file			= $options->{asp_counter_file}		|| "";
	my $MultiValueFormDelimiter		= $MULTI_VALUE_FORM_DELIMITER;
	my $count_hits_to_counterstats	= 1;
	my $forced_stat_dir			= 0;
	my $counterindex				= "";
	my $TITLEWORD				= "TITLE";
	local $counterdir				= $DEFAULT_COUNTER_DIR;
	local @DO_NOT_CHECK_FOR_EXISTENCE_OF_FILES_WITH_THESE_REGULAR_EXPRESSIONS_IN_NAME=();
	my $file;

	##### PARSE FORM DATA, PRINT HEADER:
	&Parse_Data;
	&Print_Header;								#moved from A1 below

	##### GET OPTIONS:
	my $sorttype = $FORM{sort}    || "count";
	my $reverse  = $FORM{reverse} || 0;
	if ($FORM{title}) { $USAGE_STATS_TITLE=$FORM{title}; }
	if ($FORM{treat_titles_as_attributes}) { $treat_titles_as_attributes=$FORM{treat_titles_as_attributes}; }


	##### GET OPTIONS: Determine stat dir
	if ($FORM{stat_dir} ne "") { $forced_stat_dir=1; $counterdir=$FORM{stat_dir}; }
	# If the stat dir is the same as the default one, it's not really forced:
	if ($counterdir =~ /^$DEFAULT_COUNTER_DIR$/i) { $forced_stat_dir=0; }

	##### We need to find the ASP counter file, if any, but not if we are using a forced stat dir:
	if ($forced_stat_dir != 1) {
		if ($use_asp_counter eq "") { $use_asp_counter = $USE_ASP_COUNTER_DEFAULT; }
		if ((($ASP_counter_file eq "") || (!-e $ASP_counter_file)) && ($use_asp_counter)) {
			my $s = &GetValueFromRegistryByFullKeyName("HKEY_CLASSES_ROOT\\MSWC.PageCounter\\File_Location");
			if (-e $s) 	{ $ASP_counter_file = $s; }
			else			{ $use_asp_counter=0; }
		}
	}#endif
	#DEBUG: if ($verbose) { print "use_asp_counter = $use_asp_counter, asp_counter_file=$ASP_counter_file<BR>"; }

	##### RESPOND TO OPTIONS:
	$counterindex="$counterdir/counter-index.dat";
	if ($treat_titles_as_attributes) { $TITLEWORD="ATTRIBUTE"; }


	##### BEGIN EXECUTION:
	#A1
	local $URL_TO_THIS_PROGRAM = $ENV{PATH_INFO};

	print qq[<HEAD>];
	print qq[<TITLE>$USAGE_STATS_TITLE</TITLE>];
	print qq[</HEAD>];
	print qq[<BODY>];
	print "\n\n<!--\n\ncounterindex=$counterindex\ncounterdir=$counterdir\nusage_stats_title=$USAGE_STATS_TITLE\n\n\n-->\n";
			
	##### IRONY FIRST: DISPLAY COUNTER TO THE COUNTERSTATS PAGE.
	my $accessreport="";
	$accessreport=&counter({begintext => "You are the ",
				treat_titles_as_attributes=>$treat_titles_as_attributes,
			   	usesuffix => 1,
			   	nolinks   => 1,
			   	endtext   => " person to use this stat counter."});	

	##### See if we need to regenerate the counter index:
	if (!-e $counterindex) {
		print "\n<!-- Will regenerate counter index. REASON: !-e $counterindex -->\n";
		&generate_counter_index($counterdir,$counterindex);
	} else {
		my $age = time - &GetFileInfo($counterindex,"mtime");
		print "\n<!-- Will regenerate counter index. REASON: Age of $counterindex is $age seconds, more than max age of $MAX_COUNTER_INDEX_AGE seconds -->\n";
		if ($age > $MAX_COUNTER_INDEX_AGE) { &generate_counter_index($counterdir,$counterindex); }
	}

	#### Open the counter index and read it in:	
	my @RAWDATA=();
	open(FILE,"$counterindex") || die("[1] couldn't open counter log index of $counterindex, please alert $MAILTO!\n");
	while (<FILE>) {  chomp; next if /^\#/; push(@RAWDATA,$_);	 }
	close(FILE);

	#### Get the ASP data as well if necessary:
	my $ASP_FLAG = "___ASP___COUNTER___ASP___";
	if ($use_asp_counter) {
		open(FILE,"$ASP_counter_file") || die("[2] couldn't open ASP counter log index of $ASP_Counter_file, please alert $MAILTO!\n");
		while(<FILE>) { chomp; push(@RAWDATA,$ASP_FLAG . $_); 	}
		close(FILE);
	}#endif

	print qq[\n<!-- done reading $counterindex -->\n];

	#### Convert the data to a hashtable:
	my %DATA=();
	my $totalcount=0;
	my $tmpalias="";
	my ($count,$url,$title)=("","","");
	my ($tmpcount,$tmpurl,$tmptitle)=("","","");
	foreach my $datum (@RAWDATA) {
		#DEBUG: print "Datum=[[[$datum]]]<BR>";#

		##### Split the data off... It may be in 2 different formats, ours, or ASP standard:
		if ($datum =~ /^$ASP_FLAG/) {
			$datum =~ s/^$ASP_FLAG//;
			($count,$url) = split(/\t/,$datum);
			$title="";
		} else {
			($count,$url,$title)=split($MultiValueFormDelimiter,$datum);
		}

		##### Check if the current URL is an alias:
		foreach $tmpalias (keys %Aliases) {
			#DEBUG: print "Checking if url=$url is an alias of $tmpalias...<BR>";#
			if ($url eq $tmpalias) {
				#DEBUG:print "<B>URL $url is an alias of $Aliases{$tmpalias} ... changing URL to $Aliases{$tmpalias}</B><BR>";#
				$url = $Aliases{$tmpalias};
			}
		}

		##### Determine if the file exists:
		$file=$url;
		if ($verbose) { print "Will check to see if file exists: file=\"$file\"<BR>"; }	
		#UNIX DAYS: $file =~ s/~$USERNAME/$WWWDIR/;
		#UNIX DAYS: $file =~ s/^.*\/pub-cgi-bin\/$USERNAME/$BASECGIDIR/;
		if (!-e $file) { $file = &remap_virtual_directory($file,{inverse=>0,verbose=>($verbose)}); }
		if ($title eq "") { $title=&GetMetaTitleFromFile($file); }

		##### Store the data now that we have it gathered:
		$totalcount+=$count;

		##### If it's an alias we need to adjust the value:
		if ($DATA{$url} ne "") {
			#DEBUG:	print "key $url already exists!<BR>";	#
			($tmpcount,$tmpurl,$tmptitle)=split(/$MultiValueFormDelimiter/,"$DATA{$url}");
			$count += $tmpcount;
		}#endif
		$DATA{$url}="$count$MultiValueFormDelimiter$title$MultiValueFormDelimiter$file";

		#DEBUG:print "\$DATA{$url}=$count$MultiValueFormDelimiter$title$MultiValueFormDelimiter$file<BR>";#OH

	}#endforeach

	
	#### Sort the hash table:
	my @sorted_keys=();
	my ($atmp,$btmp,$junk);
	print "\n<!-- sort type is $sorttype -->\n";
	if ($sorttype eq "url") {
		@sorted_keys = reverse sort { $a cmp $b } (keys %DATA);
	} elsif ($sorttype eq "title") {
		@sorted_keys = sort { 
			($junk,$atmp) = split($MultiValueFormDelimiter,$DATA{$a});
			($junk,$btmp) = split($MultiValueFormDelimiter,$DATA{$b});
			$atmp cmp $btmp;
			#DEBUG: print "$atmp cmp $btmp<BR>"; #
		} (keys %DATA);
	} elsif (($sorttype eq "count") || ($sorttype eq "") || 1) {
		@sorted_keys = reverse sort { 
			($atmp,$junk) = split($MultiValueFormDelimiter,$DATA{$a});
			($btmp,$junk) = split($MultiValueFormDelimiter,$DATA{$b});
			#DEBUG: print "$atmp <=> $btmp<BR>"; #
			$atmp <=> $btmp;
		} (keys %DATA);
	}#endif
	print "\n<!-- reverse is $reverse -->\n";
	my $reversent=1;
	if ($reverse) {$reversent=0;}
	if ($reverse) { @sorted_keys=reverse @sorted_keys; }
	
	
	print "<h1 align=center>$USAGE_STATS_TITLE</h1>\n";	
	print "<B>$accessreport</B>";
	print "<font size=2>";
	#print "(Yes, I decided to keep stats on how often stats are checked.)";
	if (!$forced_stat_dir) {
		print "<br>(The URL to these stats shows up in the list.)";
	}#endif
	print "</font>";
	print "<h2 align=center>Total hits: ".&commaize($totalcount)."</h2>\n";
	

	if (@sorted_keys==0) { print "ERROR: No stats to count!"; }
	
	my @colwidth=("","55\%","30\%","15\%");
	my $FONTB="<font size=5><B>";
	my $FONTE="</b></font>";
	print qq[
	<table border=0 cellspacing=0 cellpadding=2 align=center width=100\%>
	<tr valign=middle bgcolor=$DARKEST>
	<td align=center width=$colwidth[1]>$FONTB<a href="$URL_TO_THIS_PROGRAM?title=$USAGE_STATS_TITLE&reverse=$reversent&treat_titles_as_attributes=$treat_titles_as_attributes&stat_dir=$FORM{stat_dir}&sort=title">$TITLEWORD</a>$FONTE</td>
	<td align=center width=$colwidth[2]>$FONTB<a href="$URL_TO_THIS_PROGRAM?title=$USAGE_STATS_TITLE&reverse=$reversent&treat_titles_as_attributes=$treat_titles_as_attributes&stat_dir=$FORM{stat_dir}&sort=url">URL</a>$FONTE</td>
	<td align=right  width=$colwidth[3]>$FONTB<a href="$URL_TO_THIS_PROGRAM?title=$USAGE_STATS_TITLE&reverse=$reversent&treat_titles_as_attributes=$treat_titles_as_attributes&stat_dir=$FORM{stat_dir}&sort=count">Hits</a>$FONTE</td>
	</tr>
	];
	
	
	my $url="";
	my $name="";
	my $pair="";
	my @pairs=();
	my $value="";
	my $title="";
	my $buffer="";
	my $linkit="";
	my %TMPFORM=();
	my $tmpfile="";
	my $url4print="";
	my $tmp_query_info="";
	my $count;
	my $file;
	my $j=0;
	foreach my $url (@sorted_keys) {
		#DEBUG: print "key=$url<BR>";
		next if ($url eq "");	
		if (($verbose) || ($DEBUG > 1)) { print "Processing url: $url<BR>\n"; }
	
		$title="";	
		($count,$title,$file) = split($MultiValueFormDelimiter,$DATA{$url});
	
		##### Determine if it actually exists (this code block shouldn't really happen anymore,
		##### because most of it was copied above and this has already happened):
		$linkit=1;
		if (!-e $file) {
			$file=$url;
			if ($verbose) { print "Will check to see if file exists: file=\"$file\"<BR>"; }	
			$file =~ s/~$USERNAME/$WWWDIR/;
			$file =~ s/^.*\/pub-cgi-bin\/$USERNAME/$BASECGIDIR/;
			#print "tmp_query_info[1] is \"$tmp_query_info\" .. file is $file<BR>\n";#
			if ($verbose) { print "Does exist[1]? file=\"$file\"<BR>"; }
			if (!-e $file) { $file = &remap_virtual_directory($file,{inverse=>0,verbose=>($verbose)}); }
			if ($verbose) { print "Does exist[2]? file=\"$file\"<BR>"; }
		}#endif 

		if ($file =~ /\?/) {
			$tmp_query_info = $file;
			$tmp_query_info =~ s/^([^\?]*)\?(.*)$/$2/;	#query info
			$file =~ s/\?(.*)$//;	#query info - remove it
		}
		#DEBUG: print "tmp_query_info[2] is \"$tmp_query_info\" .. file is $file<BR>\n";#
		#$title .= " <nobr>[]</nobr>";
	
		if ((!-e $file) && (&IgnoreTheFactThatItDoesNotExist($file))==0) { 
			if (($verbose) || ($DEBUG > 1)) { print "^-- Can't find above file! Does it exist?<BR>\n"; }
			$linkit=0; 
			if ($title eq "") { $title="<B>(dead)</b>"; }
			if ($file !~ /\.html?$/) { next; }
		} else {	
			if ($tmp_query_info ne "") {		#used to be the 1st part of 'if'
				#DEBUG:print "tmpqueryinfo is $tmp_query_info<BR>";#
				%TMPFORM=();	
				$buffer=$tmp_query_info;
				@pairs = split(/&/, $buffer);
				foreach $pair (@pairs) {
					($name, $value) = split(/=/, $pair);
					$value =~ tr/+/ /;	
					$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
					if ($TMPFORM{$name} eq "") { $TMPFORM{$name} = $value; } 
					else { $TMPFORM{$name} = $TMPFORM{$name} . $MultiValueFormDelimiter . $value; }
					#DEBUG: print "setting \$TMPFORM{$name} to $TMPFORM{$name} .. MultiValueFormDelimiter=$MultiValueFormDelimiter<BR>\n";#
				}#endforeach pair
				if ($treat_titles_as_attributes) {
					$title = &niceattrib($TMPFORM{attrib},{logic=>""}); 
				}#endif
				#DEBUG: print "<B>title is $title</B> ... tmpform{attrib} is $TMPFORM{attrib} ... tmp_query_info is \"$tmp_query_info\" .. file is $file<BR><BR>\n";##
	
			} elsif ($file =~ /\.html?$/i) {		##### Get title:

				if (open(FILE,"$file")) {
					my $second2lastlinetmp;
					my $lastlinetmp;
					my $islast=0;
					while (<FILE>) {
						if ($_ =~ /<\/TITLE>/i) {
							#DEBUG: print "Found title in line $_<br>";
							$title = $_;
							$title =~ s/^(.*)<TITLE>(.*)<\/TITLE>(.*)$/$2/ig;
							$title =~ s/<TITLE>//ig;
							$title =~ s/<\/TITLE>//ig;
							
							$islast=1;
						}#endif
						$second2lastlinetmp = $lastlinetmp;
						$lastlinetmp = $_;
						if ($islast) { last; }
					}#endif
					close(FILE);
					if ($title eq "") { $title="<B>N/A</B>"; }
				} else {
					$title="&nbsp;";
				}#endif
			} elsif ($file =~ /\.pl$/i) {
				$title = &GetMetaTitleFromFile($file);
				if ($title eq "") { $title="<B>(perl script)</b>"; }
			} elsif ($file =~ /\.asp$/i) {
				$title = &GetMetaTitleFromFile($file);
				if ($title eq "") { $title="<B>(Active Server Page)</b>"; }
			} elsif ($file =~ /\.cgi$/i) {
				$title="<B>(cgi script)</b>";
			} else {
					$title="<B>N/A</B>";
			}#endif
		}#endif
		
		##### KLUDGE:
		if ($title =~ /<nobr>\[\]<\/nobr>/i) { $title="<B>N/A</B>"; }
	
		##### Prepare URL for printing:
		$url =~ s/$WWWMACHINENAME\///;
		$url4print = $url;
		$url4print =~ s/^~$USERNAME\///;
		$url4print =~ s/pub-cgi-bin\/$USERNAME\///;
		##$url4print =~ s/pub-cgi-bin\/$USERNAME\///;
	
		##### Draw the row with the link, linking it if ($linkit)
		print "<tr valign=middle bgcolor=\"\#". (($j++%2)?$LIGHTEST:$MID) ."\">\n";
	
		##### Column 1: Print title:
		print qq[<td align=center><font face="arial, helvetica, sans-serif" size=2>$title</font></td>];
	
		##### Column 2: Print URL:
		print "<td align=center>";
		if ($url =~ /(^[\\\/])/) { $url =~ s/$1//; }
		if ($url =~ /counterstats\.pl/) { print "<font size=4>"; }
		if ($linkit) {
			print "<a target=\"_backfromcounterstats\" ";
			print "href=\"$MACHINEURL" . "/" . "$url\">";
		} else {
			print "<font size=2><B>";
		}#endif
		if ($url4print =~ /\?(.*)/) { $url4print =~ s/\?.*$//; }
		print "$url4print";

		if ($linkit) { 
			print "</a>"; 
		} else { 
			#OHOHOH: if (!$fake_urls) { print " (dead)"; }
			print "</B></font>"; 
		}#endif

		#DEBUG: print "<BR>file=$file";#
		if ($url =~ /counterstats\.pl/) { print "</font> <font color=ff0000><nobr><B>(This Page!)</B></nobr></font>"; }
		print "</td>";
	
		##### Print count:
		print "<td align=right><B>";
		print &commaize($count) || "0";
		print "</B></td>";
		print "</tr>";
	}#endforeach
	
	print qq[</table><BR><BR>];

	&LinkToOtherCountersIfAny;
	
	&footer({nocounter=>1,table=>1});
}#endsub counterstats
######################################################################################################################


####################################################################################################
sub generate_counter_index {
	my ($counterdir)	= $_[0];
	my ($counterindex) = $_[1];
	my ($lockfile) 	= $counterindex . ".lock";
	my ($tmpline)		= "";
	my ($tmpkey)		= "";
	my ($tmphash)		= ();
	my $DELIMITER		= $MULTI_VALUE_FORM_DELIMITER;		#from Clio::Constants


	my $verbose = 0;		

	if ($verbose) { print "<BR><B>Generating counter index...<!-- index=of $counterindex ... dir=$counterdir -->...</B><P>"; }

	if (!-d $counterdir) { die("counterdir of $counterdir does not exist!!!!!!!!!!"); }

	##### Generate lockfile, which we will hold while gathering data so that there are not
	##### multiple processes running all gathering the same data:
	if (-e $lockfile) { 
		my $lockfileageinseconds = time - &GetFileInfo($lockfile,"mtime");
		my $threshold = $MAX_STAT_GATHER_TIME*2;			#*10 would be better.
		if ($lockfileageinseconds > $threshold) {
			print "WARNING: Ignoring old lockfile. It is $lockfileageinseconds seconds old, which is more than the threshold of $threshold seconds. Regenerating stats despite presence of lockfile.<BR>";
		} else {
			print "<P><h2>counter statistics are currently being generated. please hit reload in a few seconds ($MAX_STAT_GATHER_TIME seconds at most if things are running smoothly; at least $threshold seconds if things just broke) (lockfile is $lockfileageinseconds seconds old).</h2>"; 
			print "\n<!-- lockfileageinseconds = $lockfileageinseconds ... threshold=$threshold -->\n";
			exit;
		}
	}
	open(LOCK,">$lockfile");
	print LOCK "Locked!\n";
	close(LOCK);

	##### Gather data for statistics:
	my %INDEX_DATA=();
	my ($junk,$count,$url,$title)=("","","","");
	my @COUNTERS = &ReturnListOfFilesInDirectoryAsArray($counterdir);
	foreach my $counterfile (@COUNTERS) {
		($junk,$count,$url,$title)=("","","","");
		if ($counterfile !~ /\.$counter_extension$/) { next; }
		if (!open(COUNTER,"$counterfile")) {
			carp "Could not open counter file $counterfile!!!!!!!!<BR>";
			next;
		}#endif
		while ($tmpline=<COUNTER>) {
			chomp $tmpline;
			if ($tmpline =~ /\|\|/)	{ 
				($junk,$count)	= split(/\|\|/,"$tmpline"); 
			}
			if ($tmpline =~ /URL=/) { 
				$url =  $tmpline;
				$url =~ s/^URL=//;
			}
			if ($tmpline =~ /TITLE=/) { 
				$title =  $tmpline;
				$title =~ s/^TITLE=//;
			}
		}
		close(COUNTER);
		if ($url eq "") { $url = $counterfile; $url =~ s/\.$counter_extension//; }
		$tmpkey=$counterfile;
		$INDEX_DATA{$tmpkey}=join($DELIMITER,$count,$url,$title);
		if ($verbose) { print &tabledump("tmpkey=$tmpkey,value=count:url:title",$INDEX_DATA{$tmpkey}); }
	}#endforeach

	##### Generate counter index:
	open(INDEX,">$counterindex");
	print INDEX "\#" . join($DELIMITER,"count","url","title") . "\n";
	foreach $tmpkey (sort keys %INDEX_DATA) {
		($count,$url,$title)=split($DELIMITER,$INDEX_DATA{$tmpkey});
		print INDEX "$count$DELIMITER$url$DELIMITER$title\n";
	}
	close(INDEX);

	##### Remove lockfile:
	unlink $lockfile;
	if (-e $lockfile) { print "WARNING: Could not unlink $lockfile!!!!!!!!!!!!! This is nonfatal but will mess things up in the future probably . . ."; }
	
}#endsub generate_counter_index
####################################################################################################


#######################################################################################################
sub LinkToOtherCountersIfAny {	
	#ASSUMES global $URL_TO_THIS_PROGRAM
	#ASSUMES local $counterdir

	my $url="";
	my $linktitle="";
	my $querystring="";
	my $options;

	my @dirs=&GetSubdirsInDir($COUNTER_DIR);
	my $first=1;
	foreach my $dir (@dirs) {
		if ($dir eq $counterdir) { next; }
		($querystring,$options)=&GetDefaultQueryStringOptionsFromStatDirName($dir);
		$url="$URL_TO_THIS_PROGRAM?stat_dir=$dir$querystring";
		$linktitle = $dir;
		if ($options->{linktitle}) { $linktitle=$options->{linktitle}; }
		if ($first) {
			$first=0;
			print qq[<table border=0 cellspacing=0 cellpadding=0 align=center><tr valign=top><td align=center>];
			print qq[<font face="arial, helvetica, sans-serif"><B>Other statistics available:</B><BR>];
		}
		print qq[<a href="$url">$linktitle</a><BR>];
	}
	print qq[</td></tr></table></font><BR>\n];

}#endsub LinkToOtherCountersIfAny 
#######################################################################################################

##########################################################################################
sub GetDefaultQueryStringOptionsFromStatDirName {
	my $dir 		= $_[0];
	my $options	= &GetDefaultOptionsFromStatDirName($dir);
	my $retval	= "";

	#DEBUG: print &tabledump("options",$options);#

	if (not ref $options) { return ""; }

	if ($options->{treat_titles_as_attributes}) { 
		$retval .= "&treat_titles_as_attributes=1"; 
	}
	if ($options->{counterstatstitle}) { 
		$retval .= "&title=" . &urlencode($options->{counterstatstitle}); 
	}

	return($retval,$options);		#let's also return the $options hashref just in case
}#endsub GetDefaultQueryStringOptionsFromStatDirName
##########################################################################################


###############################################################################################
sub GetDefaultOptionsFromStatDirName {
	my $dir	 	= $_[0];
	my $options;
	#ASSUMES %STATDIR_REGEX_OPTIONLIST is defined (see top of file)

	#DEBUG: print &tabledump("master options",\%STATDIR_REGEX_OPTIONLIST);

	foreach my $regex (keys %STATDIR_REGEX_OPTIONLIST) {
		if ($dir =~ /$regex/i) { 
			$options=$STATDIR_REGEX_OPTIONLIST{$regex}; next;
		}#endif
	}#endforeach

	#DEBUG: print &tabledump("options for dir of $dir",$options);

	return $options;
}#endsub GetDefaultOptionsFromStatDirName
###############################################################################################
