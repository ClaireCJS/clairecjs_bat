### EXPORT ATTEMPT -- didn't seem to work...remove this if photoalbum breaks etc
#require Exporter;
#@ISA = qw(Exporter);
#@EXPORT = qw(DoQuery EstablishDatabaseConnection);
###

use DBI;
use Clio::Constants;
use Clio::TabledDataDumper;
use Clio::HTML;
use strict;
use vars qw(	$database_server 		$database_name 
			$database_username 	$database_password
			$database_system_DSN 	$database_connect_string
			@ISA @EXPORT
		);


$database_server			= "FIRE";
$database_name			= "FireWWW";
$database_username		= "sa";
$database_password		= "Foofoog0";
$database_system_DSN		= "www";
$database_connect_string	= "dbi:ODBC:" . $database_system_DSN;




########################################################################################
BEGIN {
	my $static_dbh = "";

	sub DoQuery {
		my $options		= $_[0];
		my @results		= ();
		my @rowarray	= ();
		my $rowhashref	= {};
		my $create_own_dbh= 0;
		my $dbhlocal	= "";
		my $optiondbh	= "";
		my $sql		= "";
		my $verbose		= "";

		#USAGE:	my $sql = "select * from $DATABASE_TABLE_GAME_TYPES order by name";
		#USAGE:	my @rs=&DoQuery({sql=>$sql,dbh=>$dbh,verbose=>0});
		#USAGE:	print &tabledump("my results",\@rs);



		#### Get options -- if they did not pass a hash, let's assume they just passed a query:
		if ((ref $options) =~ /HASH/i) {
			$optiondbh	= $options->{dbh};
			$sql		= $options->{sql};
			$verbose	= $options->{verbose};
		} else {
			$sql = $options;
		}

#$verbose=1;#



		#DEBUG: print "<nobr>verbose is $verbose...ref \$options is \"".(ref $options)."\"...sql is $sql</nobr><BR>";
	
		#### If they did not pass a dbh, let's see if one happens to be defined in our namespace:
		#DOES NOT WORK, UNFORTUNATELY, IF $DBH IS NOT DEFINED: if (($optiondbh eq "") && (defined $dbh)) { $optoindbh=$dbh; }

		#### Otherwise, let's make our own dbh and pool it for later:
		if ($verbose>1) { print "<BR>optiondbh is: " . &tabledump("\$optiondbh",$optiondbh); }
		if ($optiondbh eq "") { 
			if ($verbose>1) { print "<BR>optiondbh is null/invalid\n"; }
			$create_own_dbh=1; 
			if ($static_dbh eq "") { 
				if ($verbose>1) { print "<BR>getting database connection myself\n"; }			
				$static_dbh=&EstablishDatabaseConnection({}); 
			}
			$dbhlocal = $static_dbh;
		} else {
			$dbhlocal = $optiondbh;
		}
	
		#### And if it all failed, let them know the error:
		if ($verbose>1) { print "<BR>dbh is now:\n" . &tabledump("dbh",$dbhlocal); }
		if ($dbhlocal eq "") { print "<BR>Fatal Error: Could not establish database connectivity in &DoQuery!\n"; return; }
		
		eval {				#optional but safer
			my $sth = $dbhlocal->prepare($sql) || die($DBI::errstr . " with " . $sql); 

			if ($verbose>1) { print "<BR>\$sth is prepared and is now: " . &tabledump("\$sth",$sth); }
			#also acceptible: $dbhlocal->do($sql) for creating tables and such...

			$sth->execute() || die($DBI::errstr . " with " . $sql);

			if ($verbose) { print "\nSQL = <B>$sql</B><BR>\n"; }

		     while($rowhashref = $sth->fetchrow_hashref)
		     #while(@rowarray = $sth->fetchrow) 
			{
				if ($verbose>1) { print "<BR>rowhashref is $rowhashref\n"; }
				push(@results,$rowhashref);
				#push(@results,@rowarray);
			}#endwhile

			$sth->finish() || die("couldn't finish \$sth: $DBI::errstr");
		};

		return @results;
	}#endsub DoQuery
}#end static variable block for DoQuery
########################################################################################


###############################################################################################
BEGIN {			#establisdatabaseconnection

	my $STATIC_DB_CONNECTION_ESTABLISHED=0;		#is set to the DBH later

	sub EstablishDatabaseConnection {
		#USAGE: $dbh = &establish_database_connection({});	
		if ($STATIC_DB_CONNECTION_ESTABLISHED==1) { 
			print "\n<!-- Static db connection established already! -->\n";
			return $STATIC_DB_CONNECTION_ESTABLISHED;
		}
		
		my $options = $_[0];
		my $verbose = $options->{verbose} || 0;
		my $dbh="";
		my @driver_names=();
		my @data_sources=();

		if ($verbose) {
			@driver_names = DBI->available_drivers;
			print &tabledump("driver_names",\@driver_names);			
			foreach my $drivername (@driver_names) {
				@data_sources = DBI->data_sources($drivername);#, \%attr);
				print &tabledump("data sources for driver $drivername",\@data_sources);
			}
		}
		
		$dbh = DBI->connect($database_connect_string,$database_username,$database_password) || die("could not connect: $DBI::errstr");

		if ($dbh ne "") { $STATIC_DB_CONNECTION_ESTABLISHED=$dbh; }
		else { print "<BR><BR>\n\nERROR: Could not establish connection to database!<BR>\n\n"; }

		if ($verbose) { print "<BR>\nDB connection established. dbh is now: " . &tabledump("\$dbh",$dbh); }

		return($dbh);
	}#endsub establish_database_connection 
}#end static variable block for establish_database_connection
###############################################################################################

################################################################################################
sub SQLScrub {
	my $value		= $_[0];
	my $options	= $_[1];
	my $strict	= "";
	#This takes all ' in a value and turns them into '' ... beacause SQL requires this.
	#If $strict==TRUE, then it also considers this to be DANGEROUS USER INPUT and scrubs
	#it for things like HTML tags, etc.
	#	STRICT VALUES:
	#	0 - just change ' to ''
	#	1 - remove HTML tags

	##### Figure out our strict value (set to default if none given):
	if ($options ne "") {
		$strict = $options->{strict};
	}#endif
	#DEBUG: print "Strict is $strict [b]<BR>";
	if ($strict eq "") { $strict=1; }
	#DEBUG: print "Strict is $strict [c]<BR>";

	##### Doublequote apostrophes since they are a special SQL character:
	$value =~ s/'/''/g;
	
	##### Remove HTML if strict is set (using Clio::HTML package):
	if ($strict) { $value = &strip_HTML($value); }

	##### Return the scrubbed value:
	return($value);
}#endsub SQLScrub
################################################################################################



1;
