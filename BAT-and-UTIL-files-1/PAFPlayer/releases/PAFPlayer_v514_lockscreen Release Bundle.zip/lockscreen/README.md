# PAFPlayer Lock Screen V514

Self-contained Windows 10 MSIX with a read-only desktop publisher, COM background
refresh registration and actual activation checks. Visible lock-screen status
remains unresolved; publication is not visual proof.

See the [guide and verification procedure](../docs/windows-lock-screen.md).
Use `python -B -X utf8 lockscreen_installer.py --check` for read-only validation;
omit `--check` to install and verify. The package in `dist/v514` contains the EXE;
an external runtime directory is no longer required. Select the versioned V514
entry in both Windows lock-screen status slots.

Build using `build_desktop.ps1` (optional `-SigningThumbprint` signs after verified
backups). Full MSIX validation is enabled. Run `run_regression_checks.py` and
`test_desktop.ps1`. Earlier UWP and sparse-package candidates are retained for
diagnosis. Never overwrite immutable releases or distribute a private key.
