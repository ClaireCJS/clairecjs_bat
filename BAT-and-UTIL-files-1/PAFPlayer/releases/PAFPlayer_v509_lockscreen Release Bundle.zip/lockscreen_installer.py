"""Install the PAFPlayer Windows 10 lock-screen status companion.

Run from the interactive Windows account that should see the lock-screen status.
Only certificate trust is elevated; AppX registration stays in that account.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile


PACKAGE_NAME = "ClaireCJS.PAFPlayer.LockScreen"
PACKAGE_VERSION = "509.0.0.0"
CERT_THUMBPRINT = "08AC642F1C17B503BC857189AE8C78E76B3358EC"
PACKAGE_FILE = "PAFPlayerLockScreen_v509_x64.msix"
CERT_FILE = "PAFPlayerLockScreen_v505.cer"
DEPENDENCIES = (
    "Microsoft.NET.Native.Framework.2.2.appx",
    "Microsoft.NET.Native.Runtime.2.2.appx",
    "Microsoft.VCLibs.x64.14.00.appx",
)
EXPECTED_SHA256 = {
    PACKAGE_FILE: "0a9b279372457c1c29c4d155e17c78bbd1924d4d0c7826191bec7b732e4b1b69",
    CERT_FILE: "ada1449f903cdd9eba33578400d81ad612374da12fcf300b059d3e39c1ed1fc2",
    DEPENDENCIES[0]: "c195047f4af9c3ff3d92c40e55a901cf7cfa08a679b8ca2543bb104bab2f7ff1",
    DEPENDENCIES[1]: "27fae660d8c609e020703bb463b6601e62811dc75db19975bcb7d68d959b527d",
    DEPENDENCIES[2]: "9c17b521f9d690a1f504da5108ed6eec5669eb3a8fd1331eef43e40d84e74283",
}
FOUNDATION = "http://schemas.microsoft.com/appx/manifest/foundation/windows10"
UAP = "http://schemas.microsoft.com/appx/manifest/uap/windows10"


class InstallerError(RuntimeError):
    pass


def artifacts(root: Path) -> tuple[Path, Path, tuple[Path, ...]]:
    dist = root / "dist"
    portable_deps = dist / "dependencies" / "x64"
    project_deps = (root / "AppPackages" /
                    "PAFPlayerLockScreen_509.0.0.0_x64_Test" /
                    "Dependencies" / "x64")
    dep_dir = portable_deps if portable_deps.is_dir() else project_deps
    return dist / PACKAGE_FILE, dist / CERT_FILE, tuple(dep_dir / name for name in DEPENDENCIES)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_artifacts(package: Path, certificate: Path, dependencies: tuple[Path, ...]) -> None:
    for path in (package, certificate, *dependencies):
        if not path.is_file():
            raise InstallerError(f"Missing installation file: {path}")
        expected = EXPECTED_SHA256.get(path.name)
        if not expected or sha256(path) != expected:
            raise InstallerError(f"File differs from the verified V509 Release build: {path}")
    try:
        with zipfile.ZipFile(package) as archive:
            manifest = ET.fromstring(archive.read("AppxManifest.xml"))
            if "PAFPlayerLockScreen.dll" not in archive.namelist():
                raise InstallerError("Expected the Release app package, not a Debug launcher.")
    except (OSError, KeyError, ValueError, zipfile.BadZipFile, ET.ParseError) as error:
        raise InstallerError(f"Invalid package manifest: {error}") from error
    identity = manifest.find(f"{{{FOUNDATION}}}Identity")
    app = manifest.find(f"{{{FOUNDATION}}}Applications/{{{FOUNDATION}}}Application")
    visual = app.find(f"{{{UAP}}}VisualElements") if app is not None else None
    lockscreen = visual.find(f"{{{UAP}}}LockScreen") if visual is not None else None
    if (identity is None or identity.get("Name") != PACKAGE_NAME or
            identity.get("Version") != PACKAGE_VERSION or
            identity.get("Publisher") != "CN=PAFPlayerLocal" or
            identity.get("ProcessorArchitecture") != "x64" or
            lockscreen is None or lockscreen.get("Notification") != "badgeAndTileText" or
            visual.find(f"{{{UAP}}}DefaultTile") is None):
        raise InstallerError("Package does not declare the expected x64 lock-screen app.")


def require_windows_10() -> None:
    if platform.system() != "Windows" or not hasattr(sys, "getwindowsversion"):
        raise InstallerError("This installer must run on Windows 10.")
    build = sys.getwindowsversion().build
    if build < 19041 or build >= 22000:
        raise InstallerError(f"Windows build {build} is outside the supported Windows 10 range.")
    if os.environ.get("PROCESSOR_ARCHITECTURE", "").upper() not in ("AMD64", "ARM64") and not os.environ.get("PROCESSOR_ARCHITEW6432"):
        raise InstallerError("This package requires 64-bit Windows and an x64-compatible CPU.")


def ps_literal(value: object) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def powershell_executable() -> Path:
    windows = Path(os.environ.get("WINDIR", r"C:\Windows"))
    sysnative = windows / "Sysnative" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    system32 = windows / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    return sysnative if sysnative.is_file() else system32


def ps_args(command: str) -> list[str]:
    # The parent process may prepend PowerShell 7 modules to PSModulePath.
    # Windows PowerShell 5.1 then autoloads incompatible copies of built-in
    # modules (including Microsoft.PowerShell.Security). Use its own modules.
    command = (r"$env:PSModulePath = $env:WINDIR + '\System32\WindowsPowerShell\v1.0\Modules'; "
               + command)
    encoded = base64.b64encode(command.encode("utf-16le")).decode("ascii")
    return [str(powershell_executable()), "-NoLogo", "-NoProfile", "-NonInteractive",
            "-EncodedCommand", encoded]


class WindowsBackend:
    def run_ps(self, command: str) -> str:
        result = subprocess.run(ps_args("$ErrorActionPreference='Stop'; " + command),
                                capture_output=True, text=True, encoding="utf-8-sig", errors="replace")
        if result.returncode:
            detail = (result.stderr or result.stdout).strip()
            raise InstallerError(detail or f"Windows PowerShell failed ({result.returncode}).")
        return result.stdout.strip()

    def installed_version(self) -> str:
        command = ("$p = Get-AppxPackage -Name " + ps_literal(PACKAGE_NAME) +
                   "; if ($p) { [string]$p.Version }")
        output = self.run_ps(command)
        return output.splitlines()[-1] if output else ""

    def uac_enabled(self) -> bool:
        command = ("[int](Get-ItemProperty -Path "
                   "'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' "
                   "-Name EnableLUA).EnableLUA")
        return self.run_ps(command).splitlines()[-1] == "1"

    def trusted(self) -> bool:
        return self.run_ps("[bool](Get-ChildItem Cert:\\LocalMachine\\TrustedPeople\\" +
                           CERT_THUMBPRINT + " -ErrorAction SilentlyContinue)").lower() == "true"

    def signature_matches(self, package: Path, certificate: Path) -> None:
        command = ("$c = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new(" +
                   ps_literal(certificate) + "); " +
                   "$s = Get-AuthenticodeSignature -LiteralPath " + ps_literal(package) + "; " +
                   "if (-not $s.SignerCertificate -or $s.SignerCertificate.Thumbprint -ne $c.Thumbprint " +
                   "-or $c.Thumbprint -ne " + ps_literal(CERT_THUMBPRINT) +
                   ") { throw 'Package signer does not match the verified PAFPlayer certificate.' }")
        self.run_ps(command)

    def elevate_certificate_import(self, certificate: Path) -> None:
        # ShellExecuteW uses UAC for this one machine-store operation. The
        # unelevated Python process remains the user's AppX installation owner.
        import ctypes
        command = ("$ErrorActionPreference='Stop'; Import-Certificate -FilePath " +
                   ps_literal(certificate) +
                   " -CertStoreLocation 'Cert:\\LocalMachine\\TrustedPeople' | Out-Null")
        args = ps_args(command)
        parameters = subprocess.list2cmdline(args[1:])
        shell_execute = ctypes.windll.shell32.ShellExecuteW
        shell_execute.restype = ctypes.c_void_p
        result = shell_execute(None, "runas", args[0], parameters, None, 1)
        if not result or int(result) <= 32:
            raise InstallerError("Certificate trust was not approved or could not be started.")
        for _ in range(90):
            if self.trusted():
                return
            time.sleep(1)
        raise InstallerError("Certificate trust was not confirmed. Registration was not attempted.")

    def register(self, package: Path, dependencies: tuple[Path, ...]) -> None:
        deps = ", ".join(ps_literal(path) for path in dependencies)
        self.run_ps("Add-AppxPackage -Path " + ps_literal(package) +
                    " -DependencyPath @(" + deps + ") -ErrorAction Stop")


def manual_steps() -> None:
    print("\nFinish these steps in your Windows account:")
    print("  1. Start PAFPlayer with its web server reachable from this computer.")
    print("  2. Open 'PAFPlayer Lock Screen' from Start. Enter the official")
    print("     player's machine name and port (for example machineservername:666),")
    print("     then choose 'Connect and refresh'.")
    print("  3. Open Settings > Personalization > Lock screen. Under")
    print("     'Choose one app to show detailed status', select PAFPlayer Lock Screen.")
    print("  4. Lock with Win+L and check the text. Background refresh can be delayed")
    print("     by Windows; lyrics on the lock screen are not synchronized live.")


def install(root: Path, backend: WindowsBackend, *, check_only: bool = False,
            ask=input) -> int:
    require_windows_10()
    package, certificate, dependencies = artifacts(root)
    validate_artifacts(package, certificate, dependencies)
    backend.signature_matches(package, certificate)
    installed = backend.installed_version()
    if not backend.uac_enabled():
        print("Windows User Account Control is disabled (EnableLUA=0). This UWP app cannot be")
        print("confirmed working in the current session. Enable UAC and restart Windows first.")
        print("The installer will not claim a successful launch from registration alone.")
        return 3
    if installed == PACKAGE_VERSION:
        print(f"PAFPlayer Lock Screen V509 is registered for this Windows account.")
        print("Open it from Start to verify that Windows can activate it.")
        manual_steps()
        return 0
    if check_only:
        print(f"PAFPlayer Lock Screen V509 is available; installed version: {installed or 'none'}.")
        print("Run this installer without --check to install or update it.")
        return 1
    if installed:
        print(f"Updating PAFPlayer Lock Screen from {installed} to V509.")
    if not backend.trusted():
        print("\nThe package uses a self-signed PAFPlayerLocal development certificate.")
        print("Trusting it in LocalMachine\\TrustedPeople lets Windows accept packages")
        print("signed by that certificate. Windows will ask for administrator approval.")
        try:
            consent = ask("Trust this certificate and install PAFPlayer Lock Screen? [y/N] ")
        except (EOFError, KeyboardInterrupt):
            consent = ""
        if consent.strip().casefold() not in ("y", "yes"):
            print("No certificate trust or app registration was changed.")
            return 2
        backend.elevate_certificate_import(certificate)
        if not backend.trusted():
            raise InstallerError("Certificate trust could not be verified.")
    print("Installing the companion and its three x64 runtime dependencies...")
    backend.register(package, dependencies)
    installed = backend.installed_version()
    if installed != PACKAGE_VERSION:
        raise InstallerError("Windows did not report V509 registered for this account.")
    print("Verified: PAFPlayer Lock Screen V509 is registered for this account.")
    print("Open it from Start to verify that Windows can activate it.")
    manual_steps()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="validate files and check this account; change nothing")
    args = parser.parse_args(argv)
    try:
        return install(Path(__file__).resolve().parent, WindowsBackend(), check_only=args.check)
    except InstallerError as error:
        print(f"Installer stopped: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
