# PAFPlayer Lock Screen Recovery — V512

The user confirmed native lock-screen status after selecting **PAFPlayer Lock
Screen Recovery** in both Windows Settings slots. The older music-note entry is
a different identity. UAC remains unchanged at 0. The final V512 update passed
real activation/publication and fixes false offline status after 30 seconds.

See [architecture, diagnosis, limitations and manual checks](../docs/windows-lock-screen.md).
Run `python -B -X utf8 lockscreen_installer.py --check` for a read-only check;
omit `--check` to install, verify actual activation/publication, and run the
publisher. Keep `dist/v512/runtime` in place. Closing hides it to the tray;
use its publishing switch or Exit to disable updates. No login startup is added.

Build with `build_desktop.ps1`, test with `test_desktop.ps1` and
`python -B -X utf8 run_regression_checks.py`. Build output is unique. Make
verified backups before signing both EXE and MSIX, then pin their hashes in the
installer. The existing certificate is public in dist; never distribute its key.

The App.xaml/MainPage.xaml UWP projects and previous build candidates are
historical reference. Current sources are DesktopHost.cs and StatusUpdater.cs.
Do not rerun original-family registration experiments as routine installation.
The original package and prior releases remain preserved.
