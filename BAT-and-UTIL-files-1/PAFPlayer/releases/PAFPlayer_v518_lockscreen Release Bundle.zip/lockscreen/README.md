# PAFPlayer Lock Screen V518

Badge and detailed text are submitted together to prevent the V517 badge-only
renewal disappearance. Three requested rows show song, previous lyric and current
lyric. Launch the V518 player for previous cues that fell between polling samples.

See the [architecture, evidence and manual check](../docs/windows-lock-screen.md).
Install the signed package in dist/v518 with lockscreen_installer.py.
Run run_regression_checks.py and test_desktop.ps1 for focused checks.
Windows owns the actual layout and can coalesce rapid lyric changes.
