# Windows 10 lock-screen status — V518

V518 fixes the recurring disappearance caused by V517's independent badge
renewal. It also supplies the previous lyric alongside the current lyric so a
brief cue can remain readable after the next cue arrives. The native Windows
lock screen still controls timing, truncation, font size and clock placement.

## Use lyrics

1. Run V518 `PAFPlayer.py` or its versioned release copy. The V518 companion
   works with V517, but recovering an unobserved previous cue requires V518's
   player endpoint. A running older player must be relaunched to load that part.
2. Keep **Windows Lock Screen → Enable lock-screen song status** enabled.
   Fresh installations remain disabled by default; existing choices are retained.
3. Choose **PAFPlayer Lock Screen V518** in Windows Settings' top **Choose one
   app to show detailed status** slot for text. A bottom quick-status slot shows
   only the playing/paused/idle/offline badge. Both may be selected. The Recovery
   package family and app ID are unchanged, so existing selections should survive.
4. Play a track with timed lyrics. The requested three rows are **artist — song**,
   **previous lyric**, and **current lyric**. Missing previous/current text uses
   `—` / `♪` so lyric gaps still request three nonempty rows.

The current lyric follows PAFPlayer's existing lyric state. Previous context is
looked up from the same timeline and position with the same lyric offset; it
follows seeks and resets for gaps and new tracks. No speech recognition or second
playback clock is involved. With an older player, the companion retains only the
previous line it actually observed. Long rows are capped at 120 UTF-16 code units
without breaking surrogate pairs, and Windows can truncate them further.

## Cause and delivery fix

The October 9 baseline trace recorded two badge-only renewals followed about
200 ms later by `PublishDetailedStatusChanged` reason 2 with no text update. Text
returned on the next tile update; one absence lasted roughly eight seconds.
This matches the reported disappearing status area and clock movement.

V518 always submits badge then detailed text together whenever content changes
or the unchanged content needs its 30-second renewal. Both share a 90-second
expiration and renewal deadline. It does not clear notifications between lyric
updates. The native Windows trace coalesces arrivals over roughly 200 ms; merely
polling faster cannot guarantee a visible frame for every arbitrarily short cue.
The extra previous row makes one preceding cue available after a quick transition,
including a cue that fell between polls. Multiple rapid cues can still be missed.

The companion continues polling every 250 ms. PAFPlayer's existing status cadence
is 200 ms, so those stages alone can add about 450 ms, before Windows rendering
and network overhead. This is line-level display, not word-highlighted karaoke.
No notification queue is used to replay stale lyrics. Sleep/suspension can stop
updates. A publisher restart or installation handoff can briefly clear the area.

## Architecture and compatibility

The controller is bundled in PAFPlayer.py and manages the installed signed desktop
publisher in a separate process. Its worker checks ownership/settings every five
seconds; Windows process work is outside the audio callback and visualizer frame.
Disabling the setting or ending the owning player stops managed publication and
clears status; notification expiration is the fallback after abrupt failure.

The compact local GET/HEAD endpoint `/api/remote-tray/hello?lockscreen=1` activates
only the existing status sidecar updates. It copies metadata, transport state,
current and previous lyric text; it does not transfer artwork/full timelines,
activate the browser spectrum, or send playback commands. Previous-cue lookup is
bounded. Ordinary tray requests retain their existing behavior.

The publisher requires `official=true`, a nonempty instance identity,
case-insensitive PAFPlayer program names in root/state, and matching nonempty
versions. Managed mode also pins the launching identity and requires loopback.
Redirects, proxies, cookies and default credentials remain disabled. One reusable
HTTP client has a bounded response size, a three-second timeout, no overlapping
requests, and a three-second backoff after failed reads. Failed reads show offline
status instead of stale track details.

`PAFPlayerLockScreenEnabled`, `PAFPlayerServerUrl`, the Recovery package family,
`!App` identity and existing configuration IDs are preserved. This feature is
separate from the `.scr` screensaver, wallpaper and media transport panel.
The periodic Windows background task is not a subsecond lyric clock.

## Installation

The signed package is `lockscreen/dist/v518/PAFPlayerLockScreen_v518_x64.msix`,
version `518.0.0.0`. From the PAFPlayer project directory:

```powershell
& C:\ProgramData\anaconda3\python.exe -B -X utf8 lockscreen\lockscreen_installer.py --check
& C:\ProgramData\anaconda3\python.exe -B -X utf8 lockscreen\lockscreen_installer.py
```

The installer verifies pinned hashes, signer, manifest, interactive activation,
publication and background COM activation. It upgrades the Recovery companion;
playback stays running. A successful receipt is not proof of visible pixels.

## Verification evidence

- **148 focused tests passed:** 67 C# and 81 Python, covering paired renewals,
  failed-submission retries, gaps/track changes, short preceding cues, seeks and
  offsets, old-player compatibility, local/official-only reads, browser-inactive
  real HTTP polling, lifecycle, installer and related tray regressions.
- Python compilation, final C# build, full MakeAppx validation, executable/MSIX
  signatures and pinned installer checks passed. Interactive V518 activation,
  tile/badge submission and background COM registration succeeded as
  `DEMONA\Claire`, session 1.
- The real October 9 V518 lock cycle recorded 32 detailed-text updates. One explicit
  clear during the standalone-to-managed handoff briefly removed text; it returned
  about 0.56 seconds later. After the publisher settled, **23 text updates had zero
  reason-2 removals**. This sample supports the recurring-refresh fix, but does not
  visually prove clock stability or delivery of every line.
- Reports: `tests/reports/v518-badge-disappearance-evidence.json`,
  `tests/reports/v518-lock-cycle-analysis.json`, and the linked raw trace names
  inside those reports. The Winlogon trace provider was access-denied; the relevant
  lock-screen text/notification providers recorded successfully. Some other events
  reported schema mismatches during decoding.
- Main-player function/class ASTs match the pre-edit backup. Version constants and
  the bundled lock-screen module changed. The user's intervening edits were kept.
  The historical 678-test V514/V515 comparison had identical 614 passes, 51 failures
  and 13 errors; this narrow release does not claim a clean full-suite result.

## Manual check still needed

After the publisher has settled, close the web browser, play a timed-lyric track,
lock Windows manually and watch the clock/date screen for at least one minute.
Check that current and previous lines advance without the entire status area
collapsing. Check a lyric gap and a section with rapid cues. Then use normal player
controls to test pause, resume, a backward seek and disabling the setting. Check
that previous lyrics do not leak into the next song. The agent has not visually
verified V518's clock position or every cue; native text rendering is trace-verified.

## Windows host history and boundaries

The October 8 trace separately recorded Microsoft's LockApp activation failing
with `0x80270252` (`E_UAC_DISABLED`). On October 9 native status was user-confirmed
and a read-only check reported `EnableLUA=1`; this work did not change UAC. That old
failure is not the cause of the now-working screen's V517 refresh regression.
See the [historical investigation](lockscreen-renderer-investigation-20261008.md).

Source/signing replacements have verified backups. Prior releases are preserved.
`play_audio_file.py` and all literal `C:\BAT` paths are unchanged.

## Microsoft references

- [Local tile and badge notifications](https://learn.microsoft.com/en-us/windows/apps/design/shell/tiles-and-notifications/choosing-a-notification-delivery-method)
- [Lock-screen tile and badge presentation](https://learn.microsoft.com/en-us/previous-versions/windows/apps/hh779720(v=win.10))
- [LockScreen API boundary](https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.lockscreen?view=winrt-28000)
