# PAFPlayer Lock Screen companion (V505)

This Windows 10 UWP app is the registered companion for the **Choose one app to show detailed status** picker. The Python player and tray remain separate. The companion reads the official player's `/api/remote-tray/hello` response and publishes title, artist/playback state and current lyric as Windows tile detailed-status text. It never sends playback commands.

## Install and configure

Run `py -3 lockscreen_installer.py` from this folder **in the Windows account that should display the status**. The installer checks Windows 10 x64 compatibility, verifies SHA-256 hashes and package identity, checks that the signing certificate matches, prompts before adding the self-signed public certificate to `LocalMachine\TrustedPeople` through Windows UAC, registers the MSIX with its three x64 dependencies for the original interactive user, and verifies `Get-AppxPackage`. `py -3 lockscreen_installer.py --check` is read-only. If trust is declined or UAC fails, registration does not start. The certificate permits Windows to accept other packages signed by the same key; trust it only on machines you control. The private signing key is not included.

For another computer, extract `../releases/PAFPlayer_v508_lockscreen_install_bundle.zip` and run its `lockscreen_installer.py`. The installer and everything it needs are in that bundle. The signed V505 x64 package, public certificate, and runtime dependency copies are also in this project's `dist/` folder. The original V505 build output is archived under `archive/build-v505/` and is not needed to install.

After a verified install, open **PAFPlayer Lock Screen** from Start, enter the official player's machine name and port (for example `machineservername:666`), and press **Connect and refresh**. On Windows 10, open Settings → Personalization → Lock screen, then choose **PAFPlayer Lock Screen** in **Choose one app to show detailed status**. Windows does not let the app choose that slot itself. Close and reopen Settings after a new install. The older `Register.ps1` and two short PowerShell setup snippets are archived under `archive/legacy-installers/` because they did not handle the same trust store and all package dependencies consistently.

The player must expose its web server to the companion computer on the LAN. The companion accepts only a response claiming the official active instance; it never sends remote control actions. It stores only the server address in this Windows user's UWP local settings. Use a trusted home network: the existing tray API uses plain HTTP and does not authenticate the server cryptographically.

## Refresh behavior

With the companion window open, status refreshes every five seconds. When Windows suspends the app, a timer background task requests refresh every 15 minutes. Windows may delay or decline background tasks; therefore track changes and lyrics are **not live** on the lock screen. Tile text expires after 40 minutes. Someone viewing the locked screen may read the displayed title, artist and lyric. Artwork and interactive controls cannot be shown in this detailed-status slot. The tray and SMTC media card continue to work independently.

## Build

The project targets Windows 10 19041 and SDK 26100. It uses Visual Studio 2022 UWP build tools and the official `Microsoft.NETCore.UniversalWindowsPlatform` 6.2.14 NuGet package. Build `PAFPlayerLockScreen.csproj` for x64. The project builds a separate Windows Runtime background-task component under `BackgroundTasks/`; the resulting MSIX manifest is validated by the Windows SDK packager. `make_assets.py` regenerates the six PAF-branded PNG assets using Pillow.

The source package in `AppPackages/` is unsigned. The signed package in `dist/` was signed with a non-exportable per-user development certificate. If rebuilding, increment the PAFPlayer and package versions, sign the new MSIX with a certificate whose subject matches the manifest Publisher, and preserve existing release filenames.

## Verification

The V505 build completed with MSBuild and produced an MSIX whose unpacked manifest includes `uap:LockScreen Notification="badgeAndTileText"`, a timer background task, and the matching activatable class. Its signature is present, but chain verification fails until the self-signed public certificate is trusted. V508 installer regression tests verify files, consent behavior, dependency routing, and registration checks with a fake Windows backend. App registration and visual presence in the Settings picker remain unverified for the interactive Windows user; run the installer there to complete that check.
