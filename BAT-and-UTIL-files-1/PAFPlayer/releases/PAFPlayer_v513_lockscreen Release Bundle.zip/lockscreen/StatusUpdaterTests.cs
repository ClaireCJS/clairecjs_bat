using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Windows.Data.Json;

namespace PAFPlayerLockScreen
{
    internal static class StatusUpdaterTests
    {
        private static int passed, failed;
        private static string Fixture()
        {
            return "{\"program\":\"PAFplayer\",\"version\":\"V509\",\"official\":true,\"identity\":\"official-instance\",\"state\":{\"program\":\"PAFplayer\",\"version\":\"V509\",\"updated_at_epoch\":1700000000,\"playing\":true,\"paused\":false,\"metadata\":{\"Artist\":\"Artist & company\",\"Song\":\"Song <one>\"},\"lyric\":\"Line one\"}}";
        }
        private static PlayerStatus Parse(string json) { return StatusUpdater.Parse(json); }
        private static void Check(bool condition) { if (!condition) throw new Exception("Assertion failed"); }
        private static void Reject(string json) { try { Parse(json); } catch { return; } throw new Exception("Accepted invalid identity/state"); }
        private static void Test(string name, Action action)
        {
            try { action(); passed++; Console.WriteLine("PASS " + name); }
            catch (Exception error) { failed++; Console.WriteLine("FAIL " + name + ": " + error); }
        }
        private static string Change(string field, IJsonValue value, bool state)
        {
            var root = JsonObject.Parse(Fixture());
            (state ? root.GetNamedObject("state") : root)[field] = value;
            return root.Stringify();
        }
        private static async Task<PlayerStatus> FetchFixture(string response, Action<string> check)
        {
            var listener = new TcpListener(IPAddress.Loopback, 0);
            listener.Start();
            int port = ((IPEndPoint)listener.LocalEndpoint).Port;
            var serve = Task.Run(async () => {
                using (var peer = await listener.AcceptTcpClientAsync())
                using (var reader = new StreamReader(peer.GetStream()))
                {
                    string first = await reader.ReadLineAsync();
                    check(first);
                    while (!String.IsNullOrEmpty(await reader.ReadLineAsync())) { }
                    byte[] bytes = Encoding.UTF8.GetBytes(response);
                    await peer.GetStream().WriteAsync(bytes, 0, bytes.Length);
                }
            });
            try { var result = await StatusUpdater.FetchAsync("http://127.0.0.1:" + port); await serve; return result; }
            finally { listener.Stop(); }
        }
        private static string Http(string body)
        {
            return "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: " + Encoding.UTF8.GetByteCount(body) + "\r\nConnection: close\r\n\r\n" + body;
        }
        private static int Main()
        {
            Test("official PAFplayer capitalization and canonical metadata", () => {
                var result = Parse(Fixture()); Check(result.Verified && result.Title == "Song <one>" && result.Artist == "Artist & company" && result.Identity == "official-instance");
            });
            Test("playing badge", () => Check(Parse(Fixture()).Badge == "playing"));
            Test("paused takes precedence over playing", () => Check(Parse(Change("paused", JsonValue.CreateBooleanValue(true), true)).Badge == "paused"));
            Test("stopped clears lyrics", () => { var s = Parse(Change("transport_stopped", JsonValue.CreateBooleanValue(true), true)); Check(s.Badge == "available" && s.Lyric == ""); });
            Test("waiting badge", () => Check(Parse(Change("playing", JsonValue.CreateBooleanValue(false), true)).Badge == "available"));
            Test("offline badge and no stale track", () => { var s = PlayerStatus.Offline("unreachable"); Check(s.Badge == "unavailable" && s.Lyric == "" && !s.Verified && s.Title == "PAFPlayer offline"); });
            Test("reject unofficial server", () => Reject(Change("official", JsonValue.CreateBooleanValue(false), false)));
            Test("reject string official flag", () => Reject(Change("official", JsonValue.CreateStringValue("true"), false)));
            Test("reject another program", () => Reject(Change("program", JsonValue.CreateStringValue("MusicPlayer"), false)));
            Test("reject missing instance identity", () => Reject(Change("identity", JsonValue.CreateStringValue(""), false)));
            Test("reject different state program", () => Reject(Change("program", JsonValue.CreateStringValue("Fake"), true)));
            Test("reject state version mismatch", () => Reject(Change("version", JsonValue.CreateStringValue("V508"), true)));
            Test("old state-change timestamp does not mark live official player offline", () => Check(Parse(Fixture()).Verified));
            Test("long paused state remains paused", () => Check(Parse(Change("paused", JsonValue.CreateBooleanValue(true), true)).Badge == "paused"));
            Test("server clock difference is not an identity failure", () => Check(Parse(Change("updated_at_epoch", JsonValue.CreateNumberValue(9999999999), true)).Verified));
            Test("reject malformed JSON", () => Reject("{"));
            Test("legacy metadata remains supported", () => Check(Parse(Fixture().Replace("Artist\"", "artist\"").Replace("Song\"", "title\"")).Title == "Song <one>"));
            Test("missing metadata uses idle title", () => Check(Parse(Change("metadata", new JsonObject(), true)).Title == "PAFPlayer idle"));
            Test("filename fallback", () => { var root = JsonObject.Parse(Fixture()); var s = root.GetNamedObject("state"); s["metadata"] = new JsonObject(); s["track"] = JsonObject.Parse("{\"filename\":\"file.flac\"}"); Check(Parse(root.Stringify()).Title == "file.flac"); });
            Test("tile contains actual lyric text and XML escaping", () => { var doc = StatusUpdater.TileXml(Parse(Fixture())); var lines = doc.GetElementsByTagName("text"); Check(lines[0].InnerText == "Song <one>" && lines[1].InnerText.Contains("Artist & company") && lines[2].InnerText == "Line one" && doc.GetXml().Contains("&lt;one&gt;")); });
            Test("lock-screen lines belong to wide binding and survive XML roundtrip", () => {
                var doc = new Windows.Data.Xml.Dom.XmlDocument();
                doc.LoadXml(StatusUpdater.TileXml(Parse(Fixture())).GetXml());
                var binding = (Windows.Data.Xml.Dom.XmlElement)doc.GetElementsByTagName("binding")[0];
                Check(binding.GetAttribute("template") == "TileWide310x150Text01");
                Check(binding.GetAttribute("hint-lockDetailedStatus1") == "Song <one>");
                Check(binding.GetAttribute("hint-lockDetailedStatus2") == "Artist & company · Playing");
                Check(binding.GetAttribute("hint-lockDetailedStatus3") == "Line one");
                Check(((Windows.Data.Xml.Dom.XmlElement)doc.GetElementsByTagName("visual")[0]).GetAttribute("hint-lockDetailedStatus1") == "");
            });
            foreach (string glyph in new[] { "playing", "paused", "available", "unavailable" })
            { string current = glyph; Test("badge XML " + current, () => Check(StatusUpdater.BadgeXml(new PlayerStatus { Badge = current }).GetXml().Contains("value=\"" + current + "\""))); }
            Test("XML controls removed", () => Check(StatusUpdater.Clip("a\0b\u0001c\uffff\nline") == "abc line"));
            Test("valid Unicode retained", () => Check(StatusUpdater.Clip("café 🎵 中文") == "café 🎵 中文"));
            Test("unpaired surrogates removed", () => Check(StatusUpdater.Clip("a\ud800b\udc00c") == "abc"));
            Test("truncation preserves surrogate pair", () => Check(StatusUpdater.Clip(new string('a', 119) + "🎵").Length == 119));
            Test("maximum output length", () => Check(StatusUpdater.Clip(new string('a', 1000)).Length == 120));
            foreach (string input in new[] { "127.0.0.1:666", "http://localhost:666", "http://[::1]:666", "http://music-server:666/" })
            { string current = input; Test("valid server " + current, () => { Uri u; Check(StatusUpdater.TryServerUrl(current, out u)); }); }
            foreach (string input in new[] { "", "file:///tmp", "https://localhost:666", "http://user:secret@localhost", "http://localhost/path", "http://localhost?x=1", "http://localhost#fragment", "http://localhost:0", "http://localhost:65536" })
            { string current = input; Test("reject server " + current, () => { Uri u; Check(!StatusUpdater.TryServerUrl(current, out u)); }); }
            Test("read-only GET verifies official server", () => {
                var body = Fixture(); // Deliberately old state-change time from a fresh HTTP response.
                var result = FetchFixture(Http(body), line => Check(line == "GET /api/remote-tray/hello HTTP/1.1")).GetAwaiter().GetResult(); Check(result.Verified);
            });
            Test("redirect rejected without contacting target", () => {
                var result = FetchFixture("HTTP/1.1 302 Found\r\nLocation: http://127.0.0.1:1/commands\r\nContent-Length: 0\r\n\r\n", line => Check(line.StartsWith("GET /api/remote-tray/hello "))).GetAwaiter().GetResult(); Check(!result.Verified && result.Error.Contains("HTTP 200"));
            });
            Test("invalid network response becomes offline", () => Check(!FetchFixture(Http("{bad-json"), line => Check(line.StartsWith("GET "))).GetAwaiter().GetResult().Verified));
            Test("connection refusal becomes offline", () => Check(StatusUpdater.FetchAsync("http://127.0.0.1:1").GetAwaiter().GetResult().Badge == "unavailable"));
            Console.WriteLine("RESULT: " + passed + " passed, " + failed + " failed");
            return failed == 0 ? 0 : 1;
        }
    }
}
