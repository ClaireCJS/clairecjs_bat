param([string]$OutputDirectory)
$ErrorActionPreference = 'Stop'
if (!$OutputDirectory) { $OutputDirectory = Join-Path $PSScriptRoot ('build-v513-' + (Get-Date -Format yyyyMMddHHmmss)) }
if (Test-Path -LiteralPath $OutputDirectory) { throw 'Build directory already exists; choose a new name.' }
$stage = New-Item -ItemType Directory -Path (Join-Path $OutputDirectory 'package')
$runtime = New-Item -ItemType Directory -Path (Join-Path $OutputDirectory 'runtime')
$framework = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319"
$sdk = "${env:ProgramFiles(x86)}\Windows Kits\10"
$references = @('System.dll','System.Core.dll','System.Net.Http.dll','System.Drawing.dll','System.Windows.Forms.dll',
    "$framework\System.Runtime.dll", "$framework\System.Runtime.WindowsRuntime.dll", "$framework\System.Runtime.InteropServices.WindowsRuntime.dll",
    "$sdk\UnionMetadata\10.0.26100.0\Windows.winmd")
$compilerArgs = @('/nologo','/target:winexe','/platform:x64','/optimize+',('/win32manifest:' + (Join-Path $PSScriptRoot 'DesktopHost.manifest')),('/out:' + (Join-Path $runtime 'PAFPlayerLockScreen.exe')))
foreach ($reference in $references) { $compilerArgs += '/r:' + $reference }
& "$framework\csc.exe" @compilerArgs (Join-Path $PSScriptRoot 'DesktopHost.cs') (Join-Path $PSScriptRoot 'StatusUpdater.cs')
if ($LASTEXITCODE) { throw "C# compilation failed: $LASTEXITCODE" }
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'DesktopPackage.appxmanifest') -Destination (Join-Path $stage 'AppxManifest.xml')
New-Item -ItemType Directory -Path (Join-Path $stage 'Assets') | Out-Null
Get-ChildItem (Join-Path $PSScriptRoot 'Assets\PAF*.png') | Copy-Item -Destination (Join-Path $stage 'Assets')
Copy-Item -LiteralPath (Join-Path $stage 'Assets') -Destination $runtime -Recurse
$package = Join-Path $OutputDirectory 'PAFPlayerLockScreen_v513_x64.msix'
# External executables are deliberately absent from the identity package.
# Microsoft requires /nv for this external-location package layout.
& "$sdk\bin\10.0.26100.0\x64\makeappx.exe" pack /nv /d $stage.FullName /p $package
if ($LASTEXITCODE) { throw "Package validation failed: $LASTEXITCODE" }
Write-Output $package
