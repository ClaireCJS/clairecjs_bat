$ErrorActionPreference = 'Stop'
$stamp = Get-Date -Format yyyyMMddHHmmss
$folder = Join-Path $PSScriptRoot ('test-build-' + $stamp)
if (Test-Path -LiteralPath $folder) { throw 'Test build directory exists.' }
New-Item -ItemType Directory -Path $folder | Out-Null
$framework = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319"
$sdk = "${env:ProgramFiles(x86)}\Windows Kits\10"
$refs = @('System.dll','System.Core.dll','System.Net.Http.dll',
    "$framework\System.Runtime.dll", "$framework\System.Runtime.WindowsRuntime.dll", "$framework\System.Runtime.InteropServices.WindowsRuntime.dll",
    "$sdk\UnionMetadata\10.0.26100.0\Windows.winmd")
$exe = Join-Path $folder 'StatusUpdaterTests.exe'
$compilerArgs = @('/nologo','/target:exe','/platform:x64',('/out:' + $exe))
foreach ($ref in $refs) { $compilerArgs += '/r:' + $ref }
& "$framework\csc.exe" @compilerArgs (Join-Path $PSScriptRoot 'StatusUpdater.cs') (Join-Path $PSScriptRoot 'StatusUpdaterTests.cs')
if ($LASTEXITCODE) { throw 'Test compilation failed.' }
$report = Join-Path (Split-Path $PSScriptRoot) ('tests\reports\v512-status-updater-' + $stamp + '.txt')
if (Test-Path -LiteralPath $report) { throw 'Report exists.' }
& $exe | Tee-Object -FilePath $report
if ($LASTEXITCODE) { throw "Tests failed; see $report" }
