# PAFPlayer Lock Screen V513

The app picker, window title and tray tooltip now show **PAFPlayer Lock Screen
V513**. It upgrades the existing Recovery identity and preserves its settings.
Actual locked-screen rendering remains unresolved; API publication works.

See the [current guide and manual checks](../docs/windows-lock-screen.md).
Use `python -B -X utf8 lockscreen_installer.py --check` for a read-only check;
omit `--check` to install, activate and run the publisher. Retain
`dist/v513/runtime`. Select the exact V513 name in BOTH lock-screen Settings
pickers. Reopen Settings if it still displays a cached older name.

Build with `build_desktop.ps1`; use `run_regression_checks.py` for related Python
checks and `test_desktop.ps1` for the unchanged C# status tests. Make verified
backups before signing EXE/MSIX; pin hashes and both display names in the installer.
Never overwrite a release artifact or distribute the private signing key.
The older UWP projects and build candidates are historical reference.
