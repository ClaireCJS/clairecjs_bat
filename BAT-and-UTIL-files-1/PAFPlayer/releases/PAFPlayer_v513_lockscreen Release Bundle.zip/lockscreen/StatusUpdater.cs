using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Windows.Data.Json;
using Windows.Data.Xml.Dom;
using Windows.Storage;
using Windows.UI.Notifications;

namespace PAFPlayerLockScreen
{
    internal static class StatusUpdater
    {
        internal const string ServerKey = "PAFPlayerServerUrl";

        internal static bool TryServerUrl(string input, out Uri endpoint)
        {
            endpoint = null;
            string raw = (input ?? "").Trim();
            if (raw.Length == 0) return false;
            if (!raw.Contains("://")) raw = "http://" + raw;
            Uri candidate;
            if (!Uri.TryCreate(raw, UriKind.Absolute, out candidate) ||
                candidate.Scheme != "http" || string.IsNullOrWhiteSpace(candidate.Host) ||
                candidate.UserInfo.Length != 0 || candidate.AbsolutePath != "/" ||
                candidate.Query.Length != 0 || candidate.Fragment.Length != 0 ||
                candidate.Port < 1 || candidate.Port > 65535) return false;
            endpoint = candidate;
            return true;
        }

        internal static async Task<string> RefreshAsync()
        {
            string value = ApplicationData.Current.LocalSettings.Values[ServerKey] as string ?? "http://127.0.0.1:666";
            var status = await FetchAsync(value);
            Publish(status);
            return status.Summary;
        }

        internal static async Task<PlayerStatus> FetchAsync(string value)
        {
            Uri server;
            if (!TryServerUrl(value, out server))
                return PlayerStatus.Offline("Invalid server address");
            try
            {
                using (var handler = new HttpClientHandler { AllowAutoRedirect = false, UseProxy = false,
                    UseCookies = false, UseDefaultCredentials = false })
                using (var client = new HttpClient(handler))
                {
                    client.Timeout = TimeSpan.FromSeconds(3);
                    client.MaxResponseContentBufferSize = 2 * 1024 * 1024;
                    var response = await client.GetAsync(new Uri(server, "/api/remote-tray/hello"));
                    using (response)
                    {
                        if (response.StatusCode != System.Net.HttpStatusCode.OK)
                            throw new InvalidOperationException("Server must return HTTP 200 without a redirect.");
                        return Parse(await response.Content.ReadAsStringAsync());
                    }
                }
            }
            catch (Exception error)
            {
                return PlayerStatus.Offline("Could not verify official player: " + error.Message);
            }
        }

        internal static PlayerStatus Parse(string json)
        {
            var root = JsonObject.Parse(json);
            if (!String.Equals(Read(root, "program"), "PAFPlayer", StringComparison.OrdinalIgnoreCase) ||
                !root.GetNamedBoolean("official", false) || Read(root, "identity").Length == 0)
                throw new InvalidOperationException("Target is not the official PAFPlayer instance.");
            var state = root.GetNamedObject("state");
            if (!String.Equals(Read(state, "program"), "PAFPlayer", StringComparison.OrdinalIgnoreCase) ||
                Read(root, "version").Length == 0 || Read(root, "version") != Read(state, "version"))
                throw new InvalidOperationException("Official instance state identity does not match.");
            // updated_at_epoch dates the last state change, not this live hello
            // response. Long songs and a paused/idle player can legitimately keep
            // it unchanged. Availability comes from the successful, verified GET.
            var metadata = state.GetNamedObject("metadata", new JsonObject());
            var track = state.GetNamedObject("track", new JsonObject());
            string title = Read(metadata, "Song");
            if (title.Length == 0) title = Read(metadata, "title");
            if (title.Length == 0) title = Read(track, "filename");
            if (title.Length == 0) title = "PAFPlayer idle";
            string artist = Read(metadata, "Artist");
            if (artist.Length == 0) artist = Read(metadata, "artist");
            bool stopped = state.GetNamedBoolean("transport_stopped", false);
            string playback = stopped ? "Waiting" : state.GetNamedBoolean("paused", false) ? "Paused" :
                              state.GetNamedBoolean("playing", false) ? "Playing" : "Waiting";
            return new PlayerStatus { Title = Clip(title), Artist = Clip(artist),
                Lyric = stopped ? "" : Clip(Read(state, "lyric")), Playback = playback,
                Badge = playback == "Playing" ? "playing" : playback == "Paused" ? "paused" : "available",
                Identity = Read(root, "identity"), Verified = true };
        }

        private static string Read(JsonObject value, string name)
        {
            IJsonValue item;
            if (!value.TryGetValue(name, out item) || item.ValueType != JsonValueType.String) return "";
            return item.GetString().Trim();
        }

        internal static XmlDocument TileXml(PlayerStatus status)
        {
            // Keep legacy text nodes and explicitly identify the three lock-screen
            // lines on the WIDE BINDING, as Toolkit 7.1.2's TileVisual serializer does.
            var tile = TileUpdateManager.GetTemplateContent(TileTemplateType.TileWide310x150Text01);
            var lines = tile.GetElementsByTagName("text");
            lines[0].InnerText = Clip(status.Title);
            lines[1].InnerText = Clip(status.Artist.Length == 0 ? status.Playback : status.Artist + " · " + status.Playback);
            lines[2].InnerText = Clip(status.Lyric);
            var binding = (XmlElement)tile.GetElementsByTagName("binding")[0];
            for (int i = 0; i < 3; i++)
                binding.SetAttribute("hint-lockDetailedStatus" + (i + 1), lines[i].InnerText);
            return tile;
        }

        internal static XmlDocument BadgeXml(PlayerStatus status)
        {
            var badge = BadgeUpdateManager.GetTemplateContent(BadgeTemplateType.BadgeGlyph);
            ((XmlElement)badge.GetElementsByTagName("badge")[0]).SetAttribute("value", status.Badge);
            return badge;
        }

        internal static void Publish(PlayerStatus status)
        {
            var expiration = DateTimeOffset.Now.AddSeconds(90);
            var notification = new TileNotification(TileXml(status)) { ExpirationTime = expiration, Tag = "PAFStatus" };
            TileUpdateManager.CreateTileUpdaterForApplication().Update(notification);
            BadgeUpdateManager.CreateBadgeUpdaterForApplication().Update(
                new BadgeNotification(BadgeXml(status)) { ExpirationTime = expiration });
        }

        internal static void Clear()
        {
            TileUpdateManager.CreateTileUpdaterForApplication().Clear();
            BadgeUpdateManager.CreateBadgeUpdaterForApplication().Clear();
        }

        internal static string Clip(string value)
        {
            // Metadata is untrusted text. Keep XML 1.0 characters and intact pairs.
            var clean = new StringBuilder();
            value = value ?? "";
            for (int i = 0; i < value.Length && clean.Length < 120; i++)
            {
                char c = value[i];
                if (c == '\r' || c == '\n' || c == '\t') clean.Append(' ');
                else if (Char.IsHighSurrogate(c))
                {
                    if (i + 1 < value.Length && Char.IsLowSurrogate(value[i + 1]) && clean.Length < 119)
                        clean.Append(c).Append(value[++i]);
                }
                else if (!Char.IsLowSurrogate(c) && c >= 0x20 && c != 0xfffe && c != 0xffff) clean.Append(c);
            }
            return clean.ToString().Trim();
        }
    }

    internal sealed class PlayerStatus
    {
        internal string Title = "", Artist = "", Lyric = "", Playback = "", Badge = "", Identity = "", Error = "";
        internal bool Verified;
        internal string Summary { get { return Playback + ": " + Title + (Artist.Length == 0 ? "" : " — " + Artist); } }
        internal static PlayerStatus Offline(string error)
        {
            return new PlayerStatus { Title = "PAFPlayer offline", Playback = "Offline", Badge = "unavailable", Error = error };
        }
    }
}
