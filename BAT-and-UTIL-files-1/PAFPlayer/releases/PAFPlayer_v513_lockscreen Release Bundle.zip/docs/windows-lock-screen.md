# Windows 10 lock-screen status — V513

The Windows app-picker name is now **PAFPlayer Lock Screen V513**. The package
display name, application display name, window title, tray tooltip and setup
instructions all include the version. Windows' installed manifest and Start-app
catalog were read back and report this exact name.

**Actual locked-screen rendering remains unresolved.** The user clarified that
nothing appears there. Earlier V512 documentation interpreted an intermediate
reply as visual confirmation; that interpretation is withdrawn. Activation and
notification publication succeed, but they are not proof of visible status.
V513 is a naming update, not a claim to have fixed the remaining rendering issue.

## Select the versioned entry

Close and reopen Windows Settings if it was already open during installation.
Under Settings > Personalization > Lock screen, choose **PAFPlayer Lock Screen
V513** in BOTH places:

- Top, **Choose one app to show detailed status**: song, artist and current lyric.
- Bottom, **Choose which apps show quick status**: playing/paused/offline badge.

Open each picker and check the name rather than relying on the music-note icon.
The original unversioned **PAFPlayer Lock Screen** package is a different app.
V513 upgrades the existing Recovery package; it does not create another family.
Keep its companion running. Closing the window hides it to the tray; **Exit and
clear status** stops it. No login startup entry is installed.

## Installation and compatibility

From the project directory under the interactive Windows account:

```powershell
& C:\ProgramData\anaconda3\python.exe -B -X utf8 lockscreen\lockscreen_installer.py --check
& C:\ProgramData\anaconda3\python.exe -B -X utf8 lockscreen\lockscreen_installer.py
```

`--check` is read-only. Normal installation verifies pinned hashes/signing
identity, registers the package, requires a real activation/publication receipt,
and starts the publisher. It may close only its existing Recovery process during
upgrade. Use the installer, not the MSIX alone, and keep
`lockscreen/dist/v513/runtime` in place. Both EXE and MSIX are signed with the
existing PAFPlayerLocal certificate; only the public certificate is distributed.

Stable package name: `ClaireCJS.PAFPlayer.LockScreen.Recovery`; family:
`ClaireCJS.PAFPlayer.LockScreen.Recovery_vz06efybxc4j2`; application ID: `App`.
Package version is `513.0.0.0`. The unchanged configuration keys are
`PAFPlayerServerUrl` and `PAFPlayerLockScreenEnabled`. Their JSON settings remain
under the same package LocalState directory; the V510 JSON migration remains.
Saved disabled state is preserved. No UAC setting is changed.

## Publisher behavior and limits

The separate .NET Framework desktop process polls asynchronously every five
seconds, reading only GET `/api/remote-tray/hello`. It verifies `official=true`,
nonempty instance identity, case-insensitive PAFPlayer root/state program names,
and matching versions on every response. The default is `http://127.0.0.1:666`.
Redirects, proxies, cookies and default credentials are disabled; timeout is
three seconds and response size is bounded. No playback commands are sent.
This existing HTTP identity assertion is not cryptographic authentication;
remote use requires a trusted LAN.

V512's timestamp correction remains: `updated_at_epoch` dates a state change,
not a heartbeat. A live official response is not rejected just because playback
or pause state has stayed unchanged. Invalid or unreachable servers produce
offline content without retaining an old song.

The wide tile contains song, artist/playback state and current timed lyric,
with explicit lock-screen fields. Badges are playing, paused, available (idle)
or unavailable (offline). Updates expire after 90 seconds; disabling/exiting
clears them. Windows controls rendering, truncation, placement and privacy.
Settings selection and successful API calls alone cannot verify the lock screen.
Internal notification-database flags are not a supported selection API.

The original package failed before startup with `0x80270254`
(`E_APPLICATION_NOT_REGISTERED`) despite Appx status Ok. Read-only inspection
found inconsistent family registration. Reinstallation did not resolve it;
the parallel Recovery identity activated successfully with EnableLUA=0.
The old package/data and previous releases remain preserved. No Windows internal
cache patch, UAC change or reboot was used. The cause of the original corruption
is unknown; the remaining rendering issue is still under investigation.

This publisher targets Windows 10 x64, builds 19041–19045. Text/badge status is
separate from the `.scr` screensaver, wallpaper, SMTC and floating lyric windows.
It cannot host album-art layouts or draw over the secure native lock screen.

## Verification

V513 passed 50 related Python checks, C# compilation, MSIX packaging, EXE/MSIX
signature verification, and actual interactive installation/activation/publication.
The installed Windows app catalog reports **PAFPlayer Lock Screen V513**. The
installer also validates both versioned manifest display names. StatusUpdater.cs
is unchanged from V512's 47-test C# run; that suite was not rerun for this label
change. Main-player changes are only three release constants.

For manual checking, select the exact V513 name in both slots, keep the official
player and companion running, and lock Windows yourself. Check current song,
available lyric and playing badge. Then use ordinary playback controls to test
pause/resume; close the player normally to test offline; disable the companion
to test clearing. Do not treat a successful publication receipt as visual proof.

Reports are directly under `tests/reports`, including the V513 regressions,
interactive installation, publication receipt and final release validation.
Build with `lockscreen/build_desktop.ps1`; run related Python checks with
`python -B -X utf8 lockscreen/run_regression_checks.py`. For future releases,
update both manifest display names alongside the version and installer constant.

[Microsoft package identity documentation](https://learn.microsoft.com/en-us/windows/apps/desktop/modernize/grant-identity-to-nonpackaged-apps)
and [tile content documentation](https://learn.microsoft.com/en-us/windows/uwp/launch-resume/tile-schema)
describe the underlying interfaces. They do not establish visible rendering on
this computer.

No literal `C:\BAT` paths were changed. `play_audio_file.py` was not modified.
