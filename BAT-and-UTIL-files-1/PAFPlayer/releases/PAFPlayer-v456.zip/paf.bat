@Echo OFF
"%~dp0PAFPlayer.py" %*
