# PAFPlayer V456 — September 25, 2026

Build: `2026-09-25-v456-todo-workflows`. Based on the current V455 `PAFPlayer.py`.

This release finishes the work already started before the request to stop taking
new TODOs. Sixty checklist entries were completed or verified in this pass; 21
untouched entries remain unchecked. New additions to the TODO file were preserved.

## What changed

- **Web queue editor:** select several songs, drag to reorder, remove membership,
  queue next/after current, move top/bottom, undo, search/filter, and save a new
  M3U playlist. Current, queued, shuffled, missing, monitored, and uploaded songs
  have separate labels. Revision checks reject stale edits and preserve newer
  changes. Removing a row never deletes an audio file.
- **Second-launch handoff:** a per-user Windows mutex prevents competing V456
  players. The second process validates its request and waits for an acknowledgment
  over an authenticated loopback endpoint. Files queue next; folders use sorted,
  nonrecursive supported-file order; regex matches retain filelist order;
  playlists replace queue membership and supply the next sequence. Startup or
  rebuild conflicts return a clear retry message. Older running versions cannot
  receive this new protocol; close the old instance once before using V456.
- **Dropped files/folders:** the web player intercepts drops. Local browser files
  are matched uniquely by name and size against the queue/library; browsers do
  not disclose arbitrary full local paths. Unresolved files can be uploaded with
  explicit confirmation when uploads are enabled. Configure library roots for
  local matching without an upload.
- **Security:** uploads default off except for username `claire` or machines
  `thailog`, `demona`, `wyvern`, `goliath`, maintained in one shared array.
  Server enforcement includes same-origin/Host checks, a per-run pairing token,
  safe filenames, supported extensions, FFprobe audio validation, 100 MiB per
  file, 512 MiB total, and read timeouts. Remote clients need the pairing token
  shown on the local Security page. Expired uploads are recycled after 24 hours
  once no longer playing or queued; cleanup also runs during playback.
- **Repair:** preview missing entries in the queue or M3U/M3U8/PLS playlists.
  Rank candidates using normalized/fuzzy names, extension, and available saved
  size, duration, tags, and SHA-256 identity. A filename alone is ambiguous.
  Original-parent, configured, extra, and recursive roots are supported. Approve
  individual replacements or a batch; dry runs leave files unchanged. Atomic
  playlist writes preserve BOM/encoding/newlines and verify a sibling backup.
  Approved changes go to the normal player log; no repair report is created.
- **Folder monitoring:** repeated `--monitor` options or web configuration,
  index/library/playlist modes, two-second stability checks, rename tracking,
  hidden/temp/backup exclusion, saved import state scoped to monitor mode and
  destination, pause/resume, scan, preview, recent actions, and logging. Saved web
  monitor choices resume with playback. Removing a source file never deletes
  anything else. Playlist destinations are M3U/M3U8.
- **Song render books:** render timed lyric starts with the source artwork and
  actual precomputed spectrum at each timestamp. Produce a self-contained HTML
  review book and numbered PNGs, open the book, then prompt to retain/rename the
  sequence. Declining sends the review directory to the Recycle Bin. The offline
  review layout is deterministic and does not change live playback settings.
- **Teeny solutions:** experimental labels centered below EmojiMaxx substitutions
  in Web Karaoke. Size is 5–150%, default 20%, and persists with web settings.
  Controls hide when inapplicable; the labels do not enter lyric character timing.
- **Live logs:** bounded polling, level/category/search filters, pause/resume,
  and redaction of paths, credentials, URLs, and uploaded-file details.
- **Discord:** optional webhook Now Playing, off until enabled and local-title
  sharing explicitly allowed. The webhook stays in `PAFPLAYER_DISCORD_WEBHOOK`,
  never in web responses. Private tracks are withheld; no paths/audio links are
  posted. Updates edit one message, suppress mentions, respect rate limits, and
  show connection status. Disabling stops future updates.
- **CUDA experiment:** opt-in alternating approximately ten-second CPU/CUDA
  windows for final lyric/shadow compositing, including floating lyrics. CPU
  remains visible during warm-up, backend failure, and correctness mismatches.
  Logs pair identical input images and record hashes, correctness, CPU/kernel/
  transfer timings, missed-frame estimates, and Tk-idle presentation latency.
  Analysis reports medians/worst cases and returns an inconclusive result when
  there are too few matched presentation samples. Tk-idle is not physical scanout;
  measured end-to-end windows include shadow comparison work.
- **Windows / Lock Screen:** a separate configuration tab with master enable,
  artwork enable/source/brightness, independent transport/seeking choices, four
  title formats, album/timeline publishing, and live status. It defaults **off**.
  Artwork is derived in memory; source covers and file tags are unchanged.
  Windows decides whether its media card appears on the lock screen.
- **UI and console polish:** fixed bottom-tab selection and tab focus/scroll,
  renamed Progress Bar / Console Alerts / Webpage Background, slightly taller
  top frame, wider wrapping volume control, editable artist/title throb periods
  that survive track changes and restart, correctly separated tooltip paragraphs,
  and a permanent artwork border. Artwork seaming and its styled choice buttons
  are in Experimental; album art onto karaoke is in Broken Experimental; karaoke
  sides has a yellow experimental tint. Removed `scum` and `cared` substitutions.
  Ctrl+H aliases the detailed HUD; the slash control byte is recognized even
  after physical modifiers have been released. Shutdown restores cursor color.
- **Developer's Choice:** canonical `C:\BAT\PAFPlayer.dcc` preference when that
  script exists, full destination reporting, and explicit verified-backup path
  in the save confirmation.

## Commands

Use `paf` or `python PAFPlayer.py`. `paf.bat` now selects the canonical sibling
`PAFPlayer.py`; archived `play_audio_file.py` copies are retained.

```text
paf --workflow-help
paf C:\music\song.flac
paf C:\music\new
paf C:\music\lists\favorites.m3u8
paf --regex "artist.*song" --filelist C:\mp3\filelist.txt
paf --monitor C:\music\new --monitor C:\music\incoming --monitor-mode library
paf --monitor C:\music\new --monitor-mode playlist --monitor-playlist C:\music\new.m3u8
paf --repair-playlist C:\music\favorites.m3u8 --repair-root D:\music --repair-recursive --repair-dry-run
paf --repair-playlist C:\music\favorites.m3u8 --repair-root D:\music --repair-batch
paf --render-song C:\music\song.flac
paf --render-song C:\music\song.flac --render-save --render-prefix review --render-no-open
paf --gather-cuda-benchmarks C:\music\song.flac
paf --analyze-cuda-benchmarks
```

CLI repair operates on the specified playlist only. Web repair can update the
active queue as well. Workflow state is under `%LOCALAPPDATA%\PAFPlayer\workflows`
on this installation. Keep all accompanying `PAFPlayer_*.py` modules beside the
main script when copying the release.

## Dependencies and verification limits

The ordinary renderer remains CPU-based. CUDA requires an appropriate CuPy/CUDA
installation, which was not present here. Windows publishing requires the optional
PyWinRT projections `winrt-runtime`, `winrt-Windows.Media`,
`winrt-Windows.Media.Playback`, and `winrt-Windows.Storage.Streams`; they were not
installed or enabled in the user's live session. Missing support gives an
Unavailable reason rather than silently claiming Windows integration is active.
The API follows [Microsoft's manual SMTC guidance](https://learn.microsoft.com/en-us/windows/apps/develop/media-playback/system-media-transport-controls)
and [PyWinRT's projection conventions](https://pywinrt.readthedocs.io/en/stable/types.html).

Validation: 33 focused tests pass, including real local HTTP requests, FFprobe
validation of silent WAV fixtures, Windows mutex/loopback handoff, encoding and
backup checks, repair approval/conflicts, monitor stability/restart/mode changes,
queue edits, deterministic render output, JavaScript syntax, mocked Discord
privacy/rate limits, CUDA selection/mismatch fallback, Windows configuration and
derived artwork, plus V452/V454/V455 regressions. Browser checks cover live queue
confirmation/undo, tab activation, saved teeny settings, actual emoji labels,
tooltip paragraphs, and unavailable-control state. No Discord message was sent,
no live user audio was played for tests, and GPU speedup/physical lock-screen
appearance are not claimed as verified.

Restart PAFPlayer once to load V456. Existing running Python processes keep their
old code; this release does not interrupt them. Untouched TODOs, including the
remaining seek, glyph, and cross-surface EmojiMaxx requests, remain unchecked.
