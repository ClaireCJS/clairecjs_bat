# PAFPlayer Lock Screen companion (V505)

This Windows 10 UWP app is the registered companion for the **Choose one app to show detailed status** picker. The Python player and tray remain separate. The companion reads the official player's `/api/remote-tray/hello` response and publishes title, artist/playback state and current lyric as Windows tile detailed-status text. It never sends playback commands.

## Install and configure

The signed x64 package and its **public** certificate are in `dist/`. The signing private key is held in this Windows user's certificate store and is not copied into the project. Because this is a self-signed development package, Windows must trust its publisher certificate for the installing user before AppX registration can succeed. That trust changes the user's security boundary; it was **not** granted during this build. `Register.ps1` checks trust and refuses to install while it is absent.

Once certificate trust is explicitly approved, run `Register.ps1` from Windows PowerShell 5.1. Open **PAFPlayer Lock Screen**, enter the player machine name and port (for example `machineservername:666`), and press **Connect and refresh**. On Windows 10, open Settings → Personalization → Lock screen, then choose **PAFPlayer Lock Screen** in **Choose one app to show detailed status**. Windows does not let the app choose that slot itself.

The player must expose its web server to the companion computer on the LAN. The companion accepts only a response claiming the official active instance; it never sends remote control actions. It stores only the server address in this Windows user's UWP local settings. Use a trusted home network: the existing tray API uses plain HTTP and does not authenticate the server cryptographically.

## Refresh behavior

With the companion window open, status refreshes every five seconds. When Windows suspends the app, a timer background task requests refresh every 15 minutes. Windows may delay or decline background tasks; therefore track changes and lyrics are **not live** on the lock screen. Tile text expires after 40 minutes. Someone viewing the locked screen may read the displayed title, artist and lyric. Artwork and interactive controls cannot be shown in this detailed-status slot. The tray and SMTC media card continue to work independently.

## Build

The project targets Windows 10 19041 and SDK 26100. It uses Visual Studio 2022 UWP build tools and the official `Microsoft.NETCore.UniversalWindowsPlatform` 6.2.14 NuGet package. Build `PAFPlayerLockScreen.csproj` for x64. The project builds a separate Windows Runtime background-task component under `BackgroundTasks/`; the resulting MSIX manifest is validated by the Windows SDK packager. `make_assets.py` regenerates the six PAF-branded PNG assets using Pillow.

The source package in `AppPackages/` is unsigned. The signed package in `dist/` was signed with a non-exportable per-user development certificate. If rebuilding, increment the PAFPlayer and package versions, sign the new MSIX with a certificate whose subject matches the manifest Publisher, and preserve existing release filenames.

## Verification

The V505 build completed with MSBuild and produced an MSIX whose unpacked manifest includes `uap:LockScreen Notification="badgeAndTileText"`, a timer background task, and the matching activatable class. Its signature is present, but chain verification fails until the self-signed public certificate is trusted. App registration and visual presence in the Settings picker remain unverified on this machine.
