using System;
using System.Net.Http;
using System.Threading.Tasks;
using Windows.Data.Json;
using Windows.Data.Xml.Dom;
using Windows.Storage;
using Windows.UI.Notifications;

namespace PAFPlayerLockScreen
{
    internal static class StatusUpdater
    {
        internal const string ServerKey = "PAFPlayerServerUrl";

        internal static bool TryServerUrl(string input, out Uri endpoint)
        {
            endpoint = null;
            string raw = (input ?? "").Trim();
            if (raw.Length == 0) return false;
            if (!raw.Contains("://")) raw = "http://" + raw;
            Uri candidate;
            if (!Uri.TryCreate(raw, UriKind.Absolute, out candidate) ||
                candidate.Scheme != "http" || string.IsNullOrWhiteSpace(candidate.Host) ||
                candidate.UserInfo.Length != 0 || candidate.AbsolutePath != "/" ||
                candidate.Query.Length != 0 || candidate.Fragment.Length != 0 ||
                candidate.Port < 1 || candidate.Port > 65535) return false;
            endpoint = candidate;
            return true;
        }

        internal static async Task<string> RefreshAsync()
        {
            string value = ApplicationData.Current.LocalSettings.Values[ServerKey] as string;
            Uri server;
            if (!TryServerUrl(value, out server))
            {
                Publish("PAFPlayer", "Server not configured", "");
                return "Server not configured.";
            }
            try
            {
                using (var client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(5);
                    var response = await client.GetAsync(new Uri(server, "/api/remote-tray/hello"));
                    response.EnsureSuccessStatusCode();
                    var root = JsonObject.Parse(await response.Content.ReadAsStringAsync());
                    if (Read(root, "program") != "PAFPlayer" || !root.GetNamedBoolean("official", false) ||
                        string.IsNullOrWhiteSpace(Read(root, "identity")))
                        throw new InvalidOperationException("Target is not the official PAFPlayer instance.");
                    var state = root.GetNamedObject("state");
                    if (Read(root, "version") != Read(state, "version"))
                        throw new InvalidOperationException("Official instance changed during status read.");
                    var metadata = state.GetNamedObject("metadata", new JsonObject());
                    var track = state.GetNamedObject("track", new JsonObject());
                    string title = Read(metadata, "title");
                    if (title.Length == 0) title = Read(track, "filename");
                    if (title.Length == 0) title = "PAFPlayer idle";
                    string artist = Read(metadata, "artist");
                    string playback = state.GetNamedBoolean("paused", false) ? "Paused" :
                                      state.GetNamedBoolean("playing", false) ? "Playing" : "Waiting";
                    string lyric = Read(state, "lyric");
                    Publish(title, artist.Length == 0 ? playback : artist + " · " + playback, lyric);
                    return playback + ": " + title + (artist.Length == 0 ? "" : " — " + artist);
                }
            }
            catch (Exception error)
            {
                Publish("PAFPlayer offline", "Check the official player server", "");
                return "Could not read official player: " + error.Message;
            }
        }

        private static string Read(JsonObject value, string name)
        {
            IJsonValue item;
            if (!value.TryGetValue(name, out item) || item.ValueType != JsonValueType.String) return "";
            return item.GetString().Trim();
        }

        private static void Publish(string first, string second, string third)
        {
            var tile = TileUpdateManager.GetTemplateContent(TileTemplateType.TileWide310x150Text03);
            var visual = (XmlElement)tile.GetElementsByTagName("visual")[0];
            visual.SetAttribute("hint-lockDetailedStatus1", Clip(first));
            visual.SetAttribute("hint-lockDetailedStatus2", Clip(second));
            visual.SetAttribute("hint-lockDetailedStatus3", Clip(third));
            tile.GetElementsByTagName("text")[0].InnerText = Clip(first + "  " + second);
            var notification = new TileNotification(tile)
            {
                ExpirationTime = DateTimeOffset.Now.AddMinutes(40)
            };
            TileUpdateManager.CreateTileUpdaterForApplication().Update(notification);
        }

        private static string Clip(string value)
        {
            value = (value ?? "").Replace('\r', ' ').Replace('\n', ' ').Trim();
            return value.Length > 120 ? value.Substring(0, 120) : value;
        }
    }
}
