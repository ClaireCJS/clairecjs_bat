# PAFPlayer Lock Screen — V510

**Activation remains blocked on DEMONA. Do not treat this release as a verified
working lock-screen display.** See the [diagnosis, architecture, configuration,
verification procedure and Microsoft references](../docs/windows-lock-screen.md).

The V510 desktop publisher preserves the existing lock-screen package/app IDs.
It reads the official player's local status API, verifies its identity on every
poll, publishes real tile text plus playing/paused/offline badges, and offers an
explicit publishing switch. It sends no playback commands and defaults to
`http://127.0.0.1:666`. UAC is neither required by the installer nor changed.

Run `python -B -X utf8 lockscreen_installer.py --check` for a read-only artifact
and registration check. Omit `--check` to install and test actual activation and
publication. The installed identity points at `dist/v510/runtime`; keep it there.
The current PC fails the activation gate with `0x80270254`, despite healthy
package enumeration. Calculator UWP activation succeeds with the same UAC setting.

Build with `build_desktop.ps1` using .NET Framework's x64 C# compiler and Windows
SDK 26100. The script creates a unique output folder and refuses overwrite.
It uses the documented external-location manifest and MakeAppx `/nv` because
the EXE is outside the identity package. Sign both EXE and MSIX with the matching
publisher certificate after making verified sibling backups; never distribute
the private key. Update version and pinned installer hashes for a new release.

`StatusUpdaterTests.cs` / `test_desktop.ps1` test the actual status implementation.
`run_regression_checks.py` runs related Python tests with isolated, retained
fixtures. Results go directly to `../tests/reports`.

`App.xaml`, `MainPage.xaml`, `BackgroundRefresh.cs`, `Package.appxmanifest`, and
the UWP projects are retained as historical/reference source, not the V510 build.
The V509 MSIX and older releases are preserved. Diagnostic candidates and the
verified registration-recovery data are retained locally for investigation.
`repair_registration.ps1` is a specific recovery experiment, not a routine
installer step: recreating registration already failed to repair this PC's cache.
Do not run it repeatedly expecting a different result.
