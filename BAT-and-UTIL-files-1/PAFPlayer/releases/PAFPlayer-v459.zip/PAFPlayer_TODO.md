# PAFPlayer TODO

Active follow-up items only. Completed work from the earlier V416 review pass
was pruned from this checklist and remains documented in the PAFPlayer
changelog/release notes.

## V459 complete song endings — September 28, 2026

- [x] Fix source-duration limits being applied after tempo processing. At 0.9×,
      this lost roughly the last 10% of each native/buffered playback segment.
- [x] Confirm the ending survives actual FFmpeg decoding at slower, normal and
      faster speeds, including seeks and 7.1/96-kHz/24-bit output.
- [x] Guard natural completion until queued PCM and every output endpoint finish.
- [ ] Confirm complete audible endings during normal transitions after restarting
      into V459; automated checks decode PCM without opening an audio device.

## V458 memory and regression repairs — September 28, 2026

- [x] Bound retained cover artwork by both count (24 tracks) and payload (64 MiB),
      evict associated source metadata, and preserve oversized-cover display.
- [x] Coalesce popup title/artwork updates, discard stale artwork-loader results,
      and yield to Tk while processing commands so presentation work cannot pile up.
- [x] Fix disabled-progress history-report crashes, incomplete console writes,
      inconsistent release metadata, and the legacy entry point loading old code.
- [x] Add a complete isolated test runner and on-demand `/api/runtime-diagnostics`.
- [x] Reproduce cover/title retention with accelerated workloads and compare
      2,400 moving artwork frames against V457 without changing rendered output.
- [ ] Complete reconciliation of historical HUD/UI/render-contract tests. The
      full V458 release report lists every remaining failure; no blanket skips.
- [ ] Verify hours-long playback with console, artwork popup, and floating lyrics
      together after restarting into V459 or later; accelerated checks are not that soak.
- [x] Investigate missing song endings: fixed the tempo/source-duration mismatch
      in V459 and verified existing output-buffer drain behavior.

## Emojimaxx cleanup and normalization

- [x] Remove the `true`/`false` Emojimaxx substitutions.
- [x] Remove the `aren’t` Emojimaxx substitution.
- [x] Remove the `’swear’` Emojimaxx substitution.
- [x] Remove the `’good’` Emojimaxx substitution.
- [x] Remove the `’bad’` Emojimaxx substitution.
- [x] Remove the `’starting’` Emojimaxx substitution.
- [x] Remove the `’ending’` Emojimaxx substitution.
- [x] Remove the `’welcome’` Emojimaxx substitution.
- [x] Remove the `’murphy’` Emojimaxx substitution.
- [x] Remove the `’spelling’` Emojimaxx substitution.
- [x] Remove the `’drinking’` Emojimaxx substitution.
- [x] Remove the `’beast’` Emojimaxx substitution; no active mapping remains.
- [x] Review and correct the `’ladies’` Emojimaxx mapping; it should not reuse
      the same substitution as `’men’`.

## External playback loudness matching (2026-09-24)

- [x] While automatically paused for browser/VLC/Winamp or other external
      playback, measure aggregate perceived loudness of its non-silent portions.
      On automatic resume, raise or reduce PAFPlayer's actual volume percentage
      to match what was just heard. Reflect the changed volume in console and web
      controls; do not implement this as a hidden, separate gain adjustment.
- [x] Account for Windows master/output volume so a shared master-volume increase
      does not cause a second boost. Compare external playback with the music's
      expected output loudness, including ReplayGain and current player volume.
- [x] Design reliable source/output selection, silence gating and a stable
      measurement window; avoid unrelated notifications or excluded Nest camera
      streams contaminating the measurement. Handle insufficient samples and
      different output devices explicitly. Use the existing resume fade to reach
      the resulting volume smoothly. These are planning requirements, not yet
      implemented; exact measurement and persistence policy remain to be decided.

## Learned-tag normalization

- [x] When marking a pattern learned, omit spaces, parentheses, and apostrophes
      from the generated regex; use `.*` as the separator wildcard. For example,
      convert `^Mom.*Goddess \(live\) \(youtube\-rip\):learned` to
      `^Mom.*Goddess.*live.*youtube\-rip:learned`.
- [x] Ensure a generated learned regex never ends with `.*`; the final token
      must remain a concrete, escaped selector component.

## Developer’s Choice persistence

- [x] When reporting `Saved Developer’s Choice to PAFPlayer.dcc`, print the
      complete destination path, not only the filename.
- [x] If `C:\BAT\PAFPlayer.py` exists, always save the Developer’s Choice file
      alongside that canonical script under `C:\BAT`, even when the currently
      running PAFPlayer instance came from a different path.
- [x] Before replacing the existing `.dcc` file, create and verify the sibling
      backup using the established replacement-backup naming formula, and say
      so explicitly in the confirmation text.

## Experimental CUDA live benchmarks

- [x] Add `--gather-cuda-benchmarks`: run an opt-in live A/B experiment that
      alternates CPU and CUDA paths in approximately 10-second windows,
      including floating-lyrics rendering, and writes a separate benchmark log.
      Keep the stable CPU renderer visible initially; capture matching live
      state snapshots for shadow comparison and record warm-up, frame latency,
      missed frames, transfer time, GPU time, and end-to-end presentation time.
- [x] Add `--analyze-cuda-benchmarks`: read the separate CUDA benchmark log and
      summarize paired CPU/CUDA results by workload, including median and
      worst-case latency, correctness mismatches, fallback reasons, and whether
      CUDA actually improves floating-lyrics rendering end to end.

## Experimental web-karaoke EmojiMaxx solutions

- [x] When Web Karaoke has EmojiMaxx enabled, add an experimental
      **Show teeny solutions** checkbox beside it. When checked, render the
      EmojiMaxx solution centered directly underneath each emoji in a very
      small size; keep the normal karaoke layout and emoji alignment intact.
- [x] When **Show teeny solutions** is checked, reveal a slider labeled
      **Teeny solution size**, ranging from 5% through 150% and defaulting to
      20%. Hide or disable the slider when the checkbox is unchecked, persist
      the choice consistently with the other web-karaoke settings, and keep the
      feature explicitly experimental.

## Experimental web and integration features

- [x] Allow dragging local media files and folders onto the web interface to
      queue them next. Intercept drag/drop without navigating or reloading the
      page. When the browser is not local, optionally upload dropped media into
      a temporary managed area and queue the uploaded files.
- [x] Add a Security section to web configuration with an upload/remote-drop
      checkbox disabled by default on new installs, but enabled by default when
      the username is `claire` or the machine name is one of `thailog`,
      `demona`, `wyvern`, or `goliath`. Store those four machine names in one
      shared code array and reuse it wherever this policy is needed. Enforce
      size, type, filename, path, cleanup, and authorization limits server-side.
- [x] Add an experimental live log viewer to the web interface, with bounded
      streaming, level/category filters, pause/resume, search, and safe redaction
      of paths, credentials, and uploaded-file details.
- [x] Add optional Discord Now Playing integration with explicit opt-in,
      token/webhook protection, connection diagnostics, rate limiting, and clear
      handling for private/local tracks.

## Missing-file repair

- [x] Add a guided, non-destructive missing-file repair workflow for playlists
      and queue entries. Show the missing path and candidate replacements, using
      normalized filename, extension, size, duration, metadata, fuzzy similarity,
      and known identity/hash evidence to rank matches.
- [x] Support original-parent, configured-library, user-selected, and optional
      recursive search roots; separate high-confidence matches from ambiguous
      candidates and require approval for replacements.
- [x] Rewrite playlist paths atomically while preserving encoding and line
      endings, and create the established sibling replacement backup first.
- [x] Write the old path, replacement path, confidence, evidence, and timestamp
      to the normal PAFPlayer log file only; do not create a separate repair
      report file unless explicitly requested later.
- [x] Provide dry-run, per-item approval, playlist-only, and batch repair modes.

## Folder monitoring

- [x] Add an opt-in `--monitor PATH` command-line option, repeatable for more
      than one folder, such as `--monitor C:\mp3\new`.
- [x] Monitor new/changed/renamed supported media with debounced events, wait
      for copied files to become stable, ignore temporary/hidden/backup files,
      and persist monitor state to avoid repeated imports after restart.
- [x] Provide monitor modes for indexing only, adding to a selected playlist,
      or adding to the general library; keep removals non-destructive by default.
- [x] Expose pause/resume, scan-now, dry-run preview, recent actions, and clear
      logging for imports, skips, renames, errors, and ignored files.

## Song renderer and render-book preview

- [x] Add a song-renderer workflow that renders each sung lyric line together
      with the corresponding visualizer/artwork state at the correct timestamp.
- [x] Assemble the rendered images into a self-contained webpage that flows
      like a book, then open it automatically for visual review.
- [x] Add a command-line mode that emits the rendered images, prompts whether
      to save them as a numbered image sequence, and allows editing the filename
      prefix before saving.
- [x] Keep rendering deterministic enough for review, include track/line/time
      context, avoid changing live playback state, and clean up temporary output
      safely when the user declines to save.

## Web playlist editing

- [x] Expand the web playlist panel into a real queue editor: drag-reorder rows,
      multi-select, remove, play next, play after current, move top/bottom, and
      undo recent queue changes.
- [x] Distinguish current track, explicit play-next queue, shuffled membership,
      monitored imports, uploaded files, and missing entries; add filtering and
      playlist search.
- [x] Support saving the current queue as a new playlist, playlist diff/history,
      server-confirmed optimistic updates, conflict handling, and live updates
      without page reloads.
- [x] Show why a shuffled track was selected and provide safe repair/remove
      actions for missing files without deleting audio files.

## Terminal cleanup

- [x] Restore the terminal cursor color to its normal value during final
      shutdown/cleanup, including error and interrupted-exit paths.

## Seek responsiveness

- [ ] Fix repeated right-arrow fast-forward seeks so every accepted keypress
      increases the pending seek distance cumulatively, even while an earlier
      seek or audio restart is still being processed. There must be no temporary
      unavailable/debounce period; rapid and held keypresses should remain
      responsive and apply in order without losing seek requests.

## Web configuration navigation

- [x] Fix web-config scroll tracking so the final tab/section becomes visibly
      highlighted when its content is at the bottom of the page.
- [x] Make every web-config tab clickable and have clicks scroll/focus the
      corresponding section while keeping the active highlight synchronized
      with both clicks and scrolling.

## Web configuration labels and karaoke controls

- [x] Rename the web-config tabs: `Progress` → **Progress Bar**, `Alerts` →
      **Console Alerts**, and `Page Background` → **Webpage Background**.
- [ ] Add EmojiMaxx enable checkboxes to Floating Lyrics and artwork pop-up
      karaoke, with buttons in each surface to open the extended EmojiMaxx
      configuration.
- [ ] Keep the checkbox state and extended-configuration controls synchronized
      across console karaoke, web karaoke, Floating Lyrics, and artwork pop-up
      karaoke without forcing a page reload.

## Console Warnings: non-default speed reminder

- [ ] Add a Console Warnings checkbox controlling a reminder for playback speed
      changes. When speed has remained away from 1× for 30 minutes, show a
      pop-up asking whether to restore 1×.
- [ ] Hide an unanswered reminder after 5 minutes, then repeat the reminder
      every 30 minutes for a maximum five-minute visible window while speed
      remains non-default. Reset/cancel the reminder schedule when speed returns
      to 1× or the user answers it.
- [ ] Ensure the warning is non-blocking, does not interrupt playback, respects
      modal/input ownership, and persists its enabled/disabled setting with the
      other Console Warnings preferences.

## Web and artwork UI polish

- [x] Make the web top frame slightly taller/larger while preserving responsive
      layout and usable space for the player content.
- [x] Make the web volume control wider so it provides finer visible granularity.
- [ ] Put a clear karaoke-display on/off switch directly on the artwork pop-up.
- [x] Keep a 5px border visible around the artwork pop-up at all times, not only
      while the pop-up has focus.

## Additional EmojiMaxx cleanup

- [x] Remove the `’scum’` Emojimaxx substitution.
- [x] Remove the `’cared’` Emojimaxx substitution.
- [ ] Remove the `’hated’`, `’maked’`, and `’made’` Emojimaxx substitutions.

## HUD shortcuts and glyph parity

- [x] Fix the intermittent `Ctrl+Alt+/` shortcut when ReplayGain and effective
      tags are added to the HUD; make `Ctrl+H` invoke the same HUD toggle.
- [ ] Fix the pentagram glyph so it renders in Floating Lyrics as it does in the
      console, including the same font/EmojiMaxx and fallback handling.

## Karaoke style cleanup

- [ ] For each applicable karaoke surface, remove Fraktur Clean, Fraktur
      Framed, all other Clean styles, and Script as a duplicate of Cursive.
- [ ] Add a Spaced modifier checkbox applicable to any style, replacing separate
      spaced/clean variants.
- [ ] Add a Framed modifier checkbox that reveals a selector for framing
      treatments, replacing separate framed styles.
- [ ] Add one new karaoke style for evaluation after the modifier cleanup.

## Windows / Lock Screen configuration

- [x] Add a lower web-configuration section named **Windows / Lock Screen**
      with its own tab. Clicking the tab must scroll directly to the section;
      scrolling naturally into it must select the tab. Do not alter the console
      visualizer merely to add this configuration section.
- [x] Add a master **Windows media / lock-screen integration** switch. Default
      it ON only if the implementation proves reliable; otherwise default it
      OFF with a clear unavailable status.
- [x] Add a **Show album artwork** switch, default ON, plus an artwork-source
      selector with **Primary cover**, **Current PAFPlayer artwork**, and **No
      artwork** choices.
- [x] Add **Lock-screen artwork brightness**, a 0–100% slider defaulting to
      100%. Apply it only to artwork published to Windows; never modify source
      artwork or other PAFPlayer artwork. Disable the slider when integration is
      disabled, album artwork is disabled, or the source is **No artwork**.
- [x] Add independent switches for Windows Play/Pause, Previous/Next, and
      seeking controls, defaulting ON where reliable.
- [x] Add a lock-screen title-format selector with **Artist — Song**,
      **Song — Artist**, **Song only**, and **PAFPlayer: Artist — Song** presets.
      Do not misuse or rewrite metadata fields to fit the lock-screen title.
- [x] Add switches for **Publish album name** and **Publish timeline / position**.
- [x] Add a compact live status line showing Active/Disabled/Unavailable plus a
      useful short reason, published title, and current artwork brightness when
      applicable.

## Single-instance queue handoff

- [x] When launching PAFPlayer while another instance is already running, hand
      the command to the original instance instead of starting competing
      playback. If the argument is an audio file, queue that file next.
- [x] If the argument is a folder, queue the supported audio files from that
      folder according to the normal folder-queue policy.
- [x] If the argument is a regex, run it against the music-collection filelist
      and queue all matching songs in deterministic filelist order.
- [x] If the argument is a playlist, load that playlist in the original
      instance according to normal playlist semantics.
- [x] Validate every argument before handoff: nonexistent files, folders,
      playlists, and regex targets/filelists must produce a clear error rather
      than silently doing nothing or starting a second player.
- [x] Make this the general supported way to queue files, folders, regex
      matches, and playlists into the already-running playlist, with clear
      acknowledgment/error reporting to the launching process.

## Floating Lyrics emoji outline

- [ ] Apply the configured black border/outline treatment to emoji in Floating
      Lyrics as well as ordinary letters, keeping thickness, color, shadow, and
      related styling consistent with the existing lyric configuration.

## URL and artwork-popup help

- [ ] Make the **Go to Last.fm** button open its URL in a new browser tab, and
      apply the same new-tab policy consistently to every URL-opening action.
- [ ] Add an album-art-popup mouseover/help tooltip explaining left click, right
      click, double click, and triple click. Explicitly mention that triple click
      opens the image in the default image viewer; consider detecting/reporting
      the configured default viewer during startup after playback begins.

## Progress-bar coloring and beat overlays

- [ ] Add 16 progress-bar coloring modes in addition to existing appearance
      types. Keep the current whole-bar ROYGBIV-by-song-progress treatment as a
      default/favorite, and add at least rainbow left-to-right and American-flag
      coloring: blue with white dots for the first 20%, red/white stripes for
      the remaining 80%.
- [ ] Add invert-order and invert-palette checkboxes without changing saved mode
      IDs or underlying configuration semantics.
- [ ] Expand beat-reactive illumination so a beat treatment can apply a coloring
      mode as a gradient overlay on another progress-bar coloring mode, such as
      rainbow base plus American-flag beat overlay.

## Control labels and layout

- [ ] Show the pause reason for `Status: Paused` only on mouseover. Rename
      `Volume:` to `Vol:`, `Output Rate` to `Output`, and avoid duplicated wording
      such as `Repeat: Repeat playlist` → `Repeat: Playlist`.
- [ ] Order the status bubbles as: first existing bubble, Last play second,
      volume third, and balance last.
- [ ] Move **Download missing art** to Broken Experimental.
- [ ] Redesign the custom curve editor so it clearly explains frequency spreads
      and its controls make sense for that purpose.

## Dropdown and cycle controls

- [ ] Add a cycle button to beat treatment and every dropdown that has Fav/Dev
      controls. Left click cycles favorites; right click cycles all values;
      triple click returns to the default. Add a tooltip explaining all actions.
- [ ] Reorder every dropdown dynamically with the default first, followed by
      favorites in favorite order, without changing saved IDs or config values.

## Artwork, tags, and overlay controls

- [ ] Fix **album art on sides** when karaoke bars are displayed; prevent the
      karaoke-bar renderer from erasing the side artwork cells.
- [ ] Move tags into their own section and tab at the very bottom of web config;
      keep it expanded by default and remove its collapse button.
- [ ] Make every **Always On Top** control a checkbox rather than a button.
- [ ] Standardize artwork pop-up and Floating Lyrics controls in this order:
      Configure; Always On Top checkbox; Bring to Top; Bring to Center;
      EmojiMaxx; De-censor profanity. Bring to Top should appear greyed out when
      Always On Top is checked but must remain operational if invoked.

## Web tooltip formatting

- [x] Fix shuffle and other button tooltips so paragraph breaks render as a
      blank line rather than displaying the literal characters `\n`. Use two
      newline separators where a blank line is intended, and determine whether
      the bug is caused by escaping/serialization, HTML attribute rendering,
      or the tooltip renderer treating text literally.

## Console karaoke throb controls

- [x] Under Console Karaoke, add a throb-speed slider for the act/artist name
      with a neighboring value box that displays the current value and also
      accepts manual numeric typing for users who dislike slider precision.
- [x] Add the same slider-plus-editable-value-box control for song-title
      throbbing speed. Validate and clamp typed values exactly like slider input,
      persist both settings consistently, and keep the controls synchronized.

## Artwork seam experiment controls

- [x] Make the artwork-seam experiment's default/favorite/cycle button match
      the visual styling of the other controls, and change its title to
      **Artwork seaming**.
- [x] Move the artwork-seam control back into the working Experimental section.
- [x] Move **album art onto karaoke** into Broken Experimental.
- [x] Keep **album art onto karaoke sides** in the experimental area but mix
      yellow into its control color because the feature is not yet settled.

## Console artwork row corruption — implementation handoff (2026-09-22)

- [x] Fix large Unicode console writes that corrupt half-block characters and
      shift artwork/visualizer rows sideways. Suitable for a bounded Luna
      implementation using the diagnosis and verification below.

**Diagnosis:** Pixel comparison with the source cover found two screenshot rows
shifted right by 22 pixels (two terminal cells). Three replacement-character
diamonds replace one half-block. A hidden-console test on the installed Anaconda
Python 3.10.9 reproduced exactly this conversion: `▌` becomes `���` in a large
write, adding two cells. The same content written and flushed in 4,096-character
chunks was exact. This is the known Python Windows console Unicode chunking bug:
https://github.com/python/cpython/issues/82052

**Relevant code:** `play_audio_file.py`: `write_console()` and the nested
`write_visualizer_console()`. The visualizer batches ANSI artwork rows into
large strings; its row-delta cache can retain a corrupted row until it changes.
The inspected V427 and V429 renderer, artwork sampling, and visualizer writer
functions were identical. The primary cause is output corruption, not the
colour-blending calculation.

**Implementation scope:** Bound large text writes at Unicode-safe boundaries
while keeping the existing console lock held for the complete logical payload.
Keep character and ANSI/control-sequence order intact, preserve synchronized
output markers, and prevent buffering from recombining chunks into an unsafe
large write (the working reproduction flushed each chunk). Preserve the fast
path for short writes and redirected-output contents. Audit the optional direct
UTF-8 writer and partial-write handling; do not blindly decode binary DRCS/SIXEL
payloads. Keep transport accounting per logical frame. Preserve audio priority,
the existing console lyric cadence, artwork quality, and requested visualizer FPS.

**Acceptance checks:** Reproduce with `"A" * 15000 + "\u258c" + "B" * 14999`
through a real `_WindowsConsoleIO` stream opened on `CONOUT$` in a hidden test
console; a pipe/StringIO alone does not exercise this bug. Read back the private
console buffer: before the fix there are three U+FFFD characters and no half-block;
afterward there must be one half-block, no replacements, and exact text/cursor
placement. Include multi-byte glyphs near chunk boundaries, ANSI payloads,
redirection, and short writes. Repeat with representative artwork/visualizer
output and measure render/transport time and FPS to check chunking overhead.
Do not interrupt the user's music or modify their settings for testing.
Follow the existing verified sibling-backup and C:\BAT disclosure rules.

## Documentation and maintenance

- [x] Keep the centralized documentation under `C:\sandbox\docs\PAFPlayer`
      synchronized with current behavior and release notes.

<!-- Completed V416 checklist items were intentionally pruned; see the
     changelog and release notes for their historical record. -->
<!--
- [x] Review/replace or remove `yelling` (currently 🤙).
- [x] Remove `flick` and `flicking` (flicking currently 🍁).
- [x] Remove `singing`.
- [x] Remove `faced` (🙂), `face` (🙂), `faces` (🙂), and `facing` (🙂).
- [x] Remove `confront` (🥇) and `confronted` (🥇).
- [x] Remove `encounter` (🤝) and `encountered` (🙈).
- [x] Remove `stare` (👓), `stared` (⭐), and `opposite` (↔️).
- [x] Remove `stuck` (😛), `trapped` (🪤), `jammed` (🍓), `blocked` (🚫), `stranded` (🏝️), and `stalled` (🛑).
- [x] Remove `cream` (🍦).
- [x] Keep `grew`, but change its substitution from 🪴 to 🌱.
- [x] Keep `wish` and `pray`.
- [x] Make `praying` use `pray` + `ing` rather than a separate mapping; review similar inflected forms such as `speaking`, `talking`, `licking`, `worshipping`, and `flicking` for the same base-word-plus-suffix rule.
- [x] Remove `single` (❜), `double` (🧬), and any future multiplier substitutions (`triple`, `quadruple`, etc.).
- [x] Remove `slice` (🍕).
- [x] Change `30` from the clock face 🕜 to `㉚` (U+325A CIRCLED NUMBER THIRTY).
- [x] Review `broke` (🪓); likely remove the generic substitution while retaining `broken` (💔).
- [x] Change `person` from 🧑 to 👤.
- [x] Remove `teenage` (🐣); review related age-category words such as teenager, adolescent, youth, young, minor, juvenile, kid, and child.
- [x] Continue reviewing overly literal/general verb substitutions, including similar words suggested during cleanup.

## Console input and playback

- [x] On the console HUD, suppress a trailing `/` when displaying a URL.
- [x] Make `J` invoke the same console action as `Insert`.
- [x] Clarify the J/Insert menu: Enter enqueues the selected song(s); Shift+Enter jumps to the selected song.
- [x] Fix Ctrl+Alt+Left/Right seeking so rapid-fire or held seeks are accepted without the current restart/debounce lag.
- [x] Fix the currently-sung-line rendering so circled digits such as `❷` receive the Windows Terminal safety space, matching other lyric lines.
- [x] Keep the Windows Terminal-only safety space after the generated “up” arrow substitution; do not add it to ordinary output or literal arrows.
- [x] Ensure `play` (▶️) does not receive an unnecessary terminal-only trailing space.

## Artwork and ANSI rendering experiments

- [x] Add an Experimental/Broken web-interface selector for artwork seam/rendering strategies:
  - `0`: use none (default for new installs)
  - `1`: full-cell glyphs with one-column overlap
  - `2`: seam-cleanup pass that fills one-cell vertical gaps
  - `3`: prefer SIXEL/bitmap artwork output
  - `4`: aspect-ratio-aware Chafa symbol mode
  - `5`: avoid mixing DRCS and ordinary Unicode block glyphs in artwork rows
- [x] Keep the selector at the bottom of the Experimental/Broken section and persist it.
- [x] Investigate the thin vertical divider lines in ANSI artwork caused by glyph painted bounds, terminal cell aspect ratio, Chafa quantization, and mixed Unicode/DRCS cursor advances.

## Web visualizer and controls

- [x] Correct Shuffle icon ordering: shuffle symbol first, then history/random indicator.
- [x] Correct Repeat icon ordering: repeat-loop icon first, then folder/playlist type indicator.
- [x] Continue verifying Repeat/Shuffle labels, tooltips, enabled/disabled visuals, and state synchronization.

## V416 additional fixes

- [x] Use consumed-sample timestamps for buffered audio and share source position across presentation surfaces.
- [x] Precompute progress pulses, send future browser spectrum frames, and provide popup/floating windows the complete lyric timeline.
- [x] Clear stale/silent beats; keep web/popup clocks advancing when the console is busy.
- [x] Protect native clock reads against output-device closure at EOF.

## External playback priority (September 20 request)

- [x] Automatically pause for VLC, Winamp, and browser media including YouTube; resume only automatically paused playback after competing media stops.
- [x] Preserve manual Pause/Play intent and handle multiple players, brief gaps, monitor failures and track transitions.
- [x] Resume through a 15-second audio fade by default, with a top-of-code default and persisted duration/enabled controls in web Playback settings.

## Provenance

This list consolidates requests made during the PAFPlayer development conversation through 2026-09-13. “Current emoji” annotations reflect the source mapping when it was inspected; “none” means no mapping was found at that time.
-->
