# PAFPlayer documentation

This directory is the project-local documentation location. Behavioral or
feature changes, new command-line invocations, keyboard shortcuts, and web-
configuration sections must update the relevant documentation here in the
same change.

## Current release: V486

- [Release notes and validation](../releases/PAFPlayer_v486_release_notes.md)
- [Rendering performance and lyric transitions](performance-v486.md)
- [Playback controls](playback-controls.md)
- [Web configuration and playback](web-config-playback.md)
- [Main manual and historical coverage](../PAFPlayer.md)

Source, numbered releases, documentation, archives and checksums are maintained
in the sandbox at `C:\codex\clairevironment\bat\PAFPlayer`. Deployment outside
that sandbox is a separate step requiring an explicit request.
