# Web configuration and playback

- Playback controls are arranged as: device/output, volume and output controls, bass boost/reduce while playing, external-media/resume controls, Bass Reduction while Locked, then visualizer input.
- The locked-bass checkbox enables its reduction slider. While Windows is unlocked, changing this checkbox or its amount saves the setting without restarting audio. A segment is rebuilt only when the effective bass gain changes; audible changes use the short interactive preroll. See [V485 performance and bass controls](performance-v485.md).
- Library roots identify folders PAFPlayer may scan for indexing, missing-file repair candidates, and monitoring. Defining a root does not move or upload files.
- Missing-file repair has an explicit enable switch.
- Discord is a normal configuration tab. Its setup help opens in a new browser tab; the webhook is stored in Windows Credential Manager.
- Logs is the final configuration tab.

Progress Bar style remains distinct from color: style selects glyph appearance, while color selects palette/treatment.
