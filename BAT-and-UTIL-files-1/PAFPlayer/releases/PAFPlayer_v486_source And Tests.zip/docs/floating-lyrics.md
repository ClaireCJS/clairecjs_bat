# Floating Lyrics positioning

The Floating Lyrics **Bring to Center** and **Center Over Visualizer** actions
temporarily use the editable window state while repositioning the window, then
restore the normal transparent, borderless lyric state after the move. The
button-driven move is tracked separately from mouse dragging so a focused
button action does not leave a flashing visible edit border around the lyrics.

Mouse-driven movement and intentional focus/edit interactions retain their
existing visible editing chrome.

## V486 transition scheduling

New cues cancel the previous color-animation timer before rendering. A full
animation interval follows the initial upload, avoiding an immediately due recolor.
Text fonts are cached by pixel size (256 entries); duplicate measurements within
an autosize candidate are reused. Typography and bitmap output remain unchanged.
See [performance validation and limitations](performance-v486.md).
