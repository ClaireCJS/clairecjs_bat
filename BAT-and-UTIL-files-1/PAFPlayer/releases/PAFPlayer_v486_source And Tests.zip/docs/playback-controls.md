# Playback control notes

## Bass Reduction while Locked

The Playback section of the web configuration contains a `Bass Reduction while Locked` checkbox and a dependent `Bass reduction amount while locked` slider. The slider is disabled until the checkbox is enabled and ranges from 0–100%.

The setting is applied through the decoder's bass filter while Windows is locked. PAFPlayer checks the lock state once per second and rebuilds the current segment only when the effective bass gain changes. Enabling the checkbox or editing its amount while unlocked saves the preference without interrupting playback. Changing the boost amount while boost is disabled also avoids a restart. Audible changes use the short interactive preroll; unlocking restores the normal bass settings when needed.

V485 reads only the four bass settings for this check and prevents a direct control change from triggering a second restart through the lock monitor. See [performance details and validation limits](performance-v485.md).

## Floating Lyrics title period

`Display song title for first` is a floating-point number of seconds (0–60, with 0.01-second web precision). The canonical persisted setting is `FloatingLyricsTrackIntroSeconds`; older installations using `FloatingLyricsTrackIntroMs` are read as a migration fallback. Web-console changes are saved as seconds and immediately published to the running player.
