# Windows 10 lock-screen status — V516

PAFPlayer now manages the optional publisher: it starts the installed Windows
app quietly, supplies the local server and current official-instance identity,
restarts failures with a 30-second backoff, and stops it when disabled or when
PAFPlayer exits. The source is included in PAFPlayer.py's application bundle;
there is no additional Python module to copy alongside the player.

**Visible native lock-screen status is still unconfirmed.** V516 fixes the
reproduced oversized-environment failure in V515 automatic startup. It does not claim to have established the cause
of every earlier blank-screen report. Successful publication, Settings selection,
Appx status Ok and background registration are not visual proof.

## Enable and use

Install the signed companion once, under the Windows account that plays music:

```powershell
& C:\ProgramData\anaconda3\python.exe -B -X utf8 lockscreen\lockscreen_installer.py --check
& C:\ProgramData\anaconda3\python.exe -B -X utf8 lockscreen\lockscreen_installer.py
```

The installer validates the package and executable hashes, certificate signer,
manifest, real interactive activation, publication receipt and background COM
activation. `--check` is read-only. The executable and assets are included in a
self-contained MSIX; there is no external runtime directory. The current package
version is `516.0.0.0`, and its display name is **PAFPlayer Lock Screen V516**.

In PAFPlayer's web configuration, **Windows Lock Screen → Enable lock-screen song
status** controls publishing. Fresh installations default to off. An explicit
saved companion preference is migrated, with a saved PAFPlayer choice taking
precedence. Once enabled, no companion window needs to be opened manually.
The running player was verified as V515 and was not restarted. The corrected
launcher is loaded when V516 is next launched. An independent publisher was restored
for that existing playback session after the live tests.

In Windows Settings → Personalization → Lock screen, choose the versioned app:

- **Choose one app to show detailed status:** song, artist/playback state, lyric.
- **Choose which apps show quick status:** playing, paused, idle or offline badge.

Both may be selected. They serve different purposes. Windows owns the picker;
PAFPlayer cannot silently choose a status slot. The original unversioned app is
a different identity. The Recovery family and `!App` ID remain unchanged from
V511–V515, preserving selection and registration compatibility.

## V516 launch failure and fix

The live V515 server reported publishing enabled but the launcher returned an
incorrect install-package message. Its installed signed package was valid.
Reproducing the child launch using the actual player's environment exposed
PowerShell Add-Type's compiler error: the environment block was 142043 bytes,
larger than its reported 65535-byte maximum. This explains why launching from
the separate diagnostic shell succeeded while automatic player startup failed.

Only the activation child now receives an allowlist of Windows/profile/temp
variables plus Windows tool paths. Its environment is approximately 1 KB.
The player's own environment and custom shell configuration remain unchanged.
The installer uses the same isolation. Windows failure text is captured as UTF-8
and surfaced in the setting status instead of an unconditional reinstall message.
The corrected launcher was tested with that same live player's environment and
working directory: headless activation, official-player publication and graceful
shutdown passed. The original failure and corrected results are retained in
tests/reports/v515-player-environment-* and v516-player-environment-*.

## Architecture and playback isolation

`lockscreen/PAFPlayer_lockscreen.py` is bundled into the single-file player.
One daemon controller starts after the web server binds. It checks official
instance ownership and saved settings every five seconds; all package discovery,
signature verification and activation happen on that worker, never in an audio
callback or visualizer frame. Web-server shutdown signals it without waiting for
Windows. Optional startup failures are contained and shown in the setting status.

Windows must own a registered app identity for the selected tile and badge. The
player uses IApplicationActivationManager to start that identity with managed
arguments. A direct CreateProcess attempt against WindowsApps failed with
ERROR_ACCESS_DENIED on this computer; the supported activation API passed.
See Microsoft's [packaged application activation API](https://learn.microsoft.com/en-us/windows/win32/api/shobjidl_core/nf-shobjidl_core-iapplicationactivationmanager-activateapplication)
and [package identity guidance](https://learn.microsoft.com/en-us/windows/apps/desktop/modernize/grant-identity-to-nonpackaged-apps).

The separate .NET publisher owns the Windows notification APIs. It is headless
in managed mode, checks a uniquely named owner stop event and the launching
process, and clears its own tile/badge on normal stop. This also covers owner
exit after a crash. Existing notifications expire after 90 seconds if cleanup
cannot run. PAFPlayer sends no audio commands to manage this process.

The helper verifies `/api/remote-tray/hello` using GET only: `official=true`,
case-insensitive PAFPlayer names in root/state, matching nonempty versions and a
nonempty identity. Managed mode additionally pins that identity to the launching
official instance and accepts only a loopback address. It refuses another player
session. Network failure removes stale track data and publishes offline status.
Redirects, proxies, cookies and default credentials are disabled; responses and
timeouts are bounded. The helper never calls playback-command endpoints.

The five-second refresh does not activate the browser spectrum or decode artwork.
The new settings endpoint is loopback-only; mutations require the existing
workflow token and same-origin checks. Existing configuration IDs are unchanged.
`PAFPlayerLockScreenEnabled` is retained in player workflow settings and companion
JSON; `PAFPlayerServerUrl` is retained. `PAFPlayerManagedPublisher` is new private
companion metadata. The Windows background registration remains, but its timer
does not publish independently for a managed session after its owner has stopped.

## Diagnosis and Windows limitations

The original identity failed activation with `0x80270254`
(`E_APPLICATION_NOT_REGISTERED`) despite Appx status Ok. The Recovery identity
activates with UAC disabled. This is evidence against treating UAC as the sole
cause, but it does not prove native lock-screen rendering works.

At the start of this change the official V514 server was running while no
publisher process was present. Ninety-second notification expiry makes that a
real availability gap. V515 supplies automatic startup/restart and lifecycle
ownership. During later checks the independently running V515 helper persisted
and Windows recorded tile/badge deliveries every five seconds.

The earlier blank display while publication was active remains unexplained.
No supported evidence has established that UAC must be changed or that native
status is impossible with it disabled. UAC, Windows notification/privacy policies,
private notification databases and Windows registration caches were not modified.
A four-minute read-only process sampler recorded the publisher, but no new
user-confirmed lock cycle was returned, so it cannot establish renderer behavior.

Microsoft documents the [lock-screen background-task requirement](https://learn.microsoft.com/en-us/uwp/schemas/appxpackage/uapmanifestschema/element-uap-lockscreen)
and [Windows 10 COM task registration](https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.background.backgroundtaskbuilder.settaskentrypointclsid).
Registration/access and COM interface activation passed. Actual scheduled timer
execution remains separately unverified. Windows controls refresh, layout and
truncation; this feature is not a .scr screensaver, wallpaper overlay, SMTC media
panel or arbitrary drawing on the secure desktop. Native status cannot reproduce
the artwork-rich screensaver.

## Verification

- **123 focused tests passed:** 51 C# payload/network/identity tests and 72 Python
  installer, tray, lifecycle and real HTTP settings tests.
- **Prior comparison: 678 embedded tests ran on V515 and the immutable V514 baseline.** Each
  produced 614 passes, 51 failures and 13 errors, with identical failing test
  names. There were no newly failing tests in that comparison. This is not a clean
  full-suite pass: obsolete historical assertions and guarded database tests
  still need separate maintenance. Reports retain the actual failures. These
  678 tests were not rerun for V516: its main-player function/class bodies match
  V515 exactly; the change is confined to the bundled launcher and release constants.
- C# compilation, full MakeAppx validation, EXE/MSIX signatures and pinned package
  checks passed. The old obsolete-enum compatibility warning remains.
- Real V515 activation/publication ran under DEMONA\Claire in console session 1
  with `EnableLUA=0`. Headless managed launch, graceful stop and rejection of a
  wrong official identity passed twice. The receipt contained real song/lyric
  text and a playing badge. Neither receipt is proof of visible rendering.
- The source bundle matches its module. Previous releases were not overwritten;
  replacements used verified backups. `play_audio_file.py` was not modified.

Reports are directly in `tests/reports`, including the V515 focused regressions,
managed live checks, C# tests and V514 baseline comparison. Run
`lockscreen/run_regression_checks.py`, `lockscreen/test_desktop.ps1`, and
`lockscreen/run_embedded_v515.py` for isolated checks. Run
`lockscreen/verify_player_environment_v516.py <player-pid>` only in the interactive account; it briefly
replaces this companion for lifecycle testing and restores independent publishing.
It does not control or restart audio.

Manual verification: launch V516, confirm the Windows Lock Screen checkbox and
publisher status, select V516 in both Windows slots, then lock Windows yourself.
Check the clock-and-date wallpaper before dismissing it for password/PIN entry.
Check song changes, timed lyrics and playing/paused badges using normal player
controls. Disable the setting to check clearing, reenable to check automatic
restart, and close PAFPlayer to check helper exit. The agent does not operate or
capture the secure desktop. **Visible text/badges are the remaining acceptance
check; a blank screen keeps the rendering issue open.**

No literal `C:\BAT` paths were created, modified or deleted.
