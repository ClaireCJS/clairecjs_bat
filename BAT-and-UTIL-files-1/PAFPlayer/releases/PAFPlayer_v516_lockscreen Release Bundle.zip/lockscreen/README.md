# PAFPlayer Lock Screen V516

Fixes automatic launch from large music-shell environments without changing the
player's environment. Native visible rendering remains unconfirmed.

See the [architecture, controls and verification](../docs/windows-lock-screen.md).
Install the signed package in dist/v516 with lockscreen_installer.py.
Run run_regression_checks.py and test_desktop.ps1 for focused checks.
build_desktop.ps1 signs only with verified signing backups; releases are immutable.
