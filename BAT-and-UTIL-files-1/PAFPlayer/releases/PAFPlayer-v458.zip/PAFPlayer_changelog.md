# PAFPlayer changelog

## V458 — September 28, 2026

Bound cover-art retention and coalesce stale popup presentation work to prevent session growth. Repair partial console writes, noninteractive history reports, release identity, and legacy entry-point routing. Add full-suite discovery and on-demand memory diagnostics. The release notes report accelerated retention/frame measurements and the remaining historical test failures explicitly. [Validation and limits](PAFPlayer_v458_release_notes.md).

## V456 — September 25, 2026

Released the work already started from the V455 TODO pass: queue editing and single-instance handoff, managed drops/uploads, guided repair, folder monitoring, render books, teeny EmojiMaxx solutions, redacted live logs, opt-in Discord and CUDA experiments, Windows media settings (off by default), DCC backup/path reporting, cursor cleanup, throb persistence, and web/artwork polish. Thirty-three focused tests pass. Sixty TODO entries were completed/verified; 21 untouched entries remain. GPU acceleration and Windows lock-screen appearance require optional backends and are not claimed as live-verified. [Changes, commands, and validation limits](PAFPlayer_v456_release_notes.md).

## V430 — September 22, 2026

Completed the active TODO list: removed the requested low-value Emojimaxx word substitutions, corrected `ladies` to use a distinct feminine mapping, and bounded/flushed large Unicode writes to real Windows console streams so half-block artwork cannot become replacement characters. Binary terminal payloads and optional direct writes now preserve all bytes across partial writes; adapters that return `None` after accepting text no longer abort playback. Eight new focused regressions plus the prior V416/V429 checks pass. [Details and validation limits](play_audio_file_v430_release_notes.md).

## V429 — September 22, 2026

Added the missing circled ten (❿) to Windows Terminal's generated-number spacing rule, fixing the unprotected gap in `ten of`. Extended the former 1–9 regression through 10 and added screenshot-phrase/wrapping/color tests; 13 focused checks pass. Preserves V428. [Details and verification limits](play_audio_file_v429_release_notes.md).


## V421 — September 21, 2026

Restored immediate manual Play/Space after automatic pause. Already-playing background applications are ignored at startup; overrides apply only to current applications and expire independently after inactivity, so newly started VLC can still interrupt an overridden Chrome video. Retains automatic 15-second fade and manual Pause/Stop ownership. 51 focused tests and real-worker manual-resume validation passed. [Details and detection limits](play_audio_file_v421_release_notes.md).


## V420 — September 21, 2026

Removed the Play/resume bypass that could disable external-media priority indefinitely while a browser stayed active. Enabled automatic pause now keeps competing media in priority; manual Pause/Stop ownership and the configured fade remain. Added decision diagnostics and verified actual audio-worker shutdown with live Chrome and VLC. Preserves V419's album-art spacing repair. [Validation and behavior](play_audio_file_v420_release_notes.md).


## V418 — September 21, 2026

Fixed browser detection's dependency on a failing helper: native Windows audio/Winamp monitoring now works independently, while an optional media-session reader provides silent-playback state. Audible tabs override conflicting paused-tab reports. Added helper diagnostics, stale-feed handling and Edge application-ID recognition; preserved manual pause ownership and the 15-second fade. [Details and live validation](play_audio_file_v418_release_notes.md).

## V417 — September 21, 2026

Added WAWI-compatible GET/HEAD transport URLs and legacy state output for the existing Winamp BAT scripts. Stop now resets and waits for Play without closing the web session. Filename clicks open Explorer locally and download remotely; a small adjacent download button always saves the original audio. See [release notes](play_audio_file_v417_release_notes.md) for setup, exact semantics, and validation.

## V416 — September 20, 2026

Completed the saved TODO pass; added consumed-sample playback clocks, future browser spectrum delivery and independent popup cue scheduling; eliminated stale/silence beat pulses; preserved Windows Terminal safety spaces through sung-line wrapping; retained rapid/held seeks; clarified J/Insert selection behavior; curated EmojiMaxx; corrected control icons/URL display; added persisted artwork seam strategies 0–5; and added read-only external-media detection with automatic pause/resume, manual-pause ownership, and a persisted 15-second audio fade setting. See [detailed release notes](play_audio_file_v416_release_notes.md) for decisions and validation limits.


This changelog was reconstructed from the recoverable project artifacts: the illustrated comprehensive manual and documentation archive through V30; the V97 source/supplement; the V100–V110 app-and-docs releases and canonical merged manuals; V111–V112 source/tests/docs; embedded regression contracts that preserve behavior from earlier releases; and the recovered visual-reference assets. It does not invent change details for release numbers that have no standalone or embedded evidence.

## Artifact coverage and authority

| Artifact family | Coverage | How it is used |
| --- | --- | --- |
| Illustrated comprehensive documentation ZIP | Through V30 | Feature breadth, original release rationale, screenshots and controlled visual plates. |
| Embedded regression suite in current source | V7–V112, with gaps | Executable contracts and branch-loss sentinels; particularly detailed from V82 onward. |
| V97 source and supplement | V31–V97 cumulative lineage | Source-authoritative behavior and detailed WAV/art/attributes/HUD release rationale. |
| V100–V110 app-and-docs archives | V100–V110 | Per-release notes, checksums, canonical manuals, and executable snapshots. |
| V111 release | V111 | Current requested changes plus the documentation split/restoration. |
| V112 release | V112 | User-owned artwork geometry, effective-tag merge, Help ordering, and optional detail HUD. |

## Audited artifact inventory

The following durable release artifacts were individually included in the audit (runtime logs, SQLite databases, temporary renders, and upload transport files are deliberately excluded because they are session data rather than release evidence):

- `library-old/DOWNLOAD_play_audio_file_v30_synchronized_visualizer_paint_documentation.zip`
- `deliverables/PAFPlayer_v100_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v101_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v102_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v103_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v104_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v105_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v106_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v107_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v108_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v109_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v110_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v97_canonical_internal_documentation.md`
- `deliverables/PAFPlayer_v97_technical_analysis_report.docx`
- `deliverables/play_audio_file_v100_reset_volume_and_playback_speed-app-and-docs.zip`
- `deliverables/play_audio_file_v101_persistent_art_dpi_floating_lyrics_and_web_choices-app-and-docs.zip`
- `deliverables/play_audio_file_v102_conventional_art_controls_native_size_and_safe_floating_lyrics-app-and-docs.zip`
- `deliverables/play_audio_file_v103_safe_redraw_floating_lyrics_and_compact_last_play-app-and-docs.zip`
- `deliverables/play_audio_file_v104_isolated_gui_lyrics_and_visualizer_safety-app-and-docs.zip`
- `deliverables/play_audio_file_v105_absolute_hud_anchor_and_isolated_artwork_lyrics-app-and-docs.zip`
- `deliverables/play_audio_file_v106_gui_error_logging_dense_metadata_and_media_keys-app-and-docs.zip`
- `deliverables/play_audio_file_v107_fast_ins_live_prompts_and_clean_tk_shutdown-app-and-docs.zip`
- `deliverables/play_audio_file_v108_recent_visit_safe_shuffle_and_readable_tag_browser-app-and-docs.zip`
- `deliverables/play_audio_file_v109_accurate_last_play_33pct_history_and_live_tag_browser-app-and-docs.zip`
- `deliverables/play_audio_file_v110_dual_rotating_diagnostics_and_tk_font_fix-app-and-docs.zip`
- `deliverables/play_audio_file_v111_queued_inserts_global_volume_stable_last_play_and_restored_docs-app-and-docs.zip`
- `deliverables/v100/play_audio_file.py`
- `deliverables/v100/play_audio_file_v100_reset_volume_and_playback_speed.py`
- `deliverables/v100/SHA256SUMS.txt`
- `deliverables/v101/play_audio_file.py`
- `deliverables/v101/play_audio_file_v101_persistent_art_dpi_floating_lyrics_and_web_choices.py`
- `deliverables/v101/SHA256SUMS.txt`
- `deliverables/v102/play_audio_file.py`
- `deliverables/v102/play_audio_file_v102_conventional_art_controls_native_size_and_safe_floating_lyrics.py`
- `deliverables/v102/SHA256SUMS.txt`
- `deliverables/v103/play_audio_file.py`
- `deliverables/v103/play_audio_file_v103_safe_redraw_floating_lyrics_and_compact_last_play.py`
- `deliverables/v103/SHA256SUMS.txt`
- `deliverables/v104/play_audio_file.py`
- `deliverables/v104/play_audio_file_v104_isolated_gui_lyrics_and_visualizer_safety.py`
- `deliverables/v104/SHA256SUMS.txt`
- `deliverables/v105/play_audio_file.py`
- `deliverables/v105/play_audio_file_v105_absolute_hud_anchor_and_isolated_artwork_lyrics.py`
- `deliverables/v105/SHA256SUMS.txt`
- `deliverables/v106/play_audio_file.py`
- `deliverables/v106/play_audio_file_v106_gui_error_logging_dense_metadata_and_media_keys.py`
- `deliverables/v106/SHA256SUMS.txt`
- `deliverables/v107/play_audio_file.py`
- `deliverables/v107/play_audio_file_v107_fast_ins_live_prompts_and_clean_tk_shutdown.py`
- `deliverables/v107/SHA256SUMS.txt`
- `deliverables/v108/play_audio_file.py`
- `deliverables/v108/play_audio_file_v108_recent_visit_safe_shuffle_and_readable_tag_browser.py`
- `deliverables/v108/SHA256SUMS.txt`
- `deliverables/v109/play_audio_file.py`
- `deliverables/v109/play_audio_file_v109_accurate_last_play_33pct_history_and_live_tag_browser.py`
- `deliverables/v109/SHA256SUMS.txt`
- `deliverables/v110/play_audio_file.py`
- `deliverables/v110/play_audio_file_v110_dual_rotating_diagnostics_and_tk_font_fix.py`
- `deliverables/v110/SHA256SUMS.txt`
- `deliverables/v111/play_audio_file.py`
- `deliverables/v111/play_audio_file_v111_queued_inserts_global_volume_stable_last_play_and_restored_docs.py`
- `deliverables/v111/SHA256SUMS.txt`
- `work/v111/play_audio_file.py`
- `deliverables/play_audio_file_v112_user_owned_art_geometry_and_optional_hud_details-app-and-docs.zip`
- `deliverables/v112/play_audio_file.py`
- `deliverables/v112/play_audio_file_v112_user_owned_art_geometry_and_optional_hud_details.py`
- `deliverables/v112/SHA256SUMS.txt`
- `work/v112/play_audio_file.py`

## Visual-documentation artifact chronology

The recovered archive contains real-session captures and controlled plates for artwork galleries, expanded spectra, shuffle metadata, EmojiMaxx karaoke, SIXEL, glyph families, treatments, palettes, processing, Signal Aurora, high-rate rendering, frequency warp, persistence, AGC, granularity, queue rotation, fades, karaoke typography/color, favorites/defaults, Help, volume, header geometry, now-playing integration, progress resolution, and atomic visualizer paint. Current descriptive filenames and links are in the main manual's visual-reference section.

# Detailed release history

## V197 — stable floating layout and shared-cost rendering optimization

- Floating edit-mode geometry is captured on focus exit, covering native Windows resizing that never reaches the canvas mouse-release binding. The rectangle center remains the compact lyric anchor, and its separately persisted size now governs font scale and line wrapping.
- The coloring destination tabs swap order and use explicit identities: **🎨 Artwork Lyric Coloring** and **☁ Floating Lyric Coloring**.
- The retained SIXEL artwork experiment no longer extracts cover data on every restore. Its encoded 64-color layer is cached by track and terminal geometry, and restore cadence adapts from 2 FPS down to 1 FPS for fullscreen-like areas while the ordinary console visualizer keeps its independent adaptive cadence.
- Animated lyric rendering applies tone controls before enlarging the small pattern tile, uses bilinear expansion, caches glyph runs and 360° shadow masks, and scales animation cadence with mask area. This removes duplicated full-frame work when artwork and floating lyrics are both large.

## V198 — history regex query and idle lyric stability

- Added `--last-play-regex REGEX`, a playback-free SQLite query over normalized filename and Artist/Song identity. It reports the newest matching play, or `NEVER` when there is no match; invalid expressions return exit code 2.
- Idle artwork crossfades now replace only the tagged base image and lower it beneath the existing lyric layer. Over-art color animation pauses during idle-gallery rotation, eliminating repeated lyric blink while many images are displayed.

## V196 — experimental retained-artwork layering

- `Ctrl+Alt+F6` now toggles a separate console-layering experiment. It caches the current cover as static SIXEL, restores it at 2 FPS, and immediately renders the normal DRCS/Unicode spectrum above it.
- This does not reuse the existing single-bitmap album-art spectrum composite. Its purpose is to exercise Windows Terminal's actual image/text layer ordering and compensate for text-cell image erasure by redrawing the retained source cover.
- V196 preserves the V192 floating-lyric placement and artwork-window geometry repairs. The canonical source and build identifiers are now V196.

## V192 refinement — compact floating lyric placement and low-rate console continuity

- Floating lyrics now measure on a temporary layout surface but immediately shrink their real transparent window to the exact rendered lyric-and-shadow bounds; idle is a one-pixel transparent window. Saved placement is an exact, unclamped screen X/Y so edge placement is possible, and the floating right-click menu can set that coordinate directly.
- Entering edit chrome rebases the drag anchor after Tk/Windows changes the client origin. The lyric color animation holds while dragging, preventing the renderer from fighting the pointer.
- Opening the lyric-color configurator no longer blanks the console or browser spectrum. Those visualizers retain a two-FPS heartbeat while the configurator is active.
- The experimental, saved-off-by-default frequency warp remains display-only: it leaves the first 55% of display frequencies untouched and monotonically compresses source 70–100% into approximately the last 15% of display width. `Ctrl+Alt+F9` toggles it.

## V1

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V2

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V3

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V4

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V5

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V6

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V7

Refined the terminal UI and established regression coverage for the compact live player surface.

## V8

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V9

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V10

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V11

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V12

Separated Artist/Song animation, stabilized lyric-title ownership, EmojiMaxx fading, and real playlist visit history.

Preserved executable/regression contracts:

## V13

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V14

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V15

Made upcoming EmojiMaxx immediate and added OSC-8 clickable URLs without breaking terminal-cell width.

Preserved executable/regression contracts:

## V16

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V17

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V18

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V19

Documented real artwork, karaoke, visualizer, metadata, shuffle, fade, and progress behavior with reference plates.

## V20

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V21

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V22

Expanded the visual reference set for SIXEL, glyph families, and karaoke treatments.

## V23

Established the lower-rate visualizer presentation baseline later used to diagnose high-rate tearing.

## V24

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V25

Added bounded persistence modes, correct analyzer-behind behavior, physical top-row crop, robust SRT parsing, and EmojiMaxx refinements.

Preserved executable/regression contracts:

## V26

Added display-only AGC, exact-stem sidecar editing, verified history upserts, persistent queue rotation, and three granularity modes.

Preserved executable/regression contracts:

## V27

Moved shuffle-cache writes off track handoff, made terminal geometry focus-safe, and refined EmojiMaxx vocabulary.

Preserved executable/regression contracts:

## V28

Locked visualizer rows to column one and normalized circled-number spacing around the compact Play header.

Preserved executable/regression contracts:

## V29

Separated glyph treatment, processing, palette, persistence, fade, and granularity; added Signal Aurora variants and adaptive high-rate painting.

Preserved executable/regression contracts:

## V30

Made multi-row visualizer paints atomic with synchronized output and explicit row advances.

Preserved executable/regression contracts:

## V31

Corrected compact Help keys, history wording, and top-visualizer crop defaults.

Preserved executable/regression contracts:

## V32

Added hierarchical/permanent attribute rules, extended timed-lyric formats, and verified embedded lyric round-trips.

Preserved executable/regression contracts:

## V33

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V34

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V35

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V36

Preferred written-word EmojiMaxx mappings and added renderer diagnostics that remove window-sensitive terminal sequences.

Preserved executable/regression contracts:

## V37

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V38

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V39

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V40

Made large playlist loading report progress in five-percent steps.

Preserved executable/regression contracts:

## V41

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V42

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V43

Deferred filesystem checks for huge playlists and made lexical path identity independent of file existence.

Preserved executable/regression contracts:

## V44

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V45

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V46

Expanded theory diagnostics, ordered help output, and trimmed unused bottom terminal reservation.

Preserved executable/regression contracts:

## V47

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V48

Extended theory-mode range and architecture diagnostics for visualizer/process investigation.

Preserved executable/regression contracts:

## V49

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V50

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V51

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V52

Standardized analyzer launch/logging state and prevented shuffle from selecting the current physical track.

Preserved executable/regression contracts:

## V53

Prevented forward history repeats and made missing attrib.lst creation safe and non-destructive.

Preserved executable/regression contracts:

## V54

Established learned/scrobble hotkeys, standard attrib.lst creation, EmojiMaxx aliases, and clean Done/scrollback behavior.

Preserved executable/regression contracts:

## V55

Made learned writes contain only the explicit learned rule and report the exact written result.

Preserved executable/regression contracts:

## V56

Limited ordinary Last.fm submission to one scrobble per logical visit with explicit duplicate confirmation.

Preserved executable/regression contracts:

## V57

Added embedded-cover extraction/materialization when no usable sidecar cover exists.

## V58

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V59

Separated Last.fm Now Playing from earned scrobbling and serialized the per-visit network lifecycle.

Preserved executable/regression contracts:

## V60

Preferred the canonical C:\bat history database and added karaoke/visualizer compositing plus EmojiMaxx and learned-record refinements.

Preserved executable/regression contracts:

## V61

Made visualizer modes genuinely distinct and preserved exact legacy per-column geometry.

Preserved executable/regression contracts:

## V62

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V63

Captured resume successors before queue rotation and rejected physical aliases during resumed forward navigation.

Preserved executable/regression contracts:

## V64

Aligned semantic metadata columns by label rather than arbitrary string position.

Preserved executable/regression contracts:

## V65

Made narrow HUD layouts relax alignment before wasting additional terminal rows.

Preserved executable/regression contracts:

## V66

Implemented four karaoke/visualizer compositing modes and corrected expansion/genre behavior.

Preserved executable/regression contracts:

## V67

Added compound timed-lyric selection/parsing, asynchronous history startup, and corrected the Up-arrow vocabulary.

Preserved executable/regression contracts:

## V68

Greatly expanded usage examples and moved keystroke guidance next to playback options.

Preserved executable/regression contracts:

## V69

Made learned selectors durable across one/two-digit track prefixes and standardized record separators.

Preserved executable/regression contracts:

## V70

Made lyric-corpus tooling preserve written output through editor failures and avoid dumping generated code to stdout.

Preserved executable/regression contracts:

## V71

Aligned Last play under Album even when optional Comment consumes a competing row.

Preserved executable/regression contracts:

## V72

Introduced the persistent external album-art window, monitor-safe geometry, and Alt+A control contract.

Preserved executable/regression contracts:

## V73

Added aspect-aware art resizing, mouse controls, stable origin, playlist counts, and terminal glyph-spacing fixes.

Preserved executable/regression contracts:

## V74

Made the Tk artwork thread own shutdown and close cleanly even when the GUI never fully started.

Preserved executable/regression contracts:

## V75

Added colorful, sorted playlist-history reporting and its usage-level diagnostic.

Preserved executable/regression contracts:

## V76

Added the full-path playlist-analysis table, paging, ANSI-free export, and editor handoff.

Preserved executable/regression contracts:

## V77

Added separate progress reporting for history resolution and playlist-analysis generation.

Preserved executable/regression contracts:

## V78

Preserved history order through rebuilds, promoted the current track safely, and prevented removed tracks from reappearing.

Preserved executable/regression contracts:

## V79

No standalone change artifact was recovered; behavior is preserved only cumulatively in later source/manual artifacts.

Evidence note: no version-specific artifact or embedded regression name was recovered for this number; later cumulative sources remain the only authority.

## V80

Finalized physically exact two-line learned records and clean selector character classes.

Preserved executable/regression contracts:

## V81

Restored persistence bindings and built a numbered URL chooser with All/None/Escape handling.

Preserved executable/regression contracts:

## V82

Added full playback-time ReplayGain, unified URL controls, Help on F1, and an exact defaults manager.

Preserved executable/regression contracts:

## V83

Added learned extra-tag/removal workflows, robust playlist mutation, art foreground/border behavior, URL errors, and stable Dir rows.

Preserved executable/regression contracts:

## V84

Made nearly all modifier-heavy controls focus-only while retaining only deliberately global physical controls.

Preserved executable/regression contracts:

## V85

Improved editor focus handoff, inherited-learned detection, duplicate avoidance, and automatic attrib editor opening.

Preserved executable/regression contracts:

## V86

Added fast playlist INS/DEL/browser editing, idle art, hard redraw/reflow cleanup, catalog search, and extensive HUD/help polish.

Preserved executable/regression contracts:

## V87

Deduplicated physical path aliases, added the idle artwork gallery/weighted crossfades, and removed filesystem work from playlist browsing.

Preserved executable/regression contracts:

## V88

Added the raw-tag browser, collection aliases, inherited attrib editing, dense Dir/HUD semantics, and 30-second typed-tag idle behavior.

Preserved executable/regression contracts:

## V89

Hardened next-track distinctness, strict metadata grids, learned-input commit rules, and dense three-field rows.

Preserved executable/regression contracts:

## V90

Made Dir conditional on Play-line fit and restored the localhost web server and clean editor activation.

Preserved executable/regression contracts:

## V91

Added near-EOF resume safety, multidisc learned selectors, bounded three-hour shuffle avoidance, and branch-audit sentinels.

Preserved executable/regression contracts:

## V92

Eliminated duplicate metadata rows, unified layout timing, cleared repaint rows, refined learned timing, and corrected EmojiMaxx low.

Preserved executable/regression contracts:

## V93

Added Ctrl+O clean playlist relaunch, VLC art fallback, compact Last play, denser metadata, and faster Artist/Song throbs.

Preserved executable/regression contracts:

## V94

Fixed an immediate web-enabled playback crash caused by publishing before the loop timestamp existed.

Preserved executable/regression contracts:

## V95

Expanded the web controller with real transport/settings, clickable progress, live analyzer data, large rainbow lyrics, and exact Never display.

Preserved executable/regression contracts:

## V96

Unified native/web related artwork and mouse behavior, clickable metadata URLs, taskbar acknowledgement, and colon-safe HUD alignment.

Preserved executable/regression contracts:

## V97

Fixed WAV sample-rate timing, enforced MISC exact-stem art, added explicit cover downloads/global base attributes, and refined HUD/history/art behavior.

Preserved executable/regression contracts:

## V98

Intentionally skipped; no V98 release was issued.

## V99

Intentionally skipped; no V99 release was issued.

## V100

Made `=` reset volume to 100% and playback speed to 1× together.

Preserved executable/regression contracts:

## V101

Made art position/DPI ownership persistent, introduced the three-way lyric mode, and separated the web Choices scroller.

## V102

Added conventional artwork controls, native-size-until-resized behavior, and pointer-safe floating-lyric hit testing.

Preserved executable/regression contracts:

## V103

Made F5 art-safe, added independent floating-lyrics control, compact Last play packing, header track text, and aspect-fill art updates.

Preserved executable/regression contracts:

## V104

Isolated GUI lyric color animation from full artwork repainting and made empty floating state visibly diagnosable.

Preserved executable/regression contracts:

## V105

Replaced the fragile saved-cursor HUD anchor with absolute viewport rows and isolated lyric layers from cover rendering.

Preserved executable/regression contracts:

## V106

Separated artwork decode/lyric errors, added warning-ledger logging, dense metadata tails, foreground art toggle, and media-key modifiers.

Preserved executable/regression contracts:

## V107

Preindexed/cached INS search, kept visualizers live during prompts, made prompts blink, and cleaned Tk shutdown.

Preserved executable/regression contracts:

## V108

Added an immediate recent-visit shuffle ledger, removed stale cache history, and made Alt+3 human-oriented and one-row-per-tag.

Preserved executable/regression contracts:

## V109

Made Last play lookup pending-aware, wrote local history at 33%, coupled learned to history, and made Alt+3 live across tracks.

Preserved executable/regression contracts:

## V110

Split diagnostics into rotating errors/trace logs and fixed Tk lyric font ownership (`root=` instead of invalid `master=`).

Preserved executable/regression contracts:

## V111

Queued INS selections to play next, added global Ctrl+Alt+Up/Down volume, reset speed at session/playlist/insert boundaries, froze per-visit Last play, removed duplicate Dir reflow, restored illustrated docs, and made truncation close delimiters.

Preserved executable/regression contracts:

Implementation and rationale details:

- INS and Shift+INS now converge on a manual-next queue. Shift+INS accepts Windows multi-selection; shuffle randomizes the inserted batch/queue order but cannot allow an ordinary shuffle candidate to jump ahead of it.
- A successful insert resets both the live and shared speed indices to 1×. Non-paused playback restarts FFplay at the current source position when that reset changes speed; paused playback resumes at 1×. Process startup and Ctrl+O playlist relaunch also initialize at 1× rather than restoring the prior speed.
- Ctrl+Alt+Up/Down are polled before the focused-console input gate and use a physical-key latch plus buffered-scan suppression, making them genuinely global without double-applying a normal Up/Down step in Windows Terminal.
- The one-third history threshold still writes SQLite, but no longer rebuilds Last play or reflows the current HUD. This preserves the track-start snapshot and removes the stale second `Dir:` row seen after the threshold repaint.
- Plain and ANSI-aware cell truncation track unmatched delimiters. When clipping would leave an opener, the matching closer replaces the final visible cell without exceeding the requested terminal width.
- Documentation history moved to this file. The operational manual contains current behavior only and ends with its 111 one-line summaries; 28 recovered image assets restore real playback, visualizer, karaoke, palette, persistence, history, and geometry coverage.

- Truncation closes open delimiters as last character.
- Last play is a track start snapshot without dir reflow.
- Insert is multiselect play next and resets speed.
- Speed starts at one and playlist relaunch inherits that rule.
- Ctrl alt arrows are global volume hotkeys.
- Release identity.

## V112

Made artwork geometry permanently user-owned, reversed the resize modifier so ordinary resizing is free-form and Ctrl forces 1:1, contained new art in the existing rectangle with black letterboxing, merged singular/plural instrumental display tags, placed Tags directly under Last play in Help, and added a persisted three-row detail HUD on Ctrl+Alt+/.

Preserved executable/regression contracts:

Implementation and rationale details:

- Foreground and track-refresh paths no longer reapply stale geometry to a visible artwork window. Idle initialization synchronously captures the current valid geometry before any transient drift, so idle teardown returns to the user's live location.
- Source-image dimensions are diagnostic only. Neither first decode nor later artwork rotation changes the popup rectangle. Both static render and crossfade frames use contain semantics against a black canvas, preserving the complete image and creating letterbox/pillarbox bars as needed.
- Tk's native aspect constraint is inactive during ordinary resizing. While Ctrl is physically down it is set to exactly 1:1, with an explicit square-snap fallback for builds that ignore the native constraint.
- `merge_attribute_display_tags` changes only presentation: exact case-insensitive `instrumental` and `instrumentals` entries collapse at their earliest list position to synthesized `instrumental(s)`. Renderers multiply that entry's color factor by 1.25 and cap RGB channels normally.
- The Help masthead is repeated on each compact page in the order Last play, Tags, divider, ReplayGain/playlist. The three optional main-HUD rows use the same async attribute snapshot and share row reflow with controls, lyrics, and visualizers.
- `HudDetails` is persisted with ordinary player settings. Enabling it moves the controls/status origin down by exactly three rows; disabling it clears the union of the old/new region and returns those rows to the visualizer.
- The supplied phrase “The lyrics over artwork” contained no requested change, so V112 preserves the existing off/over-art/floating lyric modes rather than guessing at a new contract.

- Effective instrumental tag merge.
- HUD details hotkey and persistence contract.
- User-owned art geometry contract.
- Artwork letterboxes without cropping contract.
- Release identity.

# Documentation policy

The main `play_audio_file.md` is a current operational manual. Detailed release rationale, superseded behavior, artifact provenance, and regression-history narration belong here. The main manual retains only one release-summary line per version at its very end.
## V200

- Added centered/tiled cover-art visualizer treatments: cover on black, dim cover beneath bars, and cover masked to bars, selectable with `--album-art-style`.
- Added `--last-played REGEX`, a paginated rainbow audit query over stored track history.
## V201

- Split web visualizer selection into pattern and treatment controls.
- Grouped SIXEL, DRCS, album-art visualizer, karaoke expansion, and related experimental toggles under “Experimental / broken”.
- Kept status chips on one line with horizontal scrolling and reclaimed two unused terminal rows for visualizer height.
