"""Lifecycle and authorization regressions; no real package launches."""
import ast
import importlib.util
import io
import http.client
import json
import os
from pathlib import Path
import threading
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('managed_bridge', ROOT / 'lockscreen/PAFPlayer_lockscreen.py')
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)


class ManagedPublisherTests(unittest.TestCase):
    def make(self, enabled=True, official=True):
        runtime = SimpleNamespace(settings={bridge.KEY: enabled}, lock=threading.RLock(),
                                  save_settings=Mock(), instance=SimpleNamespace(owns=lambda: official, identity='session-1'))
        owner = SimpleNamespace(workflows=runtime, port=1777)
        child = SimpleNamespace(close=Mock(), poll=Mock(return_value=None))
        launcher = Mock(return_value=child)
        return bridge.Controller(owner, launcher), launcher, child

    def test_off_by_default(self):
        with patch.dict(os.environ, {'LOCALAPPDATA': ''}):
            self.assertFalse(bridge.previous_setting())

    def test_migration_only_boolean_true(self):
        for raw, expected in ((True, True), (False, False), ('true', False)):
            with patch.object(Path, 'stat', return_value=SimpleNamespace(st_size=40)), patch.object(Path, 'read_text', return_value=json.dumps({bridge.KEY: raw})), patch.dict(os.environ, {'LOCALAPPDATA': 'C:/example'}):
                self.assertEqual(expected, bridge.previous_setting())

    def test_official_launch_pins_identity_and_actual_port(self):
        control, launch, child = self.make()
        control._step()
        launch.assert_called_once_with('http://127.0.0.1:1777', 'session-1')

    def test_secondary_instance_never_launches(self):
        control, launch, child = self.make(official=False)
        control._step()
        launch.assert_not_called()

    def test_disabled_never_launches(self):
        control, launch, child = self.make(enabled=False)
        control._step()
        launch.assert_not_called()

    def test_no_duplicate_launch_when_running(self):
        control, launch, child = self.make()
        for unused in range(10): control._step()
        launch.assert_called_once()

    def test_disable_closes_pipe_without_killing_player(self):
        control, launch, child = self.make()
        control._step()
        control.configure({'enabled': False})
        control._step()
        child.close.assert_called_once()
        self.assertIsNone(control.process)

    def test_ownership_loss_closes_pipe(self):
        control, launch, child = self.make()
        control._step()
        control.runtime.instance.owns = lambda: False
        control._step()
        child.close.assert_called_once()

    def test_failed_settings_write_preserves_previous_choice(self):
        control, launch, child = self.make()
        control.runtime.save_settings.side_effect = OSError('disk full')
        with self.assertRaises(OSError): control.configure({'enabled': False})
        self.assertTrue(control.enabled())

    def test_bad_types_rejected(self):
        control, launch, child = self.make()
        for value in ({'enabled': 1}, {'enabled': 'false'}, {}, {'enabled': False, 'port': 80}):
            with self.assertRaises(ValueError): control.configure(value)

    def test_retry_backoff_after_crash(self):
        control, launch, child = self.make()
        with patch.object(bridge.time, 'monotonic', return_value=100):
            control._step()
            child.poll.return_value = 4
            control._step()
            control._step()
        self.assertEqual(launch.call_count, 1)
        self.assertIn('code 4', control.message)

    def test_retry_backoff_after_activation_failure(self):
        control, launch, child = self.make()
        launch.side_effect = OSError('missing package')
        with patch.object(bridge.time, 'monotonic', return_value=100):
            with self.assertRaises(OSError): control._step()
            control._step()
        launch.assert_called_once()

    def test_shutdown_is_nonblocking_and_wakes_worker(self):
        control, launch, child = self.make()
        control._step()
        control.close()
        self.assertTrue(control.stop.is_set() and control.wake.is_set())
        control._step()
        child.close.assert_called_once()

    def test_remote_http_cannot_read_or_change_settings(self):
        control, launch, child = self.make()
        handler = SimpleNamespace(client_address=('10.0.0.2', 1), command='POST', _json=Mock())
        self.assertTrue(bridge.handle(handler, control.owner, '/api/lockscreen/settings'))
        self.assertEqual(handler._json.call_args.args[0], 403)

    def test_bundled_source_matches_module(self):
        tree = ast.parse((ROOT / 'PAFPlayer.py').read_text(encoding='utf-8'))
        values = [node.value.value for node in tree.body if isinstance(node, ast.Assign) and
                  isinstance(node.targets[0], ast.Subscript) and
                  isinstance(node.targets[0].slice, ast.Constant) and node.targets[0].slice.value == 'PAFPlayer_lockscreen']
        self.assertEqual(values, [(ROOT / 'lockscreen/PAFPlayer_lockscreen.py').read_text(encoding='utf-8')])

    def test_new_web_section_keeps_existing_ids(self):
        page = '<div class="group" id="visualScreensaverSection"></div></body>'
        value = bridge.augment(page)
        self.assertIn('id="lockScreenEnabled"', value)
        self.assertEqual(value.count('id="visualScreensaverSection"'), 1)

    def test_real_http_settings_require_token_and_stop_on_server_close(self):
        import PAFPlayer as app
        control, launch, child = self.make(enabled=False)
        runtime = control.runtime
        runtime.token = 'test-only-token'
        with patch.object(app, 'paf_workflows', return_value=runtime):
            server = app.PAFWebServer(host='127.0.0.1', port=0)
        control.owner = server
        server._lock_screen_controller = control
        self.assertTrue(server.start())
        connection = http.client.HTTPConnection('127.0.0.1', server.port, timeout=3)
        try:
            connection.request('GET', '/api/lockscreen/settings')
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            self.assertFalse(json.loads(response.read())['enabled'])
            connection.request('POST', '/api/lockscreen/settings', json.dumps({'enabled': True}), {'Content-Type': 'application/json'})
            response = connection.getresponse()
            self.assertEqual(response.status, 403)
            response.read()
            self.assertFalse(control.enabled())
            connection.request('POST', '/api/lockscreen/settings', json.dumps({'enabled': True}),
                               {'Content-Type': 'application/json', 'X-PAF-Workflow-Token': runtime.token})
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            self.assertTrue(json.loads(response.read())['enabled'])
            runtime.save_settings.assert_called_once()
        finally:
            connection.close()
            server.close()
            control.thread.join(timeout=3)
        self.assertFalse(control.thread.is_alive())
        self.assertTrue(control.stop.is_set())
