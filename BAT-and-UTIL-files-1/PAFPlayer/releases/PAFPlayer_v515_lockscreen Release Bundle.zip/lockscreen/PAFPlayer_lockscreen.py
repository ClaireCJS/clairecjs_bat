"""PAFPlayer-owned, optional Windows lock-screen publisher lifecycle.

Bundled into PAFPlayer.py. All Windows activation and process work stays on one
daemon worker; the audio/render loops never wait for the companion.
"""
from __future__ import annotations
import base64
import ctypes
import ipaddress
import json
import os
from pathlib import Path
import subprocess
import threading
import time
import uuid

KEY = 'PAFPlayerLockScreenEnabled'
FAMILY = 'ClaireCJS.PAFPlayer.LockScreen.Recovery_vz06efybxc4j2'
THUMBPRINT = '08AC642F1C17B503BC857189AE8C78E76B3358EC'


class ManagedProcess:
    """Handles to our own publisher and a cooperative stop event, never audio."""
    def __init__(self):
        from ctypes import wintypes
        self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        self.kernel.CreateEventW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR]
        self.kernel.CreateEventW.restype = wintypes.HANDLE
        self.kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.kernel.OpenProcess.restype = wintypes.HANDLE
        self.kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        self.kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        self.kernel.SetEvent.argtypes = [wintypes.HANDLE]
        self.kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        self.lease = uuid.uuid4().hex
        self.event = self.kernel.CreateEventW(None, True, False, 'Local\\PAFPlayerManaged-' + self.lease)
        self.handle = None
        if not self.event:
            raise ctypes.WinError(ctypes.get_last_error())

    def attach(self, pid):
        self.pid = pid
        self.handle = self.kernel.OpenProcess(0x100000 | 0x1000, False, pid)
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())
        return self

    def poll(self):
        from ctypes import wintypes
        state = self.kernel.WaitForSingleObject(self.handle, 0)
        if state == 258:
            return None
        code = wintypes.DWORD()
        if state != 0 or not self.kernel.GetExitCodeProcess(self.handle, ctypes.byref(code)):
            raise ctypes.WinError(ctypes.get_last_error())
        return code.value

    def wait(self, timeout):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            result = self.poll()
            if result is not None:
                return result
            time.sleep(.1)
        raise TimeoutError('Publisher did not exit')

    def signal(self):
        if self.event:
            self.kernel.SetEvent(self.event)

    def close(self):
        self.signal()
        for name in ('event', 'handle'):
            value = getattr(self, name)
            if value:
                self.kernel.CloseHandle(value)
                setattr(self, name, None)


def previous_setting():
    """Migrate an explicit companion choice, never enable a fresh installation."""
    local = os.environ.get('LOCALAPPDATA')
    if not local:
        return False
    for family in (FAMILY, 'ClaireCJS.PAFPlayer.LockScreen_vz06efybxc4j2'):
        path = Path(local) / 'Packages' / family / 'LocalState/publisher-settings.json'
        try:
            if path.stat().st_size > 16384:
                return False
            return json.loads(path.read_text(encoding='utf-8-sig')).get(KEY) is True
        except FileNotFoundError:
            continue
        except (OSError, ValueError, AttributeError):
            return False
    return False


def launch(server, identity):
    if os.name != 'nt':
        raise OSError('Windows 10 is required for lock-screen status')
    # Discover only our installed, signed package. Never execute a PATH match,
    # downloaded file, unverified external runtime, or the obsolete identity.
    script = r'''$ErrorActionPreference='Stop'
$env:PSModulePath=$env:WINDIR+'\System32\WindowsPowerShell\v1.0\Modules'
$p=Get-AppxPackage -Name ClaireCJS.PAFPlayer.LockScreen.Recovery
if (!$p -or $p.PackageFamilyName -ne 'ClaireCJS.PAFPlayer.LockScreen.Recovery_vz06efybxc4j2' -or [version]$p.Version -lt [version]'515.0.0.1') { throw 'Install PAFPlayer Lock Screen V515 or newer first' }
$exe=Join-Path $p.InstallLocation 'PAFPlayerLockScreen.exe'
$sig=Get-AuthenticodeSignature -LiteralPath $exe
if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Thumbprint -ne '08AC642F1C17B503BC857189AE8C78E76B3358EC') { throw 'Installed publisher signature does not match PAFPlayer' }
'''
    powershell = Path(os.environ.get('WINDIR', 'C:/Windows')) / 'System32/WindowsPowerShell/v1.0/powershell.exe'
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) | getattr(subprocess, 'BELOW_NORMAL_PRIORITY_CLASS', 0)
    child = ManagedProcess()
    arguments = subprocess.list2cmdline(['--managed', server, identity, str(os.getpid()), child.lease])
    # Packaged activation is required on this Windows installation; direct
    # CreateProcess on WindowsApps was rejected with ERROR_ACCESS_DENIED.
    script += r'''
Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices;
[ComImport,Guid("2e941141-7f97-4756-ba1d-9decde894a3d"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IActivation { [PreserveSig] int ActivateApplication([MarshalAs(UnmanagedType.LPWStr)] string app, [MarshalAs(UnmanagedType.LPWStr)] string args, uint options, out uint pid); }
public static class Launch { public static uint Run(string args) {
var manager=(IActivation)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("45BA127D-10A8-46EA-8AB7-56EA9078943C")));
uint pid; int hr=manager.ActivateApplication("ClaireCJS.PAFPlayer.LockScreen.Recovery_vz06efybxc4j2!App",args,0,out pid);
if(hr<0) Marshal.ThrowExceptionForHR(hr); return pid; } }
'@
[Launch]::Run(''' + "'" + arguments.replace("'", "''") + "')"
    try:
        result = subprocess.run([str(powershell), '-NoProfile', '-NonInteractive', '-EncodedCommand',
                                 base64.b64encode(script.encode('utf-16-le')).decode('ascii')],
                                capture_output=True, text=True, timeout=20, creationflags=flags)
        if result.returncode:
            raise OSError('Install the signed V515 lock-screen package for this Windows account')
        return child.attach(int(result.stdout.strip().splitlines()[-1]))
    except Exception:
        child.close()
        raise


class Controller:
    def __init__(self, owner, launcher=launch):
        self.owner, self.runtime, self.launcher = owner, owner.workflows, launcher
        self.process = None
        self.thread = None
        self.stop = threading.Event()
        self.wake = threading.Event()
        self.next_attempt = 0.0
        self.message = 'Disabled'
        self.migrated = False

    def enabled(self):
        return self.runtime.settings.get(KEY) is True

    def start(self):
        if self.thread is not None:
            return
        self.thread = threading.Thread(target=self._run, name='paf-lock-screen', daemon=True)
        self.thread.start()

    def _release(self):
        if self.process is not None:
            # A named event stops our child. Its owner-process handle also
            # causes cleanup after a Python crash, without polling the player.
            try:
                self.process.close()
            except (OSError, AttributeError):
                pass
            self.process = None

    def _step(self):
        instance = getattr(self.runtime, 'instance', None)
        official = bool(instance and instance.owns())
        if not self.migrated:
            if official and KEY not in self.runtime.settings:
                with self.runtime.lock:
                    self.runtime.settings.setdefault(KEY, previous_setting())
                    self.runtime.save_settings()
            self.migrated = official
        if self.stop.is_set() or not self.enabled() or not official:
            self._release()
            self.message = 'Disabled' if not self.enabled() else 'Waiting for official player ownership'
            return
        if self.process is not None:
            code = self.process.poll()
            if code is None:
                self.message = 'Publisher running; Windows controls lock-screen display'
                return
            self._release()
            self.message = 'Publisher exited (code %s); retrying in 30 seconds' % code
            self.next_attempt = time.monotonic() + 30
        if time.monotonic() < self.next_attempt:
            return
        self.next_attempt = time.monotonic() + 30
        server = 'http://127.0.0.1:%d' % self.owner.port
        self.process = self.launcher(server, instance.identity)
        self.message = 'Starting publisher'

    def _run(self):
        try:
            while not self.stop.is_set():
                try:
                    self._step()
                except Exception as error:
                    self.message = str(error)[:240]
                self.wake.wait(5)
                self.wake.clear()
        finally:
            self._release()

    def configure(self, payload):
        if set(payload) != {'enabled'} or type(payload['enabled']) is not bool:
            raise ValueError('Expected enabled: true or false')
        with self.runtime.lock:
            existed, old = KEY in self.runtime.settings, self.runtime.settings.get(KEY)
            self.runtime.settings[KEY] = payload['enabled']
            try:
                self.runtime.save_settings()
            except Exception:
                if existed:
                    self.runtime.settings[KEY] = old
                else:
                    self.runtime.settings.pop(KEY, None)
                raise
        self.next_attempt = 0
        self.wake.set()

    def snapshot(self):
        return {'enabled': self.enabled(), 'status': self.message}

    def close(self):
        self.stop.set()
        self.wake.set()


def controller(owner):
    with owner.workflows.lock:
        if not hasattr(owner, '_lock_screen_controller'):
            owner._lock_screen_controller = Controller(owner)
        return owner._lock_screen_controller


def handle(handler, owner, path):
    if path != '/api/lockscreen/settings':
        return False
    try:
        if not ipaddress.ip_address(handler.client_address[0]).is_loopback:
            raise PermissionError('Lock-screen settings are local only')
        control = controller(owner)
        if handler.command == 'POST':
            length = int(handler.headers.get('Content-Length', '0'))
            if not 0 < length <= 1024:
                handler.close_connection = True
                raise ValueError('Invalid request size')
            handler.connection.settimeout(2)
            body = handler.rfile.read(length)
            # Consume the bounded body before rejecting a token, so a persistent
            # browser connection cannot interpret it as the next HTTP request.
            from PAFPlayer_web_workflows import authorized
            authorized(handler, owner, owner.workflows, mutating=True)
            payload = json.loads(body.decode('utf-8'))
            if not isinstance(payload, dict):
                raise ValueError('Expected settings object')
            control.configure(payload)
        elif handler.command not in ('GET', 'HEAD'):
            raise ValueError('Unsupported method')
        handler._json(200, control.snapshot())
    except PermissionError as error:
        handler._json(403, {'error': str(error)})
    except (ValueError, OSError) as error:
        handler._json(400, {'error': str(error)})
    return True


HTML = '''<div class="group" id="lockScreenSection"><h3>Windows Lock Screen</h3>
<label><input type="checkbox" id="lockScreenEnabled" disabled>Enable lock-screen song status</label>
<p>PAFPlayer starts and stops its installed publisher automatically. In Windows Lock screen Settings, select PAFPlayer Lock Screen V515 for detailed status (song and lyric) and quick status (playing/paused badge).</p>
<p id="lockScreenStatus" role="status">Loading…</p></div>'''
SCRIPT = '''<script>(()=>{const box=document.getElementById('lockScreenEnabled'),status=document.getElementById('lockScreenStatus');let busy=false;
async function refresh(){if(busy)return;try{const r=await fetch('/api/lockscreen/settings',{cache:'no-store'}),v=await r.json();if(!r.ok)throw Error(v.error);box.checked=v.enabled;box.disabled=false;status.textContent=v.status}catch(e){status.textContent=String(e)}}
box.onchange=async()=>{busy=true;box.disabled=true;try{const r=await fetch('/api/workflows/status'),a=await r.json();if(!r.ok||!a.local||!a.token)throw Error('Use the controls on the player computer');const s=await fetch('/api/lockscreen/settings',{method:'POST',headers:{'Content-Type':'application/json','X-PAF-Workflow-Token':a.token},body:JSON.stringify({enabled:box.checked})}),v=await s.json();if(!s.ok)throw Error(v.error);box.checked=v.enabled;status.textContent='Setting saved'}catch(e){status.textContent=String(e)}finally{busy=false;box.disabled=false}};refresh();setInterval(()=>{if(!document.hidden)refresh()},5000)})();</script>'''


def augment(page):
    return page.replace('<div class="group" id="visualScreensaverSection">', HTML + '<div class="group" id="visualScreensaverSection">', 1).replace('</body>', SCRIPT + '</body>', 1)
