# PAFPlayer Lock Screen V515

PAFPlayer manages the installed publisher automatically. Native visible rendering
remains unconfirmed; publication is not visual proof.

See the [architecture, controls and manual verification](../docs/windows-lock-screen.md).
The current full MSIX is in dist/v515; install with lockscreen_installer.py.
Run run_regression_checks.py and test_desktop.ps1 for focused tests.
run_embedded_v515.py runs all embedded player tests with isolated write guards.
build_desktop.ps1 accepts -SigningThumbprint and preserves signing backups.
Do not overwrite release artifacts or distribute private signing keys.
