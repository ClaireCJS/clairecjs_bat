# Windows 10 lock-screen status — V517

V517 displays PAFPlayer's current lyric line through Windows' detailed-status
slot. The user confirmed native status was visible on October 9. V517's faster
lyric delivery is implemented and tested; its appearance while locked still
needs the manual check below.

## Use live lyrics

1. Launch the V517 `PAFPlayer.py` or the versioned release copy. A running V516
   process does not acquire the new lyric endpoint until the player is relaunched.
2. Keep **Windows Lock Screen → Enable lock-screen song status** enabled in the
   web configuration. The existing setting ID is unchanged.
3. Use **PAFPlayer Lock Screen V517** in Windows Settings' **Choose one app to
   show detailed status** slot. Lyrics are text in this top slot. A quick-status
   slot only shows the playing/paused/idle/offline badge. Both can be selected.
   The package family and app ID are unchanged, so an existing Recovery/V516
   selection should survive the upgrade; check the picker only if necessary.
4. Play a track whose timed lyrics already follow the song in PAFPlayer.
   The lock-screen line follows the same selected line, pause state, seeks and
   lyric offset. No second lyric timing model or speech recognition is used.

The companion checks the current line every 250 ms. PAFPlayer's existing status
cadence is 200 ms, so these two stages can add roughly 450 ms before Windows
rendering/network overhead. Windows owns presentation and can add delay; exact
word timing is not guaranteed. This is line-by-line text, not animated karaoke
highlighting. Long lines may be truncated by Windows and are capped at 120 UTF-16
code units without breaking surrogate pairs. Tracks without synchronized lyrics
cannot gain accurate lyric timing from this feature.

## Why V516 could show a song but stale or missing lyrics

The old publisher queried `/api/remote-tray/hello` once every five seconds.
That read did not mark a status client active. With the web player closed,
PAFPlayer could stop refreshing its cached current lyric, even though the
companion still published track metadata successfully.

V517 opts into `/api/remote-tray/hello?lockscreen=1`. Its compact response copies
only program/version identity, transport flags, current lyric, title, artist and
filename. An official request activates the existing status-only sidecar lane;
it does not activate the browser spectrum, transfer a lyric timeline or artwork,
change the console's lyric refresh rate, or send a playback command.

Only changed tile text is submitted immediately. The badge updates when its
value changes. Unchanged tile/badge content is renewed every 30 seconds to stay
within the existing 90-second expiration. One reusable HTTP client has bounded
response size and a three-second timeout; requests do not overlap. Failed reads
show offline status and back off to three seconds. Both the managed publisher
and standalone tray window use this delivery behavior.

## Install and architecture

The signed package is `lockscreen/dist/v517/PAFPlayerLockScreen_v517_x64.msix`.
Its version is `517.0.0.0`; the picker name includes V517. Install/check with:

```powershell
& C:\ProgramData\anaconda3\python.exe -B -X utf8 lockscreen\lockscreen_installer.py --check
& C:\ProgramData\anaconda3\python.exe -B -X utf8 lockscreen\lockscreen_installer.py
```

The installer verifies pinned hashes, signer, manifest, interactive activation,
publication receipt and background COM activation. It upgrades only the Recovery
companion and preserves its identity. The old unversioned package is separate.
Successful publication alone is not proof of pixels appearing while locked.

The controller source is bundled into PAFPlayer.py. Its daemon worker checks
ownership/settings every five seconds and manages the installed signed publisher.
Windows package/process work never runs in the audio callback or visualizer
frame. Disabling the setting or ending its owning player stops managed publishing
and clears notifications; expiration is the fallback after an abrupt failure.
Fresh installations remain disabled by default, and existing explicit settings
are retained. `PAFPlayerLockScreenEnabled`, `PAFPlayerServerUrl`, the Recovery
package family and `!App` identity are unchanged.

The read-only companion requires `official=true`, a nonempty instance identity,
case-insensitive PAFPlayer names in root/state, and matching nonempty versions.
Managed mode also pins the launching official identity and requires loopback.
The compact endpoint accepts local GET/HEAD only and reveals no state for a
non-owner instance. Redirects, proxies, cookies and default credentials remain
disabled. Existing tray hello requests retain their old behavior; older players
ignore the optional query and return their original envelope, but require the
V517 player for browser-independent lyric freshness.

## Windows host diagnosis history

The October 8 trace captured Microsoft's own LockApp activation being rejected
with `0x80270252` (`E_UAC_DISABLED`) before Windows used its secure LogonUI display.
That was separate from PAFPlayer's earlier package-registration and oversized
shell-environment launch failures. On October 9 the user reported visible native
status, and the read-only installer check now reports `EnableLUA=1`. This work did
not change UAC or any other Windows security setting. The historical trace must
not be used to claim the current working lock screen is still blocked.
See the [historical investigation](lockscreen-renderer-investigation-20261008.md).

Windows owns tile text and badge layout; third-party apps cannot replace its
native lock-screen host. This feature is separate from a .scr screensaver,
wallpaper overlay or SMTC media panel. The periodic Windows background task is
not used as a subsecond lyric clock; live lyrics require the running publisher
and player. Sleep/suspension can stop updates.

## Verification and manual check

- 138 focused tests passed: 61 C# payload/network/publication tests and 77 Python
  endpoint/lifecycle/installer/related tray regressions.
- Tests cover changed/unchanged lines, backward seeks, blank lyric gaps, pauses,
  offline clearing, 30-second renewal, failed-submission retries, local-only
  reads, identity checks, no browser spectrum activation, and real HTTP polling
  with the browser inactive.
- Final C# compilation, full MakeAppx validation, executable/MSIX signatures and
  installer artifact checks passed. Interactive V517 activation/publication and
  background registration/COM activation passed against the running official
  V516 player. That compatibility check is not the new endpoint's live test.
- Main-player function/class ASTs are unchanged from the pre-edit backup. The
  application bundle and version constants changed; the user's intervening edit
  remains preserved. The older 678-test comparison was not rerun: it previously
  had identical 614 passes, 51 failures and 13 errors on V514 and V515. This release
  does not claim a clean full-suite pass.

After launching V517, close the web browser and play a track with known timed
lyrics. Lock Windows manually and check that consecutive lines change in the
clock/date screen's detailed-status slot. Then unlock and test pause, resume,
a backward seek and a lyric gap using normal player controls; lock again to
check each result. Disabling the setting should clear the status. The agent has
not visually verified V517's locked-screen lyric timing.

Reports remain directly under `tests/reports`. Source and signing replacements
have verified backups. Prior releases were preserved. `play_audio_file.py` and
all literal `C:\BAT` paths were unchanged.

## Microsoft references

- [Local tile and badge notifications](https://learn.microsoft.com/en-us/windows/apps/design/shell/tiles-and-notifications/choosing-a-notification-delivery-method)
- [Lock-screen tile and badge presentation](https://learn.microsoft.com/en-us/previous-versions/windows/apps/hh779720(v=win.10))
- [LockScreen API boundary](https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.lockscreen?view=winrt-28000)
