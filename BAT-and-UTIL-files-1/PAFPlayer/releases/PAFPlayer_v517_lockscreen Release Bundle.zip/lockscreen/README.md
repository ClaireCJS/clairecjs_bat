# PAFPlayer Lock Screen V517

Live current-line lyrics: 250 ms compact official-player checks, change-only
tile updates and independent badge renewal. Launch the V517 player as well as
upgrading the companion to keep lyrics fresh with the web browser closed.

See the [architecture, controls and manual check](../docs/windows-lock-screen.md).
Install the signed package in dist/v517 with lockscreen_installer.py.
Run run_regression_checks.py and test_desktop.ps1 for focused checks.
