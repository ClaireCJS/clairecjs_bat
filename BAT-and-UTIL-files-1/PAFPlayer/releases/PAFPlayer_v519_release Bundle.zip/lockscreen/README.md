# PAFPlayer Lock Screen V519

V519's player endpoint selects lyrics 250 ms early while playing. Other lyric
surfaces retain their timing. The V518 paired badge/text publication fix remains.
Launch the V519 player; installing only the companion cannot change a running
older player's timing. Package identity and configuration IDs are preserved.

See the [architecture and manual check](../docs/windows-lock-screen.md).
Install dist/v519 with lockscreen_installer.py. Run run_regression_checks.py and
test_desktop.ps1 for focused checks. Windows owns the actual display timing/layout.
