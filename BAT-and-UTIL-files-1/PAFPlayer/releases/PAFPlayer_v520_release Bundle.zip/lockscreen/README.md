# PAFPlayer Lock Screen V520

The detailed-status rows are artist — song, elapsed/total time with album, and the
current lyric. The middle row replaces the previous lyric when album/time is
available; older compact endpoints retain the previous/current lyric layout.
The quick-status glyph still indicates playing/paused/idle/offline.

V519's lock-only 250 ms lyric lead and V518's paired badge/text publication remain.
The counter uses actual playback time and changes only at whole seconds. No
independent clock or playback commands are added. Package identity, configuration
IDs and optional enable/disable behavior are preserved.

Launch the V520 player; installing only the companion cannot add fields to an
already-running older player. The V520 companion has been installed and its actual
Windows activation/publication verified. Visible locked-screen layout still needs
manual verification after the player relaunch.

See the [architecture and manual check](../docs/windows-lock-screen.md).
Install dist/v520 with lockscreen_installer.py. Run run_regression_checks.py and
test_desktop.ps1 for focused checks. Windows owns actual display timing/layout.
