# Windows 10 lock-screen status — V520

V520 adds elapsed/total time and album in the middle detailed-status row, replacing
the previous-lyric row when either field is available. The current lyric stays
on the last row. See the [V520 manual and verification](PAFPlayer_v520_lock_screen_album_and_counter.md).

V519 adds a 250 ms lead to lock-screen lyric selection while playing, scaled by
playback speed. Paused/stopped clocks do not advance. Other lyric displays and audio
keep their existing timing. Windows still controls visible delivery. See the
[V519 measurements and verification](performance-v519.md).

V518 fixed the recurring disappearance caused by V517's independent badge
renewal. It also supplies the previous lyric alongside the current lyric so a
brief cue can remain readable after the next cue arrives. The native Windows
lock screen still controls timing, truncation, font size and clock placement.

## Use lyrics

1. Run V520 `PAFPlayer.py` or its versioned release copy. The companion accepts
   older players, but album/counter fields require V520's compact endpoint and the
   250 ms lyric lead requires V519 or newer. Relaunch older players to load them.
2. Keep **Windows Lock Screen → Enable lock-screen song status** enabled.
   Fresh installations remain disabled by default; existing choices are retained.
3. Choose **PAFPlayer Lock Screen V520** in Windows Settings' top **Choose one
   app to show detailed status** slot for text. A bottom quick-status slot shows
   only the playing/paused/idle/offline badge. Both may be selected. The Recovery
   package family and app ID are unchanged, so existing selections should survive.
4. Play a track with timed lyrics. The requested three rows are **artist — song**,
   **elapsed / total · album**, and **current lyric**. For example:
   `1:01 / 2:00 · Drool (EP)`. If album and time are both absent, the middle row
   uses the previous lyric as before. Missing middle/current text uses `—` / `♪`
   so lyric gaps still request three nonempty rows.

The counter uses actual playback position, without the lyric lead. It follows
pause, seeks and track changes without extrapolating a separate clock. Duplicate
polls within one displayed second do not cause extra timer updates; lyric changes
still publish immediately on the next poll. Unknown time shows `--:--`, and hours
are supported. Invalid numbers are ignored and elapsed time is capped at a known
duration. Stopping removes the counter; offline status removes album/time entirely.
Album text follows the counter so long names cannot truncate it away. Windows may
still truncate any requested row. The quick-status slot only supports preset glyphs
or numbers, so it cannot display a formatted timer or album text.

The current lyric uses the existing timeline plus V519's lock-only 250 ms lead
while playing. Previous context uses that same selected position and lyric offset; it
follows seeks and resets for gaps and new tracks. No speech recognition or second
playback clock is involved. With an older player, the companion retains only the
previous line it actually observed. Long rows are capped at 120 UTF-16 code units
without breaking surrogate pairs, and Windows can truncate them further.

## Cause and delivery fix

The October 9 baseline trace recorded two badge-only renewals followed about
200 ms later by `PublishDetailedStatusChanged` reason 2 with no text update. Text
returned on the next tile update; one absence lasted roughly eight seconds.
This matches the reported disappearing status area and clock movement.

V518 always submits badge then detailed text together whenever content changes
or the unchanged content needs its 30-second renewal. Both share a 90-second
expiration and renewal deadline. It does not clear notifications between lyric
updates. The native Windows trace coalesces arrivals over roughly 200 ms; merely
polling faster cannot guarantee a visible frame for every arbitrarily short cue.
V518/V519 used the extra previous row to retain a preceding cue after a quick
transition, including a cue that fell between polls. V520 uses that row for album
and time when available, so the preceding cue is then not displayed. Multiple rapid
cues can still be missed.

The companion continues polling every 250 ms. PAFPlayer's existing status cadence
is 200 ms, so those stages alone can add about 450 ms, before Windows rendering
and network overhead. This is line-level display, not word-highlighted karaoke.
No notification queue is used to replay stale lyrics. Sleep/suspension can stop
updates. A publisher restart or installation handoff can briefly clear the area.

## Architecture and compatibility

The controller is bundled in PAFPlayer.py and manages the installed signed desktop
publisher in a separate process. Its worker checks ownership/settings every five
seconds; Windows process work is outside the audio callback and visualizer frame.
Disabling the setting or ending the owning player stops managed publication and
clears status; notification expiration is the fallback after abrupt failure.

The compact local GET/HEAD endpoint `/api/remote-tray/hello?lockscreen=1` activates
only the existing status sidecar updates. It copies metadata, transport state,
current and previous lyric text, album and elapsed/total seconds; it does not transfer artwork/full timelines,
activate the browser spectrum, or send playback commands. Previous-cue lookup is
bounded. Ordinary tray requests retain their existing behavior.

The publisher requires `official=true`, a nonempty instance identity,
case-insensitive PAFPlayer program names in root/state, and matching nonempty
versions. Managed mode also pins the launching identity and requires loopback.
Redirects, proxies, cookies and default credentials remain disabled. One reusable
HTTP client has a bounded response size, a three-second timeout, no overlapping
requests, and a three-second backoff after failed reads. Failed reads show offline
status instead of stale track details.

`PAFPlayerLockScreenEnabled`, `PAFPlayerServerUrl`, the Recovery package family,
`!App` identity and existing configuration IDs are preserved. This feature is
separate from the `.scr` screensaver, wallpaper and media transport panel.
The periodic Windows background task is not a subsecond lyric clock.

## Installation

The signed package is `lockscreen/dist/v520/PAFPlayerLockScreen_v520_x64.msix`,
version `520.0.0.0`. From the PAFPlayer project directory:

```powershell
& C:\ProgramData\anaconda3\python.exe -B -X utf8 lockscreen\lockscreen_installer.py --check
& C:\ProgramData\anaconda3\python.exe -B -X utf8 lockscreen\lockscreen_installer.py
```

The installer verifies pinned hashes, signer, manifest, interactive activation,
publication and background COM activation. It upgrades the Recovery companion;
playback stays running. A successful receipt is not proof of visible pixels.

## V518 verification history

- **148 focused tests passed:** 67 C# and 81 Python, covering paired renewals,
  failed-submission retries, gaps/track changes, short preceding cues, seeks and
  offsets, old-player compatibility, local/official-only reads, browser-inactive
  real HTTP polling, lifecycle, installer and related tray regressions.
- Python compilation, final C# build, full MakeAppx validation, executable/MSIX
  signatures and pinned installer checks passed. Interactive V518 activation,
  tile/badge submission and background COM registration succeeded as
  `DEMONA\Claire`, session 1.
- The real October 9 V518 lock cycle recorded 32 detailed-text updates. One explicit
  clear during the standalone-to-managed handoff briefly removed text; it returned
  about 0.56 seconds later. After the publisher settled, **23 text updates had zero
  reason-2 removals**. This sample supports the recurring-refresh fix, but does not
  visually prove clock stability or delivery of every line.
- Reports: `tests/reports/v518-badge-disappearance-evidence.json`,
  `tests/reports/v518-lock-cycle-analysis.json`, and the linked raw trace names
  inside those reports. The Winlogon trace provider was access-denied; the relevant
  lock-screen text/notification providers recorded successfully. Some other events
  reported schema mismatches during decoding.
- Main-player function/class ASTs match the pre-edit backup. Version constants and
  the bundled lock-screen module changed. The user's intervening edits were kept.
  The historical 678-test V514/V515 comparison had identical 614 passes, 51 failures
  and 13 errors; this narrow release does not claim a clean full-suite result.

## Manual check still needed

After relaunching the player with V520 and allowing the publisher to settle, close
the browser, play a tagged timed-lyric track, and lock Windows manually for a minute.
Confirm artist/song, album, elapsed/total and current lyric are visible. Watch for
clock movement during lyric gaps and rapid cues. Use normal player controls to
check pause/resume, a backward seek, a track from a different album, unknown duration,
and disabling the setting. No stale album/time should survive going offline.
Actual V520 locked-screen appearance and delivery of every cue remain unverified.

## Windows host history and boundaries

The October 8 trace separately recorded Microsoft's LockApp activation failing
with `0x80270252` (`E_UAC_DISABLED`). On October 9 native status was user-confirmed
and a read-only check reported `EnableLUA=1`; this work did not change UAC. That old
failure is not the cause of the now-working screen's V517 refresh regression.
See the [historical investigation](lockscreen-renderer-investigation-20261008.md).

Source/signing replacements have verified backups. Prior releases are preserved.
`play_audio_file.py` and all literal `C:\BAT` paths are unchanged.

## Microsoft references

- [Local tile and badge notifications](https://learn.microsoft.com/en-us/windows/apps/design/shell/tiles-and-notifications/choosing-a-notification-delivery-method)
- [Lock-screen tile and badge presentation](https://learn.microsoft.com/en-us/previous-versions/windows/apps/hh779720(v=win.10))
- [LockScreen API boundary](https://learn.microsoft.com/en-us/uwp/api/windows.applicationmodel.lockscreen?view=winrt-28000)

## V519 validation

See [V519 verification and remaining manual checks](performance-v519.md). The
companion activated and published successfully. The new lyric lead requires the
V519 player; actual timing on the locked screen remains a manual check.

## V520 validation

183 focused checks passed (84 C#, 86 Python integration/installer/tray, 13 renderer).
Compilation, full package validation, signatures, pinned hashes and real interactive
Windows activation/publication passed. The receipt verified the official V518
player, whose compact endpoint lacks album/time; relaunching V520 is required to
visually verify those fields. Main-player function/class ASTs and native encoder
bytes match V519. See [V520 release notes](../releases/PAFPlayer_v520_lock_screen_album_and_counter_release_notes.md).

- [Microsoft: badge numbers and supported glyphs](https://learn.microsoft.com/en-us/windows/apps/develop/notifications/badges)
