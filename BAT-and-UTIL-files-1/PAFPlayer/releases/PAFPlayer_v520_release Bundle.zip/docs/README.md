# PAFPlayer documentation

Current release: **V520** — lock-screen album and playback counter, retaining V519's visualizer improvements and early lyrics.

- [V520 release notes](../releases/PAFPlayer_v520_lock_screen_album_and_counter_release_notes.md)
- [V520 manual snapshot](PAFPlayer_v520_lock_screen_album_and_counter.md)
- [Lock-screen guide](windows-lock-screen.md)
- [Performance measurements and manual verification](performance-v519.md)
- [V519 release notes](../releases/PAFPlayer_v519_lean_visualizer_and_early_lock_lyrics_release_notes.md)
- [Main manual and historical coverage](../PAFPlayer.md)
- [Separate visual screensaver](visual-screensaver.md)
- [Playback controls](playback-controls.md)
- [Web configuration](web-config-playback.md)
