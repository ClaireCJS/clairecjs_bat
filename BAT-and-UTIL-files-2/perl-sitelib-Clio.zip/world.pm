my $DEBUG_IS_ANIMAL=0;



##### USAGE:
#use Clio::world;
#use vars qw(@STATES @CITIES @COUNTRIES @ANIMALS);

use strict;

use vars qw(@STATES @CITIES @COUNTRIES @ANIMALS @INJURY_TYPES @FAMILIAL_RELATIONSHIPS @COLORS @INSTRUMENTS @FLAVORS @GUN_TYPES);

@ANIMALS=("chipmunk","cat","dog","horse","horses","duck","fish","bird","goat","seagull","pony","snake","crab","walking stick","rabbit","frog","guinea pig","chinchilla","hamster","gerbil","mouse","turtle","butterfly","moose","seal","walrus","rat");
@CITIES=("Alexandria","Woodbridge","Falls Church","Blacksburg","Washington D.C.","Washington DC","Las Vegas","Atlanta","Baltimore","Chicago","Orlando","Boston","Killington","New York City","Bethany","Rehobeth","Ocean City","Strasburg","Assateague","Amsterdam","Cambridge");
@COLORS=("red","orange","yellow","green","blue","indigo","violet","pink","purple","black","white");
@COUNTRIES=("Mexico","Canada","U.S.A.","America","Iceland","Holland","Netherlands","Germany","Japan","Italy","France","UK","U.K.");
@FAMILIAL_RELATIONSHIPS=("mother","father","parent","sister","brother","sibling","grandmother","grandfather","grandson","granddaughter","son","daughter","child","uncle","aunt","cousin");
@FLAVORS=("white chocolate blackberry","white chocolate","choclate","vanilla","blackberry","almond apricot","strawberry","caramel");
@GUN_TYPES=("rifle","pistol","revolver","shotgun");
@INJURY_TYPES=("burn","bruise","cut","gash","bite");
@INSTRUMENTS=("saxophone","guitar","bass","drums","keyboards");		#should probably add "keyboard","drums","drum","guitar" but will only do so when situations dictate
@STATES=("Virginia","Maryland","D.C.","Georgia","Delaware","Nevada","Florida","Hawaii","New York","Pennsylvania","Connecticut","California","Colorado","Texas","Massachusetts","Louisiana","Vermont","Wisconsin","Iowa","Idaho","Illinois","Montana","Michigan","New Jersey");

##### GLOBALS:
my $tmpanimal;
my $tmpstate;
my $tmpinjury;
my $tmprelationship;
my $tmpcolor;
my $tmpinstrument;
my $tmpflavor;
my $tmptype;


sub is_animal_name {
	my $animal=$_[0];
	my $singular="";
	$singular = &singular($animal);
	#ASSUME GLOBAL @ANIMALS=("dog","cat",etc";
	foreach $tmpanimal (@ANIMALS) {
		if (($animal =~ /^$tmpanimal$/i) || ($singular =~ /^$tmpanimal$/i)) {
			if ($DEBUG_IS_ANIMAL) { print "<B>Yes, $animal is an animal because it contains $tmpanimal</B><BR>\n"; }
			return(1);
		} elsif ($DEBUG_IS_ANIMAL) {
			print "No, $animal is not yet an animal because it does not contain $tmpanimal or $singular<BR>\n"; 
		}
	}
	if ($DEBUG_IS_ANIMAL) { print "<B>No, $animal is not an animal.</B><BR>\n"; }
	return(0);
}#endsub is_animal_name



sub is_family_relationship_name {
	#ASSUMES global $tmprelationship
	#ASSUMES global @FAMILIAL_RELATIONSHIPS
	my $s = $_[0];
	foreach $tmprelationship (@FAMILIAL_RELATIONSHIPS) {
		if ($s =~       /^$tmprelationship$/i) { return(1,$tmprelationship); }
		if ($s =~ /^great-$tmprelationship$/i) { return(1,$tmprelationship); }
		if ($s =~  /^step-$tmprelationship$/i) { return(1,$tmprelationship); }
		if ($s =~  /^grand$tmprelationship$/i) { return(1,$tmprelationship); }
	}
	return(0,"");
}


sub is_state {
	#ASSUMES global $tmpstate
	#ASSUMES global @STATES
	#RETURN VALUE #1: 0 or 1 if it's a state
	#RETURN VALUE #2: "" or $STATE_NAME
	my $s = $_[0];
	foreach $tmpstate (@STATES) {
		if ($s =~ /^$tmpstate$/i) { return(1,$tmpstate); }
	}
	return(0,"");
}


sub is_color {
	#ASSUMES global $tmpcolor
	#ASSUMES global @COLORS
	#RETURN VALUE #1: 0 or 1 if it's a state
	#RETURN VALUE #2: "" or $COLOR_NAME
	my $s = $_[0];
	foreach $tmpcolor (@COLORS) {
		if ($s =~ /^${tmpcolor}$/i   ) { return(1,$tmpcolor); }	#black
		if ($s =~ /^${tmpcolor}er$/i ) { return(1,$tmpcolor); }	#blacker		#TODO this still won't catch "redder"
		if ($s =~ /^${tmpcolor}est$/i) { return(1,$tmpcolor); }	#blackest
	}
	return(0,"");
}



sub is_instrument {
	#ASSUMES global $tmpinstrument
	#ASSUMES global @INSTRUMENTS
	#RETURN VALUE #1: 0 or 1 if it's a state
	#RETURN VALUE #2: "" or $INSTRUMENT_NAME
	my $s = $_[0];
	foreach $tmpinstrument (@INSTRUMENTS) {
		if ($s =~ /^$tmpinstrument$/i) { return(1,$tmpinstrument); }
	}
	return(0,"");
}



sub is_injury_type {
	my $s = $_[0];
	foreach $tmpinjury (@INJURY_TYPES) { if ($s =~ /^$tmpinjury$/i) { return 1; } }
	return 0;
}

sub is_flavor {
	my $s = $_[0];
	foreach $tmpflavor (@FLAVORS) { if ($s =~ /^$tmpflavor$/i) { return 1; } }
	return 0;
}

sub is_gun_type {
	foreach $tmptype (@GUN_TYPES) { if ($_[0] =~ /^$tmptype$/i) { return 1; } }
	return 0;
}


1;
