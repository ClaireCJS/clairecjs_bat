#!/usr/local/bin/perl



use strict; 
use vars qw($TAGFILE_NAME %tags %globaltags %captions %captionsFromTagfile %postcaptionsFromTagfile %postcaptions $last_caption_assembled $STOP_LINKIFY $SUSPEND_DATE_PROCESSING);	
use vars qw(@FILES %used_in_this_file %tmpmatches %captions %people %activities %place %other %things %entertainment %cameraperson %date %artby %animals);


##### LISTS OF CITIES AND STATES, WHICH MIGHT BE USEFUL FOR NON-PICTURE TAGGING STUFF, SO WAS MOVED TO ANOTHER LIBRARY:
use Clio::world;		
use Clio::date;
use Clio::string;
use Clio::HTML;												#for &linkify, my auto-linker (not to be confused with sponsored links, which are totally different)
use Clio::PictureTag;
use vars qw(@STATES @CITIES @COUNTRIES @ANIMALS $mode $TAGGING_PICTURES);	#the @s come from Clio::world
use vars qw(@looptmptags @looptmptag %sponsored $caption2use);	#globals used here due to code cut-and-paste from non-strict script :)

##### CONSTANTS:
$TAGFILE_NAME="attrib.lst";					#this must be consistent - I use this filename in many diff programs that all do the same thing
my $DELIMITER=":::::::::::::";				#shouldn't make a diff if changed, just make sure it never happens to actually be in a tag, ever
$TAGGING_PICTURES=1;						#used by shared modules to alter their behavior - do not "my" this varible! Evil scope warning!
my $FLICKR_PHOTOID_TO_URL_PREFIX = "http://flickr.com/photo.gne?id=";			#put this in front of any photo-id and it will take you to the pic



##### AUTO-CAPTION LISTS OF THINGS WE SHOULDN'T PUT INTO AN AUTO-CAPTION:
##### Is better handled by passing 0 with &add_tag in the 'capture' argument [4th I think, usually it is ""]
my @UNCAPTIONABLE_OTHERS=("funny","view","access-family","access-friend","access-closefriend","access-intimate","access-familyonly","access-private","access-temp-private","lesbian","Tranny_SPC_Concubines","cameraphone","to_identify","toidentify","to identify","^TODO.*","from_SPC_Dad");	
my @UNCAPTIONABLE_THINGS=("animal","bride","groom","wedding_SPC_dress","suit","breast","breasts","dominatrix","strap-*on","creepy_SPC_face","found_SPC_pictures*","cunt");
my @UNCAPTIONABLE_ENTERTAINMENT=("Simpsons","TV show","cartoon show");
my @UNCAPTIONABLE_ACTIVITIES=();

##### DEBUG TOGGLES:
my $DEBUG_EVENT                     = 0;	#for problems with "event"			tags not handled right - also: $DEBUG_EVENT_PARTY / $DEBUG_WEDDING / $DEBUG_EVENT_BEACH
my $DEBUG_THING						= 0;	#for problems with "thing-"			tags not handled right
my $DEBUG_ACTIVITIES				= 0;	#for problems with "activity"		tags not handled right
my $DEBUG_FIXNAME                   = 0;	#for debugging the &fix_name_of_any_form function when dealing with tags that include peopels' names
my $DEBUG_PERSON					= 0;	#for problems with "person-"        tags not handled right		#does not do much...yet
my $DEBUG_SPONSOR_CAPTION           = 0;    #for problems with sponsored captions (auto links for specificpeople) not working correctly		#the data structure can get corrupted by mis-management too, so this spits it out so you can make sure all the keys are actually keys, and all the values are actually values
my $DEBUG_PLACE                     = 0;	#for problems with "place"			tags not handled right
my $DEBUG_ANIMAL                    = 0;	#for problems with "thing-animal"	tags not handled right		
my $DEBUG_FINAL_CAPTION_KLUDGE      = 0;	#for problems with cleaning up caption detritus
my $DEBUG_ASSEMBLE_CAPTION			= 0;	#for problems with the automatically generated captions set to 2, or 1					/      go together
my $DEBUG_AUTOCAPTION				= 0;	#for problems with the automatically generated captions - this one doesn't do very much \____ these kind of 
my $DEBUG_AUTOCAPTION_PEOPLE        = 0;	#for problems with the automatically generated captions - people only
my $DEBUG_AUTOCAPTION_DATE		    = 0;	#for problems with the automatically generated captions - date only
my $DEBUG_ART						= 0;	#for problems with "thing-art"		tags not handled right
my $DEBUG_EVENT_PARTY				= 0;	#for problems with "event-party"    tags not handled right		
my $DEBUG_FOOD                      = 0;	#for problems with "thing-food"     tags not handled right
my $DEBUG_WEDDING                   = 0;	#for problems with "event-wedding"	tags not handled right 
my $DEBUG_DRINK                     = 0;	#for problems with "thing-drink"	tags not handled rightmy $DEBUG_MEAL                      = 0;
my $DEBUG_ACTIVITY_GAME				= 0;	#for problems with "activity-game-" tags not handled right
my $DEBUG_CAMERAPERSON              = 0;	#for problems with "cameraperson-"  tags not handled right
my $DEBUG_FIND_ATTRIB_LIST          = 0;	#for problems with autodetecting attrib.lst files in parent directories, when none is present in current directory
my $DEBUG_SONG						= 0;	#for problems with "entertainment-music-[BANDNAME]-song-[SONGNAME]"			tags not handled right
my $DEBUG_EVENT_BEACH               = 0;    #for problems with "event-beach-"   tags not handled right
my $DEBUG_ADDTAG_CALL				= 0;	#for problems with ***** ALL *****  tags not handled right - verbose &add_tag calls
my $DEBUG_COMEDY                    = 0;	#for problems with "comedy-"		tags not handled right		
my $DEBUG_TAG_CLEANER				= 0;	#I left this one turned on for YEARS because I was fond of the output.  Took a long time to get tired of it.
my $DEBUG_REMOVE					= 0;	#
my $DEBUG_MEAL                      = 0;	#for problems with meal- tags
my $DEBUG_TAG_PROCESSING			= 0;
my $DEBUG_TAG_PROCESSING_REPORT		= 0;
my $DEBUG_TAGCLEAN_RECURSION_PAIN	= 0;

##### LINKS TO ASSOCIATE WITH SPECIFIC PEOPLE - CAN ALSO DO "MOM AND DAD" TO MATCH "MOM AND DAD'S HOUSE" -- THE "'S HOUSE" IS TAKEN OFF AUTOMATICALLY:
my %sponsored_link=	
(
			"RONNIE LIPINSKI","\n\n<B>Ronnie L</B>, born Maria Clara Rechen, is Clio's grandmother (dad's mom). Born 10/25/1918 in Lvov, Poland. Died 11/13/2003 in Alexandria, VA.<BR>Daughter of Jozefa and Jacob, she was the only survivor of the holocaust in her family. She was liberated from a work camp by Clio's grandfather (James Bernard L.), who stormed Normandy 20 minutes into the D-Day invasion.",

#			"BECKY LIPINSKI","\n... View my parents' photos at http://www.flickr.com/photos/vic-and-becky/",
			"JAMES BERNARD LIPINSKI","\n\n<B>James Bernard L</B>, my grandfather (dad's dad). Born 2/18/1922 in Fairmont, WV. Died 12/18/2001 in Arlington, VA.<BR>Son of James and Minnie<BR>Husband of Maria Clara (\"Ronnie\")<BR>Father of Victor (dad)<BR>Brother of Arnold Ray, Lena May and Charles<BR>James Bernard L was a long-serving member of the 16th Infantry Regiment, 1st Division, and its Association. He joined the National Guard in 1936, then the 16th Infantry in 1940 at Fort Jay, New York. In the Allied landings in Africa in November, 1942, he was the Regimental Sergeant Major. He fought in Sicily and later, in the Normandy Invasion, as a Warrant Officer under General Omar Bradley. He continued with the 16th Infantry through France, the Battle of the Bulge, Germany and Czechoslovakia, earning a Silver Star.<BR>After the war, he served at Fort Knox, Kentucky, the Joint Chiefs of Staff in the Pentagon, Fort Shafter, Hawaii, Ft. Sam Houstin in San Antonio, TX, and the Adjutant Generals School, Fort Benjamin Harrison, Indiana, where he retired in 1960 as a CWO-4.<BR>James then became one of the strongest supporters of the Regimental Association, writing many articles and booklets produced by the Association, and was a contributor, editor, and participant in the production of the recent volume of the regiment's history, \"Blood and Sacrifice.\"<BR>James was also an avid flag collector and member of NAVA, and a longtime philatelist.",
			"JAMES BERNARD LIPINSKI'S FUNERAL","\n\n<B>James Bernard L</B>, my grandfather (dad's dad). Born 2/18/1922 in Fairmont, WV. Died 12/18/2001 in Arlington, VA.<BR>Son of James and Minnie<BR>Husband of Maria Clara (\"Ronnie\")<BR>Father of Victor (dad)<BR>Brother of Arnold Ray, Lena May and Charles<BR>James Bernard L was a long-serving member of the 16th Infantry Regiment, 1st Division, and its Association. He joined the National Guard in 1936, then the 16th Infantry in 1940 at Fort Jay, New York. In the Allied landings in Africa in November, 1942, he was the Regimental Sergeant Major. He fought in Sicily and later, in the Normandy Invasion, as a Warrant Officer under General Omar Bradley. He continued with the 16th Infantry through France, the Battle of the Bulge, Germany and Czechoslovakia.<BR>After the war, he served at Fort Knox, Kentucky, the Joint Chiefs of Staff in the Pentagon, Fort Shafter, Hawaii, Ft. Sam Houstin in San Antonio, TX, and the Adjutant Generals School, Fort Benjamin Harrison, Indiana, where he retired in 1960 as a CWO-4.<BR>James then became one of the strongest supporters of the Regimental Association, writing many articles and booklets produced by the Association, and was a contributor, editor, and participant in the production of the recent volume of the regiment's history, \"Blood and Sacrifice.\"<BR>James was also an avid flag collector and member of NAVA, and a longtime philatelist.",
#			"VIC LIPINSKI","\n... View my parents' photos at http://www.flickr.com/photos/vic-and-becky/",
			"SAM LIPINSKI","\n<B>Sam</B> was the family dog that we got in 1985. He was a Lhasa Apso.\n",
			"SHANE LIPINSKI","\n<B>Shane</B> was the 2nd family dog, which we got around 1987 or so. He was a Shi Tzu (shit zoo).\n",
			"BUCK LIPINSKI","\n<B>Buck</B> is the 3rd family dog, which we got around 1995 or so, by virtue of Britt hitting him with her car.\n",

			"26-H TERRACE VIEW","\n\n...26-H Terrace View was a common Theta Zeta hangout and party location.\nDarren's comical 'directions' on how to get there are at dmore26h.htm (yes, google for that filename!)\n",
			"AARON EVANS","\n... View Aaron's photos at http://www.flickr.com/photos/aejonze/",
			"ANDREW THE IMPALED","\n... Check out Andrew The Impaled's official website at http://AndrewTheImpaled.com",
#			"ANDY HALL","\n... View Andy's blog at <a target=\\\"_blog\\\" href=\\\"http://blimpcaptain.livejournal.com/\\\">http://blimpcaptain.livejournal.com/</a>",
#			"ANGEL PREBLE","\n... Read Angel's blog at http://ansaphone4.livejournal.com/"				. "\n... View Angel's photos at http://www.flickr.com/photos/ansaphone4/",		
			"ALLYSON HENRICH","\n<B>Ally</B> is my aunt (mom's sister).",
#			"ANNE SAWYER","\n... View Carolyn's mom's photos at http://www.flickr.com/photos/29444278\@N06/",
			"ARNOLD RAY LIPINSKI","\n\n<B>Arnold Ray L</B>, my great uncle (dad's dad's brother). Born 2/18/1906 and died 8/7/1972 in Fairmont, WV.<BR>Son of James and Minnie<BR>Brother of Lena May, Charles and James Bernard<BR>Occupation: 	Odd jobs",
#			"BEAVIS","\n... <B>View videos of Beavis the cat at: http://www.youtube.com/profile_videos?user=ClioCJS&search_query=beavis </B>",
			"BERTHA NAPIER","\n<B>Bertha Napier</B>, my dad's dad's brother's ex-wife. Born 7/23/1929 in Grand Prarie, TX.<BR>Mother of Michael, Linda, Johnny, Susan Miller, Jayne Albritton, David, Daniel and Paul<BR>Sister of Pauline, Dorothy and Christine<BR>Occupation: 	Waitress",
			"BETH BOWEN","\n<B>Beth</B> is my aunt (mom's sister).",
			"BLAKE BOWEN","\n<B>Blake</B>  is my cousin (mom's sister Beth's son).\n",
			"BRANDON HENRICH","\n<B>Brandon</B> is my cousin (mom's sister Ally's son).\n",
#			"BRITT","\n... View Britt's photos at http://www.flickr.com/photos/sweetest_brittany/",
			"BRENT INGEBRETSEN","\n...Friends may know Brent as Mark I's older brother.",
#			"NATHAN","\n... View my cousin Nathan's photos at http://www.flickr.com/photos/32643686\@N00/",
			"NATHAN GRAVELY","\n... View my cousin Nathan's photos at http://www.flickr.com/photos/32643686\@N00/",
#			"CAMPING","\n\n... View my camping-related blog posts at clintjcl dot wordpress dot com/category/hobbies-activities/camping/",
			"CAROL BUI","\n... View Carol's page at http://www.CarolBui.com/",
			#CAROLYN is handled in FlickR-these-generator.pl   #carolyncasl.wordpress.com
#			"CASEY DWYER","\n... View Casey's photos at http://www.flickr.com/photos/CaseyLea/",
#			"CHAD DAY","\n... Read Chad's blog at http://billdacat.livejournal.com/"				. "\n... View Chad's photos at http://www.flickr.com/photos/cvssc/",			
			"CHRIS SWENSON","\n\n<B>Chris</B> is my cousin Emily's husband.",
#			"CHRIS YATES","\n... Read Chris's blog at http://klaw.livejournal.com/"				. "\n... View Chris's photos at http://www.flickr.com/photos/97812735\@N00/",			
			"CHARLES EDWARD LIPINSKI","\n\n<B>Charles Edward L</B>, my great uncle (dad's dad's brother). Born 9/26/1912 in Fairmont, WV. Died 10/2/1995 in Grand Prarie, TX.<BR>Son of James and Minnie<BR>Husband of Ruth<BR>Father of Susan Miller L, Jayne Albritton L, David, Daniel and Paul<BR>Brother of Arnold Ray, Lena May and James Bernard<BR>Occupation: 	Precision Machinist<BR>Charles Edward L served in the Civilian Conservation Corps in the 1930's where he served as Administrator of a company sized unit. He served in the WV National Guard from 1930 to 1942. During World War II, he served with his federalized unit in the Territory of Alaska, where he participated in combat against the Japanese.<BR>His primary civilian occupation was Precision Machinist in the aircraft industry. During World War II, he worked at his craft on the Manhattan Project (development of the atom bomb) and subsequently worked on a number of NASA space rockets. -from 'Draft Family History' as compiled by James Bernard L<BR>Later, in 1976, he founded KOR (Committee For Social Self-Defense), the main dissident group involved in the founding of the Polish Solidarity movement. KOR officially disbanded in 9/28/1981.",
#			"CHRISTIAN DIAZ","\n... View Christian and Shannon's photos at http://www.flickr.com/photos/chriggy/",
			"CHRISTINA GEYER","\n... View Christina's blog at <a target=\\\"_pictures\\\" href=\\\"http://www.amiexpat.com/\\\">http://www.amiexpat.com/</a>",
#			"CHRIS NEIGH","\n... View Chris's photos at http://www.flickr.com/photos/gtiguy8/",
#			"CHUCK","\n... View Chuck's MySpace at <a target=\\\"_pictures\\\" href=\\\"http://www.myspace.com/ChuckSweetOnline\\\">http://www.myspace.com/ChuckSweetOnline</a>", 			 
			#CLIO  (me) is handled in FlickR-these-generator.pl
			"CONCERT","\n\n... I keep a list of every concert I've ever been to, but am currently looking for a new webhost ..."
#			"CONCERT","\n\n... View the list of every concert I've ever been to at http://clint.sheer.us/media/concerts.htm"
				#."\n... View my songkick gigography at http://www.songkick.com/users/ClintJCL/gigography"
				,
#			"DAD","\n... View my parents' photos at http://www.flickr.com/photos/vic-and-becky/",
			"DAN PROPHET","\n<B>Dan Prophet</B> is my uncle (mom's brother).\n",
#			"DAVE JAGGARD","\n... View Dave's photos at http://www.flickr.com/photos/davejag/",			
#			"DAVE NELSON","\n... Read Dave's blog at http://www.spugbrap.com/blog/"				. "\n... View Dave's photos at http://www.flickr.com/photos/spugbrap/",			
			"DAVE ORANCHAK","\n... Read Dave's blog at http://oranchak.com/"				. "\n... View Dave's photos at http://www.flickr.com/photos/doranchak",			
#			"DEBBIE MOORE","\n... View Debbie & Darren's photos at http://www.flickr.com/photos/debbieamoore/",
#			"DARREN MOORE","\n... View Debbie & Darren's photos at http://www.flickr.com/photos/debbieamoore/",
			"DUKE GRAVELY","\n<B>Duke Gravely</B> is my uncle (mom's sister Marcia's ex-husband). Friends may know him as cousin Nathan and Eve's dad.",
			"MARCIA GRAVELY","\n<B>Marcia</B> is my aunt (mom's sister). Friends may know her as cousin Nathan and Eve's mom.\n",
			"MARCIA PROPHET","\n<B>Marcia</B> is my aunt (mom's sister). Friends may know her as cousin Nathan and Eve's mom.\n",
			"EDWARD EADIE","\n\n<B>Edward Eadie</B>, Carolyn's great uncle-in-law (Carolyn's mom's mom's sister's husband).<BR>Husband of Frances<BR>Father of Edward, Robert and Jane",
#			"ELI SOWAR","\n... Read Eli's blog at http://camfael.livejournal.com/"				. "\n... View Eli's photos at http://www.flickr.com/photos/camfael/",			
			"ELECTRONIC CIGARETTE","\n... Read my e-cigarette howto blogpost at http://clintjcl dot wordpress dot com/2010/03/30/clints-tips-dear-clint-i-want-an-e-cigarette-too-what-do-i-do/",
#			"ELIZABETH BOURAS","\n... Read Elizabeth Bouras's blog at http://evb.livejournal.com/"				. "\n... View Elizabeth Bouras's photos at http://www.flickr.com/photos/sistinas138/",			
			"EMILY HENRICH","\n\n<B>Emily</B> is my cousin (mom's sister Ally's daughter).",
			"EMILY SWENSON","\n\n<B>Emily</B> is my cousin (mom's sister Ally's daughter).",
			"ERIN PROPHET","\n... <B>Erin</B> is my mom's half sister (mom's dad's daughter with his 2nd wife).",
			"EUNICE GRAVELY","\n<B>Eunice (Eunie) Gravely</B> (RIP) was Duke Gravely's mother, and cousin Nathan and Eve's paternal grandmother.\n",
#			"EVAN GOLDSTEIN","\n... Read Evan's blog at http://rerunsrunons.wordpress.com/"				. "\n... View Evan's photos at http://www.flickr.com/photos/evangoldstein/",
#			"EVE AKERS","\n\n<B>Eve</B> is my cousin (mom's sister Marcia's daughter). Friends may know her as cousin Nathan's sister.",
			"EVE GRAVELY","\n\n<B>Eve</B> is my cousin (mom's sister Marcia's daughter). Friends may know her as cousin Nathan's sister.",
			"EVE PROPHET","\n\n<B>Eve</B> is my cousin (mom's sister Marcia's daughter). Friends may know her as cousin Nathan's sister.",
			#Asked not to: "EVE COPE","\n... Read Eve's  blog  at http://curiouseve.livejournal.com/"		.      "\n... View Eve's photos at http://www.flickr.com/photos/23773774\@N04/",			
			"FRANCES EADIE","\n\n<B>Frances Eadie</B>, Carolyn's great aunt (Carolyn's mom's mom's sister).<BR>Daughter of Edgar and Marie<BR>Wife of Edward<BR>Mother of Edward, Robert and Jane<BR>Sister of Lib, Sarah, Edgar and Samuel (Hodge)",
			"GERALD HENRICH","\n\n<B>Gerald</B> is my uncle (mom's sister Ally's husband).",
			"GERARD SAWYER","\n\n<B>Gerard Sawyer</B> was Carolyn's grandfather (Carolyn's dad's dad), who died in 2004.",
#			"GLEN COLEN",	"\n... View Glen's photos at http://www.flickr.com/photos/glenscolen/" . 							"\n... Read Glen's blog at http://rustyorgan.livejournal.com/",
#			"GREG ZUMBROOK","\n... Read Greg's blog at http://gaugeyagee.wordpress.com/"				. "\n... View Greg and Nicole's photos at http://www.flickr.com/photos/nicolekz/",			
			"GLADYS MCDONALDSON","\n<B>Gladys McDonaldson</B> is Carolyn's great-grandmother (Carolyn's mom's dad's mom).",
#			"GEORGE BURGYAN","... High quality pictures of X-Day by George Burgyan can be found at: \n X-Day 13: http://photos.vec.com/Events/X-Day-13/12871537_jauyh#929143823_4rTeu \n X-Day 12: http://photos.vec.com/Events/X-Day-12/8832367_rTsLi ",
#			"HEATHER KATZ","\n... View Heather's photos at http://www.flickr.com/photos/51248867\@N00/",#
#			"HEATHER KOEPF","\n... View Heather Love's modeling photos at http://www.thebebedoll.com/heatherlove/",
#			"IAN BUCKWALTER","\n... Read Ian's blog at http://lonecellotheory.livejournal.com/"				. "\n... View Ian's photos at http://www.flickr.com/photos/lonecellotheory/",			
			"JACK GRAVELY","\n<B>Eunice (Eunie) Gravely</B> (RIP) was Duke Gravely's dad, and cousin Nathan and Eve's paternal grandfather.\n",
#			"JAMES OSBURN","\n... View James's photos at http://www.flickr.com/photos/10043638\@N05/",
			"JAMES HANNERS","\n... View James Hanners's photos at http://www.flickr.com/photos/jhanners/",
			"JAMES PROPHET","\n\n<B>James</B> is my cousin (mom's brother Dan's son).",
			"JAMES ROMAN LIPINSKI","\n\n<B>James Roman L</B>, my great-grandfather (dad's dad's dad). Born 2/13/1884 in Warsaw, Poland. Died 1/28/1965 in Fairmont, WV.<BR>Son of Ignatius and Hegwig?<BR>Husband of Minnie<BR>Father of Arnold Ray, Lena May, Charles and James Bernard<BR>Brother of Martha and Edward<BR>Occupation: 	B&O Railroad Engineer<BR>James Roman L's original name was believed to be Julius Roman L. Although his obituary stated he was born in Warsaw, that is not believed to be the case. He did not know exactly where he was born, but believed it to be \"somewhere near the Russian border.\" He is buried in the family plot of Jones Cemetery, Fairmont, West Virginia. His name is recorded on the American Immigrant Wall of Honor on Ellis Island, although incorrectly listed as James Rome L, from Poland. Our last name means near the river according to 'Draft Family History' as compiled by James Bernard L.",
			"JAMES TURNOCK","\n\n<B>James Turnock</B> is Carolyn's grandfather (Carolyn's mom's dad), and served in WWII and the Korean War.",
			"JASON SOMMA","\n\n...View Jason Somma's website at http://www.jasonsomma.com/",
			"JASON AKIRA SOMMA","\n\n...View Jason Akira Somma's website at http://www.jasonsomma.com/",
#			"JENNIFER TERRILL","\n\n...View my cousin Jennifer's pictures at http://www.flickr.com/photos/adventurediva/",
			"JENNIFER PROPHET","\n<B>Jennifer</B>  is my cousin (mom's brother Dan's daughter).\n...View Jennifer's pictures at http://www.flickr.com/photos/adventurediva/",
#			"JESS OSBURN","\n... View Jess's photos at http://www.flickr.com/photos/mightykins/",
#			"JESS CRANE", "\n... View Jess's photos at http://www.flickr.com/photos/mightykins/",
#			"JESSICA OSBURN","\n... View Jess's photos at http://www.flickr.com/photos/mightykins/", ############## THIS IS THE WAY TO TAG HER!!! NOT THE OTHER 3 WAYS!!!!!!!
#			"JESSICA CRANE","\n... View Jess's photos at http://www.flickr.com/photos/mightykins/",
#			"JESSE B","\n... View Jesse's MySpace at http://www.myspace.com/Yi_Zong/", 
#			"JESSE BYRD","\n... View Jesse's MySpace at http://www.myspace.com/Yi_Zong/", 
#			"JOE RINCIONE",#"\n... Read Joe's blog at http://echodork.livejournal.com/"				. 				,"\n... View Joe's photos at http://www.flickr.com/photos/23781122\@N08/",			
#			"JOHN KULIECZA","\n... Read John The Canadien's blog at http://igottarambleon.wordpress.com/"				. "\n... View John The Canadien's photos at http://www.flickr.com/photos/jlk78/",			
#			"JON BERGFELD","\n... Read Jon's blog at http://vealshanks.wordpress.com/\n... View Jon's photos at http://www.flickr.com/photos/jbergfel/",			
#			"JORDAN SAWYER",#"\n... Read J Gerard's blog at http://www.sourswinger.name/blog/"				. 				"\n... View J Gerard's photos at http://www.flickr.com/photos/soursw/",			
#			"JSUN BRUNER","\n... Fan JSun's band Dharmata 101 at http://www.facebook.com/pages/dharmata-101/31385866804",
			"KAREN MILLIGAN","\n...Karen Milligan is a Fairfax County official marriage celebrant. She married Clio and Carolyn, Chris W and Jeri, and Greg and Nicole!",
			"BERTHA JOHNSON","\n...<B>Bertha (Berthine) Johnson</B> is my grandmother's aunt (mom's mom's mom's sister) and father to Kermit Johnson.\n",
			"KERMIT JOHNSON","\n...<B>Kermit Johnson</B> is my grandmother's first cousin (mom's mom's mom's sisters's son). He owned a ~75 acre farm, which may have been comprised of land originally settled by my great-great grandparents after their emmigration from Norway.",
			"KIER CONROY",
				#"\n... Read Kier's blog at http://american-arcane.livejournal.com/"				. 
				 "\n... View Kier's photos at http://www.flickr.com/photos/kierduros/",
			"KNUTE LEE","\n\n<B>Knute Lee</b> is Clio's great-great grandfather (Clio's mom's mom's mom's dad), who raised Grandma Phyllis after she was orphaned. He didn't really speak English. He lived in Vaage, Gulbrandsdalen, Norway, and married Marie in 1882, leaving for America in 1883, and living in several places before settling the family farm in Bruce Valley (Strum, WI) in 1886. He outlived his wife, who died around May 20th, 1937, at the age of 83 years, 8 months, and 14 days, had a daughter named Berthine Johnson, and three [known] grandchildren: Phyllis Lee Prophet (Clio's grandmother), Minerva Johnson, and Kermit Johnson, all who lived on the home farm.",
#			"KIPP ELSBERND","\n... View Kipp's photos at http://www.flickr.com/photos/lurking444/",
			"KMFDM","\n... View KMFDM's official website at http://kmfdm.net/",
			"LAINE BOWEN","\n<B>Laine</B> is my cousin (mom's sister Beth's daughter).\n",
#			"LAUREN WRIGHT",				"\n... View Lauren's photos at http://www.flickr.com/photos/29427984\@N05/",				#"\n... Read Lauren's blog at http://shavemywrists.livejournal.com/" .				#She doesn't want her LiveJournal linked anymore...
			#he asked not to do this: "MARK INGEBRETSEN","\n... View Mark's MySpace at <a target=\\\"_pictures\\\" href=\\\"http://www.myspace.com/JarkJangle\\\">http://www.myspace.com/JarkJangle</a>", 
			"LIB TURNOCK","\n\n<B>Lib Turnock</B> was Carolyn's grandmother (Carolyn's mom's mom), who died in 2000.",
			"LIZA FRANCO","\n... View Liza's photos at http://www.lizafranco.com/",
#			"LOUISE SAWYER","\n... View Louise's photos at http://www.flickr.com/photos/63764082\@N00/" 				. "\n... Read Louise's blog at http://pvsawyer.wordpress.com/",			
#			"LOUISE MCMAHON","\n... View Louise's photos at http://www.flickr.com/photos/louisekatherine/",
			"LOWELL SAWYER","\n\n<B>Lowell Sawyer</B> was Carolyn's father, who died in August of 2012. He will be missed.",
#			"NATE OSBURN","\n... View Nate's photos at http://www.flickr.com/photos/thenoshow/",
			"MABEL COON PROPHET","\n\n<B>Mabel Coon Prophet</b>, my great-grandmother (mom's dad's mom). Born 6/14/1880 in Lafayette, WI. Died 1/21/1949 in Chippewa Falls, WI.<BR>Daughter of Mark \"Marquis de Lafayette\" and Wilhelmina (Minnie) Caroline<BR>Wife of Thomas S.<BR>Mother of Mark Prophet<BR>Sister of Will<BR>Half sister of Edith Louise Wilhelmina.",
			"MARGARETHA SAWYER","\n\n<B>Margaretha Sawyer</B> is Carolyn's grandmother (Carolyn's dad's mom).",
			"MARIE KRIDER","\n\n<B>Marie Krider</B> is Carolyn's great-grandmother (Carolyn's mom's mom's mom).",
			"MARK PROPHET","\n\n<B>Mark Prophet</B> is Clio's granddad (mom's dad), who started his own cult, The Summit Lighthouse.<BR>To see how he is viewed via cult members, look at his official church page: http://web.archive.org/web/20080622195145/http://www.tsl.org/Masters/lanello/lanello_set.htm<BR>To see how he is viewed via <i>ex</I>-cult members, read Mark Prophet, The Man And The Myth, reposted at my uncle's blog: http://www.blacksunjournal.com/mark-prophet/1463_mark-prophet-the-man-and-the-myth-part-1_2008.html \n",
			"ELIZABETH PROPHET","\n\n<B>Elizabeth Prophet</B> was Mark Prophet's 2nd wife, after Clio's grandmother Phyllis.\n",
			"MARQUIS DE LAFAYETTE COON","<B>Mark 'Marquis de Lafayette' Coon</B> is Clio's great-great grandfather (mom's dad's mom's dad). He served in the Civil War. His diary and sword still exist within our extended family.<BR>Husband of Wilhelmina (Minnie) Caroline Berner-Schumann<BR>Father of Mabel and Will<BR>Brother of Will, George W., A.B., Alonzo, (unknown), (unknown) and May.",
#			"MATTHEW GMINSKI","\n... Read Matthew's gun blog at http://ThoughtsOnGuns.blogspot.com/" . "\n... View Matthew's YouTube at http://www.youtube.com/user/AngryGunNerd/",
#			"MEAGAN PERKINS","\n... Read Meagan's blog at http://frosty-pink.livejournal.com" . "\n... View Meagan's photos at http://www.flickr.com/photos/meagan_perk/",
			"METAL CHRIS","\n... Read Metal Chris's DC Heavy Metal blog at http://DCHeavyMetal.com" . "\n... View Metal Chris's photos at https://www.flickr.com/photos/MetalChris",
			"MIKE BOWEN","\n<B>Mike</B> is my uncle (mom's sister Beth's husband).\n",
			"MINNIE COON","\n\n<B>Minnie Coon</B>, aka Wilhelmina Caroline Berner-Schumann, my great-great-grandmother (mom's dad's mom's mom). Died 4/6/1924. <BR>Daughter of Maritz (Maurice) Berner and Karolina Buttrey<BR>Wife of Mark Marquis De Lafayette Coon<BR>Mother of Edith Louise Wilhelmina Schumann, Mabel Coon, and Will Coon<BR>Sister of Fred & Johanna Berner<BR>Half-sister of Paul Ketelboeter<BR>",
			"MINNIE WILSON LIPINSKI","\n\n<B>Minnie Wilson L</B>, my great-grandmother (dad's dad's mom). Born 10/17/1885 (Mannington, WV). Died 10/1/1971 (Mannington, WV). She had 6 brothers & 3 sisters, 1 husband, 3 sons & 1 daughter.<BR>Daughter of Sarepta Alcinda and Nuzum<BR>Wife of James<BR>Mother of Arnold Ray, Lena May, Charles and James Bernard (Clio's grandad)<BR>Sister of Thomas, Martha, Willis, Sanford, Lawrence, Charles, Margaret, Della, Clinton and Naomi<BR>Occupation: 	Homemaker<BR>",
			"MOIRA PROPHET","\n... <B>Moira</B> is my half-aunt (mom's half-sister) (mom's dad's daughter with his 2nd wife).\n",
#			"MOM","\n... View my parents' photos at http://www.flickr.com/photos/vic-and-becky/",
#			"MOM AND DAD","\n... View my parents' photos at http://www.flickr.com/photos/vic-and-becky/",	
			"MONSTERTAIL","\n... View MonsterTail's MySpace page at http://profile.myspace.com/index.cfm?fuseaction=user.viewprofile&friendID=30200665",
			"NAIL ART","\n... View other pictures of Grandad's nail art at https://www.flickr.com/search/?user_id=31355686%40N00&tags=nailart&sort=date-taken-desc",
#			"NICOLE ZUMBROOK","\n... View Greg and Nicole's photos at http://www.flickr.com/photos/nicolekz/",			
			#"PARTHENA KYDES","\n... Read Parthena's WordPress blog at http://Parthena.wordpress.com/" . 				"\n... Read Parthena's blog at http://kittenofwrath.livejournal.com/" . 				"\n... View Parthena's photos at http://www.flickr.com/photos/97926209\@N00/",				
#			"PATRICK VOLKERDING","\n... View Patrick's X-Day photos at http://www.flickr.com/photos/volkerdi/with/4779910971/",	
#			"PETE JAQUAY","\n... Read Pete's frickin' hilarious comics at http://LunacyInk.com/ ... Seriously. I laughed my *ass* off.",
#			"PETER LANGSDORF","\n... Read Peter's blog at http://the-udjat.livejournal.com/",
			"PETER PAPOULAKOS","\n... View Peter's pictures at http://www.PNCphotography.com/",
			"PHAT MAN DEE","\n... Check out Phat Man Dee's official website at http://PhatManDee.com",
#			"GRANDMA","\n\n<B>Phyllis Prophet</B> is my grandmother (mom's mom).\n",
			"PHYLLIS PROPHET","\n\n<B>Phyllis Prophet</B> is my grandmother (mom's mom), who passed away in 2016. View her obituary at: http://www.legacy.com/guestbook/DignityMemorial/guestbook.aspx?n=phyllis-prophet&pid=177886808 \n",
			#"PRIESTESS PISCES","\n... View Priestess Pisces's tumblr at http://PriestessPisces.tumblr.com/",	#since she deleted Panik's tumblr, I am not linking to hers
			"PUTZ","\n... View Putz's photos at https://www.flickr.com/justaputz/",
#			"REBEKKA GOLDBERG","\n... Read Rebekka's blog at <a target=\\\"_blog\\\" href=\\\"http://HardToGetOver.livejournal.com/\\\">http://HardToGetOver.livejournal.com/</a>",
			"REVEREND PANIK"      ,"\n... View Rev. Panik's art on his tumblr at http://PanikEvBedlam.tumblr.com/",
			"REVEREND PANIK'S ART",,"\n... View Rev. Panik's art on his tumblr at http://PanikEvBedlam.tumblr.com/",
#			"REVEREND TWOBEANS"      ,"\n... View Rev. TwoBeans's blog at http://TwoBeans.blogspot.com",
			"RYAN SOMMA","\n... Read Ryan's blog at http://www.ideonexus.com/"	. "\n... View Ryan's photos at http://www.flickr.com/photos/ideonexus/",			
			"SAM CHUNG","\n... View Sammy's photos at <a target=\\\"_pictures\\\" href=\\\"http://www.flickr.com/photos/27975388\@N00/\\\">http://www.flickr.com/photos/27975388\@N00/</a>",
			"SAM WATSON","\n... View Sam's personal website at http://www.samwatson.com/\n",	#OLD STUFF; MYSPACE IS SO DEAD: ... or his MySpace at <a target=\\\"_picturessw\\\" href=\\\"http://www.myspace.com/secretdecoder\\\">http://www.myspace.com/secretdecoder/</a>",
			"SIDESHOW BOB","\n... View Sideshow Bob's photography repository at http://SSBproductions.com/\n",	
			#"SEAN HERRALA","\n... Visit Sean's message board at <a target=\\\"_picturesswhermb\\\" href=\\\"http://www.thespeakeasy.net/\\\">http://www.thespeakeasy.net/</a>",
			"SARAH BAKER CRUM","\n\n<B>Sarah Baker Crum</B>, Carolyn's great aunt (Carolyn's mom's mom's sister).<BR>Daughter of Edgar and Marie<BR>Wife of Howard<BR>Mother of Thomas<BR>Sister of Lib, Frances, Edgar and Samuel (Hodge)<BR>She served in the military as an Army nurse.",
			"SCOTT OBENHEIN","\n\nScott was a friend from elementary school until highschool... And I ran into him unexpectedly once in college as well. He recently popped up on Facebook, and I had to gank a bunch of pics since I had none.",
			"SEAN PROPHET","\n... Visit half-uncle Sean's blog at <a target=\\\"_picturesswhermbasd\\\" href=\\\"http://www.blacksunjournal.com/\\\">http://www.blacksunjournal.com/</a>",			
#			"SHANNON DIAZ","\n... View Shannon's photos at http://www.flickr.com/photos/shankatz/",
			"SHARON PROPHET","\n<B>Sharon Prophet</B> is my aunt (mom's brother's wife).\n",
#			"STACY MCMAHON","\n... Read Stacy's blog at http://slackmeister.wordpress.com/"	. "\n... View Stacy's photos at http://www.flickr.com/photos/crossthegreenmountain/",			
#			##### Like most of the journalistic world, Susan doesn't understand social internet and actually requested to NOT be linked to:
#			"SUSAN ETHERIDGE","\n... Read Susan's blog at http://web.mac.com/setheridge/" . "\n... View Susan's photos at http://www.flickr.com/photos/s_eth/",	
#			"SUDS PSHAW","\n... Read Suds Pshaw's blog at http://RevSudsSoapbox.blogspot.com/",
#			"SVETLANA SHARGORODSKAYA","\n... Read Svetlana's blog at http://cityofspheres.livejournal.com/" . "\n... View Svetlana's photos at http://www.flickr.com/photos/21790169\@N07/",	
#			"TABBITHA"          ,"\n... View Tabbitha's photos at http://www.flickr.com/photos/tabbootyshaker/",
#			"TABBITHA MACDICKEN","\n... View Tabbitha's photos at http://www.flickr.com/photos/tabbootyshaker/",
			"TATIANA PROPHET","\n... View my half-aunt Tatiana's photos at http://www.flickr.com/photos/lavoyeuse/",
			"THETA ZETA","\n\nTheta Zeta was a Blacksburg, VA co-ed social organization in the 1990s.\n... View the old Theta Zeta webpage at http://clint.sheer.us/oz/oz.htm\n... The Theta Zeta facebook group is at http://www.facebook.com/group.php?gid=65010123631",
			"THOMAS PROPHET","\n\n<B>Thomas Prophet</b>, my great-grandfather (mom's dad's dad). Born 12/6/1874 in Calumet, Quebec, Canada. Died 10/31/1928 in Chippewa Falls, WI.<BR>Son of Samual Prophet and Elizabeth Cook.<BR>Husband of Mabel Coon.<BR>Father of Mark Prophet.<BR>Brother of Victor, Jane, with 2(?) other brothers and 8(?) other sisters.",
			"TIFFANY OBENHEIN","\n\nTiffany was good friend in highschool right around the time I started dating Carolyn. She recently popped up on Facebook, and I had to gank a bunch of pics of her since I had none. She ended up marrying a friend of mine from elementary school.",
			"TODD HENRICH","\n<B>Brandon</B> is my cousin (mom's sister Ally's son).\n",
#			"VICKY",        "\n... Read Vicky's blog at http://tgaw.wordpress.com/"	. "\n... View Vicky's photos at http://www.flickr.com/photos/tgaw/",
#			"VICKY HERRALA","\n... Read Vicky's blog at http://tgaw.wordpress.com/"	. "\n... View Vicky's photos at http://www.flickr.com/photos/tgaw/",
#			"VICKY SAWYER", "\n... Read Vicky's blog at http://tgaw.wordpress.com/" . "\n... View Vicky's photos at http://www.flickr.com/photos/tgaw/",
#			"VICKY SOMMA",  "\n... Read Vicky's blog at http://tgaw.wordpress.com/" . "\n... View Vicky's photos at http://www.flickr.com/photos/tgaw/",
			"YARD SALE", "\n... Read my yard sale-related blogposts at http://clintjcl dot wordpress dot com/category/yard-sales/",
);

##### SANITY CHECK FOR THE ABOVE DATA STRUCTURE:
if ($DEBUG_SPONSOR_CAPTION) {
	print "\n\n\n<br><br><B>[SPONSORED LINKS DUMP:BEGIN:]</B><br>\n";
	foreach my $key (sort keys %sponsored_link) {
		print "key=\"$key\",value=\"" . $sponsored_link{$key} . "\"\n<BR>\n";
	}
	print "\n<B>[SPONSORED LINKS DUMP:END]</B><br><BR><BR><BR>\n\n\n\n";
}

##### GLOBALS:
%sponsored=();
%tags=();
%globaltags=();
%used_in_this_file=();					
%tmpmatches=();
%captions=();				#for captioner	#GET? #PUT?
%people=();					#for captioner	Y		Y
%animals=();				#for captioner	Y		Y
%activities=();				#for captioner	Y		Y
%place=();					#for captioner	Y		Y
%other=();					#for captioner	Y		Y
%things=();					#for captioner  Y       Y
%cameraperson=();			#for captioner  Y       Y
%entertainment=();			#for captioner	Y		Y
%date=();					#for captioner  Y       Y
%artby=();					#for captioner  Y       Y
%captionsFromTagfile=();	#for captioner - this lets you specify a blurb in the tagfile(attrlb.lst) like this:   100-0001:caption-This is a caption. Hi.
%postcaptionsFromTagfile=();#for captioner - this lets you specify a blurb in the tagfile(attrlb.lst) like this:   100-0001:caption-This is a caption. Hi.
%postcaptions=();           #
$STOP_LINKIFY=0;			#sometimes we suppress running &linkify because it is SLOW ... from another perl script (thus global ver)
if ($ENV{"IMAGEINDEX_QUICK"} eq "1") { $STOP_LINKIFY=1; }
$last_caption_assembled="";

#^^^ as new ones are added, initialization must be added below 
#[search for ix1]
my $TYPE="";				#for captioner. temporary flag.
#my TYPE = "date";			#TYPE = "w";
#my TYPE = "comedy";		#TYPE = "event";
#my TYPE = "cameraperson";	#TYPE = "entertainment";	
#my TYPE = "artby";			#TYPE = "animal";
my $SUBTYPE="";				#for captioner - used to distinguish thing-animals from thing
my $tmppush="";				#for captioner
my $ANIMAL_NAMED="";		#for captioner - to suppress saying "dog" when we're going to say the dog's name instead
my %cleaned=();				#for captioner?
my $STOP_ALL_CAPTIONING =0;	#sometimes we need to override our default behavior when calling subroutines, and this will  stop all captioning even if it's told     to happen
my $FORCE_ALL_CAPTIONING=0;	#sometimes we need to override our default behavior when calling subroutines, and this will force all captioning even if it's told NOT to happen
my $APPEND_TO_CAPTION="";	#sometimes we need to override our default behavior when calling subroutines, and this will force all captions to have the text in this string appended to them - NOTE that this has only been programmed for things
my $REPLACE_CAPTION_WITH="";#sometimes we need to override our default behavior when calling subroutines, and this will force all captions to be  replaced  by  the  text  in  this  string - NOTE that this has only been programmed for things
my $STOP_SYNONYM_ALIASES=0;	#sometimes we need to override our default behavior when calling subroutines, and this will force automatic synonyms from being tagged
my $STOP_RECURSION_MAX_INDEX=0;	#this gets redefined later. there is an array used to stop recursion, but it needs to be reset each image, and this helps reset it
my $FIVE_CHAIN_FAILED=0;	#we pass 5-thing chains through 5chain code once, but if that fails, we pass it through a 2nd time via our normal code which splits 5chains on "-" and processes each one individually
my $USEFULLNAME=0;			#used to manually force use of full name - those pesky SubGenius names just don't sound right when only the first name is used
my $tmpkey="";
@looptmptags=();
my $tmp2="";
my $tmp3="";
my $tmp4="";
my $tmp5="";
my $tmp6="";
my $tmp7="";
my $tmp8="";
my $tmp9="";
my $tmpanimal="";
my $tmppluralanimal="";
my $tmpfile;
my $tmpthing;
my $tmpmatch;
my $tmp;
my $left;
my $file;
my $from;
my $right;
my $tmpcleantag="";
my $tmporiginaltag="";
my $plural_was_tagged=0;
my $caption_it=1;
my $caption_it_1="";
my $caption_it_2="";
my @tokens=();
my $global_tag="";
my $tmp1="";
my $tmpplace="";
my $tmpcaptionmode="";
my $tmptag="";
my $tmptag1="";
my $tmptag2="";
my $tmplink="";
my $tmpid="";
my $tmpname="";
my $JUNIOR="";
my $line="";
my $CELEB=0;
my $s="";
my @tmparray=();
my $current_full_tag="";
my $is_artist=0;
my @STOP_RECURSION=();	#an empty array, with various items set to 1 to stop recursion...
my $TITLE="";			#"reverend" etc
my $i="";
my $MediaType="";
my %DO_NOT_SOURCE=0;	#antistalker




############################################################################################################
sub read_tags {
	local @FILES = @{$_[0]};
	my $opts=$_[1];
	my $GENERATE_OUTPUT_FILE_ONLY=0;
	if ($opts =~ /GENERATE_OUTPUT_FILE_ONLY/i) { $GENERATE_OUTPUT_FILE_ONLY=1; }
	if ($GENERATE_OUTPUT_FILE_ONLY==1) { print "* Reading tags..."; }
	if ($DEBUG_TAG_PROCESSING) { print "\n\n"; foreach my $tmpfile1 (@FILES) { print "* $TAGFILE_NAME affects: $tmpfile1 <BR><BR>\n\n"; } print "\n\n"; }

	############### GET TAGS - BEGIN ################
	$tmpcleantag=();				#global used for speedup
	$tmporiginaltag="";				#global used for speedup
	@tokens=();						#global used for speedup
	$global_tag=0;					#global used for speedup

	########### Look for attrib.lst in parent folders and such:
	if (!-e $TAGFILE_NAME) {
		if ($DEBUG_FIND_ATTRIB_LIST) { print "\$TAGFILE_NAME $TAGFILE_NAME does not exist!\n"; }
		for (my $i=1; $i < 5; $i++) {						#we'll check 5 folders back
			$TAGFILE_NAME = "..\\" . $TAGFILE_NAME; 
			if ($DEBUG_FIND_ATTRIB_LIST) { print "**** Checking $TAGFILE_NAME\n"; }
			if (-e $TAGFILE_NAME) { 
				if ($DEBUG_FIND_ATTRIB_LIST) { print "\$TAGFILE_NAME $TAGFILE_NAME exists and was found (after $i additional tries)!\n"; }
				last; 
			}
		}		
	} else {
		if ($DEBUG_FIND_ATTRIB_LIST) { print "\$TAGFILE_NAME $TAGFILE_NAME exists and was found!\n"; }
	}


	if (!open (TAGS,"$TAGFILE_NAME")) {
		my $warning = ": WARNING :   $TAGFILE_NAME does not exist!";
		die($warning);
	}

	# read tags
	my $filename="";
	my $tmp="";
	my $tmp1="";
	my $tmp2="";
	my $tag="";
	my @tmpattribs=();
	my @tmpregexes=();
	my $tmpfile="";
	my $tmpregex="";
	my $tmpplace="";
	my $tmpattrib="";
	my $tmpattrib2="";
	my @envtags=();
	my $linenum=0;
	while ($line=<TAGS>) {	#read in the file
		$linenum++;
		#print "_";			#too much useless output
		chomp $line;
		if ($line eq "")     { next; }
		if ($line =~ /^#/)   { next; }
		if ($line !~ /:/)    { print "WARNING 1XB: LINE $linenum DOESN'T HAVE A COLON:\n\t\LINE: \"$line\"<BR><BR>\n\n"; next; }
		if (($line =~ /:caption-/i) || ($line =~ /:postcaption-/i)) {
			($left,$right) = split(/\:/,"$line",2);
		} else {
			if ($line =~ /:.*:/) { print "WARNING 1XA: LINE $linenum HAS MORE THAN ONE COLON!\n\t\LINE: \"$line\"\n\n"; next; }
			($left,$right) = split(/\:/,"$line" );
		}
		#DEBUG: 		print "!!!! left=$left,right=$right,line=$line<BR>\n"; 
		if ($left eq "")   { $left=".*"; }		#abscense of a filename means match-to-ALL files
		if ($left eq ".*") { 
			#DEBUG:			print "* Setting \$global_tag to 1 because \$left is \"$left\" for line \"$line\"...<BR>\n";			#
			$global_tag=1; 
		} else { 
			$global_tag=0; 
		}
		@tmpregexes    = split(/\|/,"$left" );
		if (($line =~ /:caption-/i) || ($line =~ /:postcaption-/i)) {
			@tmpattribs=();
			$tmpattribs[0]=$right;			#NO: push(@tmpattribs,$right);
		} else {
			@tmpattribs = split(/\,/,"$right");
		}
		#DEBUG: print "left is \"$left\" right is \"$right\" tmpregexes count is ".@tmpregexes."\n";


		#figure out all the files that are applied to by all the regexies
		%tmpmatches=();
		foreach $tmpregex (@tmpregexes) {
			if ($DEBUG_TAG_PROCESSING) { print "<BR>\n\tProcessing tmpregex: $tmpregex ... for $right ..<BR>\n"; }
			foreach $tmpfile (@FILES) {
				#DEBUG: print "====> [TFE] tmpfile=$tmpfile,tmpregex=$tmpregex\n";
				if ($tmpfile =~ /$tmpregex/i) {
					if ($DEBUG_TAG_PROCESSING) { print "\n\t\tMATCHES:    $tmpfile!<BR>\n"; }
					#if ($tmpregex =~ /^\-\-/) {		#oops.    this is
					#	$tmpmatches{$tmpfile}="-2";		#not where we should
					#} else {							#be doing that
						$tmpmatches{$tmpfile}="1";
					#}									#No siree.  
				}
			} 
		}
		my $global_tag_tmp="";
		if ($DEBUG_TAG_PROCESSING) { print "So now, \%tmpmatches is "; foreach $tmp (sort keys %tmpmatches) { print "$tmp "; } print " ..<BR><BR>\n\n"; }
		#if there were any matches, tag them for each of the tags on the right side:
		foreach $tmpfile (keys %tmpmatches) {	#for each file
			next if $tmpfile =~ /^$TAGFILE_NAME$/i;
			for ($i = 0; $i <= $STOP_RECURSION_MAX_INDEX; $i++) { $STOP_RECURSION[$i]=0; }		##### Reset our recursion-stopping array
			#$DEBUG_TAG_PROCESSING=1;#
			##### TAGS PLACED AUTOMATICALLY DEPENDING ON FILENAME:								#there MAY be a bug, but I think it is fixed by now [201601]. this does not work 100% of the time in imageindex, even though it does seem to work in flickr-upload-generator - very strange
			$global_tag_tmp=$global_tag;														#this value seems to be messing us up here; store it for later - 20080502
			$global_tag=0;																		#													|
			if (($tmpfile =~ /\.avi$/i) || ($tmpfile =~ /\.mov$/i))                             #													|
				{														                        #													|
				                                &add_tag("video", $tmpfile,"","","");			#													|
				if ($tmpfile =~ /\.avi$/i)    {	&add_tag("AVI",   $tmpfile,"", 0,""); }			#													|
				if ($tmpfile =~ /\(mjpeg\)/i) {	&add_tag("mjpeg", $tmpfile,"", 0,""); }			#													|
				if ($tmpfile =~ /\(xvid\)/i)  {	&add_tag("xvid",  $tmpfile,"", 0,""); }			#													|
				if ($tmpfile =~ /\(divx\)/i)  {	&add_tag("divx",  $tmpfile,"", 0,""); }			#													|
			} elsif($tmpfile =~ /\.flv$/i)    {													#													|
				                                &add_tag("video", $tmpfile,"", 0,"");			#													|				
				                                &add_tag("FLV",   $tmpfile,"", 0,"");			#													|				
			}																					#													V
			$global_tag=$global_tag_tmp;														#now revert this value back to what it used to be............. - 20080502
			foreach $tmpattrib (@tmpattribs) {	#for each attribute, clean it
				$TYPE="";
				$current_full_tag = $tmpattrib;		#add_tag is recursive; this preserves the original argument so we can keep track of relations of parts of the expression versus itself in it's entirety (i.e. be sentient to the fact that, when processing "funny face", that it is part of comedy-funny face)
				if ($DEBUG_TAG_PROCESSING) { print "\t\t\t - TAG: $tmpfile  -AS-  $tmpattrib <BR>\n"; }
				&add_tag($tmpattrib,$tmpfile,"","","");
				if ($DEBUG_TAG_PROCESSING_REPORT) { print "......so \$tags{".$tmpfile."} is now \"$tags{$tmpfile}\" <BR><BR>\n";; }
			}
			##### Let us set tags at the environment to workaround junk:
			#if ($ENV{"TAGS"} ne "") {									#DEBUG: print "env tags is ".$ENV{"TAGS"}."\n";
			#	@envtags = split(/,/,$ENV{"TAGS"});
			#	foreach $tmptag (@envtags) { &add_tag($tmptag,$tmpfile,"","add",""); }
			#}
			#^^^^ 200806 this intefered with newly-implemented passing of ALL parameters via environment
		}
	}
	close(TAGS);
	if ($GENERATE_OUTPUT_FILE_ONLY==1) { print "...DONE!\n"; }

	if ($GENERATE_OUTPUT_FILE_ONLY==1) { print "* Assembling captions... "; }
	&assemble_all_captions;
	if ($GENERATE_OUTPUT_FILE_ONLY==1) { print "...DONE!\n"; }

	#WE ENDED UP USING A GLOBAL INSTEAD: return(\%tags);
}#endsub read_tags
################ READ TAGS - END ##################




###########################################################					This is the meatiest, largest function... perhaps ever written in my life.
sub clean_tag {
	my $s    = $_[0];
	my $file = $_[1];				#used for recursion-y things
	my $from = $_[2];				#used for recursion-y verbosity (debug)
	my $mode = $_[3];				
	$tmporiginaltag = $s;			#global used for speedup
	$TITLE="";						#global used for speedup
	$USEFULLNAME=0;					#global used for speedup

	#DEBUG:print "&clean_tag($s,$file,$from,$mode);<BR>\n";

	################ CLEAN TAG MEAT - BEGIN ################
	################ CLEAN TAG MEAT - BEGIN ################
	################ CLEAN TAG MEAT - BEGIN ################
	#OPENING KLUDGES:
	#should never be tags:
	#$s =~ /^Oranchak$//i;

	$s =~ s/\s+$//gi;		#remove trailing space


	#### ANTI-STALKER MEASURES:
	if ($s =~ /^from dad$/i) { $DO_NOT_SOURCE{$file}=1;	}			#anti-stalker


	#### KLUDGES CREATED BEFORE MOST OF THE LOGIC WAS INSERTED HERE:
	$s =~ s/Clint and Carolyn Lipinski's apartment/Clint and Carolyn's apartment/;
	$s =~ s/Virginia Tech\-Goodbye/Virginia Tech goodbye/i;
	$s =~ s/Lipinski Britt/Britt/i;
	$s =~ s/Neigh Britt/Britt/i;
#	$s =~ s/action figures/action figure/i;	#20120529 took out by Carolyn's request because it was scrubbing a mention of "action figures" in her caption
	$s =~ s/double exposed picture batch/double exposure/;
	$s =~ s/Washington DC/Washington D.C./ig;
	$s =~ s/\(ogre\) Jeff's house/Jeff Ogre's house/i;

	#### IF COULD BE A CAPTION, AND NOT A TAG:
	if ($s =~  /^caption-/i) {
		$s =~ s/^caption-//i;					
		if ($captionsFromTagfile{$file} ne "") { $captionsFromTagfile{$file} .= "<BR><BR> "; } #in case a file is captioned more than once, put a space between
		$captionsFromTagfile{$file} .= $s;
		$s="";
	#### IF COULD BE A POST-CAPTION, AND NOT A TAG:
	} elsif ($s =~  /^postcaption-/i) {
		$s =~ s/^postcaption-//i;				
		if ($postcaptionsFromTagfile{$file} ne "") { $postcaptionsFromTagfile{$file} .= "<BR><BR> "; } #in case a file is postcaptioned more than once, put a space between
		my $postCaptionTemp = $s;
		if (!$STOP_LINKIFY) { $postCaptionTemp = &linkify($s); }
		
		$postcaptionsFromTagfile{$file} .= $postCaptionTemp;
		$postcaptions{$postCaptionTemp}++;
		$s="";
	#### DATE TAGS:
	} elsif (($s =~ /^DATE /i) && ($SUSPEND_DATE_PROCESSING != 1)) {
		$TYPE = "date";
		$SUBTYPE = "";
		$s =~ s/^DATE //i;
		#YYYYMMDD:
		if ($s =~ /^([12][0-9][0-9][0-9][0-1][0-9][0-3][0-9])$/) {
			&add_tag($1,$file,$tmporiginaltag,"",$mode);
			$s =~ s/^([12][0-9][0-9][0-9][0-1][0-9])[0-3][0-9]$/$1/;
			#now YYYYMM:
		}
		if ($s =~ /^([12][0-9][0-9][0-9][0-1][0-9])$/) {
			&add_tag($1,$file,$tmporiginaltag,"",$mode);
			$s =~ s/^([12][0-9][0-9][0-9])[0-1][0-9]$/$1/;
			#now YYYY
		}
		if ($s =~ /^([12][0-9][0-9][0-9])$/) {
			&add_tag($1,$file,$tmporiginaltag,"",$mode);
			$s="";
		}
		if ($s =~ /^([12][0-9][0-9][0-9]s)$/) {
			&add_tag($1,$file,$tmporiginaltag,"",$mode);
			$s="";
		}
	} elsif ($s =~ /^windows background$/i) {
			&add_tag("desktop background",$file,$tmporiginaltag,"",$mode);
	#### PEOPLE TAGS:
	} elsif ($s =~  /^person-/i) {
		#print "PERSON!!!\n";
		$s =~ s/^person-//i;
		$TYPE = "person";
		$SUBTYPE = "";
		if ($s =~ /^random$/) { $s = "person random"; }		#gets inverted into 'random person' later
		if ($s =~ /\s+Jr\.?$/i) { 
			#DEBUG: print "JR HIT";
			$s =~ s/\s+Jr\.?$//i;
			$JUNIOR=" Jr."; 
		} else { 
			$JUNIOR=""; 
		}

		##### DEAL WITH PEOPLE WHO HAVE SPECIAL TITLES OR STATUSES:
		$CELEB=0;	 
		if   ( ($s =~ /^(celebrity)-/i) || ($s =~ /^(character)-/i)  || ($s =~ /^(politician)-/i) || ($s =~ /^(musician)-/i)		#### This code is in 2 places! Future optimization project?
			|| ($s =~ /^(Reverend)-/i)  || ($s =~ /^(Popes*)-/i)     || ($s =~ /^(Dr\.)-/i)       || ($s =~ /^(Dokt*o*r*)-/i)	|| ($s =~ /^(Doc)-/i)  
			|| ($s =~ /^(Princes*)-/i)  || ($s =~ /^(King)-/i)       || ($s =~ /^(Lord)-/i)       || ($s =~ /^(Prieste*s*)-/i) 
			|| ($s =~ /^(Queen)-/i)		|| ($s =~ /^(Duchess)-/i)	 || ($s =~ /^(Agent)-/i)      || ($s =~ /^(Saint)-/i)	 
			|| ($s =~ /^(DJ)-/i)        || ($s =~ /^(Admiral)-/i)	 || ($s =~ /^(Duke)-/i)	 	  || ($s =~ /^(Pontifex)-/i)
			|| ($s =~ /^(Sister)-/i)    || ($s =~ /^(porn *star)-/i) || ($s =~ /^(Deacon)-/i)     || ($s =~ /^(ASDFASDF)-/i)
			) {
			$tmp1=$1;
			&add_tag("$tmp1",$file,$tmporiginaltag,0,$mode);	#tag the title
			$s =~ s/^$tmp1-//i;
			$TITLE="$tmp1";
			if ($DEBUG_PERSON) { print "Setting title to $tmp1 and \$s is now \"$s\"...<BR>\n"; }
			if ($tmp1 =~ /^celebrity$/i) { $CELEB=1; $TITLE=""; }
			if (($tmp1 =~ /^character$/i) || ($tmp1 =~ /^politician$/i) || ($tmp1 =~ /^musician$/i) || ($tmp1 =~ /^porn *star$/i)) {	$TITLE .= ":";	}
		}
		##### SUBGENIUS AND OTHER NAMES THAT DON'T MAKE SENSE UNLESS THE WHOLE NAME IS DISPLAYED (!!LAST NAME FIRST!!):
		if (($s =~ /^Valerie Dildo/i)         || ($s =~ /^Day Bunny/i)          || ($s =~ /^Stain Orpheus/i)     || ($s =~ /^Dobbs J\.R\. "Bob"/i) || ($s =~ /^Lee Christopher/i)   || 
			($s =~ /^Committed Leonard The/i) || ($s =~ /^Proctor Morgan/i)     || ($s =~ /^La'*Verge Teeters/i) || ($s =~ /^Blackseed Jannus/i)   || ($s =~ /^Larry Angry/i)       || 
		    ($s =~ /^DeLimbo Jimbo/i)         || ($s =~ /^Wrong Lloyd Frank/i)  || ($s =~ /^Skull Richard/i)     || ($s =~ /^Pshaw Suds/i)         || ($s =~ /^Deathchick Nickie/i) || 
			($s =~ /^Lister Dave/i)           || ($s =~ /^McGee Sweetness/i)    || ($s =~ /^Feather Cat/i)		 || ($s =~ /^Alcandor Michael/i)   || ($s =~ /^Taj Feit C\.?/i)     ||
			($s =~ /^Mist Magic/i)            || ($s =~ /^WeirdAgain Rachel/i)  || ($s =~ /^Rhodes Dusty/i)      || ($s =~ /^Rauu Erazuu/i)	       || ($s =~ /^Springer Willow/i)   || 
			($s =~ /^Bee Ennie/i)             || ($s =~ /^Impaled Andrew The/i) || ($s =~ /^Abulafia Ankara/i)   || ($s =~ /^D'Veeve Joy/i)        || ($s =~ /^Ravel Nigel/i)       || 
			($s =~ /^Wild Bob/i)              || ($s =~ /^Bob Sideshow$/i)      ||
			($s =~ /^Duquette Lon Milo/i)	  || ($s =~ /^Dee Phat Man/i)	    || ($s =~ /^Amoeba Tommy/i)		 || ($s =~ /^Flooz[iey]* Sus[iey]* The/i)
		   )
		{
			$USEFULLNAME=1;
		}
		if ($s =~ /Mrs?./) { $USEFULLNAME=1; }	#if Mr or Mrs is in their title I probably don't know their 1st name, so saying "Mr." in the caption without their last name just doesn't make sense
		if ($DEBUG_PERSON) { print "<BR>[DEBUG_PERSON:AM1:s=$s/\$1=$1/\$2=$2,CELEB=$CELEB,TITLE=$TITLE]\n"; }


		if ($s =~ /^De (.+) (.+)/i) {
			if ($DEBUG_PERSON) { print "<BR>[DEBUG_PERSON:B00:s=$s/\$1=$1/\$2=$2]\n"; }
			$s =~ s/^De (.+) (.+)$/$2 De $1/i;
			if ($DEBUG_PERSON) { print "<BR>[DEBUG_PERSON:B00:s now =$s]\n"; }
		} elsif ($s =~ /^Van (.+) (.+)/i) {
			if ($DEBUG_PERSON) { print "<BR>[DEBUG_PERSON:B10:s=$s/\$1=$1/\$2=$2]\n"; }
			$s =~ s/^Van (.+) (.+)$/$2 Van $1/i;		#flip Van Gogh Vincent into Vincent Van Gogh
		} elsif (($s =~ /^person /i) || ($s =~ /^guy /) || ($s =~ /^girl /i) || ($s =~ /\'s ex-[bg][oi][yr]l?friend/) || ($s =~ /\'s [bg][oi][yr]l?friend/))  {
			if ($DEBUG_PERSON) { print "<BR>[DEBUG_PERSON:B20:s=$s/\$1=$1/\$2=$2]\n"; }
			#Do nothing.
			1;
		} elsif (($s !~ /\'s /i) && ($s !~ /^forgot /)) {				#"BOb's Girlfriend" should NOT be made "girlfriend Bob's" - normal names don't have apostrophes in them
			if ($DEBUG_PERSON) { print "<BR>[DEBUG_PERSON:B30:s=$s/\$1=$1/\$2=$2]\n"; }
			if ($s =~ /^(.*) (.*)$/) {
			if ($DEBUG_PERSON) { print "<BR>[DEBUG_PERSON:B40:s=$s/\$1=$1/\$2=$2]\n"; }
				##### SWITCH FIRST AND LAST NAMES:
				$s =~ s/^([^\s]+) (.*)$/$2 $1/i;
			} elsif ($s =~ /^(.*) (.*) ([JS]r)$/i) {
			if ($DEBUG_PERSON) { print "<BR>[DEBUG_PERSON:B45:s=$s/\$1=$1/\$2=$2]\n"; }
				$s =~ s/^(.*) (.*) ([JS]r)\.+$/$2 $1 $3/i;
			}
		}

		#### DEPRECATED  -- as it interferes, delete these lines with prejudice; they stop sponsored (automatic-by-person) captions from working:
		$s =~ s/^Becky Prophet$/Mom/i;					$s =~ s/^Becky Lipinski$/Mom/i;					$s =~ s/^Britt Lipinski$/Britt/i;		$s =~ s/^Britt Neigh$/Britt/i;
		$s =~ s/^Britt Sweet$/Britt/i;					$s =~ s/^Carolyn Lipinski$/Carolyn/i;			$s =~ s/^Chuck Sweet$/Chuck/i;
		$s =~ s/^Claire Sawyer$/Claire/i;				
		$s =~ s/^Clio Sawyer$/Clio/i;				
		$s =~ s/^Clio Lipinski$/Clio/i;				
		$s =~ s/^Clint Lipinski$/Clint/i;				$s =~ s/^Eve Prophet$/Eve/i;					$s =~ s/^Eve Mens$/Eve/i;
		$s =~ s/^Eve Gravely$/Eve/i;					$s =~ s/^Jennifer Prophet$/Jennifer/i;			$s =~ s/^Nathan Gravely$/Nathan/i;
		$s =~ s/^Todd Henrich$/Todd/i;					$s =~ s/^Vic Lipinski$/Dad/i;					$s =~ s/^Vicky Sawyer$/Vicky/i;
		$s =~ s/^Vicky Herrala$/Vicky/i;

		## Finally, specific people get specific tags:
		if (($s =~ /^Phyllis Prophet$/i) || ($s =~ /^Maria Lipinski$/i) || ($s =~ /^Ronnie Lipinski$/i) || ($s =~ /^Maria Clara Rechen$/i)) {
			&add_tag("Grandma",$file,$tmporiginaltag,"",$mode);
		}
		if (($s =~ /^Mark Prophet$/i) || ($s =~ /^James Bernard Lipinski$/i)) {		#Mark Prophet is problematic because I have a half-cousin-or-something with that name
			&add_tag("Grandad",$file,$tmporiginaltag,"",$mode);
		}
		if ($s =~ /^Ronnie Lipinski$/i) {
			$STOP_ALL_CAPTIONING=1;
			&add_tag("person-Rechen Maria Clara",$file,$tmporiginaltag,0,$mode);	#Ronnie Lipinski aka Maria Clara Rechen
			$STOP_ALL_CAPTIONING=0;
		}
		$s .= $JUNIOR;
		if ($s =~ /^Bob Dobbs$/i) {
			if ($DEBUG_AUTOCAPTION) { print "[[[Bob encountered. mode=$mode]]] \n"; }
			$people{"$file$DELIMITER" . "J.R. ''Bob'' Dobbs"}=1;							#I have no clue why this is broken, but this is how to fix it.

			&add_tag("J.R. ''Bob'' Dobbs"     ,$file,$tmporiginaltag,"",$mode);
			#add_tag("JR Bob Dobbs"           ,$file,$tmporiginaltag, 0,$mode);	#
			#add_tag("JR 'Bob' Dobbs"         ,$file,$tmporiginaltag, 0,$mode);	#same thing as far as flickr is concerned
			#add_tag("J.R. Bob Dobbs"         ,$file,$tmporiginaltag, 0,$mode);	#
			&add_tag("''Bob'' Dobbs"          ,$file,$tmporiginaltag, 0,$mode);
			&add_tag("''Bob''"                ,$file,$tmporiginaltag, 0,$mode);
			&add_tag("SubGenius"              ,$file,$tmporiginaltag, 0,$mode);
			&add_tag("Church Of The SubGenius",$file,$tmporiginaltag, 0,$mode);
			$s="";
		}

		$tmp=$s;
		if ((!$CELEB) && (!$USEFULLNAME) && ($s !~ /^The /i) && ($s !~ /\'s /)) {	$tmp =~ s/ .*$//;	$tmp =~ s/_SPC_/ /g; }	#strip captions to first names only
		if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[4C] $tmp on people<BR>\n"; }		
		if (($s =~ /^guy /) ||($s =~ /^man /) ||($s =~ /^woman /) ||  ($s =~ /^boy /) ||($s =~ /^girl /) || ($s =~ /^person /)){
			#don't add it to the people for the caption
		} else {
			#DEBUG:			print "STOP_ALL_CAPTIONING is $STOP_ALL_CAPTIONING for $s <BR>\n";#
			if ($STOP_ALL_CAPTIONING != 1) {
				if ($TITLE ne "") {
					$people{"$file$DELIMITER$TITLE $s"}="1";
				} else {
					$people{"$file$DELIMITER$tmp"}     ="1";			#changing this from $tmp to $s will cause LAST NAMES to appear in captions which is NOT what I want. Don't try that again!
				}
			}
		}
		if ($TITLE ne "") { &add_tag("$TITLE $s",$file,$tmporiginaltag,"",$mode); }
		&add_tag("$s",$file,$tmporiginaltag,0,$mode);
		$s="";
	}#endif person
	################################ END PERSON ################################
	################################ END PERSON ################################

	if ($s =~ /^parody-/i) {
		$s = "thing-$s";				#let's shove parodies into things and see what happens
	}


	################################ BEGIN THING ################################
	################################ BEGIN THING ################################
	#thing-food becomes food and is deal with below
	if ($s =~ /^thing-/i) {
		$TYPE = "thing";
		$SUBTYPE = "";
		$s =~ s/^thing-//i;	
		if ($DEBUG_THING) { print "<BR>\n[DT] <B>Thing encountered... \"$s\"...</B><BR>\n"; }


		
		#sometimes a descriptor at the end like "broken" in thing-whatever-broken determins the tag algorithm more than what the 'whatever' is
		if (($s =~ /^(.*)-(broken*)$/i) || ($s =~ /^(.*)-(peeling*)$/i) || ($s =~ /^(.*)-(yellow)$/i)) {
			my $tmp1=$1;
			my $tmp2=$2;
			&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);		#"broken whatever"
			&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);		#"whatever"
			$s="";
		}



		#some thing1 items get immediately stripped off and re-fed back in.
#		if ($s =~ /^(hardwares*)-/i) 
		if ($s =~ /^(hardwares*)-([^\-]*)$/i) {			#201208 changed to this, so it only affects 2-chain hardware
			if ($DEBUG_THING) { print "[2-chain hardware found OIA]";	}
			$tmp1=$1;
			&add_tag("$tmp1",$file,$tmporiginaltag,0,$mode);
			$s =~ s/^$tmp1-//i;
			&add_tag("thing-$s",$file,$tmporiginaltag,0,$mode);
			$s="";
		}

		#autographs need a name-fix
		if ($s =~ /^(autograph*)-([^\-]*)$/i) {
			$tmp1=$2;
			$tmp1=&fix_name_of_any_form($tmp1);
			&add_tag("autograph"      ,$file,$tmporiginaltag,0,$mode);
			&add_tag("$tmp1"          ,$file,$tmporiginaltag,0,$mode);
			&add_tag("$tmp1 autograph",$file,$tmporiginaltag,1,$mode);
			$s="";
		}



		#A common ambiguity is singular Transformers toys tagged as Transformer instead of Transformers:
		if (($s =~ /toy-Transformer$/) || ($s =~ /toy-Transformer-/)) { &add_tag("Transformers",$file,$tmporiginaltag,0,$mode);  }	#ALIAS

		#using above pattern randomly:
		if ($s =~ /toy-pony-/ ) { &add_tag("toy pony",$file,$tmporiginaltag,0,$mode);   
		                          &add_tag("pony toy",$file,$tmporiginaltag,0,$mode); }
		if ($s =~ /toy-nail$/i) { &add_tag("nail toy",$file,$tmporiginaltag,0,$mode); 
		                          &add_tag("toy nail",$file,$tmporiginaltag,0,$mode); }

		if (($s =~ /toy-cat$/)         || ($s =~ /toy-cat[\-\ ]/))    { 
			&add_tag("toy"			,$file,$tmporiginaltag,0,$mode);  
			&add_tag("cat toy"		,$file,$tmporiginaltag,0,$mode);  
			if ($s =~ /toy-cat-([^\-]*)$/i) {
				$tmp1=$1;
				&add_tag("$tmp1"			,$file,$tmporiginaltag, 0,$mode);  
				&add_tag("$tmp1 toy"		,$file,$tmporiginaltag, 0,$mode);  
				my $captionLast="";
				if (($tmp1 =~ /^tunnel$/) || ($tmp1 =~ /^tree$/) || ($tmp1 =~ /^house$/))  {	#"cat house","cat tree","cat tunnel" don't get tagged as "cat X toy" like other cat toys do
					&add_tag("cat $tmp1",$file,$tmporiginaltag,"",$mode);  
					$captionLast=0;
				}
				&add_tag("$tmp1 cat toy"   ,$file,$tmporiginaltag,$captionLast,$mode);  
				$s="";
			}
		}

		if ($s =~ /^(instruments*)-/i) {									#strip first in chain, process rest as if 1st wasn't there
			$tmp1=$1;
			&add_tag("$tmp1",$file,$tmporiginaltag,0,$mode);
			$s =~ s/^$tmp1-//i;
			&add_tag("thing-$s",$file,$tmporiginaltag,0,$mode);
			$s="";
		}

		if (($s =~ /^camcorder$/i) || ($s =~ /^video camera$/) || ($s =~ /^camera-video$/i)) {			#thing
			&add_tag("video camera",$file,$tmporiginaltag,"",$mode);
			&add_tag("camcorder",   $file,$tmporiginaltag, 0,$mode);
			&add_tag("camera",      $file,$tmporiginaltag, 0,$mode);
			#&add_tag("video camera",$file,$tmporiginaltag,0,$mode);
			$s="";
		}

		if ($s =~ /^bench-/i) {			#thing
			$s =~ s/^bench-//i;
			if ($s =~ /^bidirectional$/i) {
				&add_tag("bidirectional bench",$file,$tmporiginaltag,0, $mode);
				&add_tag(      "two-way bench",$file,$tmporiginaltag,"",$mode);
				&add_tag(        "2-way bench",$file,$tmporiginaltag,0, $mode);
				$s="";
				&add_tag("bench",$file,$tmporiginaltag,0,$mode);
			} else {
				&add_tag("bench",$file,$tmporiginaltag,"",$mode);
			}
		}
		#aliases and such go around here		
		if ($s =~ /^flag-pirate$/i) { &add_tag("Jolly Roger",$file,$tmporiginaltag,"",$mode); }
		if ($DEBUG_THING) { print "[DT-progress-1,s=$s] <BR>\n"; }

		if ($s =~  /^Guitarceline guitar$/i) { &add_tag("Guitarceline",$file,$tmporiginaltag,0,$mode); }
		if ($s =~  /^jacket-leather$/i) { &add_tag("leather jacket",$file,$tmporiginaltag,"",$mode); }
		if ($s =~  /^jacket-denim$/i) { 
			&add_tag("denim jacket",$file,$tmporiginaltag,"",$mode); 
			&add_tag( "jean jacket",$file,$tmporiginaltag,"",$mode); 
		}
		if ($s =~  /^Catholic school *girl$/i) { 
			&add_tag("Catholic",$file,$tmporiginaltag,"",$mode); 
			&add_tag("schoolgirl",$file,$tmporiginaltag,"",$mode); 
		}
		if ($s =~  /^gun-([^\-]*)$/i) {			#updated from .* to [^\-]* 201111 after shooting real guns with makes and models kind of broke the logic here [which originally only applied to TOY guns]
			my $tmp1=$1;
			&add_tag(      "gun",$file,$tmporiginaltag,0,$mode);
			&add_tag("$tmp1 gun",$file,$tmporiginaltag,1,$mode);
			$s="";
		}
		if ($s =~ /^pier-(.*)$/i) {
			&add_tag("pier",$file,$tmporiginaltag,0,$mode);
			&add_tag("$1 pier",$file,$tmporiginaltag,"",$mode);
			$s="";
		}
		if ($s =~  /boat-toy$/i) {
			&add_tag("boat",$file,$tmporiginaltag,"",$mode);
			&add_tag("toy",$file,$tmporiginaltag,"",$mode);
			&add_tag("toy boat",$file,$tmporiginaltag,"",$mode);
			$s="";
		}
		if (($s =~  /truck-(coal)$/i) || ($s =~  /truck-(fire)$/i)) {									#This could be developed into a "truck catch-all" for trucks that don't tag right correctly off the bat
			my $tmp1=$1;
			&add_tag("truck"      ,$file,$tmporiginaltag,0,$mode);
			&add_tag("$tmp1 truck",$file,$tmporiginaltag,1,$mode);
			$s="";
		}
		if ($s =~ /^(shots)*-(.*)$/) {
			my $tmp1=$1;
			my $tmp2=$2;
			if ($DEBUG_THING > 0) { print "DBTGHS - WE ARE HERE! \$s is $s, tmp1=$tmp1, tmp2=$tmp2<BR>\n"; } 
			&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode,0);
			&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);
			$s="";
		}
		if ($DEBUG_THING) { print "[DT-progress-2a,s=$s] "; }
		#DEPRECATED! It should be thing-case-computer-[brandname] nowadays!:
		if ($s =~  /computer-case$/i) {	&add_tag("computer case",$file,$tmporiginaltag,"",$mode); $s=""; }
		#if ($DEBUG_THING) { print "[DT-progress-2b] "; }
		if ($s =~  /^collection-/i) {
			&add_tag("collection",$file,$tmporiginaltag,0,$mode);	#don't caption that, we'll caption the one below
			$s =~  s/^collection-//i;
			if ($s =~ /^([^\-]*)-([^\-]*)$/i) {
				my $tmp1=$1; 
				my $tmp2=$2;
				my $tmp = $s;
				$STOP_ALL_CAPTIONING = 1;
				&add_tag("thing-$tmp",$file,$tmporiginaltag,0,$mode);	#don't caption that, we'll caption the one below
				$STOP_ALL_CAPTIONING = 0;
				$s = "$tmp2 $tmp1";
			}
			&add_tag("$s",$file,$tmporiginaltag,0,$mode);			#don't caption that, we'll caption the one below
			$s = &singular($s,1);									#is this still a good idea? Yes, it is!
			$s = "$s collection";									#this one will go in the caption
			#DEBUG: print "* tmptag for collectoin is: $tmptag\n";
			&add_tag($s,$file,$tmporiginaltag,"",$mode);
			$s="";
			if ($DEBUG_THING) { print "[DT-progress-B1] "; }
		} elsif (($s =~ /^(house)-/i) || ($s =~ /^(trailer)-/i)) {						#thing-house
			my $tmp5=$1;			
			&add_tag("$tmp5",$file,$tmporiginaltag,0,$mode);
			if (($s =~ /^(house)-(.*)-(.*)-([^\-]*)$/) || ($s =~ /^(trailer)-(.*)-(.*)-([^\-]*)$/)) {		#house catch-all development started 200805
				my $tmp1=$1;								#house/trailer
				my $tmp2=$2;								#state
				my $tmp3=$3;								#city
				my $tmp4=&fix_name_of_any_form($4);			#name
				#DEBUG: 								print "{{{ [DT-progress-B1-CA][tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4] }}}<BR>\n"; #DEBUG_HOUSE DEBUG_THING_HOUSE thing-house debugging	#
				$s="";										#done, because this is a catch-all
				&add_tag("$tmp1",          $file,$tmporiginaltag,"",$mode);	#house
				&add_tag("$tmp2",          $file,$tmporiginaltag, 0,$mode);
				&add_tag("$tmp3",          $file,$tmporiginaltag, 0,$mode);
				&add_tag($tmp4 ."'s $tmp1",$file,$tmporiginaltag, 0,$mode);
			}


			#DEPRECATED STUFF:
			if (($s =~ /Eric Axilbund's house/i) && ($s =~ /Cambridge/i)) { &add_tag("Eric Axilbund's Cambridge house",$file,$tmporiginaltag,"",$mode);	}
			$s =~ s/house-Maryland-Cambridge-Axilbund Eric-outside/outside of Eric Axilbund's Cambridge house/i;
			if ($s =~ /^outside of (.*)$/i) {&add_tag($1,$file,$tmporiginaltag,"",$mode); }
			$s =~ s/house-Maryland-Cambridge-Axilbund Eric/Eric Axilbund's Cambridge house/;
#			$s =~ s/house-Virginia-Petersburg-Eve and Eric Mens/Eve and Eric Mens's house/i;
#			$s =~ s/house-.+-([^\s]+) ([^\s]+) and ([^\s]+)$/$2 and $3 $1's house/i;
#			$s =~ s/house-([^\s]+) ([^\s]+) and ([^\s]+)$/$2 and $3 $1's house/i;
#			#untested?:
#			$s =~ s/house-([^\s]+) ([^\s]+)$/$2 and $1's house/i;
			#failed $s =~ s/house-([^\s]+)-([^\s]+)-([^\s]+) ([^\s]+) and ([^\s]+)$/$4 $3 and $5's house/i;
			$s =~ s/Carolyn Lipinski/Carolyn/i;
			$s =~ s/Claire Sawyer/Claire/i;
			$s =~ s/Vic \& Becky Lipinski's house/Mom and Dad's house/i;

		
		
		############## ART! #################
		} elsif ($s =~  /^art-/i) {
			$tmp1="";$tmp2="";$tmp3="";$tmp4="";$tmp5="";$tmp="";
			$is_artist=1;
			&add_tag("art",$file,$tmporiginaltag,0,$mode);
			$s =~ s/^art-//i;
			if ($DEBUG_ART) { print "<BR><BR>[[[ART-BEGIN-00]]] \$s is $s<BR>\n"; }
			$s =~ s/^music-album cover$/album cover/i;
			if ($s !~ /[A-Z]/) { $is_artist=0; }			#artists have capitalized names, so if we are describing an art that has no capital, it is probably not an artist name
			#old kludge before &fix_name_of_any_form was created: $s =~ s/Reverend-([^\-]*)/$1 Reverend/i;
			#no, not yet: $s = &fix_name_of_any_form($s);
			if ($DEBUG_ART>0) { print "<BR>[[[ART-1]]] \$s is $s, is_artist=$is_artist<BR>\n"; }
			if ($s eq "sand art") {
				&add_tag("sand art",$file,$tmporiginaltag,1,$mode);
				$s="";
			} 
			if (($s =~ /^(sculptures*)-*/i) || ($s =~ /^(statues*)-*/i)) {
				$tmp3=$1;
				$is_artist=0;
				if ($DEBUG_ART>0) { print "[[[ZZTQ]]] \$s is $s, tmp3=$tmp3<BR>\n"; }
				if (($s =~ /^(sculptures*)-(sand)-*/i) || ($s =~ /^(sculptures*)-(.*)/i)) {
					$tmp4=$1; $tmp5=$2;
					if ($DEBUG_ART>0) { print "[[[ZZFP]]] \$s is $s, /tmp4=$tmp4/tmp5=$tmp5/<BR>\n"; }
					&add_tag("$tmp5"      ,$file,$tmporiginaltag, 0,$mode);	#corn
					&add_tag("$tmp5 $tmp4",$file,$tmporiginaltag,"",$mode);	#corn sculpture
					&add_tag("$tmp4"      ,$file,$tmporiginaltag, 0,$mode);	#sculpture
					$s =~ s/^$tmp4-$tmp5-*//;
				} else {
					&add_tag("$tmp3",$file,$tmporiginaltag,"",$mode);
				}
				if ($s =~ /^(statues*)-([^\-]*)/i) {
					$tmp1=$1;
					$tmp2=$2;
					&add_tag("$tmp2"      ,$file,$tmporiginaltag, 0,$mode);
					&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);
					$s =~ s/^$tmp1-*//i;
				}
				$s =~ s/^$tmp3-*//;
				if ($s =~ /bird-Hokie/) {
					&add_tag("bird"      ,$file,$tmporiginaltag, 0,$mode);
					&add_tag("Hokie"     ,$file,$tmporiginaltag, 0,$mode);
					&add_tag("Hokie bird",$file,$tmporiginaltag,"",$mode);
					$s =~ s/bird-Hokie//i;
				}
			} elsif (($s =~ /^(computer)$/) || ($s =~ /^(ASCII)$/i) || ($s =~ /^(ANSI)$/i)) {
				my $tmp1=$1;
				&add_tag("$tmp1 art",$file,$tmporiginaltag,0,$mode);
				$is_artist=0;
				$s = "";
			} elsif ($s =~ /^music-/) {
				&add_tag("music",$file,$tmporiginaltag,"",$mode);
				&add_tag("music-related art",$file,$tmporiginaltag,"",$mode);
				$is_artist=0;
				$s =~ s/^music-//;
			} elsif (
				       ($s =~ /^(paintings*)-(.*)$/) || ($s =~ /^(paintings*)$/)  	#200702
					|| ($s =~ /^(scratchboards*)-(.*)$/)							#201602
				) {	#200702
				my $tmp1=$1; 
				my $tmp2=$2;
				if ($DEBUG_ART) { print "[DEBUG-ART:PAINTING][s=$s/tmp1=$tmp1/tmp2=$tmp2]<BR>\n"; }
				$is_artist=0;
				&add_tag("$tmp1",$file,$tmporiginaltag,"",$mode);	#painting
				if ($tmp2 ne "") {
					&add_tag("$tmp2"      ,$file,$tmporiginaltag,0,$mode);	#Starry Night
					&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);	#Starry Night painting
				}
				$s="";

#				#### The old way, before we decided the artist's name can only follow thing-art, not thing-art-[arttype]
#				if ($s =~ /^The /i) {									#that's a title, not an artist
#					&add_tag("$s",$file,$tmporiginaltag,"",$mode);		#test based on The Scream
#					$s="";
#				}
			} elsif (($s =~ /^mural-/) || ($s =~ /^mural$/)) {	#200702
				&add_tag("mural",$file,$tmporiginaltag,"",$mode);
				$is_artist=0;
				$s =~ s/^mural-*//;
			} elsif (($s =~ /^graffit+i-/) || ($s =~ /^graffit+i$/)) {	#200702
				&add_tag("graffiti",$file,$tmporiginaltag,"",$mode);
				$is_artist=0;
				$s =~ s/^graf+itti-*//;
			} elsif (($s =~ /^rocks*-/) || ($s =~ /^rocks*$/)) {	#200702
				&add_tag("rocks",$file,$tmporiginaltag,"",$mode);
				$is_artist=0;
				$s =~ s/^rocks*-*//;
			} elsif (($s =~ /^(fractal)$/i) || ($s =~ /^(nail)$/i)) {
				&add_tag("$1 art"     ,$file,$tmporiginaltag,"",$mode);
				&add_tag("$1"         ,$file,$tmporiginaltag, 0,$mode);
				&add_tag(&plural("$1"),$file,$tmporiginaltag, 0,$mode);
				$s="";
			} elsif (($s =~ /^(string)$/i) || ($s =~ /^(wood)$/i)) {									#string art, wood art
				&add_tag("$1"    ,$file,$tmporiginaltag, 0,$mode);
				&add_tag("$1 art",$file,$tmporiginaltag,"",$mode);
				$s="";
			} elsif ($s =~ /^(picture-.*)$/i) {									#fold pictures into thing-catcha1l by prepending "thing" to it:
				&add_tag("thing-$1",$file,$tmporiginaltag,"",$mode);
				$s="";
			} elsif ($s eq "stereogram") {
				&add_tag("stereogram",$file,$tmporiginaltag,"",$mode);
				$s="";
			#BLANKS:
			#}elsif ($s eq "") {								&add_tag("sand art",$file,$tmporiginaltag);				$s=","",$mode";
			#}elsif ($s eq "") {								&add_tag("sand art",$file,$tmporiginaltag);				$s=","",$mode";
			#}elsif ($s eq "") {								&add_tag("sand art",$file,$tmporiginaltag);				$s=","",$mode";
			} 
			if ($DEBUG_ART > 0) { print "56XX0 - WE ARE HERE! \$s is $s, tmp=$tmp<BR>\n"; }
			#This used to be an elsif. This is a big experiment, breaking it off. I wish I'd explained to myself why this was necessary, though.
			#f ($s =~ /^([^\s]+)$/) 
			if ($s =~ /^(.*)$/) {									# Took years for this to break; now it's pretty much a null/do-nothing if
				my $tmp1 = $1;	 
				if ($tmp eq "") { $tmp = $1; }						# I'm so confused by how I did this before ... I THINK this may fix my 200809 problems
				if ($tmp =~ /[A-Z]/) {								# if it's capital letters, it's probably the creator's name and not something like 'crow' ("crow painting")
					$tmp1=&fix_name_of_any_form($tmp1);
					$tmp = "by $tmp1"; 
				}			
				$tmp =~ s/\s+$//;
				if ($DEBUG_ART > 0) { print "56XX9 - WE ARE HERE! \$s is $s ... /tmp1=$tmp1/tmp2=$tmp2/tmp=$tmp/is_artist=$is_artist/ <BR>\n"; }
				if ($is_artist) { 
					if ($DEBUG_ART > 0) { print "[56XX9-1][tmp=$tmp]<BR>\n"; }
					$TYPE = "artby";
					$s = &fix_name_of_any_form($s);
					my $argh=$tmp;
					$argh = &censor_tag($argh);
					&add_tag($argh,$file,$tmporiginaltag,0,$mode); 
					if ($artby{$file} eq "") {
						$artby{$file}="$s";
						if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[9] $s onto \$artby{$file} which is now ".$artby{$file}."<BR>\n"; }
					} else {
						$artby{$file}.=", $s";
						if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[9] $s onto \$artby{$file} which is now ".$artby{$file}."<BR>\n"; }
					}
				} elsif ($tmp =~ /^paintings*$/) {
					if ($DEBUG_ART > 0) { print "[56XX9-2][tmp1 tmp=$tmp1 $tmp]<BR>\n"; }
					$tmp5 = "$tmp1 $tmp";
					$tmp5 =~ s/painting painting/painting/i;
					&add_tag($tmp5,$file,$tmporiginaltag,"",$mode); 
				}
				$tmp =~ s/^by ([^\s+]+)$/$1's art/;
				if ($is_artist) { 
					if ($DEBUG_ART > 0) { print "[56XX9-3][tmp=$tmp]<BR>\n"; }
					&add_tag($tmp,$file,$tmporiginaltag,0,$mode); 
				}
				if ($DEBUG_ART > 0) { print "[56XX9-99][\$s=$s,tmp=$tmp]<BR><BR>\n\n"; }
			} elsif ($s =~ /^([^\s]+) ([^\s].+)(-.*)$/) {	#thing-art-lipinski clio-something something - without somethingsomething is handled below
				if ($DEBUG_ART > 0) { print "93YY9 - WE ARE HERE! \$s is $s<BR>\n"; }
				$tmp1 = $1;				#Smith
				$tmp2 = $2;				#John
				$s =~ &censor_w_real_spaces($s);
				#DEBUG: print "\$s is $s ... tmp1 is $tmp1 ... tmp2 is $tmp2 ... \$tmp is $tmp ... [yy3m]\n";
				$tmp = "by $tmp2";
				if (($tmp1 =~ /^lipinski$/i) && ($tmp2=~ /^James$/i))	{		$s =~ s/James Lipinski/Grandad/i;	}
				if (($tmp1 =~ /^lipinski$/i) && ($tmp2=~ /^Vic$/i))		{		$s =~ s/Vic/Dad/i;					}
				if (($tmp1 =~ /^lipinski$/i) && ($tmp2=~ /^Becky$/i))	{		$s =~ s/Becky/Mom/i;				}
				if (($tmp1 !~ /^lipinski$/i) && (($tmp1 !~ /^Sawyer$/i) && ($tmp2 !~ /^Vicky$/i))) { $tmp .= " $1";	} 
				if ($tmp =~ /^by Vic$/i) { $tmp="by Dad"; }
				$tmp =~ s/\s+$//;
				&add_tag($tmp,$file,$tmporiginaltag,"",$mode);
				$tmp =~ s/^by ([^\s]+)$/$1's art/;
				$tmp =~ s/^by ([^\s]+) ([^\s]+)$/$2 $1's art/;
				&add_tag($tmp,$file,$tmporiginaltag,"",$mode);
				$s =~ s/Lipinski Clint/Clint/i;
				$s =~ s/Lipinski Clio/Clio/i;
				$s =~ s/Sawyer Clio/Clio/i;
				$s =~ s/Sawyer Claire/Claire/i;
				$s =~ s/Lipinski Carolyn/Carolyn/;
				#DEBUG: print "FINALLY S IS: $s\n";
				$s =~ s/^([a-z]+) ([a-z]+)-(.*)$/$3/i;
			} elsif ($s =~ /^drawing$/i) {
				if ($DEBUG_ART > 0) { print "ABB3344 - WE ARE HERE! \$s is $s<BR>\n"; }
				&add_tag("drawing",$file,$tmporiginaltag,"",$mode);
			} elsif ($s =~ /^sketch$/i) {
				if ($DEBUG_ART > 0) { print "AAA2233 - WE ARE HERE! \$s is $s<BR>\n"; }
				&add_tag("sketch art",$file,$tmporiginaltag,"",$mode);
				&add_tag("drawing",$file,$tmporiginaltag,"",$mode);
			} elsif ($s =~ /^album cover$/i) {
				&add_tag("album"      ,$file,$tmporiginaltag,0,$mode);
				&add_tag("cover"      ,$file,$tmporiginaltag,0,$mode);
				&add_tag("album cover",$file,$tmporiginaltag,0,$mode);
				$s="";
			} elsif ($s =~ /^([^\s]+) ([^\s]+)$/i) {
				$tmp1=$1;
				$tmp2=$2;
				if ($DEBUG_ART > 0) { print "MNOP66 - WE ARE HERE! \$s is $s<BR>\n"; }
				if ($s =~ /Brothers$/i) {		#Marx Brothers
					$s = "$tmp1 $tmp2";
				} else {
					$s = "$tmp2 $tmp1";
				}
				$TYPE = "artby";
				$s=&fix_name_of_any_form($s);		#added 201105
				#DEBUG: print "s is now $s!!!\n<BR>";
				&add_tag($s . "'s art",$file,$tmporiginaltag,0,$mode);	#,0?
				&add_tag("by $s",      $file,$tmporiginaltag,0,$mode);	#,0?
				if ($artby{$file} eq "") {
					$artby{$file}="$s";
					if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[9] $s onto \$artby{$file} which is now ".$artby{$file}."<BR>\n"; }
				} else {
					$artby{$file}.=", $s";
					if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[9] $s onto \$artby{$file} which is now ".$artby{$file}."<BR>\n"; }
				}
				$TYPE="person";
				&add_tag($s,$file,$tmporiginaltag,"",$mode);
			} elsif ($s =~ /^([^\s]+) ([^\s]+) ([^\s]+)$/i) {				#basically 3-name artist copy of the 2-name artist code above - this could definitely be done more efficiently
				$tmp1=$1;
				$tmp2=$2;
				$tmp3=$3;
				if ($DEBUG_ART > 0) { print "QRST66 - WE ARE HERE! /s=$s/tmp1=$tmp1/tmp2=$tmp2/tmp3=$tmp3/<BR>\n"; }
				$s=&fix_name_of_any_form($s);
				if ($DEBUG_ART > 0) { print "QRST66 - WE ARE HERE! /s=$s/tmp1=$tmp1/tmp2=$tmp2/tmp3=$tmp3/<BR>\n"; }
				$TYPE = "artby";
				&add_tag($s . "'s art",$file,$tmporiginaltag,0,$mode);	#,0?
				&add_tag("by $s",      $file,$tmporiginaltag,0,$mode);	#,0?
				if ($artby{$file} eq "") {
					$artby{$file}="$s";
					if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[9] $s onto \$artby{$file} which is now ".$artby{$file}."<BR>\n"; }
				} else {
					$artby{$file}.=", $s";
					if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[9] $s onto \$artby{$file} which is now ".$artby{$file}."<BR>\n"; }
				}
				$TYPE="person";
				&add_tag($s,$file,$tmporiginaltag,"",$mode);
			} else {
				if ($DEBUG_ART > 0) { print "[DEBUG_ART]ZZZYYYZZZ - WE ARE HERE! \$s is $s<BR>\n"; }
				$s =~ s/Lipinski Vic/Dad/;			#stalker/privacy
				$s =~ s/Lipinski Becky/Mom/;		#stalker/privacy
				$s =~ s/Lipinski Clint/Clint/;		#stalker/privacy
				$s =~ s/Lipinski Clio/Clio/;		#stalker/privacy
				$s =~ s/Sawyer Clio/Clio/;			#stalker/privacy
				$s =~ s/Sawyer Claire/Claire/;		#stalker/privacy
			}
			if ($DEBUG_ART > 0) { print "[58ZZ-3][s=$s]"; }
		} elsif ($s =~ /X-ray$/i) {			#thing
			&add_tag("X-ray",$file,$tmporiginaltag,"",$mode);
			$s =~ s/X-ray$//i;
#		} elsif ($s =~ /^document-/) {			#thing
#			&add_tag("document",$file,$tmporiginaltag,"",$mode);
#			$s =~ s/document-(.*)$/$1 document/;
		#DEPRECATED
		#} elsif ($s =~  /^flag-[a-z\.]+$/i) {
		#	&add_tag("flag",$file,$tmporiginaltag,"",$mode);
		#	$s =~ s/^flag-//i;
		#	&add_tag("$s flag",$file,$tmporiginaltag,"",$mode);
		#	&add_tag("$s",$file,$tmporiginaltag,"",$mode);
		#	$s =~ s/\.//g;
		#	&add_tag("$s flag",$file,$tmporiginaltag,"",$mode);
		#	&add_tag("$s",$file,$tmporiginaltag,"",$mode);
		#DEPRECATED
		#} elsif ($s =~  /^fire-pit/i) {												#There can be fire pits without fire, so this is probably not a good idea.
		#	&add_tag("fire",$file,$tmporiginaltag,"",$mode);
		#	&add_tag("fire pit",$file,$tmporiginaltag,"",$mode);
		#	$s =~ s/fire-pit//;

		} elsif ($s =~ /^(food)-(platters*)-(.*)-(.*)$/i) {
			my $tmp1=$2; my $tmp2=$3; my $tmp3=$4;
			if (($DEBUG_THING) || (0)) { print "[PLATTER FOUND!] tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3<BR>\n"; }
			&add_tag("food"             ,$file,$tmporiginaltag,0,$mode);	#food
			&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);	#platter
			&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);	#seafood
			&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);	#seafood platter
			&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag,0,$mode);	#broiled platter
			&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#broiled seafood
			&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);	#broiled seafood platter
			$s="";
		} elsif (($s =~  /^food-/i) && ($s !~ /^food\-[^\-]*\-[^\-]*\-/)) {				#food with 4+ dashes after "food" instead goes to our "thing chain catch-all" code
			#if ($cleaned{$1} eq "") { &add_tag($1,$file,$tmporiginaltag,"",$mode);	}		
			if (($DEBUG_THING) || ($DEBUG_FOOD>0)) { print "[FOOD encountered! \$s=$s]"; }
			&add_tag("food",$file,$tmporiginaltag,"",$mode);
			$s =~ s/food-//;

			if ($s =~ /^(condiment)-(.*)$/i) {
				$tmp1=$1; $tmp2=$2;
				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);
				&add_tag("thing-$tmp2",$file,$tmporiginaltag,"",$mode);
				$s="";
			}
			if ($DEBUG_FOOD>0) { print "FOOD HERE 1X1X1X: s is $s<BR>\n"; }



			

			if (($s =~ /^(Indian)(-*)/)  || ($s =~ /^(Japanese)(-*)/) || ($s =~ /(^Mexican)(-*)/)  || 
				($s =~ /^(Italian)(-*)/) || ($s =~ /^(Chinese)(-*)/)  || ($s =~ /(^Peruvian)(-*)/) || 
				($s =~ /^(Mexican)(-*)/) || ($s =~ /^(Salvadorian)(-*)/)) {
				$tmp1=$1; $tmp2=$2;
				&add_tag("food",$file,$tmporiginaltag,0,$mode);
				if ($tmp2 eq "") {											#if the food is not named (just "Chinese food")...
					&add_tag("$1 food",$file,$tmporiginaltag,"",$mode);		#...then, caption it
				} else {													#else
					&add_tag("$1 food",$file,$tmporiginaltag,0,$mode);		#don't caption it
				}
				$s =~ s/^$tmp1-*//i;
			}
			
			if ($DEBUG_FOOD >= 1) { print "HERE! 3Y3Y3Y3Y s=\"$s\"<BR>\n"; }

			if ($s =~ /^pudding-/i) {
				&add_tag("pudding",$file,$tmporiginaltag,0,$mode);
				$s =~ s/^pudding-(.*)/$1 pudding/i;
				$s =~ s/pudding pudding/pudding/i;
			} elsif ($s =~ /^hamburger$/)        { &add_tag("burger",$file,$tmporiginaltag,0,$mode); } 
			  elsif ($s =~ /^cheeseburger$/)     { &add_tag("burger",$file,$tmporiginaltag,0,$mode); } 
			  elsif ($s =~ /^veggie *burger$/)   { &add_tag("burger",$file,$tmporiginaltag,0,$mode); } 
			  elsif ($s =~ /^(cat)$/i) {							#food catch-all for one-word foods that still need the word 'food' (thing-food-cat = cat food)
				&add_tag("$1 food",$file,$tmporiginaltag,"",$mode);	$s="";				
			} elsif (($s =~ /^(cake)-(.*)$/i) || ($s =~ /^(nachos*)-(.*)$/i) || ($s =~ /^(tarts*)-(.*)$/i)) {						#food catch-all for two-word foods (food-food1-food2)
				my $tmp1=$1; my $tmp2=$2;
				&add_tag("thing-$tmp1-$tmp2",$file,$tmporiginaltag,"",$mode);	$s="";
				if (&is_flavor($tmp2)) { &add_tag("$tmp2",$file,$tmporiginaltag,0,$mode); } 
				return;
			} elsif (($s =~ /^(pork)-(pulled)$/) || ($s =~ /^(crackers)-([A-Z].*)$/) || ($s =~ /^(cheese)-([^\-]*)$/)) {				
				#food1,food2 that we need tagged as "food1,food2 food1" (+"food") but captioned as "food2 food1"
				if ($DEBUG_FOOD >= 1) { print "HERE! APAPAPAP s=\"$s\"<BR>\n"; }
				my $tmp1=$1; my $tmp2=$2; 
				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#"pork"			
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#"pulled pork"	
				$s="";
			} elsif (($s =~ /^(apple)-([^\-]*)$/) || ($s =~ /^(casserole)-([^\-]*)$/) || ($s =~ /^(dip)-([^\-]*)$/) || ($s =~ /^(jerky)-([^\-]*)$/) || ($s =~ /^([^\-]+)-(bacon wrapped)$/i)) {				
				#food1,food2 that we need tagged as "food1,food2,food2 food1" (+"food") but captioned as "food2 food1"
				if ($DEBUG_FOOD >= 1) { print "HERE! APAPAPAP s=\"$s\"<BR>\n"; }
				my $tmp1=$1; my $tmp2=$2; 
				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#"food"				from thing-food-apple-caramel
				&add_tag("$tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#"apple"			from thing-food-apple-caramel
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#"caramel apple"	caption this one
				$s="";
			} elsif ($s =~ /^([a-z !']+)\-([0-9a-z !']+)$/i) {
				my $tmp1=$1; my $tmp2=$2;
				if (($DEBUG_FOOD >= 1)||($DEBUG_THING>1)) { print "HERE! FZFZFZFZFZF s=\"$s\",tmp1=$tmp1,tmp2=$tmp2<BR>\n"; }

				#EXCEPTIONS TO FOOD CATCH-ALL -- think about thing1,thing2, etc catch-alls, and throw them into those:
				if (($s =~ /^seeds-/) || ($s =~ /^salads*-/) || ($s =~ /^ice creams?-/)) {						#kick certain foods back into the non-food code as it works better for these specific situations
					if (($DEBUG_FOOD >= 1)||($DEBUG_THING>1)) { print "[FHMM] Hmm -- let's kick back=\"$s\" to the normal tagging code as thing-$s<BR>\n"; $DEBUG_THING=1; }
					&add_tag("thing-$s",$file,$tmporiginaltag, 0,$mode); $s=""; return;
				}	




				#GENERIC COLOR/FLAVOR CATCH-ALL
				if ((&is_color($tmp2)) || (&is_flavor($tmp2))) {	#food1,food2 where food2 is a color or a flavor - tagged as "food1,food2 food1", captioned "Food2 food1"
					&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);		#"food"				
					&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);		#"white food"		caption this one
					$s="";					$tmp1=""; $tmp2="";
					return;
				}



				#cookie-fortune is a food1-food2 that should be tagged fortune cookie, fortune, and cooke - tagged "food1,food2,food2 food1", captioned "food2 food1"
				if (($s =~ /^cookies?-/i) || ($s =~ /livers?-/i) || ($s =~ /-chocolate$/i) || ($s =~ /^chicken-/i) ||		#chicken MAY only work for chicken-tandoori
					($s =~ /^roulade-/i)  || ($s =~ /sauces?-/i) ) {							
					if ($DEBUG_FOOD >= 1) { print "[FZFZFZAZF3FXX1 s=\"$s\",tmp1=$tmp1,tmp2=$tmp2] <BR>\n"; }
					&add_tag("thing-$tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);
					$STOP_ALL_CAPTIONING=1;
					&add_tag("thing-$tmp1"      ,$file,$tmporiginaltag,0,$mode);
					&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);
					$STOP_ALL_CAPTIONING=0;
				} else {					#THIS WILL BE THE FOOD CATCH-ALL for some food!!
					if ($DEBUG_FOOD >= 1) { print "[FZFZFZFZFZFXX1 s=\"$s\",tmp1=$tmp1,tmp2=$tmp2] <BR>\n"; }
					$caption_it=1;
					if (("$tmp2 $tmp1" =~ /^potato chips*/i) || ($tmp1 =~ /^sundae$/i)) {				#brownie sundae necesitated the sundae being added
						&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);
						$caption_it=0;
					}

					&add_tag("$tmp1",$file,$tmporiginaltag,          0,$mode);
					&add_tag("$tmp2",$file,$tmporiginaltag,$caption_it,$mode);

				}
				$s="";
			} else {
				if (($DEBUG_FOOD>0)||($DEBUG_THING>1)) { print "ELSE BEFORE 2X2X2X<BR>\n"; }
			}
			if (($DEBUG_FOOD>0)||($DEBUG_THING>1)) { print "FOOD HERE 2X2X2X2<BR>s is \"$s\"<BR>\n"; }

			&add_tag("thing-$s",$file,$tmporiginaltag,"",$mode); #kick anything missed by the above code back into the main procedure

		} elsif ($s =~ /^mannequin-/) {			#thing
			&add_tag("mannequin",$file,$tmporiginaltag,"",$mode);
			$s =~ s/mannequin-([a-z]+) ([a-z\s]+)/$2 $1 mannequin/i;
		} elsif ($s =~ /^injury-/) {											#this block decomissioned 5/2008
			&add_tag("injury",$file,$tmporiginaltag,0,$mode);
			$s =~ s/^injury-//;
			#DEBUG:			print "checking if is_injury_type($s)<BR>\n";
			if ($s =~ /-/) {			#if there's still a hyphen in it, it may be "bite-tick" or "bite-bug" which can be thrown back as a thing catchall
				&add_tag("thing-$s" ,$file,$tmporiginaltag,"",$mode); 				
			} elsif (&is_injury_type($s)) {
				&add_tag("$s"       ,$file,$tmporiginaltag,"",$mode); 
			} else {
				&add_tag("$s injury",$file,$tmporiginaltag,"",$mode); 
			}
			$s = "";
		} elsif (($s =~ /^hat-/i) || ($s =~ /^cap-/i)) {
			#first, deal with whether it is a hat or a cap
			if ($s =~ /^cap-/) {
				&add_tag("cap",$file,$tmporiginaltag,0,$mode);	
				$s =~ s/^cap-(.*)//i;
				$tmp1 = $1;
				$tmp2 = "cap";
			} else {
				&add_tag("hat",$file,$tmporiginaltag,0,$mode);	
				$s =~ s/^hat-(.*)//i;
				$tmp1 = $1;
				$tmp2 = "hat";
			}

			#certain types of hats need the type tagged as well
			#for example, umbrella hat deserves an umbrella tag
			#whereas a basball cap would NOT deserve a baseball tag
			if (($tmp1 =~ /^cowboy$/i) || ($tmp1 =~ /^sombrero$/i) || ($tmp1 =~ /^fez$/i) || ($tmp1 =~ /^umbrella$/i) || ($tmp1 =~ /^dildo$/i)) {
				&add_tag($tmp1,$file,$tmporiginaltag,0,$mode);
			}


			#now, the leftover cases - hat-umbrella = umbrella hat and such
			&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag,"",$mode);
			

			#DEBUG: print "==========HAT:[$s]\n";
		} elsif ($s =~ /-dock$/i) {			#thing
			&add_tag("dock",$file,$tmporiginaltag,"",$mode);
		} elsif ($s =~ /^concert set list$/) {
			&add_tag("set list",$file,$tmporiginaltag,"",$mode);
		} elsif (($s =~ /^(animals*)-/i) || ($s =~ /^(animals*)$/i))   {
			$tmp1=$1;						#animal(s)
			#$TYPE = "animal";				#200704
			$SUBTYPE = "animal";
			$ANIMAL_NAMED = "";
			&add_tag("$tmp1",$file,$tmporiginaltag,0,$mode);
			$s =~ s/$tmp1-//;

			if ($s =~ /^bug-/) { &add_tag("bug",$file,$tmporiginaltag,0,$mode); $s =~ s/^bug-//i; }
			if ($DEBUG_ANIMAL) { print "[DA-1: \$s is $s] <BR>\n"; }			#]]]]]]]]]

			foreach $tmpanimal (@ANIMALS) {
				$tmppluralanimal = &plural($tmpanimal);
				if ($s =~ /^$tmpanimal\-/i) {									#thing-animal
					$ANIMAL_NAMED = "$tmpanimal";								#cat,dog,etc
					&add_tag("$tmpanimal",$file,$tmporiginaltag,0,$mode);	
				} elsif ($s =~ /^$tmppluralanimal\-/i) {						#thing-animals
					$ANIMAL_NAMED = "$tmppluralanimal";							#cats,dogs,etc
					&add_tag("$tmppluralanimal",$file,$tmporiginaltag,0,$mode);	
				}
			}
			if ($DEBUG_ANIMAL) { print "[DA-2: ANIMAL_NAMED is $ANIMAL_NAMED] <BR>\n"; }


			$s =~ /^([^\-]*)-([A-Z][^\-\s]*)-([A-Z][^\-\s]* [A-Z][^\-]*)$/i;	#Not a good idea to mess with this, but unsure if this code is still valid. This is ollllld code.
			$tmp1=$1; $tmp2=$2; $tmp3=$3; 
			$s =~ /^([^\-]*)-([A-Z]+)$/i;
			$tmp4=$1; $tmp5=$2;
			if ($DEBUG_ANIMAL) { print "<B>[DA-3/post-tmp-assignment: tmp1=$tmp2/tmp2=$tmp2/tmp3=$tmp3/tmp4=$tmp4/tmp5=$tmp5]</B> <BR>\n"; }
			if ($DEBUG_ANIMAL) { print "[XAN-BEGIN] \$s is $s ... /ANIMAL_NAMED=$ANIMAL_NAMED/ ... /tmp2=$tmp2/&is_fam_relat_name(\$tmp2)=".(&is_family_relationship_name($tmp2)?1:0)." <BR>\n"; }


			if (($s =~ /^([^\-]*)-([A-Z][^\-\s]*)-([A-Z][^\-\s]* [A-Z][^\-]*)$/i) && (&is_family_relationship_name($tmp2))) {	#for nameless animal relatives a la thing-animal-cat-brother-Lipinski Oranjello for our cat's brother that we met once
				$tmp4=&fix_name_of_any_form($tmp3);
				if ($DEBUG_ANIMAL) { print " [XAN-A][tmp1=$tmp1/2=$tmp2/3=$tmp3/4=$tmp4] <BR>\n"; }
				&add_tag("$tmp2"           ,$file,$tmporiginaltag, 0,$mode);				#brother
				$APPEND_TO_CAPTION="'s $tmp2";												#was not adding "'s brother"
				&add_tag("$tmp4" . "'s $tmp2",$file,$tmporiginaltag,"",$mode);				#Oranjello Lipinski's brother
				$APPEND_TO_CAPTION="";
				$s="";
			} elsif ((&is_animal_name($tmp4)) && (&is_family_relationship_name($tmp5))) {
				if ($DEBUG_ANIMAL) { print " [XAN-D][tmp4=$tmp4/tmp5=$tmp5] <BR>\n"; }
				$REPLACE_CAPTION_WITH="$tmp5 $tmp4";								#kludge to caption 'mother cat' instead of 'mother the cat'
				&add_tag("$tmp5 $tmp4",$file,$tmporiginaltag,"",$mode);				#mother cat
				$REPLACE_CAPTION_WITH="";
				&add_tag("$tmp4 $tmp5",$file,$tmporiginaltag, 0,$mode);				#cat mother
				&add_tag("$tmp5"      ,$file,$tmporiginaltag, 0,$mode);				#mother 
				$s="";
			} elsif ($s =~ /^([^\-]*)-([A-Z][^\-\s]*)$/) {			#1-name animals like Lassie that have no last name
				if ($DEBUG_ANIMAL) { print " [XAN-Q1,\$1=$1,\$2=$2] <BR>\n"; }
				$s =~ s/^([^\-]*)-([A-Z][^\-\s]*)$/$2/;			
				$REPLACE_CAPTION_WITH="$2 the $ANIMAL_NAMED";						
				&add_tag("$s",$file,$tmporiginaltag,"",$mode);				
				$REPLACE_CAPTION_WITH="";
				$s="";
			} elsif ($s =~ /^([^\-]*)-([A-Z][^\-\s]*) ([A-Z][^\-]*)$/) {			#oops, had /i here, but this is supposed to be case sensitive for species names
				if ($DEBUG_ANIMAL) { print " [XAN-E,\$1=$1,\$2=$2,\$3=$3] <BR>\n"; }
				$s =~ s/^([^\-]*)-([A-Z][^\-\s]*) ([A-Z][^\-]*)$/$3 $2/;			#doing the 'snoopy the dog' type conversion here would not make sense, by the way
				$REPLACE_CAPTION_WITH="$3 the $ANIMAL_NAMED";						#kludge to caption 'mother cat' instead of 'mother the cat'
				&add_tag("$s",$file,$tmporiginaltag,"",$mode);				
				$REPLACE_CAPTION_WITH="";
				$s="";
			} elsif ($s =~ /-kitten$/) {	#thing-animal
				if ($DEBUG_ANIMAL) { print " [XAN-B,\$1=$1,\$2=$2,\$3=$3] <BR>\n"; }
				$ANIMAL_NAMED = "kitten";
				&add_tag("kitten",$file,$tmporiginaltag,"",$mode);
				$s =~ s/-kitten$//;
			} elsif ($s =~  /^([^\-]*)-([^\-\sa-z]*)$/) {	#thing		
				if ($DEBUG_ANIMAL) { print " [XAN-C,\$1=$1,\$2=$2] <BR>\n"; }
				$s      =~ s/^([^\-]*)-([^\-\sa-z]*)$/$2 the $1/;
			} elsif (($s =~  /^(crabs*)-([^\-]*)$/) ||
					 ($s =~  /^(bears*)-([^\-]*)$/)  )		#polar bears
			{																	#animal1-animal2 tagged as "animal1,animal2 animal1" and captioned as "animal2 animal1" - EG: "crab-horseshoe=horseshoe crab"
				if ($DEBUG_ANIMAL) { print " [XAN-2-A,\$1=$1,\$2=$2] <BR>\n"; } 
				$ANIMAL_NAMED="";												#necessary to not get captions like "horseshoe the crab"
				&add_tag("$1"   ,$file,$tmporiginaltag,0,$mode);				
				&add_tag("$2 $1",$file,$tmporiginaltag,1,$mode);				
				$s="";
			} elsif ($s =~  /^([^\-]*)-(dead)$/)  {								#animal1-animal2 tagged as "animal1,animal1,animal2 animal1" and captioned as "animal2 animal1" - EG: "mouse-dead=mouse,dead mouse,dead"
				if ($DEBUG_ANIMAL) { print " [XAN-2-B,\$1=$1,\$2=$2] <BR>\n"; } 
				$ANIMAL_NAMED="";												#necessary to not get captions like "horseshoe the crab"
				&add_tag("$1"   ,$file,$tmporiginaltag,0,$mode);				
				&add_tag("$2 $1",$file,$tmporiginaltag,1,$mode);				
				&add_tag("$2"   ,$file,$tmporiginaltag,0,$mode);				
				$s="";
					#vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv If this starts catching things it shouldn't, change to only hit bird-seagull-dead
			} elsif ($s =~  /^([^\-]*)-([a-z][^\-]*)-(dead)$/i) {						#animal1-animal2-animal3 tagged as "animal1,animal2,animal2 animal1,animal3,animal3 animal1,animal3 animal2,animal3 animal2 animal1" and captioned as "animal3 animal2"
				my $tmp1=$1; my $tmp2=$2; my $tmp3=$3;
				if ($DEBUG_ANIMAL) { print " [XAN-FA1,tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3] <BR>\n"; }
				$ANIMAL_NAMED="";												#necessary to not get captions like "horseshoe the crab"
				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);	#bird
				&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);	#seagull
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);	#seagull bird
				&add_tag("$tmp3"	        ,$file,$tmporiginaltag,0,$mode);	#dead
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag,0,$mode);	#dead bird
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag,1,$mode);	#dead seagull
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,0,$mode);	#dead seagull bird
				$s="";
			} elsif ($s =~  /^([^\-]*)-([^\-]*)-([^\-]*)$/i) {					#animal1-animal2-animal3 tagged as "animal1,animal2,animal3" and captioned as animal3
				if ($DEBUG_ANIMAL) { print " [XAN-15,\$1=$1,\$2=$2,\$3=$3] <BR>\n"; }
				my $tmp1=$1;
				my $tmp2=$2;
				my $tmp3=$3;
				if (($tmp2 =~ /eagle/i) && ($tmp3 =~ /^bald$/)	#bald eagle exception - tag as "animal1,animal2,animal3 animal2"
				 || ($tmp3 =~ /^fake$/i)) {						#this is also a fake spider (or any animal) exception 
					if ($DEBUG_ANIMAL) { print "[[[[BALD EAGLE EXCEPTION]]]]"; }
					&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);				
					&add_tag("$tmp2"      ,$file,$tmporiginaltag,0,$mode);				
					$REPLACE_CAPTION_WITH="$tmp3 $tmp2";							#gotta kludge over default behavior
					&add_tag("$tmp3 $tmp2",$file,$tmporiginaltag,1,$mode);				
					$REPLACE_CAPTION_WITH="";
				} else {
					&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);				
					&add_tag("$tmp2"      ,$file,$tmporiginaltag,0,$mode);				
					&add_tag("$tmp3"      ,$file,$tmporiginaltag,1,$mode);				
				}
				$s="";

			} elsif ($s =~  /^([^\-]*)-([a-z][^\-]*)$/i) {							#animal1-animal2-animal3 tagged as "animal1,animal2,animal2 animal1" and captioned as "animal2 animal1"
				if ($DEBUG_ANIMAL) { print " [XAN-F-2-Q,\$1=$1,\$2=$2...s=$s] <BR>\n"; }		#Note that this can't have capital letters in the last part, or we're going to assume Capitalized Species or Proper Pet Name
				my $tmp1=$1;
				my $tmp2=$2;
				$ANIMAL_NAMED="";
				&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);
				if ((($tmp2 =~ /^pony$/i) || ($tmp2 =~ /^ponies$/i)) && (($tmp1 =~ /^horses$/i))) {
					&add_tag("$tmp2"      ,$file,$tmporiginaltag,1,$mode);									#for "pony horses", do this - we want it to say "pony" not "pony horse"; that's dumb
				} else {
					&add_tag("$tmp2"      ,$file,$tmporiginaltag,0,$mode);									#normally do this
					&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);
				}
				$s="";
			} else {
				if ($DEBUG_ANIMAL) { print " [XAN-Z-BEG,\$1=$1,\$2=$2,s=$s,ANIMAL_NAMED=$ANIMAL_NAMED] <BR>\n"; }
				#$s =~ s/^([^\-]*)-([^\-\s]*)$/$2/;
				$s =~ s/^([^\-]*)-([^\-\s]*)$/$2/;
				$tmp1 = $1;		$tmp2 = $2;		$tmp2 =~ /^(.)(.*$)/;	
				#thing-bird-seagull isn't captioning seagull... Is this the problem?
				#NO, commenting this out doesn't make a difference in that:
				if ($tmp1 =~ /^[a-z]$/) { $ANIMAL_NAMED=""; }			#if the second word is an animal name (bird-seagull), it's NOT a name -
																		#^^^^ comment makes no sense because $ANIMAL_NAMED is not the name, but the type, like 'cat' or 'dog'
				if ($DEBUG_ANIMAL) { print " [XAN-Z-END,\$tmp1=$tmp1,\$tmp2=$tmp2,s=$s,ANIMAL_NAMED=$ANIMAL_NAMED] <BR>\n"; }

				##### 200808 test: thing-horses-ponies was not tagging horses ... and that was tmp1... so we'll force it out here,
				#####					and see how that affects other things (if any) later:
				&add_tag("$tmp1",$file,$tmporiginaltag,0,$mode);
			
			}
			if ($DEBUG_ANIMAL) { print "[XAN-99]--\$s is [$s]/ANIMAL_NAMED=$ANIMAL_NAMED/\$1=$1/<BR>\n"; }


			#### KLUDGE: g0at-fake should not say "fake the g0at", but simply be "fake g0at", which also wasn't getting tagged:
			if ($s =~ /^(fake)$/i) {
				$tmp1=$1;	$tmp2=$ANIMAL_NAMED; $ANIMAL_NAMED="";
				if ($DEBUG_ANIMAL) { print "[ANIMAL-E] about to tag \"$tmp1 $tmp2\"<BR>\n"; }
				&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag,"",$mode);
				$s="";
			}


			if ($s =~ s/([^\s]+) Lipinski/$1/) { &add_tag($1,$file,$tmporiginaltag,"",$mode); }			#really confused me with T.D. :)
			if ($DEBUG_ANIMAL) { print "               <BR>\n"; }

			##### 200808 test: If there's just one word left in $s, no hyphen, then maybe we need to make it be in the caption.
			####					thing-bird-seagull isn't captioning - but only when there is more than 1 pic in the set. VERY weird.
			if ($s !~ /\-/) {
				if ($DEBUG_ANIMAL) { print "[ANIMAL-F] about to tag \"$s\"/ANIMAL_NAMED=$ANIMAL_NAMED/R=$REPLACE_CAPTION_WITH/<BR>\n"; }
				if ($s =~ /[a-z]/) { $ANIMAL_NAMED=""; }	#lower case letter = not proper name = not a named animal, just an unnamed animal
				&add_tag("$s",$file,$tmporiginaltag,"",$mode);
				$s="";
			}

		#deprecated synonyms (we do this elsewhere nowadays):
		} elsif ($s =~ /^cubicle$/)          { &add_tag("cube",    $file,$tmporiginaltag,0,$mode);
		} elsif ($s =~ /^AllSteel \#.*$/i)   { &add_tag("AllSteel",$file,$tmporiginaltag,0,$mode);
		} elsif ($s =~ /^urine$/) {
			&add_tag("pee" ,$file,$tmporiginaltag,0,$mode);
			&add_tag("piss",$file,$tmporiginaltag,0,$mode);
		} elsif ($s =~ /^([a-z]+)-broken/) {
			&add_tag($1,$file,$tmporiginaltag,"",$mode);
			&add_tag("broken $1",$file,$tmporiginaltag,"",$mode);
			&add_tag("broken",   $file,$tmporiginaltag,"",$mode);
			$s = "";	#stop recursion
		##### this "thing chain catch-all" was added 4/16/2008 and might interfere with other thing chains -- it may need to be limited to /drink-.*-/ and such...
		} elsif ($s =~ /^(drink)-(wine)-(.*)-(.*)$/) {			
			$tmp1=$1; $tmp2=$2; $tmp3=$3; $tmp4=$4;
			if ($DEBUG_DRINK) { print "[Drink checkpoint A] "; }
			&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#"drink"				from thing-drink-wine-Cabernet Sauvignon-Burlwood 
			&add_tag("$tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#"wine"					from thing-drink-wine-Cabernet Sauvignon-Burlwood 
			&add_tag("$tmp3"      ,$file,$tmporiginaltag, 0,$mode);		#"Cabernet Sauvignon"	from thing-drink-wine-Cabernet Sauvignon-Burlwood 
			&add_tag("$tmp4"      ,$file,$tmporiginaltag, 0,$mode);		#"Burlwood"				from thing-drink-wine-Cabernet Sauvignon-Burlwood 
			&add_tag("$tmp4 $tmp3",$file,$tmporiginaltag,"",$mode);		#"Burlwood Cabernet Sauvignon" - caption this one
			$s="";
		} elsif (($s =~ /^(drinks*)-(liquor)-(.*)$/) || ($s =~ /^(drinks*)-(alcohol)-(.*)$/)) {
			$tmp1=$1; $tmp2=$2; $tmp3=$3; 
			if ($DEBUG_DRINK) { print "[Drink checkpoint B][/s=$s/tmp1=$tmp1/tmp2=$tmp2/tmp3=$tmp3/]<BR>\n "; }
			&add_tag("$tmp1"			,$file,$tmporiginaltag, 0,$mode);		#drink
			&add_tag("$tmp2"			,$file,$tmporiginaltag, 0,$mode);		#liquor/alcohol
			&add_tag("thing-drink-$tmp3",$file,$tmporiginaltag, 0,$mode);		#liquor/alcohol
			$s="";
		} elsif (  ($s =~ /^(drink)-(Tequila)-(.*)$/i) || ($s =~ /^(drink)-(Bourbon)-(.*)$/i) 
				|| ($s =~ /^(drink)-(Vodka)-(.*)$/i)   || ($s =~ /^(drink)-(Rum)-(.*)$/i)     || ($s =~ /^(drink)-(Wh?iske?y)-(.*)$/i)
				|| ($s =~ /^(drink)-(absinthe)-(.*)$/i)
		) {	
			my $tmp1=$1; my $tmp2=$2; my $tmp3=$3;
			if ($DEBUG_DRINK) { print "[Drink checkpoint C][/s=$s/tmp1=$tmp1/tmp2=$tmp2/tmp3=$tmp3/]<BR>\n "; }
			&add_tag("$tmp1"                 ,$file,$tmporiginaltag, 0,$mode);		#"drink"				
			&add_tag("$tmp2"                 ,$file,$tmporiginaltag, 0,$mode);		#"rum"				
			&add_tag("$tmp3"                 ,$file,$tmporiginaltag, 0,$mode);		#"Captain Morgan's"				
			&add_tag("$tmp3 $tmp2"           ,$file,$tmporiginaltag,"",$mode);		#"Captain Morgan's" rum				
			$s="";
		#20080624: having toy in the next one makes thing-toy-cat-wand tag toy and throw back thing-cat-wand which makes "wand cat" since thing-cat-X is usually something like thing-cat-calico for "calico cat". thus, we can't put toy in here anymore unless it's a 2-chain (toy1-toy2) only. So (toy)-(.*) becomes (toy)-([^\-]*)
		} elsif (($s =~ /^(drink)-(.*)$/) || ($s =~ /^(toy)-([^\-]*)$/)) {				#heirarchies where we tag the first one and then do the rest as normal
			my $tmp1=$1; 
			my $tmp2=$2;
			if (($tmp1 =~ /^toy$/i) && (&is_animal_name($tmp2) || ($tmp2 =~ /^workbench$/i))) {
				if ($DEBUG_THING) { print " <B>[TOY-1Z][tmp1=$tmp1,tmp2=$tmp2]</B> "; }
				&add_tag(        "toy",$file,$tmporiginaltag,0,$mode);					#toy
				&add_tag(      "$tmp2",$file,$tmporiginaltag,0,$mode);					#workbench
				&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag,1,$mode);					#"toy workbench"
				$s="";
			} else {
				if ($DEBUG_THING) { print " [TOY-1Q][tagging $tmp1 and throwing thing-$tmp2 back] "; }
				&add_tag(      "$tmp1",$file,$tmporiginaltag, 0,$mode);					#"drink"/"toy"
				&add_tag("thing-$tmp2",$file,$tmporiginaltag, 0,$mode);					#send the rest back as if it's not a drink/toy but just a generic thing...
				$s="";
			}
		} elsif ($s =~ /^([^\-]*)\-([^\-]*)\-([^\-]*)\-([^\-]*)\-([^\-]*)\-([^\-]*)$/) {		#thing1-thing2-thing3-thing4-thing5-thing6 6chain 6 chain catchall beginnings? ----- chain size of 6 (7 if you count 'thing')
			my $tagged=0;
			$tmp1=$1; $tmp2=$2; $tmp3=$3; $tmp4=$4; $tmp5=$5; $tmp6=$6;
			if ($DEBUG_THING) { print "<BR>\n[DT-6chain-catchall-6CA] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4,tmp5=$tmp5,tmp6=$tmp6]<BR>\n"; }
			#tag used to create this codeblock: thing-hardware-RAM-OCZ-DDR2-800mHz-PC6400-Dual Channel
			if ($tmp1 =~ /^RAM$/i) {												
				$s="";

				#### It turns out that flickr doesn't want you tagging 200+ tags on one photo, so my idea of tagging all possible permutations is bad.
				#### Will have to comment out a lot of these:
				#	[tmp1=RAM,tmp2=OCZ,tmp3=DDR2,tmp4=800mHz,tmp5=PC6400,tmp6=Dual Channel]
				&add_tag("$tmp4",                                 ,$file,$tmporiginaltag, 0,$mode);		#800mHz
				&add_tag("$tmp4 $tmp3"                            ,$file,$tmporiginaltag, 0,$mode);		#800mHz DDR2 
				&add_tag("$tmp4 $tmp6 $tmp3 $tmp5 $tmp1"          ,$file,$tmporiginaltag, 0,$mode);		#800mHz Dual Channel DDR2 PC6400 RAM
				&add_tag("$tmp4 $tmp5"                            ,$file,$tmporiginaltag, 0,$mode);		#800mHz PC6400
				&add_tag("$tmp4 $tmp1",                           ,$file,$tmporiginaltag, 0,$mode);		#800mHz RAM
				&add_tag("$tmp3",                                 ,$file,$tmporiginaltag, 0,$mode);		#DDR2
				&add_tag("$tmp3 $tmp4"                            ,$file,$tmporiginaltag, 0,$mode);		#DDR2 800mHz
				&add_tag("$tmp3 $tmp4"                            ,$file,$tmporiginaltag, 0,$mode);		#DDR2 800mHz RAM
				&add_tag("$tmp3 $tmp6"                            ,$file,$tmporiginaltag, 0,$mode);		#DDR2 Dual Channel 
				&add_tag("$tmp3 $tmp5 $tmp4"                      ,$file,$tmporiginaltag, 0,$mode);		#DDR2 PC6400 800mHz 
				&add_tag("$tmp2 $tmp1"                            ,$file,$tmporiginaltag, 0,$mode);		#DDR2 RAM
				&add_tag("$tmp6 $tmp2 $tmp1"                      ,$file,$tmporiginaltag, 0,$mode);		#Dual Channel OCZ RAM
				&add_tag("$tmp2"	                              ,$file,$tmporiginaltag, 0,$mode);		#OCZ
				&add_tag("$tmp2 $tmp4 $tmp5 $tmp3 $tmp6 $tmp1"    ,$file,$tmporiginaltag,"",$mode);		#OCZ 800mHz PC6400 DDR2 Dual Channel RAM		#CAPTIONED ONE!
				&add_tag("$tmp2 $tmp4 $tmp5 $tmp1"                ,$file,$tmporiginaltag, 0,$mode);		#OCZ 800mHz PC6400 RAM
				&add_tag("$tmp2 $tmp3 $tmp5 $tmp1"                ,$file,$tmporiginaltag, 0,$mode);		#OCZ DDR2 PC6400 RAM
				&add_tag("$tmp2 $tmp3 $tmp1"                      ,$file,$tmporiginaltag, 0,$mode);		#OCZ DDR2 RAM
				&add_tag("$tmp2 $tmp5 $tmp1"                      ,$file,$tmporiginaltag, 0,$mode);		#OCZ PC6400 RAM
				&add_tag("$tmp2 $tmp1"                            ,$file,$tmporiginaltag, 0,$mode);		#OCZ RAM
				&add_tag("$tmp5"                                  ,$file,$tmporiginaltag, 0,$mode);		#PC6400
				&add_tag("$tmp5 $tmp4"                            ,$file,$tmporiginaltag, 0,$mode);		#PC6400 800mHz
				&add_tag("$tmp5 $tmp4 $tmp3"                      ,$file,$tmporiginaltag, 0,$mode);		#PC6400 800mHz DDR2 
				&add_tag("$tmp5 $tmp4 $tmp1"                      ,$file,$tmporiginaltag, 0,$mode);		#PC6400 800mHz RAM
				&add_tag("$tmp5 $tmp3"                            ,$file,$tmporiginaltag, 0,$mode);		#PC6400 DDR2
				&add_tag("$tmp5 $tmp3 $tmp4"                      ,$file,$tmporiginaltag, 0,$mode);		#PC6400 DDR2 800mHz
				&add_tag("$tmp5 $tmp3 $tmp1"                      ,$file,$tmporiginaltag, 0,$mode);		#PC6400 DDR2 RAM
				&add_tag("$tmp5 $tmp6"                            ,$file,$tmporiginaltag, 0,$mode);		#PC6400 Dual Channel
				&add_tag("$tmp5 $tmp1"                            ,$file,$tmporiginaltag, 0,$mode);		#PC6400 RAM
				&add_tag("$tmp1"                                  ,$file,$tmporiginaltag, 0,$mode);		#RAM
				$tagged=1;
			}
			if ($tagged) { $s=""; } else { print "WARNING: $s was not tagged in DT-7chain-catchall-7CA-1! Probably will be passed along to chain catch-all code instead....<BR>\n"; }

		} elsif ($s =~ /^(food)-(chips)-(.*)-(.*)$/) {
			my $tmp1=$1; my $tmp2=$2; my $tmp3=$3; my $tmp4=$4;

			#Might have to later determine if $4 ends with 's for things like "Stacy's pita chips", before doing this:
			if ($DEBUG_FOOD) { print "[Food checkpoint Q934][/s=$s/tmp1=$tmp1/tmp2=$tmp2/tmp3=$tmp3/$tmp4=$tmp4]<BR>\n "; }
			&add_tag("$tmp1"			,$file,$tmporiginaltag, 0,$mode);		#food
			&add_tag("$tmp2"			,$file,$tmporiginaltag, 0,$mode);		#chips
			#May have to later do this only if it's pita, but not potato:
			&add_tag("$tmp3"			,$file,$tmporiginaltag, 0,$mode);		#pita
			&add_tag("$tmp3 $tmp2" 		,$file,$tmporiginaltag, 0,$mode);		#pita chips
			&add_tag("$tmp4"			,$file,$tmporiginaltag, 0,$mode);		#Stacy's
			&add_tag("$tmp4 $tmp3 $tmp2",$file,$tmporiginaltag,"",$mode);		#Stacy's pita chips
			&add_tag("$tmp4 $tmp2"		,$file,$tmporiginaltag, 0,$mode);		#Stacy's chips
			$s="";


		} elsif (($s =~ /^(toys*)\-(Transformers*)\-([^\-]*)\-([^\-]*)\-([^\-]*)$/) && ($FIVE_CHAIN_FAILED==0)) {		#"thing1-thing3-thing3-thing4-thing5" tagged as "thing1,thing2,thing2 thing1,thing2: thing5,thing3,thing3 thing1,thing4,thing4 thing1,thing5" and captioned as "thing5 (thing1 thing3 thing4)"
			my $tmp1=$1; my $tmp2=$2; my $tmp3=$3; my $tmp4=$4; my $tmp5=$5; 
			my $caprepl="$tmp5 ($tmp2 $tmp3 $tmp4)";									#replacement caption will say things like "Long Haul (Decepticon, Constructicon)
			if ($DEBUG_THING) { print "<BR>\n[DT-5chain-catchall-5BZ] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4,tmp5=$5/caprepl=$caprepl]<BR>\n"; }
			 #[tmp1=toy,tmp2=Transformers,tmp3=Decepticon,tmp4=Constructicon,tmp5=Hook]
			&add_tag("$tmp1"			,$file,$tmporiginaltag,0,$mode);		#toy
			&add_tag("$tmp2"			,$file,$tmporiginaltag,0,$mode);		#Transformers
			&add_tag("$tmp2: $tmp5"		,$file,$tmporiginaltag,0,$mode);		#Transformers: Long Haul
			&add_tag("$tmp2 $tmp1"		,$file,$tmporiginaltag,0,$mode);		#Transformers toy
			&add_tag("$tmp3"			,$file,$tmporiginaltag,0,$mode);		#Decepticon
			&add_tag("$tmp3 $tmp1" 		,$file,$tmporiginaltag,0,$mode);		#Decepticon toy
			&add_tag("$tmp4"			,$file,$tmporiginaltag,0,$mode);		#Constructicon
			&add_tag("$tmp4 $tmp1" 		,$file,$tmporiginaltag,0,$mode);		#Constructicon toy
			$REPLACE_CAPTION_WITH = $caprepl;
			&add_tag("$tmp5"			,$file,$tmporiginaltag,1,$mode);		#Long Haul
			$REPLACE_CAPTION_WITH = "";
			$s="";


		
		} elsif (($s =~ /^(guns*)\-([^\-]*)\-([^\-]*)\-([^\-]*)\-([^\-]*)$/) && ($FIVE_CHAIN_FAILED==0)) {		#"thing1-thing3-thing3-thing4-thing5" tagged as "thing1,thing2,thing3,thing3 thing5,thing3 thing5 thing1,thing3 thing5 thing2,thing3 thing1,thing3 thing2,thing3 thing4,thing3 thing4 thing1,thing3 thing4 thing2,thing3 thing4 thing5,thing3 thing4 thing5 thing1,thing3 thing4 thing5 thing2,thing4,thing4 thing1,thing4 thing2,thing4 thing5,thing4 thing5 thing1,thing4 thing5 thing2,thing5,thing5 thing1,thing5 thing2" and captioned as "thing3 thing4 thing2 (thing5)"
			my $tmp1=$1; my $tmp2=$2; my $tmp3=$3; my $tmp4=$4; my $tmp5=$5; 

			if ($DEBUG_THING) { print "<BR>\n[DT-5chain-catchall-5CG] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4,tmp5=$5]<BR>\n"; }
			 #[tmp1=gun,tmp2=pistol,tmp3=Beretta,tmp4=U22 Neos,tmp5=22LR/caprepl=22LR (pistol Beretta U22 Neos)]
			&add_tag("$tmp1"					,$file,$tmporiginaltag,0,$mode);		#gun
			&add_tag("$tmp2"					,$file,$tmporiginaltag,0,$mode);		#pistol
			&add_tag("$tmp3"					,$file,$tmporiginaltag,0,$mode);		#Beretta
			&add_tag("$tmp3 $tmp5"				,$file,$tmporiginaltag,0,$mode);		#Beretta 22LR
			&add_tag("$tmp3 $tmp5 $tmp1"		,$file,$tmporiginaltag,0,$mode);		#Beretta 22LR gun
			&add_tag("$tmp3 $tmp5 $tmp2"		,$file,$tmporiginaltag,0,$mode);		#Beretta 22LR pistol
			&add_tag("$tmp3 $tmp1"				,$file,$tmporiginaltag,0,$mode);		#Beretta gun
			&add_tag("$tmp3 $tmp2"				,$file,$tmporiginaltag,0,$mode);		#Beretta pistol
			&add_tag("$tmp3 $tmp4"				,$file,$tmporiginaltag,0,$mode);		#Beretta U22 Neos
			&add_tag("$tmp3 $tmp4 $tmp1"		,$file,$tmporiginaltag,0,$mode);		#Beretta U22 Neos gun
			&add_tag("$tmp3 $tmp4 $tmp2"		,$file,$tmporiginaltag,0,$mode);		#Beretta U22 Neos pistol
			&add_tag("$tmp3 $tmp4 $tmp5"		,$file,$tmporiginaltag,0,$mode);		#Beretta U22 Neos 22LR
			&add_tag("$tmp3 $tmp4 $tmp5 $tmp1"	,$file,$tmporiginaltag,0,$mode);		#Beretta U22 Neos 22LR gun
			$REPLACE_CAPTION_WITH = "$tmp3 $tmp4 $tmp2 ($tmp5)";
			&add_tag("$tmp3 $tmp4 $tmp5 $tmp2"	,$file,$tmporiginaltag,1,$mode);		#Beretta U22 Neos 22LR pistol
			$REPLACE_CAPTION_WITH = "";
			&add_tag("$tmp4"					,$file,$tmporiginaltag,0,$mode);		#U22 Neos
			&add_tag("$tmp4 $tmp1"				,$file,$tmporiginaltag,0,$mode);		#U22 Neos gun
			&add_tag("$tmp4 $tmp2"				,$file,$tmporiginaltag,0,$mode);		#U22 Neos pistol
			&add_tag("$tmp4 $tmp5"				,$file,$tmporiginaltag,0,$mode);		#U22 Neos 22LR
			&add_tag("$tmp4 $tmp5 $tmp1"		,$file,$tmporiginaltag,0,$mode);		#U22 Neos 22LR gun
			&add_tag("$tmp4 $tmp5 $tmp2"		,$file,$tmporiginaltag,0,$mode);		#U22 Neos 22LR pistol
			&add_tag("$tmp5"					,$file,$tmporiginaltag,0,$mode);		#22LR
			&add_tag("$tmp5 $tmp1"				,$file,$tmporiginaltag,0,$mode);		#22LR gun 
			&add_tag("$tmp5 $tmp2"				,$file,$tmporiginaltag,0,$mode);		#22LR pistol
			$s="";



		###	put new 5chains/FIVE CHAIN/FIVE_CHAIN *types* above, not here ... some existing types are below.. for reasons.. like hardware and such


		} elsif (($s =~ /^([^\-]*)\-([^\-]*)\-([^\-]*)\-([^\-]*)\-([^\-]*)$/) && ($FIVE_CHAIN_FAILED==0)) {		#thing1-thing2-thing3-thing4-thing5 catchall beginnings? ----- chain size of 5
			my $tagged=0; 
			my $tmp1=$1; my $tmp2=$2; my $tmp3=$3; my $tmp4=$4; my $tmp5=$5;
			if ($DEBUG_THING) { print "<BR>\n[DT-5chain-catchall-5CA] <I>[tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]</i><BR>\n"; }

			if ($tmp1 =~ /^vehicles*$/) {												#for vehicles, strip off 1st thing and throw the remaining 4 chain back into the code as a 4 chain...
				&add_tag("$tmp1"	               ,$file,$tmporiginaltag, 0,$mode);		
				$s = "thing-$tmp2-$tmp3-$tmp4-$tmp5";
				&add_tag("$s"					   ,$file,$tmporiginaltag, 0,$mode);		
				$tagged=1;	$s="";
			}



			if ($tmp1 =~ /^hardware$/) {												#for harddrives with brand, model, and make numbers - it's a 5chain!

				if ($DEBUG_THING) { print "[DT] <B>Hardware encountered... </B> [checking hardware]  [tmp1=$tmp1/2=$tmp2/3=$tmp3/4=$tmp4/5=$tmp5]<BR>\n"; }
				if (($tmp2 =~ /^hard *drive/i) && ($tmp5 ne "")) {			"thing1,thing2,thing3,thing3 thing2,thing3 thing4,thing3 thing4 thing2,thing3 thing4 thingt5,thing3 thing4 thing5 thing2,thing4,thing4 thing2,thing4 thing5,thing5"
					&add_tag("$tmp1"					,$file,$tmporiginaltag, 0,$mode);	#hardware
					&add_tag("$tmp2"					,$file,$tmporiginaltag, 0,$mode);	#harddrive
					&add_tag("$tmp3"					,$file,$tmporiginaltag, 0,$mode);	#Western Digital
					&add_tag("$tmp4"					,$file,$tmporiginaltag, 0,$mode);	#Cavier Black
					&add_tag("$tmp5"					,$file,$tmporiginaltag, 0,$mode);	#WD15EADS00R6B0
					&add_tag("$tmp3 $tmp2"				,$file,$tmporiginaltag, 0,$mode);	#Western Digital harddrive
					&add_tag("$tmp3 $tmp4"				,$file,$tmporiginaltag, 0,$mode);	#Western Digital Cavier Black 
					&add_tag("$tmp3 $tmp4 $tmp2"		,$file,$tmporiginaltag, 0,$mode);	#Western Digital Cavier Black harddrive
					&add_tag("$tmp4 $tmp2"				,$file,$tmporiginaltag, 0,$mode);	#Cavier Black harddrive
					&add_tag("$tmp4 $tmp5"				,$file,$tmporiginaltag, 0,$mode);	#Cavier Black WD15EADS00R6B0
					&add_tag("$tmp3 $tmp4 $tmp5"		,$file,$tmporiginaltag, 0,$mode);	#Western Digital Cavier Black WD15EADS00R6B0
					&add_tag("$tmp3 $tmp4 $tmp5 $tmp2"	,$file,$tmporiginaltag, 1,$mode);	#Western Digital Cavier Black WD15EADS00R6B0 harddrive
					$tagged=1;	$s="";
				}


				if ($tmp2 =~ /^(cards*)-*.*$/) {												#5-chain
					if ($DEBUG_THING) { print "[DT] Hardware card found! [HCF!]...<BR>\n"; }
					&add_tag("$tmp1",$file,$tmporiginaltag,0,$mode);
					if (($s =~ /-(cards*)-(PCI)-/i) || ($s =~ /-(cards*)-(PCI)$/i) ||
						($s =~ /-(cards*)-(ISA)-/i) || ($s =~ /-(cards*)-(ISA)$/i) ||
						($s =~ /-(cards*)-(AGP)-/i) || ($s =~ /-(cards*)-(AGP)$/i))  {
						&add_tag("$tmp2"      ,$file,$tmporiginaltag,0,$mode);
						&add_tag("$tmp3"      ,$file,$tmporiginaltag,0,$mode);
						&add_tag("$tmp3 $tmp2",$file,$tmporiginaltag,0,$mode);
						$s =~ s/(cards*)-PCI/$1-/i;
						$s =~ s/(cards*)-ISA/$1-/i;
						$s =~ s/(cards*)-AGP/$1-/i;
					}
					$s =~ s/--/-/g;
					if ($DEBUG_THING) { print "s is now $s!!!!!<BR>\n"; }
					if (
							($s =~ /-(cards*)-+.*(controller)-([^\-]+)$/i) ||
							($s =~ /-(cards*)-+.*(SD)-([^\-]+)$/i)
						) {		#exceptions
						if ($DEBUG_THING) { print "[DT] Default Thing Processing case controller#2[DB]...tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4,tmp5=$tmp5<BR>\n"; }
						#tmp1=hardware,tmp2=card,tmp3=PCI,tmp4=controller,tmp5=SATA
						&add_tag("$tmp1"                  ,$file,$tmporiginaltag,0,$mode);	#hardware
						&add_tag("$tmp2"                  ,$file,$tmporiginaltag,0,$mode);	#card
						&add_tag("$tmp3 $tmp2"            ,$file,$tmporiginaltag,0,$mode);	#PCI card
						&add_tag("$tmp4"                  ,$file,$tmporiginaltag,0,$mode);	#controller
						&add_tag("$tmp4 $tmp2"            ,$file,$tmporiginaltag,0,$mode);	#controller card
						&add_tag("$tmp3 $tmp4 $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#PCI controller card
						&add_tag("$tmp5"                  ,$file,$tmporiginaltag,0,$mode);	#SATA
						&add_tag("$tmp5 $tmp4"            ,$file,$tmporiginaltag,0,$mode);	#SATA controller
						&add_tag("$tmp5 $tmp4 $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#SATA controller card
						&add_tag("$tmp3 $tmp5 $tmp4 $tmp2",$file,$tmporiginaltag,1,$mode);	#PCI SATA controller card
						$s=""; $tagged=1;

					} elsif (($s =~ /-(controller)-([^\-]+)-/i) || ($s =~ /-(controller)-([^\-]+)$/i)) {	#hardware2 hardware1,hardware1,hardware2
						if ($DEBUG_THING) { print "[DT] Default Thing Processing case controller#3...<BR>\n"; }
						&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);
						&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);
						&add_tag("$tmp2"      ,$file,$tmporiginaltag,0,$mode);
						$s=""; $tagged=1;

					} elsif (($s =~ /-(cards*)-([^\-]+)-/i) || ($s =~ /-(cards*)-([^\-]+)$/i)) {
						&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);
						&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);
						$s =~ s/-(cards*)-([^\-]+)/-/i;
					}
					#
					$s =~ s/--/-/g;
					$s =~ s/^hardware-//i;
					$s =~ s/^cards*-PCI-//i;
					$s =~ s/^controller-([^\-]+)-//i;
					#DEBUG:					print "[HW1] s is now $s!<BR>\n";					#ohoh
					##### Some stuff may be left, and will get tagged elsewhere. But some many not end up being captioned like it should, so we can force that here:
					if ($s =~ /^TV$/i) { &add_tag("thing-$1"   ,$file,$tmporiginaltag,"",$mode); }
				}
				if (($tmp2 =~ /^case$/i) && ($tmp3 =~ /^computer$/i)) {	#thing1-thing2-thing3-thing4-thing5 taggeed as "thing1,thing2,thing2 thing1,thing3 thing2,thing3 thing2 thing1,thing4,thing4 thing1,thing4 thing2,thing4 thing2 thing1,thing4 thing3 thing2 thing1,thing4 thing5,thing4 thing5 thing1,thing4 thing5 thing2,thing4 thing5 thing2 thing1,thing4 thing5 thing3 thing2,thing4 thing5 thing3 thing2 thing1,thing5,thing5 thing1,thing5 thing2,thing5 thing2 thing1,thing5 thing3 thing2,thing5 thing3 thing2 thing1" and captioned as "thing4 thing5 thing3 thing2"

																									#hardware-case-computer-NZXT-Phantom 820
						&add_tag("$tmp1"						,$file,$tmporiginaltag,0,$mode);	#hardware
						&add_tag("$tmp2"						,$file,$tmporiginaltag,0,$mode);	#case
						&add_tag("$tmp2 $tmp1"					,$file,$tmporiginaltag,0,$mode);	#case hardware
						&add_tag("$tmp3 $tmp2"					,$file,$tmporiginaltag,0,$mode);	#computer case 
						&add_tag("$tmp3 $tmp2 $tmp1"			,$file,$tmporiginaltag,0,$mode);	#computer case hardware
						&add_tag("$tmp4"						,$file,$tmporiginaltag,0,$mode);	#NZXT
						&add_tag("$tmp4 $tmp1"					,$file,$tmporiginaltag,0,$mode);	#NZXT hardware
						&add_tag("$tmp4 $tmp2"					,$file,$tmporiginaltag,0,$mode);	#NZXT case 
						&add_tag("$tmp4 $tmp2 $tmp1"			,$file,$tmporiginaltag,0,$mode);	#NZXT case hardware
						&add_tag("$tmp4 $tmp3 $tmp2 $tmp1"		,$file,$tmporiginaltag,0,$mode);	#NZXT computer case hardware
						&add_tag("$tmp4 $tmp5"					,$file,$tmporiginaltag,0,$mode);	#NZXT Phantom 820
						&add_tag("$tmp4 $tmp5 $tmp1"			,$file,$tmporiginaltag,0,$mode);	#NZXT Phantom 820 hardware
						&add_tag("$tmp4 $tmp5 $tmp2"			,$file,$tmporiginaltag,0,$mode);	#NZXT Phantom 820 case 
						&add_tag("$tmp4 $tmp5 $tmp2 $tmp1"		,$file,$tmporiginaltag,0,$mode);	#NZXT Phantom 820 case hardware
						&add_tag("$tmp4 $tmp5 $tmp3 $tmp2"		,$file,$tmporiginaltag,1,$mode);	#NZXT Phantom 820 computer case 
						&add_tag("$tmp4 $tmp5 $tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,0,$mode);	#NZXT Phantom 820 computer case hardware 
						&add_tag("$tmp5"						,$file,$tmporiginaltag,0,$mode);	#Phantom 820
						&add_tag("$tmp5 $tmp1"					,$file,$tmporiginaltag,0,$mode);	#Phantom 820 hardware
						&add_tag("$tmp5 $tmp2"					,$file,$tmporiginaltag,0,$mode);	#Phantom 820 case 
						&add_tag("$tmp5 $tmp2 $tmp1"            ,$file,$tmporiginaltag,0,$mode);	#Phantom 820 case hardware
						&add_tag("$tmp5 $tmp3 $tmp2"            ,$file,$tmporiginaltag,0,$mode);	#Phantom 820 computer case 
						&add_tag("$tmp5 $tmp3 $tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);	#Phantom 820 computer case hardware
						$tagged=1;	$s="";
				}
	

				if ($tmp2 =~ /^(RAM)$/) {
					if ($DEBUG_THING) { print "[DT] Hardware::RAM found! [HRF!]...<BR>\n"; }
					&add_tag("$tmp1",$file,$tmporiginaltag,0,$mode);

					if ($tmp5 =~ /DDR/i) {					#[tmp1=hardware/2=RAM/3=GSkill/4=RipJaws X/5=DDR3]
						&add_tag("$tmp3 $tmp2"            ,$file,$tmporiginaltag,0,$mode);	#GSkill Ram
						&add_tag("$tmp3 $tmp4"            ,$file,$tmporiginaltag,0,$mode);	#GSkill RipJaws
						&add_tag("$tmp3 $tmp4 $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#GSkill RipJaws Ram
						&add_tag("$tmp3 $tmp4 $tmp5 $tmp2",$file,$tmporiginaltag,1,$mode);	#GSkill RipJaws DDR3 Ram
						&add_tag("$tmp3 $tmp5 $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#GSkill DDR3 Ram
						&add_tag("$tmp5 $tmp2"            ,$file,$tmporiginaltag,0,$mode);	#DDR3 Ram

						$s=""; $tagged=1;
					}
				}

				if ($tmp2 =~ /^(CPU)$/) {					
					if ($DEBUG_THING) { print "[DT] Hardware::CPU found! [CPF!]...<BR>\n"; }
					&add_tag("$tmp1",$file,$tmporiginaltag,0,$mode);

					#[tmp1=hardware/2=CPU/3=Intel/4=Core i7/5=3770 Ivy Bridge]
					&add_tag("$tmp3 $tmp2"            ,$file,$tmporiginaltag,0,$mode);	#Intel CPU
					&add_tag("$tmp4"                  ,$file,$tmporiginaltag,0,$mode);	#Core i7
					&add_tag("$tmp4 $tmp2"            ,$file,$tmporiginaltag,0,$mode);	#Core i7 CPU
					&add_tag("$tmp4 $tmp5 $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#Core i7 3770 Ivy Bridge CPU
					&add_tag("$tmp3 $tmp4"            ,$file,$tmporiginaltag,0,$mode);	#Intel Core i7
					&add_tag("$tmp3 $tmp4 $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#Intel Core i7 CPU
					&add_tag("$tmp3 $tmp4 $tmp5"      ,$file,$tmporiginaltag,0,$mode);	#Intel Core i7 3770 Ivy Bridge
					&add_tag("$tmp3 $tmp4 $tmp5 $tmp2",$file,$tmporiginaltag,1,$mode);	#Intel Core i7 3770 Ivy Bridge CPU
					&add_tag("$tmp5"                  ,$file,$tmporiginaltag,0,$mode);	#3770 Ivy Bridge
					&add_tag("$tmp5 $tmp2"            ,$file,$tmporiginaltag,0,$mode);	#3770 Ivy Bridge CPU

					$s=""; $tagged=1;
				}

			}





			### STUB -- ADD NEW 4CHAIN CODE HERE


			if ($tagged) { $s=""; $FIVE_CHAIN_FAILED=0; } else { $FIVE_CHAIN_FAILED=1; print "WARNING: $s was not tagged in Dt-5chain-catchall-5CA-1!<BR>\n"; }
		} elsif ($s =~ /^([^\-]*)\-([^\-]*)\-([^\-]*)\-([^\-]*)$/) {				#thing1-thing2-thing3-thing4 catchall beginnings? ----- chain size of 4 (5 if you count 'thing')
			my $tagged=0;
			my $tmp1=$1; my $tmp2=$2; my $tmp3=$3; my $tmp4=$4;
			if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CAQZX] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
			#some 4chains are easily processed by tagging the first word, then throwing the rest into our 3chain code:
			#but apparently "hardware" is not a good one because I commented it out around 200806
			#This is because thing-hardware- simply throws hardware into things, then strips hardware, and feeds the rest of the chain in as is.




			#thing1-thing2-thing3-thing4 we want tagged as "thing1,thing1 thing2,thing2,thing3 thing2,thing4,thing4 thing1,thing4 thing2,thing4 thing3 thing2" and captioned as "thing4 thing3 thing2"
			if (($tmp1 =~ /^hardware*$/i) && ($tmp2 =~ /^card*$/i)) {					#things we want tagged as "thing1,thing1 thing2,thing2,thing3 thing4,thing3 thing4 thing2,thing3 thing4 thing1 thing2" and captioned as "thing3 thing4 thing1 thing2"
				#[tmp1=hardware,tmp2=card,tmp3=SD,tmp4=Sandisk]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-ACARD2B] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                    ,$file,$tmporiginaltag,0,$mode);		#hardware
				&add_tag("$tmp1 $tmp2"              ,$file,$tmporiginaltag,0,$mode);		#hardware card
				&add_tag("$tmp2"                    ,$file,$tmporiginaltag,0,$mode);		#card
				&add_tag("$tmp3 $tmp2"				,$file,$tmporiginaltag,0,$mode);		#SD card
				&add_tag("$tmp4"					,$file,$tmporiginaltag,0,$mode);		#Sandisk
				&add_tag("$tmp4 $tmp1"				,$file,$tmporiginaltag,0,$mode);		#Sandisk hardware
				&add_tag("$tmp4 $tmp2"				,$file,$tmporiginaltag,0,$mode);		#Sandisk card
				&add_tag("$tmp4 $tmp3 $tmp2"		,$file,$tmporiginaltag,1,$mode);		#Sandisk SD card
				$tagged=1;	


			} elsif (($tmp1 =~ /^subjects*$/i) && (1)) {					###thing1-thing2-thing3-thing4 we want tagged as "thing1,thing2,thing3,thing4" and captioned as "thing4"
				#[tmp1=toy,tmp2=gun,tmp3=Walther,tmp4=P38]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-AAAAAC1] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                    ,$file,$tmporiginaltag,0,$mode);		#subject
				&add_tag("$tmp2"                    ,$file,$tmporiginaltag,0,$mode);		#math
				&add_tag("$tmp3"                    ,$file,$tmporiginaltag,0,$mode);		#Albe
				&add_tag("$tmp4"                    ,$file,$tmporiginaltag,1,$mode);		#gun
				$tagged=1;	


			} elsif (($tmp1 =~ /^toy$/i) && ($tmp2 =~ /^gun$/i)) {					#toy guns ##thing1-thing2-thing3-thing4 we want tagged as "thing1,thing1 thing2,thing2,thing3 thing4,thing3 thing4 thing2,thing3 thing4 thing1 thing2" and captioned as "thing3 thing4 thing1 thing2"
				#[tmp1=toy,tmp2=gun,tmp3=Walther,tmp4=P38]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-AAAAAC1] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                    ,$file,$tmporiginaltag,0,$mode);		#toy                                        
				&add_tag("$tmp1 $tmp2"              ,$file,$tmporiginaltag,0,$mode);		#toy gun
				&add_tag("$tmp2"                    ,$file,$tmporiginaltag,0,$mode);		#gun
				&add_tag("$tmp3 $tmp4"              ,$file,$tmporiginaltag,0,$mode);		#Walther P38
				&add_tag("$tmp3 $tmp4 $tmp2"        ,$file,$tmporiginaltag,0,$mode);		#Walther P38 gun
				&add_tag("$tmp3 $tmp4 $tmp1 $tmp2"  ,$file,$tmporiginaltag,1,$mode);		#Walther P38 toy gun
				$tagged=1;	


			} elsif (($tmp1 =~ /^guns*$/i) && (&is_gun_type($tmp2))) {					#things we want tagged as "thing1,thing1 thing2,thing2,thing3 thing4,thing3 thing4 thing2,thing3 thing4 thing1 thing2" and captioned as "thing3 thing4 thing1 thing2"
				#[tmp1=gun,tmp2=pistol,tmp3=Bryco,tmp4=38]

				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-AGUN2] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                    ,$file,$tmporiginaltag,0,$mode);		#gun
				&add_tag("$tmp2"                    ,$file,$tmporiginaltag,0,$mode);		#pistol
				&add_tag("$tmp3"					,$file,$tmporiginaltag,0,$mode);		#Bryco
				&add_tag("$tmp3 $tmp1"				,$file,$tmporiginaltag,0,$mode);		#Bryco gun
				&add_tag("$tmp3 $tmp2"				,$file,$tmporiginaltag,0,$mode);		#Bryco pistol
				&add_tag("$tmp3 $tmp4"				,$file,$tmporiginaltag,0,$mode);		#Bryco 38
				&add_tag("$tmp3 $tmp4 $tmp1"		,$file,$tmporiginaltag,0,$mode);		#Bryco 38 gun
				&add_tag("$tmp3 $tmp4 $tmp2"		,$file,$tmporiginaltag,1,$mode);		#Bryco 38 pistol
				&add_tag("$tmp4"					,$file,$tmporiginaltag,0,$mode);		#38
				&add_tag("$tmp4 $tmp1"				,$file,$tmporiginaltag,0,$mode);		#38 gun
				&add_tag("$tmp4 $tmp2"				,$file,$tmporiginaltag,0,$mode);		#38 pistol
				$tagged=1;	


			#cover-album-Freezepop-Future Future Future Perfect = cover, album, album cover, Freezepop Freezepop cover, Freezepop album, Freezepop album cover, Freezepop - Albunmame, Freezepop - Albunmame cover, Albumname, Albumname cover
			} elsif (($tmp2 =~ /^album$/i) && ($tmp1 =~ /^cover$/i)) {							
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-AC] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                    ,$file,$tmporiginaltag,0,$mode);		#cover
				&add_tag("$tmp2"                    ,$file,$tmporiginaltag,0,$mode);		#album
				&add_tag("$tmp2 $tmp1"              ,$file,$tmporiginaltag,0,$mode);		#album cover
				&add_tag("$tmp3"                    ,$file,$tmporiginaltag,0,$mode);		#Freezepop 
				&add_tag("$tmp3 $tmp1"              ,$file,$tmporiginaltag,0,$mode);		#Freezepop cover
				&add_tag("$tmp3 $tmp2"              ,$file,$tmporiginaltag,0,$mode);		#Freezepop album
				&add_tag("$tmp3 $tmp2 $tmp1"        ,$file,$tmporiginaltag,0,$mode);		#Freezepop album cover
				&add_tag("$tmp3 - $tmp4"            ,$file,$tmporiginaltag,0,$mode);		#Freezepop - Albumname
				&add_tag("$tmp3 - $tmp4 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#Freezepop - Albumname cover
				&add_tag("$tmp3 - $tmp4 $tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);		#Freezepop - Albumname album cover
				&add_tag("$tmp4"                    ,$file,$tmporiginaltag,0,$mode);		#Albumname
				&add_tag("$tmp4 $tmp1"              ,$file,$tmporiginaltag,0,$mode);		#Albumname cover
				push(@UNCAPTIONABLE_THINGS,$tmp3);											#prevent bandname from showing up in caption due to a sister entertainment-music-bandname tag which should also be present in this situation according to tagging standards-and-practices.txt - unfortunately this approach only works for tags occuring in the file AFTER this one, so other measures will have to be taken as well
				push(@UNCAPTIONABLE_OTHERS,$tmp3);											#prevent bandname from showing up in caption due to a sister entertainment-music-bandname tag which should also be present in this situation according to tagging standards-and-practices.txt - unfortunately this approach only works for tags occuring in the file AFTER this one, so other measures will have to be taken as well
				$tagged=1;
			} elsif (($tmp1 =~ /^tile$/i) || ($tmp2 =~ /^vinyl composite$/)) {				#thing1-thing2-thing3-thing4 tagged "thing1,thing2,thing2 thing1,thing3,thing3 thing1,thing3 thing2,thing3 thing2 thing1,thing3 thing4,thing3 thing4 thing1,thing3 thing4 thing2,thing3 thing4 thing2 thing1,thing4,thing4 thing1,thing4 thing2,thing4 thing2 thing1" and captioned as "thing3 thing4 thing2 thing1"
				#may need to add other types of tyle to "vinyl composite"
				#tmp1=tile,tmp2=vinyl composite,tmp3=Armstrong,tmp4=Excelon
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-A21] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                   ,$file,$tmporiginaltag, 0,$mode);		#tile
				&add_tag("$tmp2"	               ,$file,$tmporiginaltag, 0,$mode);		#vinyl composite
				&add_tag("$tmp2 $tmp1"             ,$file,$tmporiginaltag, 0,$mode);		#vinyl composite tile
				&add_tag("$tmp3"                   ,$file,$tmporiginaltag, 0,$mode);		#Armstrong
				&add_tag("$tmp3 $tmp1"             ,$file,$tmporiginaltag, 0,$mode);		#Armstrong tile
				&add_tag("$tmp3 $tmp2"             ,$file,$tmporiginaltag, 0,$mode);		#Armstrong vinyl composite 
				&add_tag("$tmp3 $tmp2 $tmp1"       ,$file,$tmporiginaltag, 0,$mode);		#Armstrong vinyl composite tile
				&add_tag("$tmp3 $tmp4"             ,$file,$tmporiginaltag, 0,$mode);		#Armstrong Excelon
				&add_tag("$tmp3 $tmp4 $tmp1"       ,$file,$tmporiginaltag, 0,$mode);		#Armstrong Excelon tile
				&add_tag("$tmp3 $tmp4 $tmp2"       ,$file,$tmporiginaltag, 0,$mode);		#Armstrong Excelon vinyl composite 
				&add_tag("$tmp3 $tmp4 $tmp2 $tmp1" ,$file,$tmporiginaltag,"",$mode);		#Armstrong Excelon vinyl composite tile ****
				&add_tag("$tmp4"                   ,$file,$tmporiginaltag, 0,$mode);		#Excelon
				&add_tag("$tmp4 $tmp1"             ,$file,$tmporiginaltag, 0,$mode);		#Excelon tile
				&add_tag("$tmp4 $tmp2"             ,$file,$tmporiginaltag, 0,$mode);		#Excelon vinyl composite 
				&add_tag("$tmp4 $tmp2 $tmp1"       ,$file,$tmporiginaltag, 0,$mode);		#Excelon vinyl composite tile
				$tagged=1;
			} elsif (($tmp1 =~ /^toy$/i) && ($tmp2 =~ /^Transformers$/)) {					#thing1-thing2-thing3-thing4 tagged "thing1,thing2,thing2 thing1,thing3,thing3 thing1,thing4,thing2: thing4" and captioned as "thing2: thing4"
				# [tmp1=toy,tmp2=Transformers,tmp3=Decepticon,tmp4=Megatron]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-A22] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				&add_tag("$tmp1"                   ,$file,$tmporiginaltag, 0,$mode);		#toy
				&add_tag("$tmp2"	               ,$file,$tmporiginaltag, 0,$mode);		#Transformers
				&add_tag("$tmp2 $tmp1"             ,$file,$tmporiginaltag, 0,$mode);		#Transformers toy
				&add_tag("$tmp3"                   ,$file,$tmporiginaltag, 0,$mode);		#Decepticon
				&add_tag("$tmp3 $tmp1"             ,$file,$tmporiginaltag, 0,$mode);		#Decepticon toy
				&add_tag("$tmp4"                   ,$file,$tmporiginaltag, 0,$mode);		#Megatron 
				$REPLACE_CAPTION_WITH = "$tmp4 ($tmp2 $tmp3)";
				&add_tag("$tmp2: $tmp4"            ,$file,$tmporiginaltag,"",$mode);		#Transformers: Megatron ************
				$REPLACE_CAPTION_WITH = "";
				$tagged=1;
				$s="";
			} elsif (($tmp1 =~ /^tape$/i) && ($tmp2 =~ /^VHS$/)) {					#thing1-thing2-thing3-thing4 tagged "thing1,thing2,thing2 thing1,thing3,thing3 thing1,thing3 thing2,thing3 thing2 thing1,thing3 - thing4,thing3 - thing4 thing2,thing3 - thing4 thing1,thing3 - thing4 thing2 thing1,thing4,thing4 thing2,thing4 thing1" and captioned as "thing3 - thing4 thing2 thing1"
				#tmp1=tape,tmp2=VHS,tmp3=Sex Pistols,tmp4=The Filth And The Fury
				if ($DEBUG_THING) { print "<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                    ,$file,$tmporiginaltag, 0,$mode);		#tape                                                
				&add_tag("$tmp2"	                ,$file,$tmporiginaltag, 0,$mode);		#VHS                                                 
				&add_tag("$tmp2 $tmp1"              ,$file,$tmporiginaltag, 0,$mode);		#VHS tape                                            
				&add_tag("$tmp3"                    ,$file,$tmporiginaltag, 0,$mode);		#Sex Pistols                                         
				&add_tag("$tmp3 $tmp1"              ,$file,$tmporiginaltag, 0,$mode);		#Sex Pistols tape                                    
				&add_tag("$tmp3 $tmp2"              ,$file,$tmporiginaltag, 0,$mode);		#Sex Pistols VHS                                     
				&add_tag("$tmp3 $tmp2 $tmp1"        ,$file,$tmporiginaltag, 0,$mode);		#Sex Pistols VHS tape                                
				&add_tag("$tmp3 - $tmp4"            ,$file,$tmporiginaltag, 0,$mode);		#Sex Pistols - The Filth And The Fury                
				&add_tag("$tmp3 - $tmp4 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#Sex Pistols - The Filth And The Fury VHS            
				&add_tag("$tmp3 - $tmp4 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#Sex Pistols - The Filth And The Fury tape           
				&add_tag("$tmp3 - $tmp4 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#Sex Pistols - The Filth And The Fury VHS tape	**** 
				&add_tag("$tmp4"					,$file,$tmporiginaltag, 0,$mode);		#The Filth And The Fury                              
				&add_tag("$tmp4 $tmp2"              ,$file,$tmporiginaltag, 0,$mode);		#The Filth And The Fury VHS                          
				&add_tag("$tmp4 $tmp1"              ,$file,$tmporiginaltag, 0,$mode);		#The Filth And The Fury tape                     
				&add_tag("$tmp4 $tmp2 $tmp1"        ,$file,$tmporiginaltag, 0,$mode);		#The Filth And The Fury VHS tape                     
				$tagged=1;	
			} elsif (
				   (($tmp1 =~ /^vehicles*$/i) && (($tmp2 =~ /^truck$/       ) || ($tmp2 =~ /^car$/      )))
				|| (($tmp1 =~ /^hardware*$/i) && (($tmp2 =~ /^televisions*$/) || ($tmp2 =~ /^consoles*$/)))
			) {											
				#[tmp1=vehicle,tmp2=truck,tmp3=Dodge,tmp4=Durango]	#thing1-thing2-thing3-thing4 tagged as "thing1,thing2,thing3,thing3 thing2,thing3 thing4,thing3 thing4 thing2,thing4" an dcaptioned as "thing3 thing4 thing2"
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-A24] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                    ,$file,$tmporiginaltag, 0,$mode);		#vehicle
				&add_tag("$tmp2"	                ,$file,$tmporiginaltag, 0,$mode);		#truck
				&add_tag("$tmp3"                    ,$file,$tmporiginaltag, 0,$mode);		#Dodge
				&add_tag("$tmp3 $tmp2"              ,$file,$tmporiginaltag, 0,$mode);		#Dodge truck
				&add_tag("$tmp3 $tmp4"              ,$file,$tmporiginaltag, 0,$mode);		#Dodge Durango	
				&add_tag("$tmp3 $tmp4 $tmp2"        ,$file,$tmporiginaltag,"",$mode);		#Dodge Durango truck	*****
				&add_tag("$tmp4"					,$file,$tmporiginaltag, 0,$mode);		#Durango
				$tagged=1;	

			} elsif (($tmp1 =~ /^food$/i) && ($tmp2 =~ /^candy$/) && ($tmp3 =~ /^bar$/)) {			
				#[tmp1=food,tmp2=candy,tmp3=bar,tmp4=Yorkie]	#thing1-thing2-thing3-thing4 tagged as "thing1,thing2,thing2 thing3,thing3,thing4,thing4 thing2 thing3,thing4 thing3" and captioned as "thing4 thing2 thing3"
				if (($DEBUG_THING) || ($DEBUG_FOOD)) { print "<BR>\n[DT-4chain-catchall-4CA-A25] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                    ,$file,$tmporiginaltag, 0,$mode);		#food
				&add_tag("$tmp2"	                ,$file,$tmporiginaltag, 0,$mode);		#candy
				&add_tag("$tmp2 $tmp3"              ,$file,$tmporiginaltag, 0,$mode);		#candy bar
				&add_tag("$tmp3"                    ,$file,$tmporiginaltag, 0,$mode);		#bar
				&add_tag("$tmp4"					,$file,$tmporiginaltag, 0,$mode);		#Yorkie
				&add_tag("$tmp4 $tmp2 $tmp3"        ,$file,$tmporiginaltag,"",$mode);		#Yorkie candy bar	******
				&add_tag("$tmp4 $tmp3"              ,$file,$tmporiginaltag, 0,$mode);		#Yorkie bar
				$tagged=1;	
			} elsif (($tmp1 =~ /^stereo$/i) && ($tmp2 =~ /^car$/)) {						#thing1-thing2-thing3-thing4 tagged "thing1,thing2 thing1,thing3,thing3 thing1,thing3 thing2 thing1,thing3 thing4,thing3 thing4 thing1,thing3 thing4 thing2 thing1,thing4" and captioned as "thing3 thing4 thing2 thing1"
				#	[tmp1=stereo,tmp2=car,tmp3=AIWA,tmp4=CDCMP3]	
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-A26] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                    ,$file,$tmporiginaltag, 0,$mode);		#stereo
				&add_tag("$tmp2 $tmp1"              ,$file,$tmporiginaltag, 0,$mode);		#car stereo
				&add_tag("$tmp3"                    ,$file,$tmporiginaltag, 0,$mode);		#Aiwa
				&add_tag("$tmp3 $tmp1"              ,$file,$tmporiginaltag, 0,$mode);		#Aiwa stereo
				&add_tag("$tmp3 $tmp2 $tmp1"        ,$file,$tmporiginaltag, 0,$mode);		#Aiwa car stereo
				&add_tag("$tmp3 $tmp4"				,$file,$tmporiginaltag, 0,$mode);		#Aiwa CDC-MP3
				&add_tag("$tmp3 $tmp4 $tmp1"		,$file,$tmporiginaltag, 0,$mode);		#Aiwa CDC-MP3 stereo
				&add_tag("$tmp3 $tmp4 $tmp2 $tmp1"	,$file,$tmporiginaltag,"",$mode);		#Aiwa CDC-MP3 car stereo
				&add_tag("$tmp4"                    ,$file,$tmporiginaltag, 0,$mode);		#CDC-MP3
				$tagged=1;	
			} elsif (($tmp1 =~ /^toy$/i) && ($tmp2 =~ /^puzzle$/) && ($tmp3 =~ /^Rubik'*s*$/)) {	
				#	[tmp1=toy,tmp2=puzzle,tmp3=Rubik's,tmp4=Homer]							#thing1-thing2-thing3-thing4 tagged "thing1,thing2,thing3,thing3 thing1,thing3 thing2,thing3 thimg4,thing3 thing4 thing1,thing3 thing4 thing2,thing4,thing4 thing1,thing4 thing2" and captioned as "thing3 thing4 thing2"
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-A27] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				my $tmp5=$s;
				$s="";
				my $caption_it=1;
				if ($s =~ /Rubik-/i) { $caption_it=0; }												#caption "Rubik's" stuff but not "Rubik" stuff which we alias
				&add_tag("$tmp1"                    ,$file,$tmporiginaltag,          0,$mode);		#toy
				&add_tag("$tmp2"                    ,$file,$tmporiginaltag,          0,$mode);		#puzzle
				&add_tag("$tmp3"                    ,$file,$tmporiginaltag,          0,$mode);		#Rubik's
				&add_tag("$tmp3 $tmp1"              ,$file,$tmporiginaltag,          0,$mode);		#Rubik's toy
				&add_tag("$tmp3 $tmp2"              ,$file,$tmporiginaltag,          0,$mode);		#Rubik's puzzle
				&add_tag("$tmp3 $tmp4"              ,$file,$tmporiginaltag,          0,$mode);		#Rubik's Homer Simpson
				&add_tag("$tmp3 $tmp4 $tmp1"        ,$file,$tmporiginaltag,          0,$mode);		#Rubik's Homer Simpson toy
				&add_tag("$tmp3 $tmp4 $tmp2"        ,$file,$tmporiginaltag,$caption_it,$mode);		#Rubik's Homer Simpson puzzle
				&add_tag("$tmp4"                    ,$file,$tmporiginaltag,          0,$mode);		#Homer Simpson
				&add_tag("$tmp4 $tmp1"              ,$file,$tmporiginaltag,          0,$mode);		#Homer Simpson toy
				&add_tag("$tmp4 $tmp2"              ,$file,$tmporiginaltag,          0,$mode);		#Homer Simpson puzzle

				if ($tmp5 =~ /Rubik's/) {
					$tmp5 =~ s/Rubik\'s/Rubik/i;
					$STOP_ALL_CAPTIONING=1;
					&add_tag("thing-$tmp5"                ,$file,$tmporiginaltag, 0,$mode);		#
					$STOP_ALL_CAPTIONING=0;
				}

				$s="";
				$tagged=1;	





			} elsif (($tmp1 =~ /^costume$/i) && ($tmp2 =~ /^Transformers$/)) {					#thing1-thing2-thing3-thing4 tagged "thing1,thing2,thing2 thing1,thing3,thing3 thing1,thing4,thing4 thing1" and captioned as "thing4 thing1"
				#	[tmp1=costume,tmp2=Transformers,tmp3=Autobots,tmp4=Wheeljack]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-A28] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				&add_tag("$tmp1"                    ,$file,$tmporiginaltag,          0,$mode);		#
				&add_tag("$tmp2"                    ,$file,$tmporiginaltag,          0,$mode);		#
				&add_tag("$tmp2 $tmp1"              ,$file,$tmporiginaltag,          0,$mode);		#
				&add_tag("$tmp3"                    ,$file,$tmporiginaltag,          0,$mode);		#
				&add_tag("$tmp3 $tmp1"              ,$file,$tmporiginaltag,          0,$mode);		#
				&add_tag("$tmp4"                    ,$file,$tmporiginaltag,          0,$mode);		#
				&add_tag("$tmp4 $tmp1"              ,$file,$tmporiginaltag,          1,$mode);		#
				$s="";
				$tagged=1;	






			} elsif (($tmp1 =~ /^game$/i) && ($tmp2 =~ /^card$/i))  {			#thing1-thing2-thing3-thing4 tagged "thing1,thing2 thing1,thing3,thing3 thing1,thing3 thing2 thing1,thing4 thing3,thing4 thing3 thing1,thing4 thing3 thing2 thing1" and captioned "thing4 thing3 thing2 thing1"
				# [tmp1=game,tmp2=card,tmp3=Fluxx,tmp4=Stoner]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-A29] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				print "<font size=7><BR><BR><BR><BR>WARNING! TAG SHOULD BE 'game-card game-' not 'game-card' --- THIS SHOULD NEVER HAPPEN!</B></font><BR><BR><BR><BR>\n";					#oops; should have caught myself when I added this section. Now we must leave it here to catch ourselves in the future. But still process in case we don't notice the error message.
				$s="";
				&add_tag("$tmp1"                   ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp2 $tmp1"             ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3"                   ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3 $tmp1"             ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3 $tmp2 $tmp1"       ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp4 $tmp3"             ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp4 $tmp3 $tmp1"       ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp4 $tmp3 $tmp2 $tmp1" ,$file,$tmporiginaltag,"",$mode);		#
				$tagged=1;

			


			} elsif (($tmp1 =~ /^game$/i) && ($tmp2 =~ /^(.*) game$/i))  {			#thing1-thing2-thing3-thing4 tagged "thing1,thing2,thing3,thing3 thing1,thing3 thing2,thing4,thing4 thing1,thing4 thing2,thing4 thing3,thing4 thing3 thing1,thing4 thing3 thing2" and captioned "thing4 thing3 thing2"
				# [tmp1=game,tmp2=board game,tmp3=Life,tmp4=Simpsons]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-A301] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                   ,$file,$tmporiginaltag,0,$mode);		#game
				&add_tag("$tmp2"                   ,$file,$tmporiginaltag,0,$mode);		#board game
				&add_tag("$tmp3"                   ,$file,$tmporiginaltag,0,$mode);		#Life
				&add_tag("$tmp3 $tmp1"             ,$file,$tmporiginaltag,0,$mode);		#Life game
				&add_tag("$tmp3 $tmp2"             ,$file,$tmporiginaltag,0,$mode);		#Life board game
				&add_tag("$tmp4"                   ,$file,$tmporiginaltag,0,$mode);		#Simpsons
				&add_tag("$tmp4 $tmp1"             ,$file,$tmporiginaltag,0,$mode);		#Simpsons game
				&add_tag("$tmp4 $tmp2"             ,$file,$tmporiginaltag,0,$mode);		#Simpsons board game
				&add_tag("$tmp4 $tmp3"             ,$file,$tmporiginaltag,0,$mode);		#Simpsons Life
				&add_tag("$tmp4 $tmp3 $tmp1"       ,$file,$tmporiginaltag,0,$mode);		#Simpsons Life game
				&add_tag("$tmp4 $tmp3 $tmp2"       ,$file,$tmporiginaltag,1,$mode);		#Simpsons Life board game
				$tagged=1;






			} elsif (($tmp1 =~ /^food$/i) && ($tmp2 =~ /^candy$/i))  {			#thing1-thing2-thing3-thing4 tagged "thing1,thing2,thing3,thing4,thing4 thing3,thing4 thing3 thing2" and captioned "thing4 thing3 thing2"
				# [tmp1=food,tmp2=candy,tmp3=Peanut Butter Cups,tmp4=Reese's]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-RPBC1] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                   ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp2"                   ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp3"                   ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp4"                   ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp4 $tmp3"             ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp4 $tmp3 $tmp2"       ,$file,$tmporiginaltag,1,$mode);		#
				$tagged=1;




			
			} elsif ($tmp1 =~ /^food$/i)  {			#4-chain food catch-all
				#[tmp1=food,tmp2=fetuses,tmp3=aborted,tmp4=pickled]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-FOODCA] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s =~ s/^food-//i;
				&add_tag("food"                   ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("thing-$s"               ,$file,$tmporiginaltag,0,$mode);		
				$s="";				$tagged=1;
				






			} elsif (($tmp1 =~ /^logo$/i) && ($tmp2 =~ /^SubGenius$/i) && ($tmp3 =~ /^clench$/i))  {			#thing1-thing2-thing3-thing4 tagged "thing1,thing2,thing2 thing1,thing2 thing3,thing2,thing4 thing1,thing2 thing4 thing3,thing2 thing4 thing3 thing1,thing3,thing3 thing1,thing4,thing4 thing1,thing4 thing2 thing3 thing4,thing4 thing3,thing4 thing3 thing1" and captioned as "thing2 thing4 thing3 thing1"
				#[tmp1=logo,tmp2=SubGenius,tmp3=clench,tmp4=GFY]	
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-RPBCSB2] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                   ,$file,$tmporiginaltag,0,$mode);		#logo
				&add_tag("$tmp2"                   ,$file,$tmporiginaltag,0,$mode);		#SubGenius
				&add_tag("$tmp2 $tmp1"             ,$file,$tmporiginaltag,0,$mode);		#SubGenius logo
				&add_tag("$tmp2 $tmp3"             ,$file,$tmporiginaltag,0,$mode);		#SubGenius clench
				&add_tag("$tmp2 $tmp4 $tmp1"       ,$file,$tmporiginaltag,0,$mode);		#SubGenius GFY logo
				&add_tag("$tmp2 $tmp4 $tmp3"       ,$file,$tmporiginaltag,0,$mode);		#SubGenius GFY clench
				&add_tag("$tmp2 $tmp4 $tmp3 $tmp1" ,$file,$tmporiginaltag,1,$mode);		#SubGenius GFY clench logo
				&add_tag("$tmp3"                   ,$file,$tmporiginaltag,0,$mode);		#clench
				&add_tag("$tmp3 $tmp1"             ,$file,$tmporiginaltag,0,$mode);		#clench logo
				&add_tag("$tmp4"                   ,$file,$tmporiginaltag,0,$mode);		#GFY
				&add_tag("$tmp4 $tmp1"             ,$file,$tmporiginaltag,0,$mode);		#GFY logo
				&add_tag("$tmp4 $tmp2 $tmp3 $tmp1" ,$file,$tmporiginaltag,0,$mode);		#GFY SubGenius clench logo
				&add_tag("$tmp4 $tmp3"             ,$file,$tmporiginaltag,0,$mode);		#GFY clench
				&add_tag("$tmp4 $tmp3 $tmp1"       ,$file,$tmporiginaltag,0,$mode);		#GFY clench logo
				$tagged=1;






			} elsif (($tmp1 =~ /^software$/i) && ($tmp2 =~ /^operating systems*$/i))  {			#thing1-thing2-thing3-thing4 tagged "thing1,thing2,thing3,thing3 thing2,thing4,thing4 thing2" and captioned as "thing4 thinmg2"
				# [tmp1=software,tmp2=operating system,tmp3=Windows,tmp4=Windows NT]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-RPBCSB3] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                   ,$file,$tmporiginaltag,0,$mode);		#software
				&add_tag("$tmp2"                   ,$file,$tmporiginaltag,0,$mode);		#operating system
				&add_tag("$tmp3"                   ,$file,$tmporiginaltag,0,$mode);		#Windows
				&add_tag("$tmp3 $tmp2"             ,$file,$tmporiginaltag,0,$mode);		#Windows operating system
				&add_tag("$tmp4"                   ,$file,$tmporiginaltag,0,$mode);		#Windows NT
				&add_tag("$tmp4 $tmp2"             ,$file,$tmporiginaltag,1,$mode);		#Windows NT operating system
				$tagged=1;




			} elsif (($tmp1 =~ /^toys*$/i) && ($tmp2 =~ /^animals*$/i) && ($tmp4 =~ /^rubber$/i))  {	#thing4 could also be plastic,rubber, any kind of material
				##thing1-thing2-thing3-thing4 tagged "thing1,thing1 thing2,thing1 thing3,thing1 thing4 thing2,thing1 thing4 thing3,thing2,thing2 thing1,thing3,thing3 thing1,thing4 thing1,thing4 thing2,thing4 thing2 thing1,thing4 thing3,thing4 thing3 thing1" and captioned as "thing4 thing3 thing1"

				# [tmp1=toy,tmp2=animal,tmp3=duck,tmp4=rubber]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-RPBCSC5] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }
				$s="";
				&add_tag("$tmp1"                   ,$file,$tmporiginaltag,0,$mode);		#toy
				&add_tag("$tmp1 $tmp2"             ,$file,$tmporiginaltag,0,$mode);		#toy animal
				&add_tag("$tmp1 $tmp3"             ,$file,$tmporiginaltag,0,$mode);		#toy duck
				&add_tag("$tmp1 $tmp4 $tmp2"       ,$file,$tmporiginaltag,0,$mode);		#toy rubber animal
				&add_tag("$tmp1 $tmp4 $tmp3"       ,$file,$tmporiginaltag,0,$mode);		#toy rubber duck
				&add_tag("$tmp2"                   ,$file,$tmporiginaltag,0,$mode);		#animal
				&add_tag("$tmp2 $tmp1"             ,$file,$tmporiginaltag,0,$mode);		#animal toy
				&add_tag("$tmp3"                   ,$file,$tmporiginaltag,0,$mode);		#duck
				&add_tag("$tmp3 $tmp1"             ,$file,$tmporiginaltag,0,$mode);		#duck toy
				&add_tag("$tmp4 $tmp1"             ,$file,$tmporiginaltag,0,$mode);		#rubber toy
				&add_tag("$tmp4 $tmp2"             ,$file,$tmporiginaltag,0,$mode);		#rubber animal
				&add_tag("$tmp4 $tmp2 $tmp1"       ,$file,$tmporiginaltag,0,$mode);		#rubber animal toy
				&add_tag("$tmp4 $tmp3"             ,$file,$tmporiginaltag,0,$mode);		#rubber duck
				&add_tag("$tmp4 $tmp3 $tmp1"       ,$file,$tmporiginaltag,1,$mode);		#rubber duck toy
				$tagged=1;




			} elsif (($tmp1 =~ /^hardware$/i) && 
					(($tmp2 =~ /^motherboards*$/i) || ($tmp2 =~ /^power supply$/i))
				) {		#thing1-thing3-thing3-thing4 (thing-hardware-motherboard-ASRock-X99 WS) tagged as "thing1,thing2,thing2 thing1,thing3,thing3 thing2,thing3 thing2 thing1,thing3 thing4,thing3 thing4 thing1,thing3 thing4 thing2,thing3 thing4 thing2 thing1,thing4,thing4 thing1,thing4 thing2,thing4 thing2 thing1," and captioned as "thing3 thing4 thing2"
				if ($DEBUG_THING) { print "[DT-4chain-MOBO-CA] [checking hardware] [motherboard found!]\n"; }	#hardware
				&add_tag("$tmp2"					,$file,$tmporiginaltag, 0,$mode);	#motherboard
				&add_tag("$tmp2 $tmp1"              ,$file,$tmporiginaltag, 0,$mode);	#motherboard hardware
				&add_tag("$tmp3"					,$file,$tmporiginaltag, 0,$mode);	#ASRock
				&add_tag("$tmp3 $tmp2"				,$file,$tmporiginaltag, 0,$mode);	#AsRock motherboard
				&add_tag("$tmp3 $tmp2 $tmp1"        ,$file,$tmporiginaltag, 0,$mode);	#AsRock motherboard hardware
				&add_tag("$tmp3 $tmp4"				,$file,$tmporiginaltag, 0,$mode);	#AsRock X99 WS
				&add_tag("$tmp3 $tmp4 $tmp1"		,$file,$tmporiginaltag, 0,$mode);	#AsRock X99 WS hardware
				&add_tag("$tmp3 $tmp4 $tmp2"		,$file,$tmporiginaltag, 1,$mode);	#AsRock X99 WS motherboard
				&add_tag("$tmp3 $tmp4 $tmp2 $tmp1"	,$file,$tmporiginaltag, 0,$mode);	#AsRock X99 WS motherboard hardware
				&add_tag("$tmp4"					,$file,$tmporiginaltag, 0,$mode);	#X99 WS
				&add_tag("$tmp4 $tmp1"				,$file,$tmporiginaltag, 0,$mode);	#X99 WS hardware
				&add_tag("$tmp4 $tmp2"				,$file,$tmporiginaltag, 0,$mode);	#X99 WS motherboard
				&add_tag("$tmp4 $tmp2 $tmp1"		,$file,$tmporiginaltag, 0,$mode);	#X99 WS motherboard hardware
				$tagged=1;	$s="";




			### NEW 4-CHAINS GO HERE


			
			} elsif (($tmp1 =~ /^CPU$/i) || (1)) {											#thing1-thing2-thing3-thing4 tagged "thing1,thing2,thing3,thing4,thing2 thing1,thing2 thing3,thing2 thing3 thing1,thing2 thing3 thing4,thing2 thing3 thing4 thing1,thing3 thing1,thing3 thing4,thing3 thing4 thing1,thing4,thing4 thing1" and captioned "thing2 thing3 thing4 thing1"
				#	[tmp1=CPU,tmp2=Intel,tmp3=Core2Duo,tmp4=E6750]
				if ($DEBUG_THING) { print "<BR>\n[DT-4chain-catchall-4CA-DEFAULT] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4]<BR>\n"; }

				$s="";
				&add_tag("$tmp1"                   ,$file,$tmporiginaltag, 0,$mode);		#CPU
				&add_tag("$tmp2"	               ,$file,$tmporiginaltag, 0,$mode);		#Intel
				&add_tag("$tmp2 $tmp1"             ,$file,$tmporiginaltag, 0,$mode);		#Intel CPU
				&add_tag("$tmp2 $tmp3"             ,$file,$tmporiginaltag, 0,$mode);		#Intel Core2Duo
				&add_tag("$tmp2 $tmp3 $tmp1"       ,$file,$tmporiginaltag, 0,$mode);		#Intel Core2Duo CPU
				&add_tag("$tmp2 $tmp3 $tmp4"       ,$file,$tmporiginaltag, 0,$mode);		#Intel Core2Duo E6750
				&add_tag("$tmp2 $tmp3 $tmp4 $tmp1" ,$file,$tmporiginaltag,"",$mode);		#Intel Core2Duo E6750 CPU -- caption this one
				&add_tag("$tmp3"                   ,$file,$tmporiginaltag, 0,$mode);		#Core2Duo 
				&add_tag("$tmp3 $tmp1"             ,$file,$tmporiginaltag, 0,$mode);		#Core2Duo CPU
				&add_tag("$tmp3 $tmp4"             ,$file,$tmporiginaltag, 0,$mode);		#Core2Duo E6750
				&add_tag("$tmp3 $tmp4 $tmp1"       ,$file,$tmporiginaltag, 0,$mode);		#Core2Duo E6750 CPU
				&add_tag("$tmp4"                   ,$file,$tmporiginaltag, 0,$mode);		#E6750
				&add_tag("$tmp4 $tmp1"             ,$file,$tmporiginaltag, 0,$mode);		#E6750 CPU
				$tagged=1;
			}
			if ($tagged) { $s=""; } else { print "WARNING: $s was not tagged in Dt-4chain-catchall-4CA-1!<BR>\n"; }


		} elsif ($s =~ /^([^\-]*)\-([^\-]*)\-([^\-]*)$/) {							#thing1-thing2-thing3 catchall beginnings? ----- 3-chains
			my $tagged=0;
			my $tmp1=$1; my $tmp2=$2; my $tmp3=$3;
			if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-BEGIN] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }


			### NEW 3-CHAINS GO HERE, I THINK [201607]


			#computer cases are tagged in a weird way, becuase our situation is more akin to case-computer-brandname instead of whatever-brandname
			#CD-Freezepop-AlbumName = CD,Freezepop,AlbumName,Albumname CD,Freezepop CD,Freezepop - AlbumName,Freezepop - AlbumName CD,
			if ($tmp1 =~ /^CD$/i) {													#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing2 - thing3,thing2 - thing3 thing1,thing3,thing3 thing1" and captioned as "thing2 - thing3 thing1"
				$s="";
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1AAAA] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"              ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2"              ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2 $tmp1"        ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2 - $tmp3"      ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2 - $tmp3 $tmp1",$file,$tmporiginaltag,"",$mode);		
				&add_tag("$tmp3"              ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp3 $tmp1"        ,$file,$tmporiginaltag, 0,$mode);		
				$tagged=1;	


			} elsif (
				     (($tmp1 =~ /^hardware*$/i) && (($tmp2 =~  /^stereos*$/i) || ($tmp2 =~ /^CD player$/i))) || 
				     (($tmp1 =~ /^hardware*$/i) &&  ($tmp2 =~ /^speakers*$/i)                              ) || 
				     (($tmp1 =~    /^foods*$/i) &&  ($tmp2 =~     /^candy$/i)                              )
				) {			#thing1-thing2-thing3 tagged "thing1,thing2,thing3,things3 thing2" and captioned "thing3 thing2"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1AABB] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"                ,$file,$tmporiginaltag,0,$mode);		#food			#stereo
				&add_tag("$tmp2"                ,$file,$tmporiginaltag,0,$mode);		#candy			#hardawre
				&add_tag("$tmp3"                ,$file,$tmporiginaltag,0,$mode);		#Altoids		#Onkyo
				&add_tag("$tmp3 $tmp2"          ,$file,$tmporiginaltag,1,$mode);		#Altoids candy	#Onkyo stereo
				$tagged=1;	


			} elsif ((($tmp1 =~ /^games*$/i) && ($tmp2 =~ /^[a-z]+ games*$/i))  
			      || (($tmp1 =~ /^card*$/i)  && ($tmp2 =~ /^trading card*$/i)))  {			#thing1-thing2-thing3 tagged "thing1,thing2,thing3,thing3 thing1,thing3 thing2" and captioned "thing3 thing2"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1AF] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"                ,$file,$tmporiginaltag,0,$mode);		#game
				&add_tag("$tmp2"                ,$file,$tmporiginaltag,0,$mode);		#board game
				&add_tag("$tmp3"                ,$file,$tmporiginaltag,0,$mode);		#Last Word
				&add_tag("$tmp3 $tmp1"          ,$file,$tmporiginaltag,0,$mode);		#Last Word game
				&add_tag("$tmp3 $tmp2"			,$file,$tmporiginaltag,1,$mode);		#Last Word board game
				$tagged=1;	

			} elsif (
							(($tmp1 =~ /^glasses$/i) && (($tmp2 =~    /^sunglasses$/i) || ($tmp2 =~ /^huge$/i))) 
						||	(($tmp1 =~   /^cards$/i) &&  ($tmp2 =~ /^trading cards$/i))
						||	($tmp3 =~ /^portable$/i)															#thing-saw-chainsaw-portable - will this work for anything portable 2-chain? We'll see...
					)
			{			#thing1-thing2-thing3 tagged as "thing1,thing2,thing3 thing1,thing3 thing2" and captioned "thing3 thing2"
				$s="";
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1TR] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		#glasses
				&add_tag("$tmp2"			,$file,$tmporiginaltag,0,$mode);		#sunglasses
				&add_tag("$tmp3 $tmp1"		,$file,$tmporiginaltag,0,$mode);		#huge glasses
				&add_tag("$tmp3 $tmp2"		,$file,$tmporiginaltag,1,$mode);		#huge sunglasses
				$tagged=1;	
			} elsif (
					   (($tmp1 =~ /^vehicles*$/i) && (($tmp2 =~ /^car$/i)            || ($tmp2 =~ /^truck$/i)   )) 
					|| (($tmp1 =~ /^books*$/i)    && (($tmp2 =~ /^encyclopedias*$/i) || ($tmp2 =~ /^baby*$/i)   ))				#this was intended for named encyclopedias like thing-books-encyclopedias-Funk & Wagnalls - so we may need to check $tmp3 for capital letters, if we need to make this more specific in the future
					|| (($tmp1 =~ /^hardware*$/i) && (($tmp2 =~ /^tablets*$/i)       || ($tmp2 =~ /^wetvacs*$/i)))
					||  ($tmp1 =~ /^jewelry$/i)											#thing-jewelry-necklace-Firejewel
			) {																													#thing1-thing2-thing3 tagged as "thing1,thing2,thing3,thing3 thing2" and captioned "thing3 thing2"
				$s="";
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-2TR] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#vehicle
				&add_tag("$tmp2"			,$file,$tmporiginaltag, 0,$mode);		#truck
				&add_tag("$tmp3"            ,$file,$tmporiginaltag, 0,$mode);		#Suburban
				&add_tag("$tmp3 $tmp2"		,$file,$tmporiginaltag,"",$mode);		#Suburban truck
				$tagged=1;	


			#thing1-thing2-thing3 tagged as "thing1,thing2 thing1,thing3,thing3 thing1,thing3 thing2 thing1" and captioned "thing3 thing2 thing1"
			} elsif (
						   (($tmp1 =~ /^batteries$/i) || ($tmp1 =~ /^battery$/i) || ($tmp1 =~ /^cases*$/i))
						||  ($tmp1 =~ /^frames*$/i  )																	#may need to add $tmp2 =~ pictures
						|| (($tmp1 =~ /^cards*$/i   ) && ($tmp2 =~ /^trading$/i))									
						||  ($tmp1 =~ /^kits*$/i    )																	#MAY need to add $tmp2 =~ /^[A-Z]/ {starts with a capital}
					) {			
				#[tmp1=batteries,tmp2=lithium,tmp3=NB1L]					#[tmp1=frames,tmp2=picture,tmp3=pewter]	

				$s="";
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1B] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#case
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#computer case
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#Thermaltake computer case - CAPTIONED
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#Thermaltake case
				&add_tag("$tmp3"            ,$file,$tmporiginaltag, 0,$mode);		#Thermaltake
				$tagged=1;	

						 
						 
						 
						 #thing-machine-exercise-Soloflex:
			} elsif ($tmp1 =~ /^machine$/i) {										#thing1-thing2-thing3 tagged as "thing1,thing2 thing1,thing3,thing3 thing2 thing1" captioned as thing3 (only)
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1C] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#machine
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#excercise machine
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag, 0,$mode);		#Soloflex excercise machine 
				&add_tag("$tmp3",           ,$file,$tmporiginaltag,"",$mode);		#Soloflex - CAPTIONED
				$tagged=1;	
			} elsif (   ($tmp1 =~  /^team$/i) ||
					  ( ($tmp1 =~ /^phone$/i) && ($tmp2 =~  /^cell$/i) ) ||
					  ( ($tmp1 =~   /^box$/i) && ($tmp2 =~ /^lunch$/i) )			#box-lunch-Hello Kitty inspired this one
					) {											
				#thing1-thing2-thing3 tagged as "thing1,thing2 thing1,thing3,thing3 thing2 thing1" captioned as "thing3 thing2 thing1"
				#[tmp1=phone,tmp2=cell,tmp3=blackberry]	= phone,cell phone,blackberry,blackbery cell phone= thing1,thing2 thing1,thing3,thing3 thing2 thing1
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1C] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#team
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#drill team
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#goth drill team - CAPTIONED
				&add_tag("$tmp3",           ,$file,$tmporiginaltag, 0,$mode);		#goth
				$tagged=1;	
			} elsif ($tmp1 =~ /^tapestry$/i) {										#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing2 thing3,thing3,thing3 thing1" but captioned as "thing2 thing3 thing1"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1D] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp3",           ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2 $tmp3"      ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2 $tmp3 $tmp1",$file,$tmporiginaltag,"",$mode);		
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		
				$tagged=1;	
			} elsif ((($tmp1 =~ /^toys*$/i) || ($tmp1 =~ /^dolls*$/i)) && ($tmp3 =~ /^inflatable$/i)) {											
				#[tmp1=toy,tmp2=alien,tmp3=inflatable]
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-2DA] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);	#toy
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);	#alien
				&add_tag("$tmp3"            ,$file,$tmporiginaltag, 0,$mode);	#inflatable
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);	#inflatable alien
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);	#inflatable alien toy
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);	#alien toy
				$tagged=1;
			} elsif ($tmp1 =~ /^costumes?$/i) {										#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing3 thing2 thing1,thing3 thing2" and captioned as "thing3 thing2 thing1"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1E] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		
				$tagged=1;	
			##### If strings has a problem, add a check check for tmp2 =~ /guitar/:
			} elsif (($tmp1 =~ /^tapes?$/i) || ($tmp1 =~ /^strings?$/i)) {										#thing1-thing2-thing3 tagged as "thing1,thing2 thing1,thing3 thing2 thing1" and captioned as "thing3 thing2 thing1"
				#[tmp1=tape,tmp2=duct,tmp3=super] = tape, duct tape, super duct tape
				#[tmp1=strings,tmp2=guitar,tmp3=classical] = strings, guitar strings, classical guitar strings
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-2F] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		
				$tagged=1;	
			} elsif (($tmp2 =~ /^hand$/i) && ($tmp1 =~ /^sign$/i)) {	#thing1-thing3-thing3 tagged as "thing2,thing2 thing1,thing3,thing3 thing1" and captioned as "thing3" or "thing3 thing1" depeneindg
				#tmp1=sign,tmp2=hand,tmp3=devil horns
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-HS] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				#add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);	#sign - I don't think we should do this because that usually means a STREET sign	
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		
				$caption_it_1=0; $caption_it_2=1;
				if ($tmp3 =~ /^devil horns$/i) { $caption_it_1=1; $caption_it_2=0; }
				&add_tag("$tmp3"			,$file,$tmporiginaltag,$caption_it_1,$mode);		#"devil horns", not "devil horns hand sign" 
				&add_tag("$tmp3 $tmp1"		,$file,$tmporiginaltag,$caption_it_2,$mode);		#"peace sign", which means "devil horns sign" will happen now
				$tagged=1;	
			} elsif (($tmp1 =~ /^box$/i) && ($tmp2 =~ /^CD$/i) && ($tmp3 =~ /^longbox$/)) {		#not really a catch-all, but a specific case
				#[tmp1=box,tmp2=CD,tmp3=longbox]
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-SC1] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#cd
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#cd box
				&add_tag("$tmp2 $tmp3"      ,$file,$tmporiginaltag,"",$mode);		#cd longbox
				&add_tag("$tmp1"			,$file,$tmporiginaltag, 0,$mode);		#box
				&add_tag("$tmp3"			,$file,$tmporiginaltag, 0,$mode);		#longbox
				$tagged=1;
			} elsif (
				      ($tmp1 =~ /^governments*$/i) || ($tmp1 =~ /^figurines*$/i) || ($tmp1 =~ /^software*$/i)	#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing3,thing3 thing1,thing3 thing2,thing3 thing2 thing1" and tagged as "thing3 thing2 thing1"
				 || ((($tmp1 =~ /^balls*$/i)       || ($tmp1 =~ /^bags*/i))      && ($tmp3 =~ /^[A-Z]/))					#balls-bowling-Cartoon Network, bags-bowling-Cartoon Network
				 ||   ($tmp1 =~ /^dispensers*$/i)				#dispenser-Pez-Simpsons - may need to add check for tmp2 starts with capital, tmp3 starts with capital, we'll see
			) {

				# [tmp1=government,tmp2=county,tmp3=Fairfax]
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-SC2A] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"			,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3"			,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3 $tmp1"		,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3 $tmp2"		,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#
				$tagged=1;
			} elsif (($tmp1 =~ /^bridges*$/i) || ($tmp1 =~ /^files*$/i)) {						 				#thing1-thing2-thing3 tagged as "thing1,thing2 thing1,thing3 thing2 thing1,thing3 thing1" (and tmp3 sometimes) and captioned as "thing3 thing2 thing1"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-SC2B] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				#[tmp1=bridge,tmp2=foot,tmp3=invisible]
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);	#bridge
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);	#foot bridge
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);	#invisible foot bridge
				&add_tag("$tmp3 $tmp1"		,$file,$tmporiginaltag, 0,$mode);	#invisible bridge
				if ($tmp3 =~ /^invisible$/) {
					&add_tag("$tmp3"			,$file,$tmporiginaltag, 0,$mode);	#invisible - but only if this word is invisible
				}
				$tagged=1;
			} elsif (($tmp1 =~ /^card$/i) && ($tmp3 =~ /^serial$/i)) {		
				#[tmp1=card,tmp2=ISA,tmp3=serial]
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-SC2C] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp3 $tmp1",$file,$tmporiginaltag,"",$mode);		#serial card
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag, 0,$mode);		#ISA card
				&add_tag("$tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#ISA
				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#card
				$tagged=1;
			} elsif (    (($tmp1 =~ /^flowers*$/i)  && ($tmp3 =~ /^[A-Z][^\-]*$/))
				     ) {		#thing1-thing2-thing3 tagged a "thing1,thing2,thing2 thing1,thing3,thing3 thing1" and captioned as "thing3"
				#NOTE: that this is currently programmed so that the tmp3 (flower type) must be in capitals -- this may not make sense if thing3 is not a type of flower
				#[tmp1=flower,tmp2=violet,tmp3=Coastal Violet]
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-SC293] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#flower
				&add_tag("$tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#violet
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag, 0,$mode);		#violet flower
				&add_tag("$tmp3 $tmp1",$file,$tmporiginaltag, 0,$mode);		#Coastal Violet flower
				&add_tag("$tmp3"      ,$file,$tmporiginaltag,"",$mode);		#Coastal Violet				*************
				$tagged=1;
			} elsif (   
				          ($tmp1 =~ /^computers*$/i)								#may only work if tmp2=Apple, but we'll see
				     ) {		#thing1-thing2-thing3 tagged a "thing1,thing2,thing2 thing1,thing3,thing3 thing1" and captioned as "thing3 thing1"
				#NOTE: that this is currently programmed so that the tmp3 (flower type) must be in capitals -- this may not make sense if thing3 is not a type of flower
				#[tmp1=flower,tmp2=violet,tmp3=Coastal Violet]
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-SC2D1] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp2"      ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp3 $tmp1",$file,$tmporiginaltag,1,$mode);		#
				&add_tag("$tmp3"      ,$file,$tmporiginaltag,0,$mode);		#
				$tagged=1;
			} elsif (($tmp1 =~ /^pedal$/i)  && ($tmp2 =~ /^drum*$/)) {				#thing1-thing2-thing3 tagged as "thing1,thing2 thing1,thing3 thing2 tmp1" and captioned as "thing3 thing2 thing1"
				#[tmp1=pedal,tmp2=drum,tmp3=bass]	
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-SC3D3] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#pedal
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#drum pedal
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#bass drum pedal	*************
				$tagged=1;
			} elsif (($tmp1 =~ /^trees*$/i) || ($tmp1 =~ /^shells*$/i)) {				#If shell is too broad, make it be for crab shells only
				#[tmp1=tree,tmp2=Hemlock,tmp3=Eastern]	#thing1-thing3-thing3 tagged as "thing1,thing2,thing2 thing1,thing3 thing2,thing3 thing2 thing1" and captioned as "thing3 thing2 thing1"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-SC2E] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#tree
				if (($tmp2 !~ /^apple$/i) && ($tmp2 !~ /^walnut$/i)) {				#some trees do not need the tree name tagged separatly -- "apple" would be a bad tag for an apple tree, as people clicking 'apple' would want to see pictures of apples, not trees. But for some trees, it makes sense. So we must enumerate the exceptions here.
					&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);	#hemlock 
				}
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#hemlock tree
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#eastern hemlock
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#eastern hemlock tree *************
				$tagged=1;
				$s="";
			} elsif ( (($tmp1 =~ /^game$/i )     && ($tmp2 =~ /^.* game$/i))  ||
					  (($tmp1 =~ /^money$/i)     && ($tmp2 =~ /^coin$/i   ))  ||
					  (($tmp1 =~ /^subjects*$/i) && (1))				      ||
				      (($tmp1 =~ /^plant$/i)     && ($tmp2 =~ /^flower$/i )) ) {				#thing1-thing2-thing3 tagged as "thing1,thing2,thing3" and captioned as "thing3"		
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-123T3] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				#[tmp1=money,tmp2=coin,tmp3=dime]
				#[tmp1=game,tmp2=card game,tmp3=Apples To Apples]
				#[tmp1=plant,tmp2=flower,tmp3=tiger lily]
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#game			#subject
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#board game		#math
				&add_tag("$tmp3"            ,$file,$tmporiginaltag, 1,$mode);		#Monopoly		#Alegebra
				$tagged=1;
				$s="";
			} elsif ((($tmp1 =~ /^table$/i)  && ($tmp3 =~ /^plastic$/i))			#thing1-thing2-thing3 tagged as "thing1,thing2 thing1,thing3 thing1,thing3 thing2 thing1" and captioned as "thing3 thing2 thing1"
				   || ($tmp1 =~ /^jacket$/i))	{			#may need to add if tmp3 is a color																					#thing1-thing2-thing3 tagged as "thing1,thing2 thing1,thing3 thing1,thing3 thing2 thing1" and captioned as "thing3 thing2 thing1"
				#[tmp1=table,tmp2=picnic,tmp3=plastic]                              
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-123T4] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#jacket					#table
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#smoking jacket			#picnic table
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#green jacket			#plastic table
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#green smoking jacket	#plastic picnic table	**************
				$tagged=1;
			} elsif (($tmp1 =~ /^sign$/i)  && ($tmp2 =~ /^neon$/i)) {				#thing1-thing2-thing3 tagged as "thing1,thing2 thing1,thing2 thing3 thing1,thing3,thing3 thing1" and captioned as "thing2 thing3 thing1"
				#[tmp1=sign,tmp2=neon,tmp3=Bob]	
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-123T5] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#sign
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#neon sign
				&add_tag("$tmp2 $tmp3 $tmp1",$file,$tmporiginaltag,"",$mode);		#neon Bob sign	************
				&add_tag("$tmp3"            ,$file,$tmporiginaltag, 0,$mode);		#Bob
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#Bob sign
				$tagged=1;
			} elsif (																#thing1-thing2-thing3 tagged as "thing1,thing2,thing3 thing2" and captioned as "thing3 thing2"
					       ($tmp1 =~    /^tools*$/i)   
					   || (($tmp1 =~  /^hardware$/i) && (($tmp2 =~ /^mounts*$/i) || ($tmp2 =~ /^floppy drives*$/i)))
					   || (($tmp1 =~ /^vehicles*$/i) &&  ($tmp2 =~ /^bus$/i))
				       || (($tmp1 =~ /^vehicles*$/i) &&  ($tmp3 =~ /^tow$/i))
					   || (($tmp1 =~     /^water$/i) &&  ($tmp3 =~ /^[A-Z]/))			# [tmp1=water,tmp2=ocean,tmp3=Atlantic]	
			) {									
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-123T6] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				#[tmp1=vehicle,tmp2=bus,tmp3=school]	#[tmp1=vehicle,tmp2=truck,tmp3=tow]				#[tmp1=tool,tmp2=wrench,tmp3=basin] 
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#vehicle
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#bus

				#some wrenches get thing3 tagged and that should be the caption too:
				my $caption_it=1;
				if (($tmp1 =~ /^tools*/i) && ($tmp2 =~ /^wrench$/i) && (($tmp3 =~ /^Vice-*Grip$/i) || ($tmp3 =~ /^ratchet$/i))) {
					&add_tag("$tmp3"        ,$file,$tmporiginaltag,"",$mode);		#ratchet / vice grip / etc
					$caption_it=0;
				}
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag,$caption_it,$mode);		#school bus

				$tagged=1;				
			} elsif (	(($tmp1 =~ /^decoration$/i)  && ($tmp2 =~ /^military$/i)) ||
						(($tmp1 =~ /^toys*$/i      ) && ($tmp2 =~ /^tin*$/i    ))  ) {		#thing1-thing2-thing3 star tagged as "thing1,thing2,thing2 thing1,thing3,thing3 thing1,thing3 thing2 thing1"
				#[tmp1=decoration,tmp2=military,tmp3=Silver Star]
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1237N] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#decoration							#toy                           
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#military							#tin                           
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#military decoration				#tin toy                       
				&add_tag("$tmp3"            ,$file,$tmporiginaltag, 0,$mode);		#Silver Star						#Homer Simpson                 
				&add_tag("$tmp3 $tmp1",     ,$file,$tmporiginaltag, 0,$mode);		#Silver Star decoration				#Homer Simpson toy             
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#Silver Star military decoration	#Homer Simpson tin toy         
				$tagged=1;
			} elsif ((($tmp1 =~ /^toys*$/i) && ($tmp2 !~ /^stuffed$/i)) || ($tmp2 =~ /^dolls*$/i)) {										
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-2DB] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);			#toy/doll
				&add_tag("thing-$tmp2-$tmp3",$file,$tmporiginaltag, 0,$mode);			#send the rest through
				$tagged=1;
			} elsif (($tmp1 =~ /^toy$/i) && (($tmp2 =~ /^Simpsons$/i) || ($tmp2 =~ /^The Simpsons$/i))) {	#thing1-thing2-thing3 tagged as "thing1,thing2,thing3,thing3 thing1,thing2: thing3" and captioned as "thing2: thing3"
				#tmp1=toy,tmp2=Simpsons,tmp3=Lisa Simpson
				if ($tmp2 =~ /^Simpsons$/) { $tmp2="The Simpsons"; }
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1H] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#toy
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#The Simpsons 
				&add_tag("$tmp3",           ,$file,$tmporiginaltag, 0,$mode);		#Lisa Simpson
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#Lisa Simpson toy
				&add_tag("$tmp2: $tmp3"		,$file,$tmporiginaltag,"",$mode);		#The Simpsons: Lisa Simpson 
				$tagged=1;	
			#toy-inflatable works here, but toy-.* might not:
			#thing-toy-something-inflatable should be tagged toy,something,inflatable toy,inflatable something,inflatable something toy and captioned "inflatable something toy"
			} elsif ((($tmp1 =~ /^toy$/i) && ($tmp3 =~  /^inflatable$/i)) 
				   || ($tmp1 =~ /^toy-/)) {											#this line is a test
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1GA] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp3",           ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		
				$tagged=1;	
			} elsif (($tmp1 =~ /^audio$/i)  && ($tmp2 =~ /^interface$/i)) {			#thing1-thing2-thing3 tagged as "thing1,thing1 thing2,thing2,thing3,thing3 thing1,thing3 thing1 thing2,thing3 thing2" and captoined as "thing3 thing1 thing2"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1GM] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		
				&add_tag("$tmp1 $tmp2"      ,$file,$tmporiginaltag,0,$mode);		
				&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);		
				&add_tag("$tmp3",           ,$file,$tmporiginaltag,0,$mode);		
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		
				&add_tag("$tmp3 $tmp1 $tmp2",$file,$tmporiginaltag,1,$mode);		
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag,0,$mode);		
				$tagged=1;	

			} elsif (($tmp1 =~ /^wrapper$/i)  && ($tmp2 =~ /^candy$/i)) {			#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing3,thing3 thing2,thing3 thing1,thing3 thing2 thing1" and captioned as "thing3 thing2 thing1"
				#[tmp1=wrapper,tmp2=candy,tmp3=Mary Jane]	
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1H] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#wrapper
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#candy
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#candy wrapper
				&add_tag("$tmp3"            ,$file,$tmporiginaltag, 0,$mode);		#Mary Jane
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#Mary Jane wrapper
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#Mary Jane candy
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#Mary Jane candy wrapper
				$tagged=1;
				$s="";
			} elsif (
				(($tmp1 =~ /^pack$/i)  && (($tmp2 =~ /^booster$/i) || ($tmp2 =~ /^expansion$/i)))
			  ||
				(($tmp1 =~ /^signs*$/i) && ($tmp2 =~ /^zodiac$/i))
			) {
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1J] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				#[tmp1=pack,tmp2=booster,tmp3=assassins]							#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing3,thing3 thing2 thing1,thing3 thing1" and captioned as "thing3 thing2 thing1"
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3"            ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#
				$tagged=1;
				$s="";

			} elsif (($tmp1 =~ /^crest$/i)  && ($tmp2 =~ /^family$/i)) {			#thing1-thing2-thing3 tagged as "thing1,thing2 thing1,thing3,thing3 thing1,thing3 thing2,thing3 thing2 thing1"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1K] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3"            ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#
				$tagged=1;
				$s="";

			} elsif (($tmp1 =~ /^train$/i)  && ($tmp2 =~ /^dress$/i)) {			#thing1-thing2-thing3 tagged as "thing2,thing2 thing1,thing3 thing2,thing3 thing2 thing1" and captioned as "thing3 thing2 thing1"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1L2] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag, 1,$mode);		#
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#
				$tagged=1;
				$s="";


			} elsif (($tmp1 =~ /^rail$/i)  && ($tmp2 =~ /^stairs*$/i)) {			#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing3 thing2,thing3 thing2 thing1" and captioned as "thing3 thing2 thing1"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1L3] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; } #[tmp1=rail,tmp2=stair,tmp3=spiral]
				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		#rail
				&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);		#stair
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#stair trail
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag,0,$mode);		#spiral stair
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);		#spiral stair rail
				$tagged=1;

				#we also want 'stair' and 'stairs' for all variations, so we have to convert stair to stairs and run through these all one more time:
				if ($tmp2 =~ /^stair$/i) {
					$tmp2 =~ s/stair/stairs/i;
					if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-STAIR-1L3] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; } #[tmp1=rail,tmp2=stair,tmp3=spiral]
					##### DO IT ALL AGAIN (copy of same 5 lines from above, now used with the new $tmp2):
					&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		#rail
					&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);		#stair
					&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#stair trail
					&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag,0,$mode);		#spiral stair
					&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,0,$mode);		#spiral stair rail
				}
				$s="";





			} elsif (($tmp1 =~ /^beer$/i)  && ($tmp3 =~ /^40*$/i)) {				#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing2 thing3,thing3" and captioned as "thing2 thing3"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-A40] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; } #tmp1=beer,tmp2=Icehouse,tmp3=40]
				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		#beer
				&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);		#Icehouse
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#Icehouse beer
				&add_tag("$tmp2 $tmp3"      ,$file,$tmporiginaltag,1,$mode);		#Icehouse 40
				&add_tag("$tmp3"            ,$file,$tmporiginaltag,0,$mode);		#40
				$tagged=1;
				$s="";





			} elsif (($tmp1 =~ /^bug$/i)  && ($tmp2 =~ /^worm*$/i)) {				#thing1-thing2-thing3 tagged as "thing1,thing2,thing3,thing3 thing1" and captioned as "thing3"
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-A41] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; } #[tmp1=bug,tmp2=worm,tmp3=inchworm]
				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		#bug
				&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);		#worm
				&add_tag("$tmp3"            ,$file,$tmporiginaltag,1,$mode);		#inchworm
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#inchworm bug
				$tagged=1;
				$s="";


			} elsif (($tmp1 =~ /^beers*$/i) || ($tmp1 =~ /^guitars*$/i))  {											#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing2 thing3,thing2 thing3 thing1,thing3,thing3 thing1" and captioned as "thing2 thing3 thing1"
				#tmp1=beer,tmp2=Snake Dog,tmp3=India Pale Ale
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1ZYC-] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		#beer
				&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);		#Snake Dog
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#Snake Dog beer
				&add_tag("$tmp2 $tmp3"      ,$file,$tmporiginaltag,0,$mode);		#Snake Dog India Pale Ale
				&add_tag("$tmp2 $tmp3 $tmp1",$file,$tmporiginaltag,1,$mode);		#Snake Dog India Pale Beer
				&add_tag("$tmp3"            ,$file,$tmporiginaltag,0,$mode);		#India Pale Ale
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#India Pale Ale Beer
				$s=""; $tagged=1;



			} elsif ($tmp1 =~ /fetuse?s?$/i)  {										#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing3,thing3 thing1,thing3 thing2 thing1" and captioned as "thing3 thing2 thing1"
				#[tmp1=fetuses,tmp2=aborted,tmp3=pickled]
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1ZYB-3] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		#fetuses
				&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);		#aborted
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#aborted fetuses
				&add_tag("$tmp3"            ,$file,$tmporiginaltag,0,$mode);		#pickled
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#pickled fetuses
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);		#pickled aborted fetuses
				$s=""; $tagged=1;


			} elsif ($tmp1 =~ /^vehicles*$/i)    {	#3chain vehicle catch-all		#tag 'vehicle', strip 'vehicle' off, then re-send
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1ZYA-4] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				#Our default case is to just strip vehicle off, then feed it back as a 2-chain:
				&add_tag("$tmp1",			 $file,$tmporiginaltag,0,$mode);		#vehicle
				&add_tag("thing-$tmp2-$tmp3",$file,$tmporiginaltag,1,$mode);		#airplane-jet
				$s=""; $tagged=1;
				
				
																					#"thing1,thing2 thing1,thing2 thing3 thing1,thing3,thing3 thing1,thing3 thing2 thing1" and captioned as "thing3 thing2 thing1"
			} elsif ((($tmp1 =~ /^box$/i) && ($tmp3 =~ /^[A-Z]/))		#box-metal-The Beatles,box-wood-Muppets,etc
				||   (($tmp1 =~ /^box$/i) && ($tmp3 =~ /^[A-Z]/)))		#spare
			{		
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1ZYB-5] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp2 $tmp3 $tmp1",$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp3"            ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#
				&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);		#
				$s=""; $tagged=1;



			} elsif (($tmp1 =~ /^water$/i) || ($tmp1 =~ /^ocean$/i) || ($tmp1 =~ /^wave$/i))  {		#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing2 thing3,thing2 thing3 thing1,thing3,thing3 thing1" and captioned as "thing2 thing3 thing1"
				#[tmp1=fetuses,tmp2=aborted,tmp3=pickled]
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1ZYB-6] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		#guitar
				&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);		#ocean
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#ocean guitar
				&add_tag("$tmp2 $tmp3"      ,$file,$tmporiginaltag,0,$mode);		#ocean wave
				&add_tag("$tmp2 $tmp3 $tmp1",$file,$tmporiginaltag,1,$mode);		#ocean wave guitar
				&add_tag("$tmp3"            ,$file,$tmporiginaltag,0,$mode);		#wave
				$s=""; $tagged=1;



	




			} else {					#DEFAULT CASE								#thing1-thing2-thing3 tagged as "thing1,thing2,thing2 thing1,thing2 thing3,thing2 thing3 thing1" and captioned as "thing2 thing3 thing1"
				#tmp1=toy,tmp2=Simpsons,tmp3=Lisa Simpson
				if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-3CA-1ZZ-DEFAULT] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }
				$s="";
				#[tmp1=power supply,tmp2=OCZ,tmp3=GameXStream 600W]
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#power supply
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#OCZ power supply
				&add_tag("$tmp2 $tmp3 $tmp1",$file,$tmporiginaltag,"",$mode);		#OCZ GameXStream 600W power supply -- caption this one
				&add_tag("$tmp2 $tmp3"      ,$file,$tmporiginaltag, 0,$mode);		#OCZ GameXStream 600W
				&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#OCZ

				#exceptions: "stuffed octopus toy"           should be tagged "octopus" as well
				#exceptions: "remote control helicopter toy" should be tagged "helicopter" as well
				if (($tmp2 =~ /^stuffed$/i)        && ($tmp1 =~ /^toy$/i )) { &add_tag("$tmp3"      ,$file,$tmporiginaltag,0,$mode); }
				if (($tmp2 =~ /^remote control$/i) && ($tmp1 =~ /^toy$/i )) { &add_tag("$tmp3"      ,$file,$tmporiginaltag,0,$mode); }

				$tagged=1;
			}
			if ($tagged==1) { $s=""; } else { print "WARNING: $s was not tagged in Dt-3chain-catchall-3CA-1!<BR>\n"; }
			if ($DEBUG_THING) { print "<BR>\n[DT-3chain-catchall-ZZZ] [s=$s/tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3]<BR>\n"; }

		
		

		
		
		
		} elsif (($s =~ /^.*\-.*\-.*$/) && ($s !~ /^hardware-/i)) {					#thing-drink-liquor-schnapps-cinnomon schnapps-Fire Water ---- "thing chain catch-all for chains of 3 or more"
			my $DEBUG_LOCAL=0;
			if (($DEBUG_THING) || ($DEBUG_LOCAL)) { print "[DT-progress-M1] "; }
																					#thing-vehicle-car-Pontiac-Bonneville-1993 is another type of long thing chain
			@tmparray = split(/\-/,"$s");											#use @tmp to hold each part of the chain
																					#DEBUG:	print "[ASTA] splitting the array ... ".@tmparray." elements. s=$s<BR>\n";#
			for ($tmp=0; $tmp<@tmparray; $tmp++) {									#use $tmp to count through it
				if ($DEBUG_LOCAL) { print "[\$tmparray[".$tmp."]=".$tmparray[$tmp]."] "; }
				if ($tmp==(@tmparray-1)) { $tmp2=""; }								#if it's the very last element, we will caption this one
				else { $tmp2 = 0; }

				if (($tmparray[0] =~ /^vehicle$/) && ($tmparray[@tmparray-1] =~ /^([12][0-9][0-9][0-9])$/)) { $tmp2=0; }	#unless it's a vehicle with a year, in which case it's special and doesn't get captioned yet
				
				&add_tag("$tmparray[$tmp]",$file,$tmporiginaltag,$tmp2,$mode);				
			}
			if (($tmparray[0] =~ /^vehicle$/) && ($tmparray[@tmparray-1] =~ /^([12][0-9][0-9][0-9])$/)) {			#cars with years get special captioning -- "1993 Pontiac Bonneville" instead of just "Bonneville"
				&add_tag($tmparray[@tmparray-1] . " " . $tmparray[@tmparray-3] . " " . $tmparray[@tmparray-2],$file,$tmporiginaltag,"",$mode);				
			}
			
			$s="";






		
		
		
		
		} elsif ($s =~ /\-/) {		#thing  #default thing processing	#letovers

			$s =~ /^([^\)]+)-(.+)$/i; my $tmp1=$1; my $tmp2=$2;			#we need a $1 and $2 already for some advanced comparisons
			if ($DEBUG_THING) { print "<BR><B>[DT] Default Thing Processing UGH!</B>.../s=$s/tmp1=$tmp1/tmp2=$tmp2/\$1=$1/\$2=$2/<BR>\n"; }

			#thing catchalls
			#thing1-thing2 tagged "thing1,thing2 thing1" and captioned as "thing2 thing1"
			#EXAMPLES: xbox controller, red eye, stop sign

			if ( (             &is_color($tmp2)        )	||		#if the 2nd thing is simply a color describing the first thing, we don't want to just tag that color.  An image tagged "red" should be an all/mostly red image, not an image with a "red [something]" in it...
				 (             &is_instrument($tmp1)   )	||		#if the 1st thing is an instrument, the 2nd thing is describing that instrument
				 ($s =~ /^(cigarettes*)-(electronic)$/i)    || 
  			     ($s =~      /^(books*)-(coloring)$/i)      ||
  			     ($s =~      /^(books*)-(sticker)$/i)       ||
  			     ($s =~      /^(books*)-(baby)$/i)          ||
			     ($s =~        /^(controllers*)-(.*)$/i)    ||
  			     ($s =~        /^(light bulbs*)-(.*)$/i)    ||		
  			     ($s =~        /^(reflections*)-(.*)$/i)    ||		#so far, at the very least, this makes sense when the 2nd thing is a color, because we don't want to tag a whole picture as having a color that is really just the color of a reflection IN that picture
  			     ($s =~         /^(containers*)-(.*)$/i)    ||
				 ($s =~          /^(accidents*)-(.*)$/i)    || 
			     ($s =~          /^(bins*)-([a-z].*)$/ )    ||		#turns out this is right, but not for Peapod bins, so if they are capitalized bins, we'll not rule this here
  			     ($s =~          /^(carriages*)-(.*)$/i)    ||
  			     ($s =~          /^(positions*)-(.*)$/i)    ||		
				 ($s =~          /^(stockings*)-(.*)$/i)    || 
  			     ($s =~           /^(blankets*)-(.*)$/i)    ||		#electric blankets, at least!
				 ($s =~           /^(carriers*)-(.*)$/i)    || 
  			     ($s =~           /^(chimneys*)-(.*)$/i)    ||
				 ($s =~           /^(lighters*)-(.*)$/i)    ||		#at least for thing-lighter-crack ... thing-lighter-Zippo would NOT work well here because 'Zippo' would not be tagged, just 'Zippo light'
				 ($s =~           /^(railings*)-(.*)$/i)    || 
  			     ($s =~           /^(slippers*)-(.*)$/i)    ||
  			     ($s =~           /^(snuffers*)-(.*)$/i)    ||		
				 ($s =~      /^(speakers*)-([a-z].*)$/ )    ||		#brand-name [capital] speakers are handled differently
				 ($s =~           /^(supplies*)-(.*)$/i)    || 
				 ($s =~            /^(baskets*)-(.*)$/i)    || 
  			     ($s =~            /^(candles*)-(.*)$/i)    ||
  			     ($s =~            /^(feeders*)-(.*)$/i)    ||
  			     ($s =~            /^(filters*)-(.*)$/i)    ||
				 ($s =~            /^(fingers*)-(.*)$/i)    || 
				 ($s =~            /^(glasses*)-(.*)$/i)    || 
				 ($s =~            /^(ladders*)-(.*)$/i)    ||		#for ladder-attic, anyway!
  			     ($s =~            /^(mirrors*)-(.*)$/i)    ||
				 ($s =~            /^(posters*)-(.*)$/i)    || 
  			     ($s =~            /^(shrines*)-(.*)$/i)    ||
  			     ($s =~            /^(shelves*)-(.*)$/i)    ||		#shelf is handled separately
  			     ($s =~            /^(springs*)-(.*)$/i)    ||		#hot springs should not also tag 'hot'
  			     ($s =~             /^(angels*)-(.*)$/i)    ||
  			     ($s =~             /^(badges*)-(.*)$/i)    ||
  			     ($s =~             /^(boxe*s*)-(.*)$/i)    ||
  			     ($s =~             /^(brushs*)-(.*)$/i)    ||
				 ($s =~             /^(charts*)-(.*)$/i)    ||		#This may break some kind of chart, based on where it used to be. But this is definitley right for pie charts!
  			     ($s =~             /^(cloths*)-(.*)$/i)    ||		#"pool table cloth" but not "pool table" -- that's just silly
				 ($s =~             /^(covers*)-(.*)$/i)    ||		#moved, so may not apply to all situations. "thing-covers-license plate" 
  			     ($s =~             /^(flames*)-(.*)$/i)    ||
			     ($s =~             /^(lights*)-(.*)$/i)    ||
  			     ($s =~             /^(makers*)-(.*)$/i)    ||
#			     ($s =~             /^(quotes*)-(.*)$/i)    ||		#moved to case #6				 				if ($tmp1 =~ /^quotes*$/) {$tmp2=&fix_name_of_any_form($tmp2); }
  			     ($s =~             /^(sauces*)-(.*)$/i)    ||
  			     ($s =~             /^(shelfs*)-(.*)$/i)    ||		#plural would actualy be shelves, which is handled above
  			     ($s =~             /^(shorts*)-(.*)$/i)    ||
  			     ($s =~             /^(stains*)-(.*)$/i)    ||
  			     ($s =~             /^(stairs*)-(.*)$/i)    ||
  			     ($s =~             /^(stools*)-(.*)$/i)    ||
			     ($s =~             /^(papers*)-(.*)$/i)    ||
				 ($s =~             /^(salads*)-(.*)$/i)    || 
  			     ($s =~             /^(stands*)-(.*)$/i)    ||
			     ($s =~             /^(swords*)-(.*)$/i)	||		
			     ($s =~             /^(tables*)-(.*)$/i)	||		#i GUESS table goes here
			     ($s =~             /^(towers*)-(.*)$/i)	||		
  			     ($s =~              /^(bites*)-(.*)$/i)    ||
#  			     ($s =~              /^(cages*)-(.*)$/i)    ||		#this breaks thing-cage-raccoon trap which is handled later ... could expand this to be NOT cage-raccoon..that could get ugly
  			     ($s =~              /^(cakes*)-(.*)$/i)    ||
  			     ($s =~              /^(cards*)-(.*)$/i)    ||
  			     ($s =~              /^(claws*)-(.*)$/i)    ||		#this may belong in the group that also tags thing2. not sure yet.
  			     ($s =~              /^(clips*)-(.*)$/i)    ||
  			     ($s =~              /^(desks*)-(.*)$/i)    ||
  			     ($s =~              /^(domes*)-(.*)$/i)    ||
  			     ($s =~              /^(dress*)-(.*)$/i)    ||
				 ($s =~              /^(drums*)-(.*)$/i)    ||		
			     ($s =~              /^(flags*)-(.*)$/i)    || 
			     ($s =~              /^(glass*)-(.*)$/i)    ||
  			     ($s =~              /^(holes*)-(.*)$/i)    ||		
  			     ($s =~              /^(hoses*)-(.*)$/i)    ||		
  			     ($s =~              /^(mails*)-(.*)$/i)    ||
  			     ($s =~              /^(masks*)-(.*)$/i)    ||
			     ($s =~              /^(menus*)-(.*)$/i)    ||
  			     ($s =~              /^(moons*)-(.*)$/i)    ||
			     ($s =~              /^(poles*)-(.*)$/i)    ||
  			     ($s =~              /^(races*)-(.*)$/i)    ||
  			     ($s =~              /^(racks*)-(.*)$/i)    ||
			     ($s =~              /^(robes*)-(.*)$/i)    ||
				 ($s =~              /^(sheath)-(.*)$/i)    || 
  			     ($s =~              /^(shoes*)-(.*)$/i)    ||
			    #($s =~              /^(signs*)-(.*)$/i)    ||		#decided that for "stop sign", i want "stop" also, so this is moved
  			     ($s =~              /^(soaps*)-(.*)$/i)    ||
  			     ($s =~              /^(tapes*)-(.*)$/i)    ||
				 ($s =~              /^(teeth*)-(.*)$/i)    ||			#buck teeth,rotten teeth - but some things like fangs don't make sense here :/
  			     ($s =~              /^(tents*)-(.*)$/i)    ||
  			     ($s =~              /^(tests*)-(.*)$/i)    ||
  			     ($s =~              /^(tiles*)-(.*)$/i)    ||
  			     ($s =~              /^(traps*)-(.*)$/i)    ||
  			     ($s =~              /^(trays*)-(.*)$/i)    ||
  			     ($s =~              /^(veils*)-(.*)$/i)    ||
  			     ($s =~              /^(walls*)-(.*)$/i)    ||
			     ($s =~              /^(wines*)-(.*)$/i)	||		#thing-drink-wine-white gets thrown back as thing-wine-white
  			     ($s =~              /^(wings*)-(.*)$/i)    ||		#thing-wing-duck should not be tagged 'duck' - seems like sane thinking
  			     ($s =~               /^(amps*)-(.*)$/i)    ||
  			     ($s =~               /^(bags*)-(.*)$/i)    ||
			     ($s =~               /^(boas*)-(.*)$/i)    ||
  			     ($s =~               /^(cans*)-(.*)$/i)    ||
  			     ($s =~               /^(caps*)-(.*)$/i)    ||
  			     ($s =~               /^(dots*)-(.*)$/i)    ||
			     ($s =~               /^(eyes*)-(.*)$/i)    || 
#			     ($s =~               /^(guns*)-(.*)$/i)    ||		#moved away -- "rifle gun" doesn't make sense
			     ($s =~               /^(inks*)-(.*)$/i)    || 
			     ($s =~               /^(jars*)-(.*)$/i)    || 
  			     ($s =~               /^(nose*)-(.*)$/i)    ||
  			     ($s =~               /^(rags*)-(.*)$/i)    ||
				 ($s =~               /^(saws*)-(.*)$/i)    || 
  			     ($s =~               /^(ties*)-(.*)$/i)    ||
 			     ($s =~               /^(toys*)-([^\-]*)$/i)||		#this is a better way
  			     ($s =~               /^(wars*)-(.*)$/i)    ||
  			     ($s =~               /^(webs*)-(.*)$/i)    ||
  			     ($s =~            /^([^\-]*)-(fake)$/i)  			#a rare REVERSED way .. I no longer understand why I put that here :)
			   )	 							  {	
				my $tmp1=$1; my $tmp2=$2;
				if ($DEBUG_THING) { print "[DT-L] Default Thing Processing case #1.../tmp1=$tmp1,tmp2=$tmp2/<BR>\n"; }


				if ($s =~ /(posters*)-movie-$/i) {
					my $tmp5=$1;
					&add_tag("movie"       ,$file,$tmporiginaltag, 0,$mode);
					&add_tag("movie $tmp5" ,$file,$tmporiginaltag,"",$mode);
				}

				$STOP_ALL_CAPTIONING=1;
				&add_tag("thing-$tmp1",$file,$tmporiginaltag, 0,$mode);
				if ($tmp2 =~ /^Guitar Hero$/i) { &add_tag ("Guitar Hero",$file,$tmporiginaltag,0,$mode); }			#exception: controller
				$STOP_ALL_CAPTIONING=0;


				my $tmp3="$tmp2 $tmp1";
				if ($DEBUG_THING) { print "[DT-Y] /tmp3=$tmp3/<BR>\n"; }
				if ($tmp3 =~ /^pinky finger$/) {				#exceptions to also be tagged with thing2
					&add_tag ("thing-$tmp2",$file,$tmporiginaltag,0,$mode);	#"pinky"
				} elsif ($tmp3 =~ /^(LEDs*) lights*$/i) {
					my $tmp1=$1;
					$STOP_ALL_CAPTIONING=1; &add_tag ("thing-$tmp1",$file,$tmporiginaltag,0,$mode);	$STOP_ALL_CAPTIONING=0;		#LED
				}
				$tmp3 =~ s/jets airplanes/jet airplanes/i;
				$tmp3 =~ s/LEDs lights/LED lights/i;
				$tmp3 =~ s/chandelier light/chandelier/;										#exception: chandelier
				$tmp3 =~ s/lava lamp light/lava lamp/;											#exception: lava lamp
				$tmp3 =~ s/spotlight light/spotlight/;											#exception: spotlight
				$tmp3 =~ s/(barstools* )stools*/$1/;											#exception: blacklight
				$tmp3 =~ s/blacklight light/blacklight/;										#exception: blacklight
				$tmp3 =~ s/flashlight light/flashlight/;										#exception: flashlight
				$tmp3 =~ s/sun light/sunlight/;													#exception: sunlight
				$tmp3 =~ s/infinity mirror light/infinity mirror/;								#exception: infinity mirror
				$tmp3 =~ s/bookshelf shelf/bookshelf/;											#exception: bookshelf
				$tmp3 =~ s/Airzooka toy/Airzooka/;												#exception: toy
				$tmp3 =~ s/(stuffed .*) toy/$1/;												#exception: anything stuffed
				$tmp3 =~ s/paint brush/paintbrush/i;											#exception: no space between words
				$tmp3 =~ s/news paper/newspaper/i;												#exception: no space between words
				$tmp3 =~ s/sunglasses glasses$/sunglasses/i;									#exception: no space between words
				$tmp3 =~ s/watch tower$/watchtower/i;											#exception: no space between words
				$tmp3 =~ s/Crocs shoes*$/Crocs/i;												#exception:    Crocs   not    Crocs   shoes
				$tmp3 =~ s/flip[\ \-]*flops shoes*$/flipflops/i;
				$tmp3 =~ s/barstool stool*$/barstool/i;											#exception: flip flops not flip flips shoes
				$tmp3 =~ s/headlight(s*) light(s*)/headlight$1/;								#exception: headlight
				$tmp3 =~ s/afghan blanket(s*)$/afghan$1/i;										
				if ($DEBUG_THING) { print "[DT] about to tag thing-$tmp3<BR>\n"; }
				&add_tag ("thing-$tmp3",$file,$tmporiginaltag,1,$mode); $s=""; 
				$s="";
			}




			#thing1-thing2 tagged as "thing1,thing2" and captioned as "thing2" only
			#DEBUG: print "ALMOST THERE --> S=$s<br>";
			if (
				($s =~     /^(cages*)-(raccoon.*)$/i) ||								#this at least makes sense for thing-cage-raccoon trap, but not for bird cage. will move cage elsewhere and leave this here.
				($s =~             /^(body*)-(.*)$/i) ||
				($s =~             /^(guns*)-(.*)$/i) ||								#don't use games, because games in plural isn't specific games and is usually a different situation like "board games" to denote a pile of board games
				($s =~             /^(toys*)-(.*)$/i) ||
				($s =~            /^(burns*)-(.*)$/i) ||
				($s =~            /^(books*)-(.*)$/i) ||
				($s =~            /^(coins*)-(.*)$/i) ||
				($s =~            /^(drugs*)-(.*)$/i) ||
				($s =~            /^(fires*)-(.*)$/i) ||
				($s =~            /^(games*)-(.*)$/i) ||								#don't use games, because games in plural isn't specific games and is usually a different situation like "board games" to denote a pile of board games
			   (($s =~            /^(tools*)-(.*)$/i) && ($s !~ /^(tools*)-(manicure)$/i)) ||
				($s =~            /^(woods*)-(.*)$/i) ||
				($s =~           /^(drinks*)-(.*)$/i) ||
				($s =~           /^(lights*)-(.*)$/i) ||
				($s =~           /^(sports*)-(.*)$/i) ||
				($s =~           /^(waters*)-(.*)$/i) ||
				($s =~          /^(alcohol*)-(.*)$/i) ||								#if this messes up other situations, might want to change this to (alcohol*)-(keg)
				($s =~          /^(clothes*)-(.*)$/i) ||
				($s =~          /^(flowers*)-(.*)$/i) ||								#thing-flower-Daffodil
				($s =~          /^(jewelry*)-(.*)$/i) ||
#				($s =~          /^(letters*)-(.*)$/i) ||								#not if they are handwritten letters!
				($s =~          /^(weapons*)-(.*)$/i) ||								#thing-weapon-knife
				($s =~         /^(blankets*)-(.*)$/i) ||
				($s =~         /^(hardware*)-([^\-]*)$/i) ||
				($s =~         /^(politics*)-(.*)$/i) ||
				($s =~         /^(software*)-(.*)$/i) ||
				($s =~         /^(vehicles*)-(.*)$/i) ||
				($s =~         /^(weathers*)-(.*)$/i) ||								#thing-weather-storm 
				($s =~       /^(newspapers*)-(.*)$/i) ||
				($s =~   /^(lawn ornaments*)-(.*)$/i) ||
				($s =~ /^(exercise machine*)-(.*)$/i) 
			   )  
			{
				my $tmp1=$1; my $tmp2=$2;

				if ($DEBUG_THING) { print "[DT] Default Thing Processing case #2...<BR>\n"; }
				my $DEBUG_LOCAL=0;														#DEBUG	#
				if ($DEBUG_LOCAL) { print "[AA1A] WE GOT HERE!!!!!!!!!!!!!!!! TMP1=$tmp1 TMP2=$tmp2 s=$s<br>"; }

				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);			#light / toy / software / vehicle
				if ("$tmp2 $tmp1" =~ /^power tools*$/i) {
					&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);		#light / toy / software / vehicle
					$s=""; $tmp2=""; $tmp1="";
				}

				if ($s =~ /water-holy/i) {
					&add_tag("holy water",$file,$tmporiginaltag,1,$mode);	#exceptions to the general rule
				}

				if (($tmp1 =~ /^fire$/i) && (&is_color($tmp2))) {			#thing-fire-green / colored fire exception
					&add_tag($tmp1        ,$file,$tmporiginaltag,0,$mode);
					&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);
					$s=""; $tmp1=""; $tmp2="";
				}

				if ($s =~ /^(books*)-comic/) {								#comic-book exception to 'books' rule
					my $tmp1=$1;
					&add_tag("comic $tmp1" ,$file,$tmporiginaltag,"",$mode);		
				}
				if ($s =~ /^(hardwares*)-/) {								### HARDWARE-SPECIFIC CODE DEPRECATED, NOW DONE IN 4-CHAIN/5-CHAIN CODE AREAS INSTEAD
					if ($DEBUG_THING) { print "[DT] Hardware found! [HF!]...<BR>\n"; }
					&add_tag("$1",$file,$tmporiginaltag,0,$mode);
					if (
						($s =~ /-(cards*)-(PCI)-/i) || ($s =~ /-(cards*)-(PCI)$/i) ||
						($s =~ /-(cards*)-(ISA)-/i) || ($s =~ /-(cards*)-(ISA)$/i) ||
						($s =~ /-(cards*)-(AGP)-/i) || ($s =~ /-(cards*)-(AGP)$/i)
						)  {
						&add_tag("$1"   ,$file,$tmporiginaltag,0,$mode);
						&add_tag("$2"   ,$file,$tmporiginaltag,0,$mode);
						&add_tag("$2 $1",$file,$tmporiginaltag,0,$mode);
						$s =~ s/(cards*)-PCI/$1-/i;
						$s =~ s/(cards*)-ISA/$1-/i;
						$s =~ s/(cards*)-AGP/$1-/i;
					}
					$s =~ s/--/-/g;
					if ($DEBUG_LOCAL) { print "s is now $s!!!!!<BR>\n"; }
					if (($s =~ /-(cards*)-+.*(controller)-([^\-]+)-/i) || ($s =~ /-(cards*)-+.*(controller)-([^\-]+)$/i)) {		#exceptions
						my $tmp1=$1; my $tmp2=$2; my $tmp3=$3;
						if ($DEBUG_THING) { print "[DT] Default Thing Processing case controller#2[DA]...tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3<BR>\n"; }
						&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);
						&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag,0,$mode);
						&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);
						&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);
						&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);
					} elsif (($s =~ /-(controller)-([^\-]+)-/i) || ($s =~ /-(controller)-([^\-]+)$/i)) {	#hardware2 hardware1,hardware1,hardware2
						if ($DEBUG_THING) { print "[DT] Default Thing Processing case controller#3...<BR>\n"; }
						&add_tag("$2 $1",$file,$tmporiginaltag,1,$mode);
						&add_tag("$1"   ,$file,$tmporiginaltag,0,$mode);
						&add_tag("$2"   ,$file,$tmporiginaltag,0,$mode);
					} elsif (($s =~ /-(cards*)-([^\-]+)-/i) || ($s =~ /-(cards*)-([^\-]+)$/i)) {
						&add_tag("$2 $1",$file,$tmporiginaltag,1,$mode);
						&add_tag("$1"   ,$file,$tmporiginaltag,0,$mode);
						$s =~ s/-(cards*)-([^\-]+)/-/i;
					}
					#
					$s =~ s/--/-/g;
					$s =~ s/^hardware-//i;
					$s =~ s/^cards*-PCI-//i;
					$s =~ s/^controller-([^\-]+)-//i;

					#DEBUG:					print "[HW1] s is now $s!<BR>\n";					#ohohoh
					##### Some stuff may be left, and will get tagged elsewhere. But some many not end up being captioned like it should, so we can force that here:
					if ($s =~ /^TV$/i) { &add_tag("thing-$1"   ,$file,$tmporiginaltag,"",$mode); }
					#$FORCE_ALL_CAPTIONING=1;	#ended up not helping for thing-TV due to its "television" synonym code taking over, but this may help in the future
					#$FORCE_ALL_CAPTIONING=0;
				} elsif ($tmp2 =~ /^([^\-]*)-(.*)$/) {						### TWO WORD THINGIES
					if ($DEBUG_LOCAL) { print "[B] WE GOT HERE ALSO!!!!!!!!!!!!!!!! TMP1=$tmp1 TMP2=$tmp2<br>"; }
					$tmp3 = $1;
					$tmp4 = $2;
					&add_tag("$tmp3"      ,$file,$tmporiginaltag,0 ,$mode);
					&add_tag("$tmp3 $tmp1",$file,$tmporiginaltag,"",$mode);
					$s =~ s/$tmp1-$tmp3//i;
					if ($tmp4 !~ /\-/) {
						&add_tag("$tmp4",$file,$tmporiginaltag,0,$mode);
					}
				} else {			#thing-truck-vehicle = FAIL!
					if ($DEBUG_LOCAL) { print "[C] WE GOT HERE ALSO!!!!!!!!!!!!!!!! TMP1=$tmp1 TMP2=$tmp2<br>"; }
					#&add_tag("$tmp2",      $file,$tmporiginaltag,"",$mode);		#OLD

					&add_tag("$tmp1",      $file,$tmporiginaltag, 0,$mode);		
					&add_tag("$tmp2",      $file,$tmporiginaltag,"",$mode);		
					#&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag, 0,$mode);		#This needs more logic. Fails for thing-vehicle-truck!
					$s="";
				}
			}




			#thing1-thing2 tagged as "thing1,thing2,thing1 thing2" and captioned as "thing1 thing2" only
			#EXAMPLES: thing-Photoshop-layers ... "photoshop layers"
			if ($DEBUG_THING) { print "[DT-checkpoint-3,s=$s]\n"; }
			if (
  				($s =~ /^(hurricanes*)-([A-Z].*)$/)  ||				#Hurricanes with a proper, capitalized name, e.g. thing-hurricane-Katrina
				($s =~  /^(Photoshop*)-(.*)$/i)		||
  				($s =~   /^(ethernet*)-(.*)$/i)		||
  			    ($s =~       /^(X10*)-(.*)$/i)  
				)  {
				$tmp1=$1; $tmp2=$2; 
				if ($DEBUG_THING) { print "[DT] Default Thing Processing case #3...<BR>\n"; }
				&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$tmp2"      ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag,1,$mode);
				$s="";
			}




			#thing1-thing2 tagged "thing1,thing2,thing2 thing1" and captioned as "thing2" only
			#EXAMPLES: christmas tree+christmas+tree,  Misfits shirt+shirt+Misfits
			#EXAMPLES: thing-ball-bowling
			if (($s =~           /^(wars*)-(.*)$/i)  ||
			    ($s =~          /^(rides*)-(.*)$/i)  ||
				($s =~          /^(birds*)-(.*)$/i)  ||
				($s =~         /^(plants*)-(.*)$/i)) {
				$tmp1=$1;	$tmp2=$2;												#DEBUG:print "We got here! $tmp1 $tmp2<BR>\n";
				if ($DEBUG_THING) { print "[DT] Default Thing Processing case #4...<BR>\n"; }
				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);
				&add_tag("$tmp2"      ,$file,$tmporiginaltag,"",$mode);
				if ("$tmp2 $tmp1" !~ /^weed plant$/) {								#some plants are just generic terms like weed and we don't tag things like "weed plant"
					&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag, 0,$mode);
				}
				$s="";
			}


			#thing1-thing2 tagged "thing2 thing1" and captioned as "thing2 thing1"
			if (($s =~ /^(pads*)-(.*)$/i) ||
			    ($s =~ /^(face)-(creepy)$/i)) {										#oddly enough, have found this logic to be aligned with my goals for creepy face, but not for creepy hands
				if ($DEBUG_THING) { print "[DT] Default Thing Processing case #554...<BR>\n"; }
				$tmp1=$1;	$tmp2=$2;
				$tmp = "$tmp2 $tmp1";
				$tmp =~ s/^mouse pad$/mousepad/i;
				&add_tag($tmp,$file,$tmporiginaltag,0,$mode);
				$s="";
			}




			#thing1-thing2 tagged "thing2,thing2 thing1" and captioned as "thing2 thing1"
			if (($s =~ /^(videos*)-(.*)$/i) ||										#added in 201006 due to thing-video-abstract which is a PICTURE of an abstract video, so it should NOT be tagged 'video' even though it gets tagged 'abstract video' and also 'abstract'
			    ($s =~ /^(.*)-(ASDFASD)$/i)) { 
				my $tmp1=$1;	my $tmp2=$2;
				if ($DEBUG_THING) { print "[DT] Default Thing Processing case #555...<BR>\n"; }
				&add_tag("$tmp2"      ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);
				$s="";
			}





			#thing1-thing2 tagged as "thing1,thing1 thing2" captioned as "thing1 thing2"
			if ($s =~          /^(Ardex*)-(.*)$/i)  
			{
				$tmp1=$1;	$tmp2=$2;												#DEBUG:print "[112/12] We got here! $tmp1 $tmp2<BR>\n";
				if ($DEBUG_THING) { print "[DT] Default Thing Processing case #5...<BR>\n"; }
				&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag,1,$mode);
				$s="";
			}





			######################### THIS ONE SEEMS TO BE GRADUALLY EMERGING AS THE 'WINNER':

			#thing1-thing2 tagged "thing1,thing2,thing2 thing1" and captioned as "thing2 thing1" only
			#EXAMPLES: christmas tree+christmas+tree,  Misfits shirt+shirt+Misfits
			#EXAMPLES: thing-ball-bowling
			if (($s =~ /^([^\-]+)-([^\-]+)$/)        ||													#20080601 SUPER DUPER EXPERIMENTAL CODE CHAGNE - make all /^thing1-thing2$/ go here! this is our catch-all of catch-alls!
				($s =~ /^(license plates*)-(.*)$/i)  ||
				($s =~   /^(gas stations*)-(.*)$/i)  ||
				($s =~   /^(paper plates*)-(.*)$/i)  ||
				($s =~   /^(paperweights*)-(.*)$/i)  ||
				($s =~    /^(expressions*)-(.*)$/i)  ||
			    ($s =~    /^(impressions*)-(.*)$/i)  ||
				($s =~    /^(insulations*)-(.*)$/i)  ||
				($s =~    /^(simulations*)-(.*)$/i)  ||
				($s =~     /^(detergents*)-(.*)$/i)  ||
				($s =~     /^(dispensers*)-(.*)$/i)  || 
				($s =~     /^(dropcloths*)-(.*)$/i)  || 
				($s =~     /^(ice creams*)-(.*)$/i)  ||
				($s =~     /^(lubricants*)-(.*)$/i)  || 
				($s =~      /^(figurines*)-(.*)$/i)  ||
				($s =~      /^(figures*)-(.*)$/i)    ||
				($s =~      /^(fountains*)-(.*)$/i)  || 
			    ($s =~      /^(bins*)-([A-Z].*)$/)   ||		#turns out this is right, but only for capitalized bins, like "Peapod bins" - separate rule for lower case bins
				($s =~       /^(earrings*)-(.*)$/i)  ||
				($s =~       /^(machines*)-(.*)$/i)  || 
				($s =~       /^(messages*)-(.*)$/i)  ||
				($s =~       /^(politics*)-(.*)$/i)  || 
				($s =~       /^(stickers*)-(.*)$/i)  || 
				($s =~       /^(websites*)-(.*)$/i)  || 
				($s =~       /^(writings*)-(.*)$/i)  || 
				($s =~        /^(bottles*)-(.*)$/i)  || 
				($s =~        /^(corpses*)-(.*)$/i)  ||
				($s =~        /^(damages*)-(.*)$/i)  || 
				($s =~        /^(enamels*)-(.*)$/i)  || 
				($s =~        /^(guitars*)-(.*)$/i)  || 
#				($s =~        /^([Gg][Uu][Ii][Tt][Aa][Rr][Ss]*)-([a-z0-9]*)$/)  || 
				($s =~        /^(jackets*)-(.*)$/i)  || 
				($s =~        /^(letters*)-(.*)$/i)  || 
				($s =~        /^(napkins*)-(.*)$/i)  || 
				($s =~        /^(shakers*)-(.*)$/i)  || 
				($s =~        /^(statues*)-(.*)$/i)  || 
				($s =~         /^(cables*)-(.*)$/i)  ||
			    ($s =~         /^(chairs*)-(.*)$/i)  ||
#				($s =~         /^(charts*)-(.*)$/i)  ||			#This does not make sense for pie chart. I wonder what it DID make sense for?
#				($s =~         /^(covers*)-(.*)$/i)  ||			#This does not make sense for licence plate covers - it tags them license plate even tho one may not be in that picture
				($s =~         /^(gloves*)-(.*)$/i)  ||
				($s =~         /^(injury*)-(.*)$/i)  ||
			    ($s =~         /^(quotes*)-(.*)$/i)  ||			#moved from case #1 - did not belong there
				($s =~         /^(shirts*)-(.*)$/i)  || 
				($s =~         /^(skulls*)-(.*)$/i)  || 
				($s =~         /^(stones*)-(.*)$/i)  || 
				($s =~         /^(styles*)-(.*)$/i)  || 
				($s =~          /^(balls*)-(.*)$/i)  ||
				($s =~          /^(beers*)-(.*)$/i)  || 
				($s =~          /^(bones*)-(.*)$/i)  ||
				($s =~          /^(cases*)-(.*)$/i)  ||
				($s =~          /^(dolls*)-(.*)$/i)  || 
				($s =~          /^(doors*)-(.*)$/i)  || 
				($s =~          /^(dusts*)-(.*)$/i)  || 
				($s =~          /^(faces*)-(.*)$/i)  || 
				($s =~          /^(glass*)-(.*)$/i)  ||
				($s =~          /^(hairs*)-(.*)$/i)  || 
				($s =~          /^(hands*)-(.*)$/i)  || 
				($s =~          /^(heads*)-(.*)$/i)  ||			#was in 2 sections but definitely belongs here
				($s =~          /^(piles*)-(.*)$/i)  ||
				($s =~          /^(polls*)-(.*)$/i)  || 
				($s =~          /^(roads*)-(.*)$/i)  || 
				($s =~          /^(seeds*)-(.*)$/i)  || 
				($s =~          /^(signs*)-(.*)$/i)  ||			#moved from above section due to changing my mind
				($s =~          /^(suits*)-(.*)$/i)  ||
				($s =~          /^(trees*)-(.*)$/i)  ||
				($s =~          / ^(cans*)-(.*)$/i)  ||
				($s =~          / ^(mans*)-(.*)$/i)  ||
  			    ($s =~           /^(rums*)-(.*)$/i)  ||
  			    ($s =~            /^(sex*)-(.*)$/i)  ||
				($s =~            /^(CDs*)-(.*)$/i)) { 
				my $tmp1caption=0;								#as stated above, we don't caption thing1 -- but there IS an exception or two, so we must track that
				my $tmp2caption=0;								#as stated above, we don't caption thing2 -- but there IS an exception or two, so we must track that

				my $tmp1=$1;				#figurine
				my $tmp2=$2;				#Jesus Christ
				my $tmp ="$tmp2 $tmp1";		#Jesus Christ figurine
				if ($DEBUG_THING) { print "[DT] Default Thing Processing case #6.../tmp1=$tmp1/tmp2=$tmp2/tmp=$tmp/s=$s/<BR>\n"; }
			
				if ($tmp1 =~ /^quotes*$/) { $tmp5=$tmp2; $tmp2=&fix_name_of_any_form($tmp2); }				#If it's a quote, then tmp2 is a person, and needs a name cleanup, and store uncleaned name as tmp5
				if ($tmp =~ /^organization chart$/) { &add_tag("org chart",$file,$tmporiginaltag,"",$mode); $tmp1caption=0; $tmp2caption=0; }	## thing synonyms: this synonym goes to captions
				if ($tmp =~ /AllSteel .* chair/   ) { &add_tag("AllSteel", $file,$tmporiginaltag, 0,$mode); }									## thing synonyms: this synonym doesn't go to captions
				$tmp =~ s/(mohawks*) hair/$1/i;																									## exception: only caption thing1
				$tmp =~ s/(braids*) hair/$1/i;																									## exception: only caption thing1
				$tmp =~ s/(pig[\-\ ]*tails*) hair/$1/i;																							## exception: only caption thing1
				$tmp =~ s/briefcase case/briefcase/i;																							## exception: only caption thing1
				$tmp =~ s/recliner chair/recliner/i;																							## exception: only caption thing1
				$tmp =~ s/jets airplanes/jet airplanes/i;
				$tmp =~ s/ball ball/ball/i;																				#to stop things like "foosball ball" or "basketball ball"
				if ($tmp =~ /^primer paint$/i) { $tmp=""; $tmp2caption=1; }												#exception: don't tag tmp/"thing1 thing2", caption thing2 

				&add_tag($tmp ,$file,$tmporiginaltag,""          ,$mode);
				&add_tag($tmp1,$file,$tmporiginaltag,$tmp1caption,$mode);
				my $tagtmp2=1;
				if (($tmp1 =~ /^jacket$/i) &&  ($tmp2 =~ /^smoking$/i)) { $tagtmp2=0; }											#don't tag 'smoking' for 'smoking jacket'/thing-jacket-smoking
				if (($tmp1 =~ /^chair$/i)  &&  ($tmp2 =~ /^iron$/i))    { $tagtmp2=0; }											#don't tag 'iron' for 'iron chair'/thing-chair-iron
				if (($tmp1 =~ /^chair$/i)  &&  ($tmp2 =~ /^high$/i))    { $tagtmp2=0; }											#^ like that but for high chairs
				if (($tmp1 =~ /^face$/i)   &&  (&is_color($tmp2)))      { $tagtmp2=0; }											#don't tag 'iron' for 'iron chair'/thing-chair-iron
				if (($tmp1 =~ /^tree$/i)   && (($tmp2 =~ /^apple$/i) || ($tmp2 =~ /^walnut$/i))) { $tagtmp2=0; }				#don't tag certain tree types because "apple" should be for pictures of apples, not apple trees. But "Sycamore" doesn't mean anything and should be tagged. Individual enumerations are the only way to deal with this.
				if ($tagtmp2) { &add_tag("$tmp2",$file,$tmporiginaltag,$tmp2caption,$mode); 	}
				$s="";

				##### If it's a quote, the person who made the quote should be tagged as a person as well:
				if ($tmp1 =~ /^quotes*$/) { 
					$STOP_ALL_CAPTIONING=1;
					&add_tag("person-$tmp5",$file,$tmporiginaltag,0,$mode); 
					$STOP_ALL_CAPTIONING=0;
				}

			}




			if ($s =~ /^([^\-]*)\-([^\-]*)\-([^\-]*)\-([^\-]*)\-([^\-]*)\-([^\-]*)-([^\-]*)$/) {		#7chain catchall
				my $tmp1=$1;		my $tmp2=$2;		my $tmp3=$3;		my $tmp4=$4;		my $tmp5=$5;		my $tmp6=$6;		my $tmp7=$7;				
				if ($DEBUG_THING) { print "<BR><I>[7chain catch-all]</i> 1=$tmp1,2=$tmp2,3=$tmp3,4=$tmp4,5=$tmp5,6=$tmp6,7=$tmp7 <BR>\n";	}
				#1=hardware,2=card,3=PCI Express,4=video card,5=ATI,6=Radeon,7=HD6870 
				if (($tmp1 =~ /^hardware$/i) && ($tmp2 =~ /^card$/i) && ($tmp3 =~ /^PCI Express$/i)) {
					&add_tag("$tmp1"                         ,$file,$tmporiginaltag,0,$mode);		#hardware
					&add_tag("$tmp2"                         ,$file,$tmporiginaltag,0,$mode);		#card
					&add_tag("$tmp3"                         ,$file,$tmporiginaltag,0,$mode);		#PCI Express
					&add_tag("$tmp3 $tmp2"                   ,$file,$tmporiginaltag,0,$mode);		#PCI Express card
					&add_tag("$tmp3 $tmp4"                   ,$file,$tmporiginaltag,0,$mode);		#PCI Express video card
					&add_tag("$tmp4"                         ,$file,$tmporiginaltag,0,$mode);		#video card
					&add_tag("$tmp5"                         ,$file,$tmporiginaltag,0,$mode);		#ATI
					&add_tag("$tmp5 $tmp2"                   ,$file,$tmporiginaltag,0,$mode);		#ATI card
					&add_tag("$tmp5 $tmp4"                   ,$file,$tmporiginaltag,0,$mode);		#ATI video card
					&add_tag("$tmp5 $tmp6"                   ,$file,$tmporiginaltag,0,$mode);		#ATI Radeon
					&add_tag("$tmp5 $tmp6 $tmp7"             ,$file,$tmporiginaltag,0,$mode);		#ATI Radeon HD6870
					&add_tag("$tmp5 $tmp6 $tmp2"             ,$file,$tmporiginaltag,0,$mode);		#ATI Radeon HD6870 card
					&add_tag("$tmp5 $tmp6 $tmp4"             ,$file,$tmporiginaltag,0,$mode);		#ATI Radeon HD6870 video card
					&add_tag("$tmp5 $tmp6 $tmp7 $tmp3 $tmp4" ,$file,$tmporiginaltag,1,$mode);		#ATI Radeon HD6870 PCI Express video card
					&add_tag("$tmp6"                         ,$file,$tmporiginaltag,0,$mode);		#Radeon
					&add_tag("$tmp6 $tmp2"                   ,$file,$tmporiginaltag,0,$mode);		#Radeon card
					&add_tag("$tmp6 $tmp4"                   ,$file,$tmporiginaltag,0,$mode);		#Radeon video card
					&add_tag("$tmp6 $tmp7"                   ,$file,$tmporiginaltag,0,$mode);		#Radeon HD6870
					&add_tag("$tmp6 $tmp7 $tmp2"             ,$file,$tmporiginaltag,0,$mode);		#Radeon HD6870 card
					&add_tag("$tmp6 $tmp7 $tmp4"             ,$file,$tmporiginaltag,0,$mode);		#Radeon HD6870 video card
					&add_tag("$tmp7"                         ,$file,$tmporiginaltag,0,$mode);		#HD6870
					$s="";
				}

			}




			if ($DEBUG_THING && ($s ne "")) { print "<BR><font size=9><B>[DT] Processing what's left at the end...s is \"$s\"...</B></font><BR>\n"; }


			#### If there's anythig left, this will process it:
			@tmparray = (split(/-/,$s));
			$FIVE_CHAIN_FAILED=0;											#5chains get processed in their own code area; but if that fails, this gets set to 1 which causes things to go here. we have to reset this after processing, so that's what this line does.
			foreach $tmp (@tmparray) {
				#LAST-MINUTE TAG RE-HYPHENIZATION...				
				$tmp =~ &rehyphenate($tmp);
				
				$tmpcaptionmode = "";
				#my @CURRENTLY_UNUSED_LIST("hotel","plants","cup","bug","costume");
				#foreach $thing1 () { if thing OR if thing- set captin=0}
				#thing1-thing2 and we don't want to caption thing1 -- thought this was handled elsewhere, however
				if (($tmp =~ /^hotel$/)   && ($s =~ /^hotel-/))    { $tmpcaptionmode=0; } 
				if (($tmp =~ /^plant$/)   && ($s =~ /^plant-/))    { $tmpcaptionmode=0; } 
				if (($tmp =~ /^cup$/)     && ($s =~ /^cup-/))      { $tmpcaptionmode=0; } 
				if (($tmp =~ /^bug$/)     && ($s =~ /^bug-/))      { $tmpcaptionmode=0; } 
				if (($tmp =~ /^costume$/) && ($s =~ /^costume-/))  { $tmpcaptionmode=0; } 
				#try to add future fixes elsewhere
				&add_tag($tmp,$file,$tmporiginaltag,$tmpcaptionmode,$mode);
			}
			$s="";	#stop processing this line because we totally dissected it and used all the parts :)


		} else {													#we're still in thing-only !      by the way, ALL THIS PLURAL CODE IS DEPRECATED!
			if ($DEBUG_THING > 0) { print "<B>Plural</B> checking for \"$s\"...\n";	}
			# THINGS - PLURAL TAG CATCHALLS
			#If s is still plural we may want to add the plural tag before singularizing it:
			#DEBUG: print "What is s? It's $s!<BR>";
			if ($s =~ /^.*[^\s]s$/) {				$plural_was_tagged=0;	
			if ($DEBUG_THING > 0) { print "... it ends in \"s\"!\n";	}
				#### PLURAL  TAG ONLY 
				#### if it's in the "singular words that end in s" list (Clio::String), don't worry about adding it here:
				if    ($s =~     /brothers$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode); $s=""; $plural_was_tagged=1; }
				elsif ($s =~      /.*pants$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode); $s=""; $plural_was_tagged=1; }				
				elsif ($s =~      /.*claws$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode); $s=""; $plural_was_tagged=1; }				
				elsif ($s =~      /.*wings$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode); $s=""; $plural_was_tagged=1; }				
				elsif ($s =~     /.*lenses$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode); $s=""; $plural_was_tagged=1; }				
				elsif ($s =~ /^code of ethics$/i)     { &add_tag("$s",$file,$tmporiginaltag,"",$mode); $s=""; $plural_was_tagged=1; }				
				else {
					##### KEEP PLURAL TAG, ALSO HAVE SINGULAR:			FOR THINGS ONLY......
					#if ($s =~ /^bridesmaids$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~   /^fireworks$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
					#if ($s =~   /^sparklers$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~   /^stockings$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
#DEPRECATED			#if ($s =~   /^strippers$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~    /^cushions$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
					#if ($s =~    /^pictures$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~     /^candles$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
#SECTION			#if ($s =~     /^mirrors$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					#had to put a ^ in front of this one so "house of mirrors" would not become "house of mirror"
					#if ($s =~     /^skewers$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~     /freckles$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
#OF					#if ($s =~     /presents$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~      /bubbles$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
					#if ($s =~      /flowers$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~      /letters$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
#CODE				#if ($s =~      /virgins$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~      /^bricks$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
					#if ($s =~      /^ushers$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~       /boards$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
#KEPT				#if ($s =~       /cracks$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~       /ravers$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
					#if ($s =~       /screws$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~        /^vows$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
#HERE				#if ($s =~        /beads$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~        /hands$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
					#if ($s =~        /names$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~        /tacks$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
#AS					#if ($s =~        /trees$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~        /tools$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
					#if ($s =~         /legs$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~         /lips$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
#REMINDER			#if ($s =~         /arms$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }					if ($s =~         /eyes$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }
					#if ($s =~         /ears$/i)        { &add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1; }				
					if ($DEBUG_THING > 0) { print "... Adding tag for \"$s\"...\n";	}

					#20080527 PLURAL CATCH-ALL:
					&add_tag("$s",$file,$tmporiginaltag,"",$mode);        $plural_was_tagged=1;
				}
			} else {
				if ($DEBUG_THING > 0) { print "...doesn't end in s\n";	}
				$plural_was_tagged=0;
			}
			&add_tag("$s",           $file,$tmporiginaltag,"",$mode);		#20080801 - thing-teeth only tags tooth. probably due to all this now-deprecated code
			$s = &singular($s,1); 
			if ($DEBUG_THING > 0) { print "...<B>Singular</B> is now \"$s\"...\n";	}
		}
		#some singular things we want pluralized also:
		if ($s eq "rune")            { &add_tag("runes",           $file,$tmporiginaltag,"",$mode); }
		if ($s eq "power line")      { &add_tag("power lines",     $file,$tmporiginaltag,"",$mode); }

		if ($plural_was_tagged) { $caption_it=0; } else { $caption_it=""; } 
		#DEBUG:print "\$plural_was_tagged=$plural_was_tagged,\$caption_it=$caption_it,\$s=$s<BR>\n";
		#And finally, let's do what we're supposed to do:
		if ($s ne "") {	
			#DEBUG:print "&add_tag(\$s=$s,\$file,\$tmporigtag=$tmporiginaltag,$caption_it,$mode)<BR>\n";
			&add_tag($s,$file,$tmporiginaltag,$caption_it,$mode); 
		}
	}#endif thing






	######################################### PLACE BEGIN ##################################################
	if ($s =~  /^-place/i) { $s =~ s/^-//; }
	if ($s =~  /^place-/i) {
		$s =~ s/^place-//i;
		$TYPE = "place";		$SUBTYPE = "";																												if ($DEBUG_PLACE) { print "\$s[111] is $s <BR>\n"; }

		##### place synonyms / place-synonyms
		if ($s =~ /Brushwood Folklore Center/)               { &add_tag("Brushwood",$file,$tmporiginaltag,0,$mode); }
		if ($s =~ /United States Postal Inspection Service/) { &add_tag("USPIS",$file,$tmporiginaltag,0,$mode); }
		if ($s =~ /United States Postal Service/)            { &add_tag("USPS" ,$file,$tmporiginaltag,0,$mode); }
		if ($s =~ /Washington D\.*C\.*/) { 
			&add_tag("Washington",$file,$tmporiginaltag,0,$mode); 
			&add_tag("D.C."      ,$file,$tmporiginaltag,0,$mode); 
			&add_tag("DC"        ,$file,$tmporiginaltag,0,$mode); 
		}

		##### One-Off kludges (DEPRECATED, but left in until they break something):
		$s =~ s/club-Crucible/club-The Crucible/i;																					#some clubs sound better with 'the' in the beginning even though we don't tag the 'the'
		$s =~ s/house-Prophet Phyllis/Grandma's house/i;							#1												#DEBUG:				print "s[MM2] is $s\n";
		$s =~ s/house-Sawyer Gerard and Margaretha/Carolyn's Grandparents' house/i;
		$s =~ s/house-Lipinski Vic and Becky/Mom and Dad's house/i;					#2
		$s =~ s/house-Lipinski Clint and Carolyn/Clint and Carolyn's house/i;		#3
		$s =~ s/house-Lipinski Clio and Carolyn/Clio and Carolyn's house/i;			#4
		$s =~ s/house-Sawyer Clio and Carolyn/Clio and Carolyn's house/i;			#5
		$s =~ s/house-Sawyer Clio and Lipinski Carolyn/Clio and Carolyn's house/i;	#6
		$s =~ s/house-Sawyer Claire and Carolyn/Claire and Carolyn's house/i;			#5
		$s =~ s/house-Sawyer Claire and Lipinski Carolyn/Claire and Carolyn's house/i;	#6
		$s =~ s/apartment-Howard Wayne and Moustafa Shehab/Wayne Howard and Shehab Moustafa's apartment/;								if ($DEBUG_PLACE) { print "\$s[311] is $s <BR>\n"; }																		#BAD BAD BAD for Eve and Eric Mens's house, anyway: $s =~ s/house-([^\s]+) ([^\s]+)/$2 $1's house/i;						#5
		$s =~ s/Bob & Stuart Schafrik's house Becky/Becky and Bob's house/i;														#only worked because of one of the 5 lines of code behind this...			#DEBUG:				print "s[4D] is $s\n";
		if (($s =~ /Eric Axilbund's house/i) && ($s =~ /Cambridge/i)) {	&add_tag("Eric Axilbund's Cambridge house",$file,$tmporiginaltag,"",$mode);	}					#DEBUG:		print "s[5F] is $s\n";		#DEBUG: if ($s =~ /house/i) { print "\$s is $s\n"; }
		if ($DEBUG_PLACE) { print "\$s[5732] is $s , tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3<BR>\n"; }
		#DEBUG:print "[b]s is $s<BR>\n";

		#places where the type of place is often in the name of the place, but not always... churches, country clubs...
		if (($s =~ /(church)-([a-z ]+)$/i) || ($s =~ /(country club)-([a-z ]+)$/i)) {
			$tmp1=$1; $tmp2=$2;
			#DEBUG:print "/tmp1=$tmp1/tmp2=$tmp2/ <BR>\n";
			&add_tag("$tmp1",$file,$tmporiginaltag,"",$mode);
			$s =~ s/$tmp1-$tmp2/$tmp2 $tmp1/i;
			$s =~ s/$tmp1 $tmp1/$tmp1/i;						#don't let the place name repeat if the type of place is already in it, i.e. "Bob's Church church" or "Richmond Country Club country club"
		}

		if ($DEBUG_PLACE) { print "\$s[c3]s is $s<BR>\n"; }


		#"place1-place2" but caption "place2"
		if (($s =~ /(zoo)-.+$/i)  || (($s =~ /(club)-.+$/i)&&($s !~ /(country club)-.+$/i))) {	#place-club, place-zoo (?!)
			$s =~ s/Washington DC-club-Edge/Washington DC-club-The Edge/i;
			$s =~ s/930 Club/9:30 Club/i;
			$tmp1 = $1;
			&add_tag("$tmp1",$file,$tmporiginaltag,0,$mode); 
			$s =~ s/$tmp1-*//i;
		}

		if ($DEBUG_PLACE) { print "\$s[d3]s is $s<BR>\n"; }

		if (($s =~ /-(apartment)-/i) || ($s =~ /-(house)-/i) || ($s =~ /-(trailer)-/i)) {		#apartment catch-all		#house catch-all	#trailer catch-all
			if ($DEBUG_PLACE) { print "\$s[6831] is <B>$s</B><BR>\n"; }
			#DEPRECATED# $s =~ s/Lipinski Carolyn/Carolyn/i;
			my $tmp1=$1;														#housetype							
			if ($DEBUG_PLACE) { print "[HOUSETYPE] housetype seems to be $tmp1 <BR>\n"; }
			if ($s =~ /([^\-]+)-([^\-]+)-($tmp1)-([^\-]+)-([^\-]+)$/) {			#place catch-all FOR housetype-person-address	-	EX: Virginia-Blacksburg-apartment-Lipinski Carolyn-400 Ellet Rd
				my $tmp3=$5;													#address
				my $tmp4=$1;
				my $tmp5=$2;
				my $tmp2=&fix_name_of_any_form($4);							#person						
				if ($DEBUG_PLACE) { print "[PLACE-A88]tmp1=$tmp1/2=$tmp2/3=$tmp3/4=$tmp4/5=$tmp5/<BR>\n"; }
				if (($tmp3 !~ /[0-9]/i) && ($s !~ /Sawyer Claire and Lipinski Carolyn/i)) { print "<B>POSSIBLE ERROR: Did you tag something :place-state-town-Lastname-Firstname ? There should not be a dash between Lastname and Firstname!<BR>This is the tag: \$s=$s -- If there's a Lastname-Firstname, this is a mistake and is triggering the wrong code.<BR>If there is a Lastname-Firstname, then fix it and try again. [tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4,tmp5=$tmp5]<BR></B>\n"; }
				if ($DEBUG_PLACE) { print "[PLACE-A89]tmp1=$tmp1/2=$tmp2/3=$tmp3/4=$tmp4/5=$tmp5/<BR>\n"; }
				&add_tag("$tmp4"		   ,$file,$tmporiginaltag,1,$mode);	#state - experimental 
				&add_tag("$tmp5"		   ,$file,$tmporiginaltag,1,$mode);	#city - experimental
				&add_tag("$tmp1"           ,$file,$tmporiginaltag,0,$mode);	#apartment
				&add_tag("$tmp1 $tmp2"     ,$file,$tmporiginaltag,0,$mode);	#apartment Carolyn
				if ($DEBUG_PLACE) { print "[PLACE-D88]tmp1=$tmp1/2=$tmp2/3=$tmp3/4=$tmp4/5=$tmp5/<BR>\n"; }
				&add_tag("$tmp2"."'s $tmp1",$file,$tmporiginaltag,1,$mode);	#Carolyn's apartment
				&add_tag("$tmp3"           ,$file,$tmporiginaltag,1,$mode);	#400 Ellet Rd.
				$s="";
			} else {		#LEGACY CODE:
				if ($DEBUG_PLACE) { print "[757575XXX-BEFORE][s=$s]<BR>\n"; }
				$s =~ /$tmp1-(.*)/;
				my $tmp2 = $1;
				$tmp2 = &fix_name_of_any_form($tmp2);
				$s =~ s/($tmp1)-(.*)/$1-$tmp2/i;

				#$s =~ s/$tmp1-([^\s]+) and ([^\s]+)$/$1 and $2's $tmp1/i;														if ($DEBUG_PLACE) { print "\$s[6832] is $s , tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3<BR>\n"; }
				#$s =~ s/$tmp1-([^\s]+) and ([^\s]+) ([^\s]+)$/$1 and $2 $3's $tmp1/i;											if ($DEBUG_PLACE) { print "\$s[6833] is $s , tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3<BR>\n"; }
				#$s =~ s/$tmp1-([^\s]+) ([^\s]+) and ([^\s]+)$/$2 and $3 $1's $tmp1/i;											if ($DEBUG_PLACE) { print "\$s[6834] is $s , tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3<BR>\n"; }
				#$s =~ s/$tmp1-([^\s]+) ([^\s]+) and ([^\s]+) ([^\s^\-]+)(-*.*)$/$2 $1 and $4 $3's $tmp1$5/i;					if ($DEBUG_PLACE) { print "\$s[6835] is $s , tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3<BR>\n"; }
				##THIS MESSED UP CAROLYN'S ELLET RD APARTMENT - $s =~ s/$tmp1-([^\s]+) ([^\s]+)/$2 $1's $tmp1/i;					if ($DEBUG_PLACE) { print "\$s[6836] is $s , tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3<BR>\n"; (22kHz snd) }

				if ($DEBUG_PLACE) { print "[757575XXX-AFTER][s=$s]<BR>\n"; }
			}
		}
		if ($s =~ /^Mexico-/i) { &add_tag("Mexico",$file,$tmporiginaltag,"",$mode); $s =~ s/^Mexico-//i; }	#moved from below
		$tmp3 = $s;
		$tmp3 =~ s/-.*$//;	#make it only the state
		($tmp1,$tmp2)=&is_state($tmp3);																							if ($DEBUG_PLACE) { print "\$s[4722] is $s , tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3<BR>\n"; }
		if (1)	{																												if ($DEBUG_PLACE > 0) { print "\$s[D1] is now $s <BR><BR>\n\n"; }
				if ($DEBUG_PLACE) { print "[9999JJJJ]<BR>\n"; }
			$s =~ s/Virginia Tech-Mall/Virginia Tech-Virginia Tech Mall/;						#will probably never happen again :)
			if    ($s =~ /^yard-([^\-]*)/i) { $tmp1 = $1; &add_tag("yard",$file,$tmporiginaltag,0,$mode); &add_tag("$1 yard",$file,$tmporiginaltag,"",$mode); $s=""; } 
			elsif ($s =~  /yard-([^\-]*)/i) { $s =~ s/yard-([^\-]*)/$1 yard/i;	if ($DEBUG_PLACE > 0) { print "<B>[YARDFIX]</B><BR>\n"; } }

			if ($s =~ /(school)-([^\-]*)-([^\-]*)$/i) {
				my $tmp1=$1; my $tmp2=$2; my $tmp3=$3;
				if ($DEBUG_PLACE > 0) { print "\$s[Q11] is now $s , tmp1=$tmp1, tmp2=$tmp2, tmp3=$tmp3<BR><BR>\n\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);	#school
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);	#middle school
				if (($tmp3 !~ /^Woodbridge$/) || ($tmp3 !~ /^Occoquan$/)) {		#let's not tag a school's name if it's simply the town's name
					&add_tag("$tmp3"        ,$file,$tmporiginaltag, 0,$mode);	#Rippon		
				}
				if ($DEBUG_PLACE > 0) { print "\$s[Q12] is now $s , tmp1=$tmp1, tmp2=$tmp2, tmp3=$tmp3<BR><BR>\n\n"; }
				&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);	#Rippon middle, Marumsco Hills Elementary

				$tmp1=ucfirst($tmp1); $tmp2=ucfirst($tmp2);
				if ($DEBUG_PLACE > 0) { print "\$s[Q13] tmp1 is now $tmp1, tmp2 is now $tmp2<BR><BR>\n\n"; }
				$s =~ s/(school)-([^\-]*)-([^\-]*)$/$3 $tmp2 $tmp1/i;
				if ($DEBUG_PLACE > 0) { print "\$s[Q14] is now $s , tmp1=$tmp1,tmp2=$tmp2,\$3=$3<BR><BR>\n\n"; }
				#&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);
				#$s="";
			}

			$s =~ s/-market-([^\-]*)$/-market-$1 market/i;					#so that -market-fish becomes -market-fish market- because we don't want to end up tagging 'fish' on every 'fish market' picture


			if ($DEBUG_PLACE > 0) { print "\$s[D2] is now $s <BR><BR>\n\n"; }
			@tokens = split(/-/,$s);
			my $DWELLING="";
			my $index=0;
			foreach $tmpplace (@tokens) {														if ($DEBUG_PLACE) { print "<BR>\$s[2934] SPLITTING tmpplace=$tmpplace<BR>\n"; }
				#WAS GOOD BEFORE!: 	#BUT THEN NOT LATER: 		#ON SECOND THOUGHT... KEEP IT:
				$caption_it=1; 
				if ($tmpplace eq "house")			{ $DWELLING="house"    ; $caption_it=0; }	
				if ($tmpplace eq "apartment")		{ $DWELLING="apartment"; $caption_it=0; }					if ($DEBUG_PLACE) { print "* if (".$tokens[$index-1]." eq ".$DWELLING.") { \$tmpplace ($tmpplace) .= \"'s $DWELLING\"; }<BR>\n"; }
				if ($tokens[$index-1] eq $DWELLING) { $tmpplace .= "'s $DWELLING"; }							if ($DEBUG_PLACE) { print "* [PL1] Adding tag $tmpplace <BR>\n....... meanwhile \$s=$s<BR>\n"; }
				if ($tmpplace =~ / yard$/i) { &add_tag("yard",$file,$tmporiginaltag,0,$mode); }
				&add_tag($tmpplace,$file,$tmporiginaltag,$caption_it,$mode);
				$index++;
			}
			if ($DEBUG_PLACE) { print "\$s[999] Returning...! /s=$s/<BR>\n"; }
			return;		#Things get very ugly if we don't stop.
		}

		##### a place c*tch-all put here would never happen!
		if ($DEBUG_PLACE) { print "\$s[PCA-1] s=$s , tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3<BR>\n"; }
	}#endif place-
	######################################### PLACE END ##################################################










	if ($s =~  /^activity-/i) {
		if ($DEBUG_ACTIVITIES>0) { print "<B>***** Yes, $s is an activity. ***** </B><BR> ***** file=$file ***** <BR>\n"; }
		$s =~  s/^activity-//i;
		$TYPE = "activity";
		$SUBTYPE = "";
		#don't put new stuff here
		if ($s =~ /^wedding-bouquet toss/i) {														#activity synonyms
			&add_tag("toss",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^wedding-bouquet toss/bouquet toss/;
		} elsif ($s =~ /^meowing$/i) {			#activity
			&add_tag("meow",$file,$tmporiginaltag,0,$mode);
		} elsif ($s =~ /^smiling$/i) {			#activity
			&add_tag("smiling"    ,$file,$tmporiginaltag,"",$mode);
			$STOP_ALL_CAPTIONING=1;
			&add_tag("thing-smile",$file,$tmporiginaltag,0,$mode);
			$STOP_ALL_CAPTIONING=0;
			$s="";
		} elsif ($s =~ /^frowning$/i) {			#activity
			&add_tag("frowning"    ,$file,$tmporiginaltag,"",$mode);
			$STOP_ALL_CAPTIONING=1;
			&add_tag("thing-frown",$file,$tmporiginaltag,0,$mode);
			$STOP_ALL_CAPTIONING=0;
			$s="";
		} elsif ($s =~ /^smirking$/i) {			#activity
			&add_tag("smirking"    ,$file,$tmporiginaltag,"",$mode);
			$STOP_ALL_CAPTIONING=1;
			&add_tag("thing-smirk",$file,$tmporiginaltag,0,$mode);
			$STOP_ALL_CAPTIONING=0;
			$s="";
		} elsif ($s =~ /^toasting$/i) {			#activity
			&add_tag("CHEERS!",$file,$tmporiginaltag,0,$mode);
		} elsif ($s =~ /^sticking out tongue$/i) {			#activity
			&add_tag("thing-tongue",$file,$tmporiginaltag,0,$mode);
		} elsif ($s =~ /^raising-eyebrow$/i) {			#activity
			&add_tag("raising eyebrow",$file,$tmporiginaltag,"",$mode);
			&add_tag("eyebrow",        $file,$tmporiginaltag, 0,$mode);
			$s="";			
		} elsif ($s =~ /^dancing-/i) {			#activity
			&add_tag("dancing",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^dancing-//i;
			if ($s !~ /dancing$/i) { $s .= " dancing"; }
			if ($s =~ /^(moonwalk) dancing$/i) {
				&add_tag("$1",$file,$tmporiginaltag,0,$mode);
			}
		} elsif ($s =~ /^cooking-/i) {			#activity
			&add_tag("cooking",$file,$tmporiginaltag,"",$mode);
			$s =~ s/cooking-(.+)/cooking $1/i;
#Superceded:
#		} elsif ($s =~ /^twirling-(.*)/i) {		#activity
#			&add_tag("twirling",$file,$tmporiginaltag,0,$mode,0);
#			$s=~ s/twirling-(.*)/$1 twirling/;
#			&add_tag($s,$file,$tmporiginaltag,"",$mode);
#			$s="";
		} elsif ($s =~ /^foosball$/i) {			#activity
			&add_tag(        "foosball",$file,$tmporiginaltag,0 ,$mode);
			&add_tag("playing foosball",$file,$tmporiginaltag,"",$mode);
			&add_tag(           "table",$file,$tmporiginaltag,0 ,$mode);
			&add_tag(  "foosball table",$file,$tmporiginaltag,0 ,$mode);
			$s="";
		} elsif ($s =~ /^game-/i) {					#activity-game
			&add_tag("game",$file,$tmporiginaltag,0,$mode);
			$s =~ s/^game-//;
			if ($DEBUG_ACTIVITY_GAME) { print "[DAG1] Got here. s=$s<BR>\n"; }

			if ($s =~ /^playing cards$/) {				#activity-game
				if ($DEBUG_ACTIVITY_GAME) { print "[DAG1-CASE-1] Got here. s=$s<BR>\n"; }
				&add_tag("playing cards",$file,$tmporiginaltag,"",$mode);
				&add_tag(        "cards",$file,$tmporiginaltag, 0,$mode);
				$s="";
			} elsif ($s =~ /^(board games*)$/) {		#activity-game
				if ($DEBUG_ACTIVITY_GAME) { print "[DAG1-CASE-2] Got here. s=$s<BR>\n"; }
				&add_tag("playing $1",$file,$tmporiginaltag,1,$mode);
				&add_tag("$1"        ,$file,$tmporiginaltag,0,$mode);
				$s = "";
			} elsif ($s =~ /^playing cards-/) {			#activity-game
				if ($DEBUG_ACTIVITY_GAME) { print "[DAG1-CASE-4] Got here. s=$s<BR>\n"; }
				&add_tag("playing cards",$file,$tmporiginaltag,0,$mode);
				$s =~ s/^playing cards-//i;
			} elsif ($s =~ /^(card games*)-*/) {		#activity-game
				if ($DEBUG_ACTIVITY_GAME) { print "[DAG1-CASE-3] Got here. s=$s<BR>\n"; }
				$s =~ s/^card games*-//i;
				my $caption_it=1;
				if ($s ne "") {
					$caption_it=0;
					&add_tag("playing $s",$file,$tmporiginaltag,1,$mode);
				}
				&add_tag("playing cards",$file,$tmporiginaltag,$caption_it,$mode);
				&add_tag(        "cards",$file,$tmporiginaltag,     0     ,$mode);
				$s = "";
			} elsif (($s =~ /^(video games*)-*/i) || ($s =~ /^(arcade games*)-*/i) || ($s =~ /^(board games*)-*/i) || ($s =~ /^(drinking games*)-*/i) || ($s =~ /^(dice games*)-*/i) || ($s =~ /^(gambling games*)-*/i)) {
				$tmp1 = $1;
				$s    =~ s/$tmp1-*//i;
				if ($DEBUG_ACTIVITY_GAME) { print "[DAG1-CASE-5] Got here. /s now=$s/tmp1=$tmp1/<BR>\n"; }
				&add_tag("$tmp1",$file,$tmporiginaltag, 0,$mode);
				if ($s eq "") {
					&add_tag("playing ".$tmp1."s",$file,$tmporiginaltag,"",$mode);
				} elsif ($s =~ /^(.*)-(.*)$/i) {										#some games have a subgame, for example Life-Simpsons or Monpoly-Star Wars
					my $tmp2 = $1;
					my $tmp3 = $2;
					if ($DEBUG_ACTIVITY_GAME) { print "[DAG1-CASE-5-A] Got here. /s now=$s/tmp1=$tmp1/tmp2=$tmp2/tmp3=$tmp3/<BR>\n"; }	#tmp1=board game/tmp2=Life/tmp3=Simpsons
					&add_tag("playing $tmp1"."s"  ,$file,$tmporiginaltag,0,$mode);	#playing board games
					&add_tag("playing $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#playing Life
					&add_tag("playing $tmp3 $tmp2",$file,$tmporiginaltag,1,$mode);	#playing Simpsons Life
					&add_tag("playing $tmp3"      ,$file,$tmporiginaltag,0,$mode);	#playing Simpsons - may not make a lot of sense, but I think it's good so that we could have one activity tag to cover Simpsons Monopoly, Simpsons Clue, etc
					&add_tag("$tmp3 $tmp2"        ,$file,$tmporiginaltag,0,$mode);	#Simpsons Life
					&add_tag("$tmp2"              ,$file,$tmporiginaltag,0,$mode);	#Life
					&add_tag("$tmp3"              ,$file,$tmporiginaltag,0,$mode);	#Simpsons
					$s="";
				} else {
					&add_tag("playing ".$tmp1."s" ,$file,$tmporiginaltag,0,$mode);	#playing board games
					&add_tag("playing ".$s        ,$file,$tmporiginaltag,1,$mode);	#playing Monopoly
					&add_tag("$s"                 ,$file,$tmporiginaltag,0,$mode);	#Monopoly
					$s="";
				}
			}
			if ($DEBUG_ACTIVITY_GAME) { print "[DAG1-CASE-Z] Almost done. s=$s<BR>\n"; }
			if ($s ne "") {
				#If there's anything left:#ohohoh
				&add_tag("playing $s",$file,$tmporiginaltag,"",$mode);
				&add_tag(        "$s",$file,$tmporiginaltag, 0,$mode);
				$s="";
			}
		} elsif ($s =~ /^wedding-cake cutting/i) {	#activity
			&add_tag("food"   ,$file,$tmporiginaltag,"",$mode);
			&add_tag("cake"   ,$file,$tmporiginaltag,"",$mode);
			&add_tag("cutting",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^wedding-cake cutting/cake cutting/;
		} elsif ($s =~ /^martial arts-/i) {	#activity
			&add_tag("martial arts",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^martial arts-//;
		} elsif ($s =~ /^saving-/i) {			#activity
			if ($s =~ /^saving-([^\-\s]+)$/i) {
				&add_tag("saving",$file,$tmporiginaltag,0,$mode);
				&add_tag("saving the $1",$file,$tmporiginaltag,"",$mode);			#the 0 at end says - do not collect for captions
				$s="";
			} else {
				&add_tag("saving",$file,$tmporiginaltag,"",$mode);
			}
		} elsif ($s =~ /^sports?-/i) {			#activity
			&add_tag("sports",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^sports?-//i;

		#temporarily disabled this code due to artwork of an elf smoking something that looks like weed making it so I couldn't upload it. Also, fake weed being smoked on stage of a comedy act
#		} elsif ($s =~ /^smoking-weed$/i) {		#activity
#			$s="smoking";												#let's not call attention to any friends' illegal activities == we'll just call it smoking.
#			&add_tag("don't upload",$file,$tmporiginaltag,"",$mode);	#and if some of those ever end up existing, they probably shouldn't really be uploaded either.

		#} elsif ($s =~ /^smoking$/i) {		#activity
		#	&add_tag("smoking"  ,$file,$tmporiginaltag,"",$mode);	
		#	#&add_tag("cigarette",$file,$tmporiginaltag, 0,$mode);	#it could be a cigar or something else...
		} elsif ($s =~ /^eating-/i) {			#activity
			&add_tag("eating",$file,$tmporiginaltag,0,$mode);	#"eating"
			$s =~ s/eating-(.+)$/eating $1/i;
			&add_tag($s,$file,$tmporiginaltag,"",$mode);		#"eating chocolate"
			$s =~ s/eating (.+)$/$1/i;
			&add_tag($s,$file,$tmporiginaltag, 0,$mode);			#"chocolate"
		} elsif ($s =~ /^([a-z]+) ([a-z\s\']+)$/i) {						
			####################^^^######NOTE THAT THIS IS SPACE AND NOT HYPHEN HERE! NOT SURE HOW THIS IS GOING TO PLAY OUT!
			#############################20080515 - starting to decide it should be activity-verb-object like activity-touching-noses...
								### in which case... if there AREN'T any dashes left... perhaps we should change the space into a dash and throw it back into this functin?
								### Not sure!

			my $tmp1 = $1;	#verb	#"touching"	#"singing"	#"eating"
			my $tmp2 = $2;	#rest	#"faces"	#"karaoke"	#"mentos"
			if ($DEBUG_ACTIVITIES > 0) { print "[[[[[ACTIVITY CATCH-ALL SECTION 9P9P9P9P9 REACHED,tmp1=$tmp1,tmp2=$tmp2]]]]]<BR>\n"; }
			
			### Activities ***SEPARATED BY A SPACE*** where we want tagged "activity1,activity2,activity1 activity2" but captioned "activity1 activity2"			#1/2/12 / 12
			if (($tmp1 =~ /^touching$/i) || ($tmp1 =~ /^playing$/i)) {
				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);	
				&add_tag("$tmp2"      ,$file,$tmporiginaltag, 0,$mode);	
				&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag,"",$mode);
				$s="";
			}
		} elsif ($s =~ /^([a-z0-9\s]+)-([a-z0-9\s\'\.]+)$/i) {							#### ACTIVITY CATCH-ALL for "activity-one-two" type activities
			$caption_it="";
			my $tmp1 = $1;	#verb	#"touching"	#"singing"	#"eating"	#"leaning"		#"drinking"		#"fighting"
			my $tmp2 = $2;	#rest	#"faces"	#"karaoke"	#"mentos"	#"necessary"	#"noodle"
			if ($DEBUG_ACTIVITIES > 0) { print "<B>activity catch-all reached for: \"$s\"</B><BR>\$tmp1=$tmp1,\$tmp2=$tmp2<BR>\n"; }
			### DEPRECATED ###			##20080503##	#DEBUG: print "<BR><BR><BR>\$tmp1=$tmp1<BR>\$tmp2=$tmp2<BR><BR><BR>\n";			##20080503##	&add_tag("$tmp1"   ,$file,$tmporiginaltag, 0,$mode);	#verb			### DEPRECATED ###


			##### Some things we want tagged as "activity1,activity2", but captioned as "activity2"										#1/2 / 1
			if (($s =~        /^drinking-/i) ||	
				($s =~  /^TODOASDFIJASDFe/i)) {
				if ($DEBUG_ACTIVITIES > 0) { print "[[[[[ACTIVITY CATCH-ALL SECTION 8D8D8D REACHED,tmp1=$tmp1,tmp2=$tmp2]]]]]<BR>\n"; }
				$s=""; 
				&add_tag("$tmp1",$file,$tmporiginaltag, 0,$mode);							#DEBUG: print "tmp2 is now surprisingly $tmp2 -----------------------------";
				&add_tag("$tmp2",$file,$tmporiginaltag,"",$mode);							#DEBUG: print "what is s? s is $s now ------------------";
                $tmp1="";$tmp2="";
				#LEGACY CODE WE MUST STILL POTENTIALLY IMPLEMENT THE FUNCTIONALITY OF NEXT TIME THIS COMES UP:
				#IF ($s =~ /^doing shots-/i) 
				#	&add_tag("doing shots",$file,$tmporiginaltag,0,$mode);
				#	$s =~ s/doing shots-(.+)/doing $1 shots/i;
				#	&add_tag($s,$file,$tmporiginaltag,"",$mode);
				#	$s =~ s/doing .* shots//i;
			}

			
			##### Some things we want tagged as "activity1,activity1 activity2", but captioned as "activity1 activity2"					#1/12 / 12
			if (($s =~         /^looking-/i) ||	
				($s =~       /^recording-/i) ||						#a picture of someone "recording video" should not be tagged "video", for example, because it's not video.
				($s =~      /^installing-/i) ||						#moved from another section
				($s =~  /^TODOASDFIJASDFe/i)) {
				if ($DEBUG_ACTIVITIES > 0) { print "[[[[[ACTIVITY CATCH-ALL SECTION 2222 REACHED,tmp1=$tmp1,tmp2=$tmp2]]]]]<BR>\n"; }
				&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);	
				&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag,1,$mode);	
				$caption_it=0;
				$s=""; $tmp1=""; $tmp2=""; 
			}




			##### Some things we want tagged as "activity1,activity2 activity1" , but captioned as "activity2 activity1"				#1/21 / 21
			if (($s =~            /^sex-/i) ||
				($s =~        /^therapy-/i) ||	
				($s =~        /^rafting-/i) ||
				($s =~        /^leaning-/i) ||	
				($s =~       /^fighting-/i) ||
				($s =~       /^printing-/i) ||	
				($s =~ /^TODOASDFIJASDFe/i)) {
				if ($DEBUG_ACTIVITIES > 0) { print "[[[[[ACTIVITY CATCH-ALL SECTION 4444 REACHED,tmp1=$tmp1,tmp2=$tmp2]]]]]<BR>\n"; }
				$caption_it=1;
				if ("$tmp2 $tmp1" =~ /^noodle fighting$/i)   { &add_tag("noodle fight",$file,$tmporiginaltag,0,$mode); }
				if ("$tmp2 $tmp1" =~ /^catfight fighting$/i) { &add_tag("catfight"	  ,$file,$tmporiginaltag,0,$mode); $caption_it=0; }
				if ("$tmp2 $tmp1" =~ /^threesome sex$/i)     { &add_tag("threesome"	  ,$file,$tmporiginaltag,1,$mode); $caption_it=0; }		#threesome vs "threesome sex"
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,$caption_it,$mode);	
				&add_tag("$tmp1"      ,$file,$tmporiginaltag,          0,$mode);	
				$caption_it=0;
				$s=""; $tmp1=""; $tmp2=""; 
			}



			##### Some things we want tagged as "activity1,activity2 activity1,activity2" , but captioned as "activity2 activity1"				
			if (($s =~           /^ride-/i) ||
				($s =~ /^TODOASDFIJASDFe/i)) {
				if ($DEBUG_ACTIVITIES > 0) { print "[[[[[ACTIVITY CATCH-ALL SECTION 555xxx555 REACHED,tmp1=$tmp1,tmp2=$tmp2]]]]]<BR>\n"; }
				$caption_it=1;
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,$caption_it,$mode);	
				&add_tag("$tmp1"      ,$file,$tmporiginaltag,          0,$mode);	
				&add_tag("$tmp2"      ,$file,$tmporiginaltag,          0,$mode);	
				$caption_it=0;
				$s=""; $tmp1=""; $tmp2=""; 
			}



			##### Some things we want tagged as "activity1,activity1 activity2,activity2 activity1" , but captioned as "activity2 activity1"	#1/12/21 / 21
			if (($s =~       /^staining-/i) ||	
			   #($s =~           /^sign-/i) ||
				($s =~ /^TODOASDFIJASDFe/i)) {
				if ($DEBUG_ACTIVITIES > 0) { print "[[[[[ACTIVITY CATCH-ALL SECTION 5555 REACHED,tmp1=$tmp1,tmp2=$tmp2]]]]]<BR>\n"; }
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);	
				&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag, 0,$mode);	
				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);	
				$caption_it=0;
				$s=""; $tmp1=""; $tmp2=""; 
			}






			
			##### 2009 jello shots code
			if ($tmp1 =~       /^(doing) (shots*)$/i) {
				my $tmp4=$1;
				my $tmp5=$2;
				if ($DEBUG_ACTIVITIES > 0) { print "[[[[[ACTIVITY CATCH-ALL SECTION 5DS5 REACHED,tmp1=$tmp1,tmp2=$tmp2]]]]]<BR>\n"; }
				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		#doing shots
				&add_tag("$tmp4 $tmp2 $tmp5",$file,$tmporiginaltag,1,$mode);		#doing jello shots
				$caption_it=0;
				$s=""; $tmp1=""; $tmp2=""; 
			}


			##### Some things we want tagged as "activity2,activity2 activity 1" , but captioned as "activity2"									#2/21 / 2
			if (($s =~      /^molesting-/i) ||	
				($s =~           /^sign-/i) ||
				($s =~ /^singing-karaoke/i)) {
				if ($DEBUG_ACTIVITIES > 0) { print "[[[[[ACTIVITY CATCH-ALL SECTION 6666 REACHED,tmp1=$tmp1,tmp2=$tmp2]]]]]<BR>\n"; }
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);	
				&add_tag("$tmp2"      ,$file,$tmporiginaltag, 0,$mode);	$caption_it=0;
				#200805ish DO I PERHAPS NEED TO DO THIS?: 				$s=""; 
				#20080527 I think so!
				$s="";
			}




			##### Some activities ***SEPARATED BY A HYPHEN*** we want tagged as "activity1,activity1 activity2,activity2,activity2 activity1" , but captioned as "activity2 activity1"	#1
			if (($s =~       /^twirling-/i) ||	
			   #($s =~           /^sign-/i) ||
				($s =~ /^TODOASDFIJASDFe/i)) {
				if ($DEBUG_ACTIVITIES > 0) { print "[[[[[ACTIVITY CATCH-ALL SECTION 4545 REACHED,tmp1=$tmp1,tmp2=$tmp2]]]]]<BR>\n"; }
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);	
				&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag, 0,$mode);	
				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);	
				&add_tag("$tmp2"      ,$file,$tmporiginaltag, 0,$mode);	
				$caption_it=0;
				$s=""; $tmp1=""; $tmp2=""; 
			}



			##### Some activites ***SEPARATED BY A HYPHEN*** we want tagged as "activity1,activity2,activity1 activity2" , but captioned as "activity1 activity2"		#1/2/12 / 12
			if ((1)                         || 
				($s =~         /^biting-/i) ||				#20081009 - making this the activity catchall for all activities that don't fall into another category. let's see how this fares.
				($s =~         /^riding-/i) ||
				($s =~        /^blowing-/i) ||
				($s =~        /^cutting-/i) ||	
				($s =~        /^groping-/i) ||
				($s =~        /^holding-/i) ||
				($s =~        /^hunting-/i) ||
				($s =~        /^opening-/i) ||
				($s =~        /^playing-/i) ||	
				($s =~        /^singing-/i) ||
				($s =~        /^sucking-/i) ||
				($s =~        /^wearing-/i) ||
				($s =~       /^braiding-/i) ||
				($s =~       /^building-/i) ||
				($s =~       /^covering-/i) ||
				($s =~       /^grabbing-/i) ||
				($s =~       /^touching-/i) ||
				($s =~      /^squeezing-/i) ||
				($s =~     /^formatting-/i) ||
#				($s =~     /^installing-/i) ||				#actually no, not every picture of us installing something has that actual something in it, so this shouldn't be here
				($s =~   /^impersonating/i)) {
				if ($DEBUG_ACTIVITIES > 0) { print "[[[[[ACTIVITY CATCH-ALL SECTION 3333 REACHED,tmp1=$tmp1,tmp2=$tmp2,file=$file,from=$from,mode=$mode,tmporiginaltag=$tmporiginaltag]]]]]<BR>\n"; }
				&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag,"",$mode);	
				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);	
				&add_tag("$tmp2"      ,$file,$tmporiginaltag, 0,$mode);	
				$caption_it=0;
				$s=""; $tmp1=""; $tmp2=""; 
			}


			### DEPRECATED ###	
			##### All things will also be tagged "activity1 activity2", with captioning already determined above, unless otherwise stopped:
			$tmp3=1;					#$tmp3 = will we add this tag:
			if ($s =~ /^sign-/i)     { $tmp3=0; }
			if ($s eq "")			 { $tmp3=0; }											#20080527 - this section stumped me - perhaps time to retire it? this may do it for a lot of situations.
			if ($tmp3) { &add_tag("$tmp1 $tmp2",$file,$tmporiginaltag,$caption_it,$mode); }
			$s="";
			### DEPRECATED ###

		
		}
	}

	
	if ($s =~  /^comedy-/i) {									
		$s =~  s/^comedy-//i;
		$TYPE = "comedy";
		$SUBTYPE = "";
		&add_tag("funny", $file,$tmporiginaltag,0,$mode);
		&add_tag("comedy",$file,$tmporiginaltag,0,$mode);

		if ($DEBUG_COMEDY) { print "[COMEDY DETECTED:\$s=<B>$s</B>]<BR>\n";	}

		$s =~ s/dog-dressed up/dressed-up dog/i;
		if ($s =~ /bunny[-\s]ears/i) {
			&add_tag("bunny ears",$file,$tmporiginaltag,"",$mode);
		} elsif (($s =~ /^(computer)$/i) || ($s =~ /^(work)$/i))  {				#comedy catch-all for comedy-X tagged as "X comedy" -- i.e. "work comedy" not "funny work"
			$tmp1=$1;
			&add_tag(   "comedy",$file,$tmporiginaltag, 0,$mode);
			&add_tag("$1 comedy",$file,$tmporiginaltag,"",$mode);
			$s="";
		} elsif ($s =~ /^hair-dyed/i) {
			$s="funny hair-dye";
		} elsif ($s =~ /bodily-contortion/i) {
			&add_tag("contortion",$file,$tmporiginaltag,"",$mode);
			&add_tag("bodily comedy",$file,$tmporiginaltag,"",$mode);
			$s =~ s/bodily-contortion/bodily contortion/i;
		} elsif (($s =~ /^(drag)$/i) || ($s =~ /^(intoxication)$/i)) { 
			$s=$1;
		} elsif ($s =~ /^(animal)(s*)-(.*)$/i) {								#animal-fake
			$tmp1=$1; $tmp2=$2; $tmp3=$3;
			if ($DEBUG_COMEDY) { print "[COMEDY-1A,\$1=$1,\$2=$2,\$3=$3,\$s=$s]";	}
			#print "\ns has animal- \"$s\"\n";
			$s =~ s/animal-//;
			$s =~ s/dog-humping/dog humping/i;
			my $caption_it=1;
			if ($s =~ /cat-fat/i) {												#DEPRECATED#
				&add_tag("cat",$file,$tmporiginaltag,"",$mode);					#DEPRECATED#
				$s =~ s/cat-fat/fat cat/i;										#DEPRECATED#
			} else {				
				&add_tag("funny $tmp3 animal", $file,$tmporiginaltag, 0,$mode);
				&add_tag("$tmp3 animal comedy",$file,$tmporiginaltag,"",$mode); $caption_it=0;
			}
			&add_tag("funny $tmp1$tmp2",$file,$tmporiginaltag,     0     ,$mode);
			&add_tag("animal comedy"   ,$file,$tmporiginaltag,$caption_it,$mode);
			$s="";		
		} elsif ($s =~ /^bodily$/i) { 
			&add_tag("bodily comedy",$file,$tmporiginaltag,"",$mode);
			$s="";
		} elsif ($s =~ /^religion$/i) { 
			&add_tag("religious comedy",$file,$tmporiginaltag,1,$mode);
			&add_tag("religion"        ,$file,$tmporiginaltag,0,$mode);
			$s="";
		} elsif ($s =~ /^midget-fake/i) { 
			&add_tag("midget",$file,$tmporiginaltag,"",$mode);
			&add_tag("fake midget",$file,$tmporiginaltag,"",$mode);
			&add_tag("little people",$file,$tmporiginaltag,"",$mode);
			$s =~ s/midget-fake//;
		} elsif ($s =~ /^sexual$/i) { 
			&add_tag("sexual",$file,$tmporiginaltag,0,$mode);
			$s="sexual comedy";
		} elsif ($s =~ /^face[-\s]drawing/i) { 
			&add_tag("face drawing",$file,$tmporiginaltag,"",$mode);
			$s="";
		} elsif ($s =~ /^political[- ]satire$/i) { 
			&add_tag("political satire",$file,$tmporiginaltag,1,$mode);
			&add_tag("political comedy",$file,$tmporiginaltag,0,$mode);
			&add_tag("satire"          ,$file,$tmporiginaltag,0,$mode);
			&add_tag("politics"        ,$file,$tmporiginaltag,0,$mode);
			$s="";
		} else {		#comedy 2-chain (comedy-descriptor) catch-all
			$s="funny $s"; 
			if (($s =~ /^funny (face)$/i) || ($s =~ /^funny (spite)$/i)) {							#funny X where X should be tagged as well... "funny spite" should be tagged "spite", for example
				$tmp1=$1;
				&add_tag("$tmp1",$file,$tmporiginaltag,0,$mode);
			}
		}
		$s =~ s/(funny.*)-funny$/$1/i;
		$s =~ s/animals$/animal/;
	}

	
	if ($s =~  /^event-/i) {
		$s =~ s/^event-//i;
		$TYPE = "event";
		$SUBTYPE = "";

		##### ONE-TIME KLUDGES:
		$s =~ s/Sports-Bicycling-Tour DuPont-1996 \(Clint On ESPN2\)/Clint on ESPN with Lance Armstrong Tour DuPont 1996/i;

		##### INTERNAL KLUDGE FIXES BEFORE MAIN PROCESSING:
		if ($s =~ /^shower-wedding-/i) { $s =~ s/shower-wedding-/wedding shower-/i; }

		##### FESTIVALS (should leave $s blank when done):
		if ($s =~ /^(festival)-/i) {
			$tmp1=$1;
			&add_tag($tmp1,$file,$tmporiginaltag, 0,$mode);
			$s =~ s/^$tmp1-//i;
			if ($s =~ /^([a-z\s\#]+)-/i) { 
				$tmp2 = $1;
				#DEBUG:	print "<B>s is now $s! tmp1=$tmp1,tmp2=$tmp2</B><BR>\n";
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag, 0,$mode);
				$s =~ s/^([a-z\s\#]+)-//i;
				if ($s =~ /^([a-z\s\#]+)-/i) { 
					$tmp3 = $1;
					&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag, 0,$mode);
					$s =~ s/^([a-z\s\#]+)-//i;
				}
			}

		}

		##### THE MAIN CHAIN:
		if ($s =~ /^pig roast-(.*)/i) {
			&add_tag("$1"       ,$file,$tmporiginaltag,"",$mode);
			&add_tag("pig roast",$file,$tmporiginaltag,"",$mode);

		#:event-date-Lastname Firstname-20180504
		} elsif ($s =~ /^(date)-([^\-]*)-([0-9]*)$/i) {										#date
			my $tmp1 =                       $1 ;											#date
			my $tmp2 = &fix_name_of_any_form($2);											#who date is with
			my $tmp3 =                       $3 ;											#date of date
			$SUSPEND_DATE_PROCESSING=1;														#otherwise calendar-date logic will go in
			&add_tag("$tmp1",                   $file,$tmporiginaltag,"",$mode);			#date	-- can't say this because "DATE" is for calendar dates haha
			&add_tag("$tmp1 $tmp2",             $file,$tmporiginaltag,"",$mode);			#date Beth Hatch
			&add_tag("$tmp1 $tmp2 $tmp3",       $file,$tmporiginaltag,"",$mode);			#date Beth Hatch YYYYMMDD
			&add_tag("$tmp1 $tmp3",             $file,$tmporiginaltag,"",$mode);			#date YYYYMMDD
			&add_tag("$tmp1 $tmp3 $tmp2",       $file,$tmporiginaltag,"",$mode);			#date YYYYMMDD Beth Hatch
			&add_tag("$tmp2 $tmp1",             $file,$tmporiginaltag,"",$mode);			#Beth Hatch date 
			&add_tag("$tmp2 $tmp1 $tmp3",       $file,$tmporiginaltag,"",$mode);			#Beth Hatch date  YYYYMMDD
			&add_tag("$tmp2 $tmp3",             $file,$tmporiginaltag,"",$mode);			#Beth Hatch YYYYMMDD
			$s="";
			$SUSPEND_DATE_PROCESSING=0;

	#:event-meetup-DC Trans Ladies-20180504
		} elsif ($s =~ /^(meetup)-([^\-]*)-([0-9]*)$/i) {		#meetup-type-group-eventTitle-date		#will need a better regex check if more 5-chain events appear in the future
			my $tmp1 = $1;		#meetup
			my $tmp2 = $2;		#group
			my $tmp3 = $3;		#date
			&add_tag("$tmp1",                   $file,$tmporiginaltag,"",$mode);			#meetup
			&add_tag("$tmp1 $tmp2",             $file,$tmporiginaltag,"",$mode);			#meetup DCTransLadies
			&add_tag("$tmp1 $tmp2 $tmp3",       $file,$tmporiginaltag,"",$mode);			#meetup DCTransLadies YYYYMMDD
			&add_tag("$tmp1 $tmp3",             $file,$tmporiginaltag,"",$mode);			#meetup YYYYMMDD
			&add_tag("$tmp1 $tmp3 $tmp2",       $file,$tmporiginaltag,"",$mode);			#meetup YYYYMMDD DCTransLadies
			&add_tag("$tmp2",                   $file,$tmporiginaltag,"",$mode);			#DCTransLadies
			&add_tag("$tmp2 $tmp1",             $file,$tmporiginaltag,"",$mode);			#DCTransLadies meetup
			&add_tag("$tmp2 $tmp1 $tmp3",       $file,$tmporiginaltag,"",$mode);			#DCTransLadies meetup YYYYMMDD
			&add_tag("$tmp2 $tmp3",             $file,$tmporiginaltag,"",$mode);			#DCTransLadies YYYYMMDD
			&add_tag("$tmp3",                   $file,$tmporiginaltag,"",$mode);			#YYYYMMDD
			$s="";

		#:event-meetup-DC Trans Ladies-soiree-Halloween-20171021
		} elsif ($s =~ /^(meetup)-([^\-]*)-([^\-]*)-([^\-]*)-([^\-]*)$/i) {		#meetup-type-group-eventTitle-date		#will need a better regex check if more 5-chain events appear in the future
			my $tmp1 = $1;		#meetup
			my $tmp2 = $2;		#type
			my $tmp3 = $3;		#group
			my $tmp4 = $4;		#eventTitle
			my $tmp5 = $5;		#date
			&add_tag("$tmp1",                   $file,$tmporiginaltag,"",$mode);			#meetup
			&add_tag("$tmp1 $tmp5",             $file,$tmporiginaltag,"",$mode);			#meetup YYYYMMDD
			&add_tag("$tmp5 $tmp2 $tmp1",       $file,$tmporiginaltag,"",$mode);			#YYYYMMDD brony meetup
			&add_tag("$tmp5 $tmp3 $tmp1",       $file,$tmporiginaltag,"",$mode);			#YYYYMMDD DCbronies meetup
			&add_tag("$tmp5 $tmp1",             $file,$tmporiginaltag,"",$mode);			#YYYYMMDD meetup
			&add_tag("$tmp5 $tmp1 $tmp3",       $file,$tmporiginaltag,"",$mode);			#YYYYMMDD meetup DCBronies
			&add_tag("$tmp2 $tmp1",             $file,$tmporiginaltag,"",$mode);			#brony meetup
			&add_tag("$tmp2 $tmp1 $tmp5",       $file,$tmporiginaltag,"",$mode);			#brony meetup YYYYMMDD
			&add_tag("$tmp3",                   $file,$tmporiginaltag,"",$mode);			#DC Bronies
			&add_tag("$tmp3 $tmp1",             $file,$tmporiginaltag,"",$mode);			#DC Bronies meetup
			&add_tag("$tmp3 $tmp1 $tmp5",       $file,$tmporiginaltag,"",$mode);			#DC Bronies meetup YYYYMMDD
			&add_tag("$tmp4",                   $file,$tmporiginaltag,"",$mode);			#Farewell Springfield Mall
			&add_tag("$tmp4 $tmp5",             $file,$tmporiginaltag,"",$mode);			#Farewell Springfield Mall YYYYMMDD
			&add_tag("$tmp4 $tmp1",             $file,$tmporiginaltag,"",$mode);			#Farewell Springfield Mall meetup
			&add_tag("$tmp4 $tmp1 $tmp5",       $file,$tmporiginaltag,"",$mode);			#Farewell Springfield Mall meetup YYYYMMDD
			&add_tag("$tmp4 $tmp2 $tmp1",       $file,$tmporiginaltag,"",$mode);			#Farewell Springfield Mall brony meetup
			&add_tag("$tmp4 $tmp2 $tmp1 $tmp5", $file,$tmporiginaltag,"",$mode);			#Farewell Springfield Mall brony meetup YYYYMMDD
			&add_tag("$tmp4 $tmp3 $tmp1",       $file,$tmporiginaltag,"",$mode);			#Farewell Springfield Mall DCBronies meetup
			&add_tag("$tmp4 $tmp3 $tmp1 $tmp5", $file,$tmporiginaltag,"",$mode);			#Farewell Springfield Mall DCBronies meetup YYYYMMDD
			$s="";
		} elsif ($s =~ /^(reunion)-([^\-]*)-([^\-]*)-([^\-]*)$/i) {		#meetup-type-group-eventTitle-date		#will need a better regex check if more 5-chain events appear in the future
			my $tmp1 = $1;		#reunion
			my $tmp2 = $2;		#high school
			my $tmp3 = $3;		#Woodbridge High
			my $tmp4 = $4;		#Class Of 1992
			&add_tag("$tmp1",                   $file,$tmporiginaltag,"",$mode);			#reunion
			&add_tag("$tmp2 $tmp1",             $file,$tmporiginaltag,"",$mode);			#highschool reunion
			&add_tag("$tmp3",                   $file,$tmporiginaltag,"",$mode);			#WSHS
			&add_tag("$tmp3 $tmp1",             $file,$tmporiginaltag,"",$mode);			#WSHS reunion
			&add_tag("$tmp3 $tmp4 $tmp1",       $file,$tmporiginaltag,"",$mode);			#WSHS ClassOf92 reunion
			&add_tag("$tmp3 $tmp4 $tmp2 $tmp1", $file,$tmporiginaltag,"",$mode);			#WSHS ClassOf92 highschool reunion
			&add_tag("$tmp4",                   $file,$tmporiginaltag,"",$mode);			#ClassOf92
			&add_tag("$tmp4 $tmp1",             $file,$tmporiginaltag,"",$mode);			#ClassOf92 reunion
			&add_tag("$tmp4 $tmp2 $tmp1",       $file,$tmporiginaltag,"",$mode);			#ClassOf92 highschool reunion
			$s="";
		} elsif ($s =~ /^fair-(.*)$/i) {
			$tmp1=$1;
			&add_tag("fair" ,$file,$tmporiginaltag,"",$mode);
			&add_tag("$tmp1",$file,$tmporiginaltag,"",$mode);
			$s="";
		} elsif ($s =~ /^hanging out-/i) {
			&add_tag("hanging out",$file,$tmporiginaltag,"",$mode);
			$s =~ s/hanging out-([12][0-9][0-9][0-9][0-9]*)$/hanging out $1/i;
			&add_tag("$s",$file,$tmporiginaltag,"",$mode);
			$s="";
		} elsif ($s =~ /^club-/i) {	#event-club 
			&add_tag("club",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^club-//;	#works so far
			$s =~ /([^\-]*)-([^\-]*)-*(.*)$/;
			$tmp1 = $1;		#club
			$tmp2 = $2;		#date
			$tmp3 = $3;		#other
			#DEBUG:			print "\$tmp1=$tmp1,\$tmp2=$tmp2,\$tmp3=$tmp3<BR>\n";
			&add_tag("$tmp1",$file,$tmporiginaltag,"",$mode);
			&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag,"",$mode);
			&add_tag("$tmp1 $tmp2 $tmp3",$file,$tmporiginaltag,"",$mode);
			&add_tag("$tmp3",$file,$tmporiginaltag,"",$mode);
			$s="";
		} elsif ($s =~ /^meal-/i) {
			&add_tag("meal",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^meal-//i;
			if ($DEBUG_MEAL) { print "s[A] is now \"$s\"<BR>\n"; }
			#if  {
			#	my $tmp1 = $1 . $2;
			#	if ($DEBUG_MEAL) { print "s[B1] is now \"$s\"<BR>\n"; }
			#	&add_tag("$tmp1",$file,$tmporiginaltag,"",$mode);
			#	$s =~ s/$tmp1-//i;
			#	#DEBUG:print "s is \"$s\"\n";
			#	$s =~ s/^([12][0-9][0-9][0-9][01][0-9][0-3][0-9])-([a-z\s]+)$/$tmp1 $1 $2/i;
			#}
			if (($s =~ /^(dinner)-/i) || ($s =~ /^([lbr]*unch)-/i)) {										#Christmas Brunch 2011 made me merge lunch/dinner/brunch into one more-optimized, more-logical code set
				my $tmp1=$1;
				&add_tag("$tmp1",$file,$tmporiginaltag,"",$mode);
				$s =~ s/^$tmp1-//i;
				if ($DEBUG_MEAL) { print "s[B2A] is now \"$s\"<BR>\n"; }
				$s =~ s/^([12][0-9][0-9][0-9][01][0-9][0-3][0-9])-*(.*)$/$tmp1 $1 $2/i;
				if ($DEBUG_MEAL) { print "s[B2B] is now \"$s\"<BR>\n"; }
				#DEBUG:print "s is now \"$s\"<BR>\n";
				&add_tag("$s",$file,$tmporiginaltag,"",$mode);
				$s =~ s/^$tmp1( *[0-9]*)(-*.*)$/$tmp1$1/;
				if ($DEBUG_MEAL) { print "s[B2C] is now \"$s\"<BR><BR>\n"; }
				&add_tag("$s",$file,$tmporiginaltag,"",$mode);
				$s="";
			}
		} elsif (($s =~ /^beach-/i) || ($s =~ /^beach trip-/i)) {
			if ($DEBUG_EVENT_BEACH) { print "[BEACH-0:s=$s]<BR>\n"; }
#		     			s=beach trip-Virginia-Virginia Beach-2001
			if ($s =~ /^(beach trip)-([^\-]+)-([^\-]+)-([0-9]+)$/i) {		#new format
				if ($DEBUG_EVENT_BEACH) { print "[BEACH-CATCHALL:1=$2,2=$2,3=$3,4=$4]<BR>\n"; }
				my $tmp1=$1;	#"beach trip"
				my $tmp2=$2;	#state - "Virginia"
				my $tmp3=$3;	#beach name - "Virginia Beach", "Bethany Beach"
				my $tmp4=$4;	#date - usually just the year

				my $tmp5="$tmp3 $tmp1";	
				$tmp5 =~ s/(beach) beach/$1/i;		#don't let beach repeat

				&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);		#beach trip
				&add_tag("$tmp1 $tmp4"      ,$file,$tmporiginaltag,0,$mode);		#beach trip 2004
				&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);		#Delaware beach trip
				&add_tag("$tmp2 $tmp1 $tmp4",$file,$tmporiginaltag,0,$mode);		#Delaware beach trip 2004
				&add_tag("$tmp5"            ,$file,$tmporiginaltag,"",$mode);		#Bethany Beach trip / Ocean City beach trip
				&add_tag("$tmp5 $tmp4"      ,$file,$tmporiginaltag,"",$mode);		#Bethany Beach trip 2004 / Ocean City beach trip 2004


				$s="";
			} else {														#old/deprecated code
				print "<B>WARNING: Deprecated beach code triggered. Double-check event-beach trip tag was entered in properly.</B><BR>\n";
				&add_tag("beach trip",$file,$tmporiginaltag,0,$mode);	#No. Let's not do this as beach; that's ambiguous with pictures of beaches. Do it as beach trip.
				$s =~ s/^beach-//i;	#works so far
				$s =~ s/^beach trip-//i;	#works so far
				if ($DEBUG_EVENT_BEACH) { print "[BEACH-A:s=$s]<BR>\n"; }
				$s =~ s/Delaware-(Bethany Beach)-/$1 /i;		#no clue if this is still required; better keep it
				$s =~ /^([^\-]+)-([^\-]+)/i;
				$tmp3=$1;
				($tmp1,$tmp2)=&is_state($tmp3);
				if ($DEBUG_EVENT_BEACH) { print "[BEACH-B:tmp1=$tmp1,tmp2=$tmp2]<BR>\n"; }
				if ($tmp1) {
					&add_tag($tmp2,$file,$tmporiginaltag,"",$mode);
					#$s =~ s/^maryland-//i;	#works so far
					$s =~ s/^$tmp2-//i;	#works so far
					$s =~ s/-([12][0-9][0-9][0-9])$/ $tmp2/;
				}
			}
		} elsif ($s =~ /^barbecue-/i) {
			$s =~ s/Diaz Christian and Shannon/Christian and Shannon Diaz/i;
			&add_tag("barbecue",$file,$tmporiginaltag,0,$mode);			
			&add_tag("BBQ",     $file,$tmporiginaltag,0,$mode);			
			$s =~ s/^barbecue-//;
			#$s =~ /([^\-]*)-/i;
			if ($s =~ /^([a-z]+)$/i) {	#barbecue-oneword (cicada)
				&add_tag("$1 barbecue",$file,$tmporiginaltag,"",$mode);						
				&add_tag("$1 BBQ",     $file,$tmporiginaltag,"",$mode);						
				$s="";
			} elsif ($s =~ /([^\-]+)-([0-9]+)$/i) {
				my $tmp1=&fix_name_of_any_form($1);	#who
				my $tmp2=$2;	#when
				$s="";								#DEBUG: print "heyooooo tmp1=$tmp1,tmp2=$tmp2<BR>";
				$STOP_ALL_CAPTIONING=1;
					&add_tag("barbecue $tmp1"      ,$file,$tmporiginaltag,0,$mode);						
					&add_tag("barbecue $tmp1 $tmp2",$file,$tmporiginaltag,0,$mode);						
					&add_tag("barbecue $tmp2"      ,$file,$tmporiginaltag,0,$mode);						
					&add_tag("barbecue $tmp2 $tmp1",$file,$tmporiginaltag,0,$mode);						
				$STOP_ALL_CAPTIONING=0;
			}
		} elsif ($s =~ /^Inspection-/i) {
			&add_tag("inspection",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^Inspection-//i;
			if ($s =~ /^house-/i) {			#event-inspection-house*
				&add_tag("house inspection",$file,$tmporiginaltag,"",$mode);
				$s =~ s/^house-//i;
				if ($s =~ /^([12][0-9][0-9][0-9])$/i) {
					$tmp1=$1;
					&add_tag("house inspection $tmp1",$file,$tmporiginaltag,"",$mode);
					$s = "";
				}
			}


		# ( this is still event )
		} elsif ($s =~ /^camping-/i) {
			&add_tag("camping",$file,$tmporiginaltag,"",$mode);
			if ($s =~ /^camping-([0-9][0-9][0-9][0-9][0-9]*)/i)      { &add_tag("camping $1"   ,$file,$tmporiginaltag,"",$mode); }
			if ($s =~ /^camping-([0-9][0-9][0-9][0-9][0-9]*)-(.*)$/) { &add_tag("camping $1 $2",$file,$tmporiginaltag,"",$mode); }
			$s = "";


		# ( this is still event )
		} elsif (($s =~ /^(party)-/i) || ($s =~ /^(craft night)-/i)) {	#event-party or other events we want to appy party logic too
			my $party=$1;
			if ($DEBUG_EVENT_PARTY) { print "<BR><BR><B>[PARTY TAG [$party] ENCOUNTERED: </b> $s<B>]</B><BR>\n"; }
			&add_tag("$party",$file,$tmporiginaltag,0,$mode);
			$s =~ s/^$party[-\s]+//i;								#DO NOT COMMENT THIS OUT!



			##### party-HOST(S)-type-date(YYYYMMDD)-IndividualPartyName
			##### i.e. :event-party-Smith John and Jane-Rainbow-20160618-Red
			$s =~ /^(.*)-(.*)-([0-9]{8})-(.*)$/;							 #party 4-chain
			my $tmp1=$1;	my $tmp2=$2;	my $tmp3=$3;	my $tmp4=$4;								 if ($DEBUG_EVENT_PARTY>=1) { print "======>  [DP1HAHA]  \$s is $s  .... 1=$tmp1;2=$tmp2,3=$tmp3,4=$tmp4 <BR>\n"; }  # 1=Smith Clio and Carolyn;2=Rainbow,3=20160618,4=Red 
			if ($tmp2 =~ /^rainbow$/i) {																 if ($DEBUG_EVENT_PARTY>=1) { print "======>  [DP1HAHA2]  Rainbow Party identified <BR>\n";  }
				&add_tag("$party $tmp1"                         ,$file,$tmporiginaltag,"",$mode);		#party Clio and Carolyn 
				&add_tag("$party $tmp1 $tmp3"                   ,$file,$tmporiginaltag,"",$mode);		#party Clio and Carolyn YYYYMMDD
				&add_tag("$party $tmp1 $tmp2 $party"             ,$file,$tmporiginaltag,"",$mode);		#party Clio And Carolyn Rainbow Party 
				&add_tag("$party $tmp1 $tmp2 $party $tmp3"       ,$file,$tmporiginaltag,"",$mode);		#party Clio And Carolyn Rainbow Party YYYYMMDD
				&add_tag("$party $tmp1 $tmp2 $party $tmp4"       ,$file,$tmporiginaltag,"",$mode);		#party Clio And Carolyn Rainbow Party I Like Red
				&add_tag("$party $tmp1 $tmp2 $party $tmp4 $tmp3" ,$file,$tmporiginaltag,"",$mode);		#party Clio And Carolyn Rainbow Party I Like Red YYYYMMDD
				&add_tag("$party $tmp1 $tmp4"                   ,$file,$tmporiginaltag,"",$mode);		#party Clio And Carolyn I Like Red
				&add_tag("$party $tmp1 $tmp4 $tmp3"             ,$file,$tmporiginaltag,"",$mode);		#party Clio And Carolyn I Like Red YYYYMMDD
				&add_tag("$party $tmp2 $party"                   ,$file,$tmporiginaltag,"",$mode);		#party rainbow party 
				&add_tag("$party $tmp2 $party $tmp3"             ,$file,$tmporiginaltag,"",$mode);		#party CYYYYMMDD
				&add_tag("$party $tmp2 $party $tmp1"             ,$file,$tmporiginaltag,"",$mode);		#party rainbow party Clio And Carolyn
				&add_tag("$party $tmp2 $party $tmp1 $tmp3"       ,$file,$tmporiginaltag,"",$mode);		#party rainbow party Clio And Carolyn YYYYMMDD
				&add_tag("$party $tmp2 $party $tmp3"             ,$file,$tmporiginaltag,"",$mode);		#party rainbow party YYYYMMDD
				&add_tag("$party $tmp2 $party $tmp4"             ,$file,$tmporiginaltag,"",$mode);		#party rainbow party i like red
				&add_tag("$party $tmp3"                         ,$file,$tmporiginaltag,"",$mode);		#party YYYYMMDD 
				&add_tag("$party $tmp3 $tmp1"                   ,$file,$tmporiginaltag,"",$mode);		#party YYYYMMDD Clio and Carolyn 
				&add_tag("$party $tmp4"                         ,$file,$tmporiginaltag,"",$mode);		#party I Like Red
				&add_tag("$party $tmp4 $tmp3"                   ,$file,$tmporiginaltag,"",$mode);		#party I Like Red YYYYMMDD
				&add_tag("$tmp2 $party"                         ,$file,$tmporiginaltag,"",$mode);		#rainbow party
				&add_tag("$tmp2 $party $tmp1"                   ,$file,$tmporiginaltag,"",$mode);		#rainbow party Clio And Carolyn
				&add_tag("$tmp2 $party $tmp1 $tmp3"             ,$file,$tmporiginaltag,"",$mode);		#rainbow party Clio And Carolyn YYYYMMDD
				&add_tag("$tmp2 $party $tmp3"                   ,$file,$tmporiginaltag,"",$mode);		#rainbow party YYYYMMDD
				&add_tag("$tmp4 $party"                         ,$file,$tmporiginaltag,"",$mode);		#I Like Red party
				&add_tag("$tmp4 $party $tmp3"                   ,$file,$tmporiginaltag,"",$mode);		#I Like Red party YYYYMMDD
				$s="";
			}





			##### ONE-OFFS:
			if ($s=~ /^work-/) { &add_tag("work $party",$file,$tmporiginaltag,"",$mode);	}
			$s =~ s/^Schafrik Bob and Stewart Becky/Becky and Bob/;
			$s =~ s/Nelson Dave and Lacey/Dave and Lacey Nelson/i;
			$s =~ s/Mens Eric and Eve/Eve and Eric Mens/i;
			$s =~ s/Howard Wayne and Moustafa Shehab/Wayne and Shehab/i;
			$s =~ s/Sweet Chuck and Britt/Britt and Chuck/i;
			$s =~ s/Neigh Chris and Britt/Britt and Chris/i;
			$s =~ s/Vic Lipinski's/Dad's/i;
			$s =~ s/Lipinski Clint/Clint/i;
			$s =~ s/Lipinski Clio/Clio/i;
			$s =~ s/Sawyer Clio/Clio/i;
			$s =~ s/Clint Lipinski's/Clint's/i;
			$s =~ s/Clio Lipinski's/Clio's/i;
			$s =~ s/Clio Sawyer's/Clio's/i;
			$s =~ s/Claire Sawyer's/Claire's/i;
			if ($s =~ /Pajama Jammy Jam/i) { &add_tag("Pajama Jammy Jam",$file,$tmporiginaltag,"",$mode); &add_tag("Pajama $party",$file,$tmporiginaltag,0,$mode); }
			if ($DEBUG_EVENT_PARTY>=1) { print "======>  [OOO1]  \$s is $s  <BR>\n"; }

			#remember, this is still for PARTY only

			#specific holidays get some special treatment:
			if ($s =~ /Memorial Day/i) {
				&add_tag("holiday"             ,$file,$tmporiginaltag,"",$mode);
				&add_tag("Memorial Day"        ,$file,$tmporiginaltag,"",$mode);
				&add_tag("Memorial Day holiday",$file,$tmporiginaltag,"",$mode);
				&add_tag("Memorial Day $party" ,$file,$tmporiginaltag,"",$mode);
			}
			if ($s =~ /Halloween/i) {
				&add_tag("holiday"          ,$file,$tmporiginaltag,"",$mode);
				&add_tag("Halloween"        ,$file,$tmporiginaltag,"",$mode);
				&add_tag("Halloween holiday",$file,$tmporiginaltag,"",$mode);
				&add_tag("Halloween $party" ,$file,$tmporiginaltag,"",$mode);
			}

			if ($DEBUG_EVENT_PARTY) { print "======>  [4AX-BEG BIG-IF]  \$s is $s  <BR>\n"; }
			if ($s =~  /^([a-z]+) ([a-z]+) and ([a-z]+) ([a-z]+)[\s\-]([12][0-9][0-9][0-9][0-9]*)$/i) {
				if ($DEBUG_EVENT_PARTY) { print "YES! [3XX]  <BR>\n"; }
				&add_tag("$2 $1 and $4 $3" . "'s $party $5",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $5 $2 $1 and $4 $3",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $2 $1 and $4 $3 $5",$file,$tmporiginaltag,"",$mode);
				return;
			} elsif ($s =~ /^([12][0-9][0-9][0-9][0-9]*) ([a-z]+) ([a-z]+)-([a-z\s]+)$/i) {
				if ($DEBUG_EVENT_PARTY) { print "YES! [2YY]  <BR>\n"; }
				$s =~ s/^([12][0-9][0-9][0-9][0-9]*) ([a-z]+) ([a-z]+)-([a-z\s]+)$/$1 $3 $2 $4/i;
				&add_tag("$3 $2's $4 $party $1",$file,$tmporiginaltag,"",$mode);
			} elsif ($s =~ /^([a-z]+) ([a-z]+) and ([a-z]+)-Halloween-([12][0-9][0-9][0-9][0-9]*)$/i) {
				my $tmp1=$1; my $tmp2=$2; my $tmp3=$3; my $tmp4=$4;
				$s="$tmp2 and $tmp3 $tmp1's Halloween $party $tmp4";				if ($DEBUG_EVENT_PARTY) { print "YES! [5AA] s=$s  <BR>\n"; }
				&add_tag($s,$file,$tmporiginaltag,"",$mode);
				$s="$party $tmp2 and $tmp3 $tmp1 $tmp4";							if ($DEBUG_EVENT_PARTY) { print "YES! [5BBX] s=$s  <BR>\n"; }
				&add_tag($s,$file,$tmporiginaltag,"",$mode);
				$s="$party Halloween $tmp4 $tmp2 and $tmp3 $tmp1";				if ($DEBUG_EVENT_PARTY) { print "YES! [5CQQ] s=$s  <BR>\n"; }
				&add_tag($s,$file,$tmporiginaltag,"",$mode);
				$s="$party $tmp4 $tmp2 and $tmp3 $tmp1 Halloween";				if ($DEBUG_EVENT_PARTY) { print "YES! [5CQQ] s=$s  <BR>\n"; }
				&add_tag($s,$file,$tmporiginaltag,"",$mode);

			#2007/03/17: let's try to process this with the catchall code more!
			#} elsif ($s =~  /^([12][0-9][0-9][0-9][0-9]*) (.*)$/i) {
			#	if ($DEBUG_EVENT_PARTY) { print "YES! [333]  <BR>\n"; }
			#	&add_tag("$2 party $1",$file,$tmporiginaltag,"",$mode);

			#:event-party-Trangenstein Pamela-20070818
			} elsif ($s =~ /^([a-z]+) ([a-z]+)[\s\-]([12][0-9][0-9][0-9]*)$/i) {
				my $tmp1=$1;	#lastname
				my $tmp2=$2;	#firstname	- so full name is "$tmp2 $tmp1"
				my $tmp3=$3;	#date
				if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[85] used\n======>  \$s=$s  <BR>tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3\n"; }
				&add_tag("$party $tmp3"            ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$party $tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,0,$mode);
				&add_tag("$party $tmp2 $tmp1 $tmp3",$file,$tmporiginaltag,0,$mode);
				$s="";
			} elsif ($s =~ /^([80a-z\s]+)[\s\-]([12][0-9][0-9][0-9]*)$/i) {
				my $tmp1=$1;	#zumbrook greg and nicole
				my $tmp2=$2;	#date
				if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[P1] used\n======>  \$s=$s,\$tmp1=$tmp1,\$tmp$tmp2  <BR>\n"; }
				##### OLD:
				#if ($tmp1 !~ / and /) {
				#	$tmp1 =~ s/([a-z]+) ([a-z]+)/$2 $1/i;								#invert name if only one name
				#} elsif ($tmp1 =~ /([a-z]+) ([a-z]+) and ([a-z]+) ([a-z]+)/i) {			#couple names where both have different last names need a different kind of inversion
				#	$tmp1 =~ s/([a-z]+) ([a-z]+) and ([a-z]+) ([a-z]+)/$2 $1 and $4 $3/i;
				#} else {
				#	$tmp1 =~ s/([a-z]+) ([a-z]+) and ([a-z]+)/$2 and $3 $1/i;			#couple names where both have the same last name need a different kind of inversion
				#}
				##### NEW:
				$tmp1 = &fix_name_of_any_form($tmp1);
				#
				&add_tag("$party $tmp2"      ,$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp1 $tmp2",$file,$tmporiginaltag,"",$mode);
				$s="";
			} elsif ($s =~ /^([a-z\s]+)-([a-z\s]+)-([12][0-9][0-9][0-9]*)$/i) {
				#$s=Dreisbach Brad and Mandy-Chili Cook Off-20070324		$1=Dreisbach Brad and Mandy,		$2=Chili Cook Off,		$3=20070324
				#$s=Axilbund Eric-Independence Day-200707					$1=Axilbund Eric,					$2=Independence Day,	$3=200707
				my $tmp1=$1;		#person or couple name
				my $tmp2=$2;		#birthday / chili cook off / etc
				my $tmp3=$3;		#date
				if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[M2] used\n======>  \$s=$s\n\$tmp1=$tmp1,\$tmp2=$tmp2,\$tmp3=$tmp3  <BR>\n"; }
				my $TMP="";
				if (($tmp1 =~ /^(birthday)$/i) || ($tmp1 =~ /^(engagement)$/i)) { $TMP=$tmp1; $tmp1=$tmp2; $tmp2=$TMP; }

				$tmp1 = &fix_name_of_any_form($tmp1);
				if ( ($tmp2 =~ /^(birthday)$/i) || ($tmp2 =~ /^(Christmas)$/i) || ($tmp2 =~ /^(Chili Cook[-\s]*Off)$/i) ) { 
					if ($DEBUG_EVENT_PARTY) { print " [BIRTHDAY/XMAS/CHILI] <BR>\n"; }
					&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode); 
					&add_tag("$tmp2 $party"     ,$file,$tmporiginaltag,0,$mode);					
				#	#add_tag($tmp1 . "'s $party",$file,$tmporiginaltag,0,$mode);					"Carolyn's party" for "Carolyn's birthday party" could be deceptive if, say, someone else other than Carolyn was hosting her birthday party
					&add_tag($tmp1 . "'s $tmp2 $party",$file,$tmporiginaltag,0,$mode); 
					&add_tag($tmp1 . "'s $tmp2 $party $tmp3",$file,$tmporiginaltag,0,$mode); 
				}
				if ($DEBUG_EVENT_PARTY) { print "======>  \$s is now $s  <BR>\n"; }
				if ($DEBUG_EVENT_PARTY) { print "======>  <b>\$s=$s\n\$tmp1=$tmp1,\$tmp2=$tmp2,\$tmp3=$tmp3</b> <BR>\n"; }
				&add_tag("$party $tmp3 $tmp1 $tmp2",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp2 $tmp1 $tmp3",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp1 $tmp3 $tmp2",$file,$tmporiginaltag,"",$mode);
				$s="";
			} elsif ($s =~ /^([0-9\#a-zA-Z\s\']+)-([12][0-9][0-9][0-9]*)-([^\-]+)$/i) {
				my $tmp1 = &fix_name_of_any_form($1);	#Britt and Chris
				my $tmp2 = $2;							#YYYYMMDD
				my $tmp3 = $3;							#freeform party description
				if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[CXQRN] used\n======>  \$s=$s\n======> Right now: \$tmp1=$tmp1,\$tmp2=$tmp2,\$tmp3=$tmp3  <BR>\n"; }
				&add_tag("$party $tmp2 $tmp1 $tmp3",$file,$tmporiginaltag,"",$mode);	#party 20020129 Christian and Shannon Diaz murder
				&add_tag("$party $tmp1 $tmp2 $tmp3",$file,$tmporiginaltag,"",$mode);	#party Christian and Shannon Diaz 20020129 murder
				&add_tag("$party $tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,"",$mode);	#party murder 20020129 Christian and Shannon Diaz 

				#add party to the end if it's not already there
				if (($tmp3 !~ / Benefit$/i) || ($tmp3 !~ / party$/i)) { $tmp3 .= " party"; }
				&add_tag("$tmp3"                        ,$file,$tmporiginaltag,"",$mode);
				$s="";		
			} elsif ($s =~ /^([0-9\#a-z\']+ [0-9\#a-z\']+ and [0-9\#a-z\']+ [0-9\#a-z\']+)-([0-9\#a-z\s\-\']+)[\s\-]([12][0-9][0-9][0-9]*)$/i) {
				#$s is Buckwalter Ian and Preble Angel-New Year's-20081231 
				my $tmp1 = $1;	#Diaz Christian and Shannon should = Christian and Shannon Diaz
				my $tmp2 = $2; #New Year's Eve
				my $tmp3 = $3; #20061230
				$tmp1=&fix_name_of_any_form($tmp1);
				if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[PBCZ2X1] used\n======>  \$s=$s\n======> Right now: \$tmp1=$tmp1,\$tmp2=$tmp2,\$tmp3=$tmp3  <BR>\n"; }
				&add_tag("$party $tmp1 $tmp2 $tmp3",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp1 $tmp3 $tmp2",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp3 $tmp1 $tmp2",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp2 $tmp3 $tmp1",$file,$tmporiginaltag,"",$mode);
				$s="";		
			} elsif ($s =~ /^([0-9\#a-z\']+) ([0-9\#a-z\']+) and ([0-9\#a-z\']+)[\s\-]([0-9\#a-z\s\-\']+)[\s\-]([12][0-9][0-9][0-9]*)$/i) {	#party-someone someone and someone-something-YYYYMMDD
				my $tmp1 = "$2 and $3 $1";	#Diaz Christian and Shannon should = Christian and Shannon Diaz
				my $tmp2 = $4; #New Year's Eve
				my $tmp3 = $5; #20061230
				if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[DIAZ2X1] used\n======>  \$s=$s\n======> Right now: \$tmp1=$tmp1,\$tmp2=$tmp2,\$tmp3=$tmp3  <BR>\n"; }
				&add_tag("$party $tmp1 $tmp2 $tmp3",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp1 $tmp3 $tmp2",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp3 $tmp1 $tmp2",$file,$tmporiginaltag,"",$mode);

				#20080423
				#NEXT LINE IS FOR WHEN $TMP2 = CHILI COOK OFF - we want "party chili cook-off brad and mandy 2007" ... if it's not a catch-all, we'll have to fix this.
				&add_tag("$party $tmp2 $tmp3 $tmp1",$file,$tmporiginaltag,"",$mode);
				$s="";				
			} elsif ($s =~ /^([0-9\#A-Za-z\s\']+)[\s\-]([0-9\#a-z\s\-\']+)[\s\-]([12][0-9][0-9][0-9]*)$/) {		#party-something-something-YYYYMMDD
				my $tmp1 = $1;	#Britt and Chris	#Neigh Chris
				my $tmp2 = $2;	#New Year's Eve		#birthday
				my $tmp3 = $3;	#20061230			#20060603
				if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[caAA] used\n======>  \$s=$s\n======> Right now: \$tmp1=$tmp1,\$tmp2=$tmp2,\$tmp3=$tmp3  <BR>\n"; }
				$tmp1=&fix_name_of_any_form($tmp1);																		#now covered by fix_name_of_any_form:				if ($tmp1 !~ / and /) { $tmp1 =~ s/([a-z]+) ([a-z]+)/$2 $1/i; }
				&add_tag("$party $tmp1 $tmp2 $tmp3",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp1 $tmp3 $tmp2",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp3 $tmp1 $tmp2",$file,$tmporiginaltag,"",$mode);
				$s="";		
#			:event-Party-20070704-Scott and Melanie-4th Of July
			} elsif ($s =~ /^([12][0-9][0-9][0-9]*)[\s\-]([a-z\s\']+)-([0-9\#a-z\s\']+)$/i) {
				if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[SMCPX] used\n======>  \$s=$s\n======> Right now: \$tmp1=$tmp1,\$tmp2=$tmp2,\$tmp3=$tmp3,\$tmp4=$tmp4  <BR>\n"; }
				my $tmp1 = $1;	#20061230			
				my $tmp2 = $2; #Scott and Melanie
				my $tmp3 = $3; #4th Of July
				if ($tmp2 !~ / and /) { $tmp2 =~ s/^([a-z]+) ([a-z]+)$/$2 $1/i; }
				if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[caAA] used\n======>  \$s=$s\n======> Right now: \$tmp1=$tmp1,\$tmp2=$tmp2,\$tmp3=$tmp3,\$tmp4=$tmp4  <BR>\n"; }
				&add_tag("$party $tmp1 $tmp2 $tmp3",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp2 $tmp1 $tmp3",$file,$tmporiginaltag,"",$mode);
				&add_tag("$party $tmp3 $tmp1 $tmp2",$file,$tmporiginaltag,"",$mode);
				$s="";		

			} elsif ($s =~ /^([0-9\#a-zA-Z\s\']+)[\-\s]([0-9\#a-zA-Z\s\-\']+)[\-\s]([12][0-9][0-9][0-9]*)-(.*)$/i) {
				my $tmp1 = $1;	#Britt and Chris
				my $tmp2 = $2;	#New Year's Eve
				my $tmp3 = $3;	#20061230
				my $tmp4 = $4;	#Breast Cancer Benefit

				if (($tmp2 =~ /^birthday$/i) && ($tmp4 =~ / and .*birthday/i)) {
					my $tmp5="";
					if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[CXPPM2] used\n======>  \$s=$s\n======> Right now: \$tmp1=$tmp1,\$tmp2=$tmp2,\$tmp3=$tmp3,\$tmp4=$tmp4  <BR>\n"; }
					#$tmp1=Wright Lauren,$tmp2=birthday,$tmp3=20080920,$tmp4=Lauren Wright and Carol Bui's birthday 

					$tmp1 = &fix_name_of_any_form($tmp1);

					#birthday party
					&add_tag("birthday party",$file,$tmporiginaltag,"",$mode);
					
					#party birthday Lauren Wright and Carol Bui 20080920 + inversion + each name individually
					$tmp5 = "$tmp2 $tmp4 $tmp3";	
					$tmp5 =~ s/$tmp1 $tmp1/$tmp1/i;		
					$tmp5 =~ s/\'s birthday( [12])/$1/i;
					&add_tag("$party $tmp5",$file,$tmporiginaltag,"",$mode);
					$tmp5 =~ s/([a-z]+ [a-z]+) and ([a-z]+ [a-z]+)/$2 and $1/i;	#invert
					&add_tag("$party $tmp5",$file,$tmporiginaltag,"",$mode);
					&add_tag("$party $tmp2 $1 $tmp3",$file,$tmporiginaltag,"",$mode);		#party birthday Lauren Wright 2008
					&add_tag("$party $tmp2 $2 $tmp3",$file,$tmporiginaltag,"",$mode);		#party birthday Carol Bui 2008
					&add_tag("$1's birthday $party",$file,$tmporiginaltag,"",$mode);			#Lauren Wright's birhtday party
					&add_tag("$1's birthday $party $tmp3",$file,$tmporiginaltag,"",$mode);	#Lauren Wright's birhtday party 2008
					&add_tag("$2's birthday $party",$file,$tmporiginaltag,"",$mode);			#Carol Bui's birhtday party
					&add_tag("$2's birthday $party $tmp3",$file,$tmporiginaltag,"",$mode);	#Carol Bui's birhtday party 2008

					#party Lauren Wright 20080920 Lauren Wright and Carol Bui's birthday  - no inversion; 1 host for 2 guests means the host is the same
					$tmp5="$tmp1 $tmp3 $tmp4";
					&add_tag("$party $tmp5",$file,$tmporiginaltag,"",$mode);

					#party Lauren Wright and Carol Bui's birthday 20080920 + inversion
					$tmp5="$tmp4 $tmp3";
					&add_tag("$party $tmp5",$file,$tmporiginaltag,"",$mode);
					$tmp5 =~ s/([a-z]+ [a-z]+) and ([a-z]+ [a-z]+)/$2 and $1/i;	#invert
					&add_tag("$party $tmp5",$file,$tmporiginaltag,"",$mode);

					#party 20080920 Lauren Wright and Carol Bui's birthday - no inversion necessary; there's only one party 20080920
					$tmp5 = "$tmp3 $tmp1 $tmp4";	
					$tmp5 =~ s/$tmp1 $tmp1/$tmp1/i;		
					&add_tag("$party $tmp5",$file,$tmporiginaltag,"",$mode);

					#Lauren Wright and Carol Bui's birthday + inversion
					&add_tag("$tmp4"                        ,$file,$tmporiginaltag,"",$mode);
					$tmp4 =~ s/([a-z]+ [a-z]+) and ([a-z]+ [a-z]+)/$2 and $1/i;	#invert
					&add_tag("$tmp4"                        ,$file,$tmporiginaltag,"",$mode);
					$s="";		
				} else {
					if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[CXPPM1] used\n======>  \$s=$s\n======> Right now: \$tmp1=$tmp1,\$tmp2=$tmp2,\$tmp3=$tmp3,\$tmp4=$tmp4  <BR>\n"; }
					&add_tag("$party $tmp2 $tmp1 $tmp3 $tmp4",$file,$tmporiginaltag,"",$mode);
					&add_tag("$party $tmp3 $tmp2 $tmp1 $tmp4",$file,$tmporiginaltag,"",$mode);
					#not sure if this is smart:
					#only case so far is "Breast Cancer Benefit"
					&add_tag("$tmp4"                        ,$file,$tmporiginaltag,"",$mode);
					$s="";		
				}

			#############final party catch-alls:
			} elsif ($s =~ /^([0-9\#\'a-z\s]+)\-([0-9\#\'a-z\s]+)\-([12][0-9][0-9][0-9][0-9]*)$/i) {
				#======> tmp1=Belefski Chris,tmp2=New Year's Chili Cookoff,tmp3=20101231 
				my $tmp1 = $1;
				my $tmp2 = $2;
				my $tmp3 = $3;
				if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[CQBM] used\n======> <BR> \$s=$s <BR> ======> tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3 <BR>\n"; }
				$tmp1 = &fix_name_of_any_form($tmp1);
				&add_tag("$party $tmp1"            ,$file,$tmporiginaltag,0,$mode);	#party Chris Belefski
				&add_tag("$party $tmp1 $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#party Chris Belefski Chili CookOff
				&add_tag("$party $tmp1 $tmp2 $tmp3",$file,$tmporiginaltag,0,$mode);	#party Chris Belefski Chili CookOff 20101031
				&add_tag("$party $tmp1 $tmp3"      ,$file,$tmporiginaltag,0,$mode);	#party Chris Belefski 20101031
				&add_tag("$party $tmp1 $tmp3 $tmp2",$file,$tmporiginaltag,0,$mode);	#party Chris Belefski 20101031 Chili CookOff
				&add_tag("$party $tmp2"            ,$file,$tmporiginaltag,0,$mode);	#party Chili Cookoff
				&add_tag("$party $tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);	#party Chili Cookoff Chris Belefski
				&add_tag("$party $tmp2 $tmp1 $tmp3",$file,$tmporiginaltag,0,$mode);	#party Chili Cookoff Chris Belefski 20101031
				&add_tag("$party $tmp2 $tmp3"      ,$file,$tmporiginaltag,0,$mode);	#party Chili Cookoff 20101031
				&add_tag("$party $tmp2 $tmp3 $tmp1",$file,$tmporiginaltag,0,$mode);	#party Chili Cookoff 20101031 Chris Belefski
				&add_tag("$party $tmp3"            ,$file,$tmporiginaltag,0,$mode);	#party 20101031
				&add_tag("$party $tmp3 $tmp1"      ,$file,$tmporiginaltag,0,$mode);	#party 20101031 Chris Belefski
				&add_tag("$party $tmp3 $tmp1 $tmp2",$file,$tmporiginaltag,0,$mode);	#party 20101031 Chris Belefski Chili Cookoff
				&add_tag("$party $tmp3 $tmp2 $tmp1",$file,$tmporiginaltag,0,$mode);	#party 20101031 Chili Cookoff Chris Belefski
				$s="";

			
			#just added 0-9\# to the following, hope that doesn't break stuff (20070301):
			} elsif ($s =~ /^([0-9\#\'a-z\s\-]+)[\s\-]([12][0-9][0-9][0-9]*)$/i) {
				my $tmp1 = $1;
				my $tmp2 = $2;
				if ($DEBUG_EVENT_PARTY) { print "======>  catch-all[CABBB] used\n======> <BR> \$s=$s <BR> ======> tmp1=$tmp1,tmp2=$tmp2 <BR>\n"; }
				$tmp1 =~ s/\-/ /g;
				$s = "$party $tmp2 $tmp1";
				if ($DEBUG_EVENT_PARTY) { print "======>  s changed to \"$s\" <BR>\n"; }
				#no longer necessary $s =~ s/-Halloween/ Halloween/i;
				$s =~ s/Pre Construction/Pre-Construction/i;
				&add_tag("$s",$file,$tmporiginaltag,"",$mode);
				$s="";
			}
			$s =~ s/-Halloween/ Halloween/i;
			if ($DEBUG_EVENT_PARTY) { print "======>  [5D-END BIG_IF]  \$s is $s  <BR>\n"; }
		} elsif ($s =~ /^funeral-/i) {
			#$s =~ s/funeral-([a-z]+) ([a-z]+)/$2 $1's funeral/i;
			$s =~ s/funeral-([^\-]*)//;
			my $tmp1 = &fix_name_of_any_form($1);
			&add_tag("funeral of $tmp1",$file,$tmporiginaltag,0,$mode);
			&add_tag($tmp1."'s funeral",$file,$tmporiginaltag,0,$mode);
			&add_tag("funeral"         ,$file,$tmporiginaltag,0,$mode);
		# ( this is still event )
		} elsif ($s =~ /^confirmation-/i) {
			if ($s =~ /confirmation-([a-z]+) ([a-z]+)/i) {
				$s =~ s/confirmation-([a-z]+) ([a-z]+)/$2 $1's confirmation/i;
				$tmp = "$2 $1"; 
			} elsif ($s =~ /confirmation-([a-z]+)/i) {
				$s =~ s/confirmation-([a-z]+)/$1's confirmation/i;
				$tmp = "$1"; 
			}
			#$tmp =~ s/\s\s/ /g;
			&add_tag("confirmation"        ,$file,$tmporiginaltag,"",$mode);
			&add_tag("confirmation of $tmp",$file,$tmporiginaltag,"",$mode);
		} elsif ($s =~ /^graduation-/i) {
			&add_tag("graduation",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^graduation-//i;
			if ($s =~ /^(.*) (.*)-college/i) {
				$s =~ s/^(.*) (.*)-college/$2 $1's college graduation/i;
			} elsif ($s =~ /^(.*)-college/i) {
				$s =~ s/^(.*)-college/$1's college graduation/i;
			} elsif ($s =~ /^(.*)-high school/i) {
				$s =~ s/^(.*)-high school/$1's high school graduation/i;
			}
		} elsif ($s =~ /^reunion-/i) {
			&add_tag("reunion",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^reunion-//i;
			if ($s =~ /^high school-/i) {
				&add_tag("high school reunion",$file,$tmporiginaltag,"",$mode);
				$s =~ s/^high school-//i;
			}
			#DEBUG: print "[9QWER] \$s is now $s<BR>\n";
			if ($s =~ /^(.* high school)-(Class Of [0-9]+)/i) {
				&add_tag("$1",$file,$tmporiginaltag,"",$mode);
				&add_tag("$2",$file,$tmporiginaltag,"",$mode);
				&add_tag("$1 $2",$file,$tmporiginaltag,"",$mode);
				$s =~ s/^(.* high school)-(Class Of [0-9]+)//i;
			}



		} elsif (($s =~ /^(convention)-(.*)-([0-9]+)$/i)) {			#event catch-all for event1-event2-YYYY[MMDD] tagged as "event1,event1 YYYY[MMDD],event1 event2,event1 event2 YYYY[MMDD],event2,event2 event1,event2 YYYY[MMDD],event2 event1 YYYY[MMDD]" and captioned (if we captioned events) as "event2 event1"
			$tmp1=$1;	#convention
			$tmp2=$2;	#AnimeUSA
			$tmp3=$3;	#2008
			&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);	#convention
			&add_tag("$tmp1 $tmp3"      ,$file,$tmporiginaltag,0,$mode);	#convention 2008
			&add_tag("$tmp1 $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#convention AnimeUSA
			&add_tag("$tmp1 $tmp2 $tmp3",$file,$tmporiginaltag,0,$mode);	#convention AnimeUSA 2008
			&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);	#AnimeUSA
			&add_tag("$tmp2 $tmp3"      ,$file,$tmporiginaltag,0,$mode);	#AnimeUSA 2008
			&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);	#AnimeUSA convention
			&add_tag("$tmp2 $tmp1 $tmp3",$file,$tmporiginaltag,0,$mode);	#AnimeUSA convention 2008
			$s="";
		} elsif ($s =~ /^(standup comedy)-(.*)-([0-9]+)$/i) {			#event catch-all for stand-up comedy ...
			$tmp1=$1;	#standup comedy
			$tmp2=$2;	#kevin nealon
			$tmp3=$3;	#2008
			$tmp2=&fix_name_of_any_form($tmp2);
			if ($DEBUG_EVENT) { print "<BR>STANDUP COMEDY: [tmp1/2/3=$tmp1/$tmp2/$tmp3]<BR>\n"; }
			#
			&add_tag("$tmp1"            ,$file,$tmporiginaltag,0,$mode);	#standup comedy
			&add_tag("$tmp1 $tmp3"      ,$file,$tmporiginaltag,0,$mode);	#standup comedy 20081231
			&add_tag("$tmp1 $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#standup comedy Kevin Nealon
			&add_tag("$tmp1 $tmp2 $tmp3",$file,$tmporiginaltag,0,$mode);	#standup comedy Kevin Nealon 20081231
			&add_tag("$tmp1 $tmp3 $tmp2",$file,$tmporiginaltag,0,$mode);	#standup comedy 20081231 Kevin Nealon 
			&add_tag("$tmp2"            ,$file,$tmporiginaltag,0,$mode);	#Kevin Nealon
			&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,0,$mode);	#Kevin Nealon standup comedy
			&add_tag("$tmp2 $tmp1 $tmp3",$file,$tmporiginaltag,0,$mode);	#Kevin Nealon standup comedy 20081231
			&add_tag("$tmp2 $tmp3"      ,$file,$tmporiginaltag,0,$mode);	#Kevin Nealon 20081231 
			&add_tag("$tmp2 $tmp3 $tmp1",$file,$tmporiginaltag,0,$mode);	#Kevin Nealon 20081231 standup comedy
			$s="";
		} elsif ($s =~ /^prom-/i) {
			&add_tag("prom",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^Prom-(.*) (.*)$/prom $2 $1/i;
			$s =~ s/^Prom-(.*)$/prom $1/i;
			$s =~ s/Prom Carolyn Lipinski/Prom Carolyn/;
			$s =~ s/Prom Clint Lipinski/Prom Clint/;
		} elsif ($s =~ /^concert-/i) {
			$tmp1=$1;
			$STOP_ALL_CAPTIONING=1;
			&add_tag("music"  ,$file,$tmporiginaltag, 0,$mode);
			&add_tag("concert",$file,$tmporiginaltag, 0,$mode);
			$s =~ s/^concert-//i;
			$s =~ s/^(.*)-([0-9]+)$/$1 concert $2/;
			if ($1 ne "") { 
				&add_tag($1          ,$file,$tmporiginaltag,0,$mode); 
				&add_tag("$1 concert",$file,$tmporiginaltag,0,$mode); 
			}
			if ($s =~ /(.*) concert ([12][0-9][0-9][0-9][0-9]*)/) {
				$tmp = $s;
				$tmp =~ s/(.*) concert ([12][0-9][0-9][0-9][0-9]*)/concert $2 $1/;
				&add_tag($tmp           ,$file,$tmporiginaltag, 0,$mode); 
				&add_tag("concert $1 $2",$file,$tmporiginaltag, 0,$mode); 
				&add_tag("concert $2 $1",$file,$tmporiginaltag, 0,$mode); 
				&add_tag("concert $1"   ,$file,$tmporiginaltag, 0,$mode); 
				&add_tag("concert $2"   ,$file,$tmporiginaltag, 0,$mode); 
				&add_tag("$1 concert"   ,$file,$tmporiginaltag, 0,$mode); 
				&add_tag("$1 concert $2",$file,$tmporiginaltag, 0,$mode); 
			}
			$STOP_ALL_CAPTIONING=0;
			$s="";
			&add_tag("entertainment-music-$tmp1",$file,$tmporiginaltag,"",$mode); 
		# ( this is still event )
		} elsif ($s =~ /^family reunion-/i) {
			&add_tag(       "reunion",$file,$tmporiginaltag,"",$mode);
			&add_tag("family reunion",$file,$tmporiginaltag,"",$mode);
			if ($s =~  /family reunion-(.*)-([12][0-9][0-9][0-9][0-1]?[0-9]?[0-3]?[0-9]?)/i) {
				$s =~ s/family reunion-(.*)-([12][0-9][0-9][0-9][0-1]?[0-9]?[0-3]?[0-9]?)/$1 family reunion $2/i;
				&add_tag("$s",$file,$tmporiginaltag,"",$mode);
				$s =~ s/family reunion .*$/family reunion/i;
			} elsif ($s =~ /family reunion-(.*)$/i) {
				$s =~ s/family reunion-(.*)$/$1 family reunion/;
			}
		} elsif (($s =~ /^(trip)-([^\-]*)-([^\-]*)-([^\-]*)$/i) || ($s =~ /^(vacation)-([^\-]*)-([^\-]*)-([^\-]*)$/i)) {		#vacation-Cape Code-2010 for example
				#DEBUG: event-trip-New York-New York City-20101009
				my $tmp1=$1;					#trip/vacation
				my $tmp2=$2;					#state
				my $tmp3=$3;					#city
				my $tmp4=$4;					#date
				#if (1) { print "[DEBUG-TRIP-4CHAINB: tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3,tmp4=$tmp4,s=<B>$s</B>] <BR>\n"; }
				&add_tag("$tmp1"               ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$tmp1 $tmp4"         ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$tmp1 to $tmp3"      ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$tmp1 to $tmp3 $tmp4",$file,$tmporiginaltag,0,$mode);
				$s="";
		} elsif (($s =~ /^(trip)-([^\-]*)-([^\-]*)/i) || ($s =~ /^(vacation)-([^\-]*)-([^\-]*)/i)) {		#vacation-Cape Code-2010 for example
				my $tmp1=$1; 
				my $tmp2=$2; 
				my $tmp3=$3;
				&add_tag("$tmp1"               ,$file,$tmporiginaltag, 0,$mode);
				&add_tag("$tmp1 $tmp3"         ,$file,$tmporiginaltag, 0,$mode);
				&add_tag("$tmp1 to $tmp2"      ,$file,$tmporiginaltag, 0,$mode);
				&add_tag("$tmp1 to $tmp2 $tmp3",$file,$tmporiginaltag, 0,$mode);
				&add_tag("$tmp1 to $tmp2"      ,$file,$tmporiginaltag, 0,$mode);
				$s="";
		} elsif (($s =~ /^(trip)-(.*)/i) || ($s =~ /^(vacation)-(.*)/i)) {
				$tmp1=$1; $tmp2=$2;
				$s =~ s/$tmp1-/$tmp1 to /i;								#If you change this line, you need to look on flickr's alltags and update any tripto/vacationto tags to not have 'to' anymore
				&add_tag("$tmp1"         ,$file,$tmporiginaltag, 0,$mode);
				&add_tag("$tmp1 to $tmp2",$file,$tmporiginaltag, 0,$mode);
				$s="";
		} elsif (($s =~ /^(wedding)-/i) || ($s =~ /^(baby shower)-/i)) {			#:event-wedding-Lipinski Clio And Carolyn Sawyer-honeymoon
			my $tmpEventType=lc($1);
			&add_tag("$tmpEventType",$file,$tmporiginaltag,0,$mode);
			$s =~ s/^$tmpEventType-//i;
			if ($s =~ /-Honeymoon$/i) {
					&add_tag("honeymoon",$file,$tmporiginaltag,0,$mode);
					$s =~ s/Lipinski Clint and Carolyn Sawyer-Honeymoon/Clint and Carolyn's honeymoon/i;			#necessary for backward compatibility with our honeymoon tagging
					$s =~ s/Lipinski Carolyn and Clio Sawyer-Honeymoon/Clio and Carolyn's honeymoon/i;				#necessary for backward compatibility with our honeymoon tagging
					$s =~ s/Sawyer Clio and Lipinski Carolyn-Honeymoon/Clio and Carolyn's honeymoon/i;				#necessary for backward compatibility with our honeymoon tagging
					$s =~ s/Sawyer Claire and Lipinski Carolyn-Honeymoon/Claire and Carolyn's honeymoon/i;			#necessary for backward compatibility with our honeymoon tagging
			} else {
				if (($s =~ /-(reception)$/i) || ($s =~ /-(rehearsal)$/i) ||  ($s =~ /-(preparation)$/i)) {
					my $tmp1=$1;
					&add_tag("wedding $tmp1",$file,$tmporiginaltag,0,$mode);
					&add_tag("$tmp1"        ,$file,$tmporiginaltag,0,$mode);
					$s =~ s/-$tmp1$//i;
				}
				if ($s =~ /-rehearsal-dinner$/i) {
					&add_tag("wedding rehearsal"       ,$file,$tmporiginaltag,0,$mode);
					&add_tag("wedding rehearsal dinner",$file,$tmporiginaltag,0,$mode);
					&add_tag("rehearsal"               ,$file,$tmporiginaltag,0,$mode);
					&add_tag("rehearsal dinner"        ,$file,$tmporiginaltag,0,$mode);
					&add_tag("dinner"                  ,$file,$tmporiginaltag,0,$mode);
					$s =~ s/-rehearsal-dinner$//i;
				}
				if ($s =~ /-honeymoon$/i) {
					&add_tag("honeymoon",$file,$tmporiginaltag,0,$mode);
					$s =~ s/-honeymoon$//i;
				}

				#BRITT'S WEDDING EXCEPTIONS:
				$s =~ s/Sweet Chuck and Britt Lipinski/Britt and Chuck/i;
				$s =~ s/Neigh Chris and Britt Lipinski/Britt and Chris/i;

				if ($DEBUG_WEDDING) { print "<B>[WEDDING-A] \$s is $s!...</B><BR>\n"; }
				if ($s =~ /^([^\s]+) ([^\s]+)$/) {
					if ($DEBUG_WEDDING) { print "<B>[WEDDING-CATCHALL-2NAME-WITHOUT-AND] \$s is $s!...</B><BR>\n"; }
					$s = "$2 $1";
					&add_tag("$tmpEventType $s"     ,$file,$tmporiginaltag, 0,$mode);
					&add_tag($s . "'s $tmpEventType",$file,$tmporiginaltag,"",$mode);
					$s="";
				} elsif ($s =~ /^([^\s]+) and ([^\s]+)$/) {
					my $tmp1=$1;
					my $tmp2=$2;
					if ($DEBUG_WEDDING) { print "<B>[WEDDING-CATCHALL-2NAME-WITH-AND] \$s is $s!...</B><BR>\n"; }
					&add_tag("$tmpEventType $s"     ,$file,$tmporiginaltag, 0,$mode);
					&add_tag($s . "'s $tmpEventType",$file,$tmporiginaltag,"",$mode);
					$s="";
				} elsif ($s =~ /^([^\s]+) ([^\s]+) and ([^\s]+) ([^\s]+)$/) {
					my $tmp1=$1;
					my $tmp2=$2;
					my $tmp3=$3;
					my $tmp4=$4;
					if ($DEBUG_WEDDING) { print "<B>[WEDDING-CATCHALL-4NAME] \$s is $s!...</B><BR>\n"; }
					$s = "$tmp2 $tmp1 and $tmp4 $tmp3";
					$s =~ s/Chris Swenson and Emily Henrich/Emily and Chris Swenson/i;						#couples where we want to list the female first for some reason, like relation
					&add_tag("$tmpEventType $s"     ,$file,$tmporiginaltag, 0,$mode);
					&add_tag($s . "'s $tmpEventType",$file,$tmporiginaltag,"",$mode);
					$s="";
				} elsif ($s =~ /^([^\s]+) and ([^\s]+) ([^\s]+)$/) {
					my $tmp1=$1;
					my $tmp2="$3 $2";
					if ($DEBUG_WEDDING) { print "<B>[WEDDING-CATCHALL-1NAME+2NAME] \$s is $s!...tmp1=$tmp1,tmp2=$tmp2;</B><BR>\n"; }
					$s = "$tmp1 and $tmp2";
					&add_tag("$tmpEventType $s"     ,$file,$tmporiginaltag, 0,$mode);
					&add_tag($s . "'s $tmpEventType",$file,$tmporiginaltag,"",$mode);
					$s="";
				}

				if ($DEBUG_WEDDING) { print "<B>[WEDDING-B] \$s is $s!...</B><BR>\n"; }
				$s =~ s/^([^\s]+) ([^\s]+) and ([^\s]+)$/$tmpEventType $2 $1 and $3/;
				$s =~ s/^([^\s]+) ([^\s]+) and ([^\s]+) ([^\s]+)$/$tmpEventType $2 $1 and $4 $3/;	#was $4 $3 at end .. then 3 4.. now back to 4 3
				if ($DEBUG_WEDDING) { print "<B>[WEDDING-Z] \$s is $s!...</B><BR>\n"; }
			}

		# ( this is still event )
		} elsif ($s =~ /^holiday/i) {
			&add_tag("holiday",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^holiday-//i;
			if ($s =~ /([^\-]+)-([1-2][0-9][0-9][0-9])/i) {
				$s =~ s/([^\-]+)-([1-2][0-9][0-9][0-9])/$1 $2/i;
				my $tmp=$2;
				&add_tag($1,$file,$tmporiginaltag,"",$mode);
				if ($s =~ /Independence Day/i) {
					&add_tag("Independence Day $tmp",$file,$tmporiginaltag,"",$mode);
					$s =~ s/Independence Day/4th Of July/i;
					&add_tag("4th Of July"        ,$file,$tmporiginaltag,"",$mode);
					&add_tag("4th Of July holiday",$file,$tmporiginaltag,"",$mode);
				} elsif ($s =~ /Christmas/i) {
					&add_tag("Christmas $tmp"   ,$file,$tmporiginaltag,"",$mode);
					&add_tag("Christmas"        ,$file,$tmporiginaltag,"",$mode);
					&add_tag("Christmas holiday",$file,$tmporiginaltag,0,$mode);
				}
			}
		#let's develop a CATCHALL for eventtype-Name Name-date		#birthday of double-named people
		} elsif ($s =~ /^(birthday)-(.+) (.+)-([0-9]+)$/i) {
			my $tmp1=$1;		#event subtype [i.e. birthday]
			my $tmp2=$4;		#date
			my $tmp3="$3 $2";	#name
			#DEBUG: print "[BIRTHDAY-1] [tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3] <BR>\n";
			&add_tag("$tmp1"                   ,$file,$tmporiginaltag, 0,$mode);	#birthday
			&add_tag("$tmp3" . "'s $tmp1"      ,$file,$tmporiginaltag,"",$mode);	#John Smith's birthday
			&add_tag("$tmp3" . "'s $tmp1 $tmp2",$file,$tmporiginaltag, 0,$mode);	#John Smith's birthday 2007
			&add_tag("$tmp1 $tmp3"             ,$file,$tmporiginaltag, 0,$mode);	#birthday John Smith 
			&add_tag("$tmp1 $tmp3 $tmp2"       ,$file,$tmporiginaltag, 0,$mode);	#birthday John Smith 2007
			$s="";
		} elsif ($s =~ /^(birthday)-(.+)-([0-9]+)$/i) {				#birthday's of single-named people
			$tmp1=$1;		#event subtype [i.e. visit,etc]
			$tmp2=$3;		#date
			$tmp3=$2;		#name
			&add_tag("$tmp1"                   ,$file,$tmporiginaltag, 0,$mode);
			&add_tag("$tmp3" . "'s $tmp1"      ,$file,$tmporiginaltag,"",$mode);
			&add_tag("$tmp3" . "'s $tmp1 $tmp2",$file,$tmporiginaltag, 0,$mode);
			$s="";
		} elsif ($s =~ /^(art show)-(.*)-(.*)$/i) {
			$tmp1=$1;	#art show
			$tmp2=$2;	#art-o-matic
			$tmp3=$3;	#date
			&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#art show
			&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#art-o-matic
			&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag,"",$mode);		#art-o-matic art show
			&add_tag("$tmp2 $tmp3"      ,$file,$tmporiginaltag,"",$mode);		#art-o-matic 2007
			$s="";
		} elsif ($s =~ /^(visit)-(.+) (.+)-([0-9]+)$/i) {
			$tmp1=$1;		#event subtype [i.e. visit,etc]
			$tmp2=$4;		#date
			$tmp3="$3 $2";	#name
			&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);
			&add_tag("$tmp1"."ing"      ,$file,$tmporiginaltag, 0,$mode);
			&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag,"",$mode);
			&add_tag("$tmp3 $tmp1 $tmp2",$file,$tmporiginaltag, 0,$mode);
			#$s =~ s/^visit-(.+) (.+)-([0-9]+)$/$2 $1 visits $3/i;
			$s="";
		} elsif ($s =~ /^(rave)-(.*)-([0-9]+)$/i) {								#event-type-Name-date catch-all
			$tmp1=$1;		#event type [i.e. rave,etc]
			$tmp2=$2;		#event name [i.e. Starscape]
			$tmp3=$3;		#event date
			&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#rave
			&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#Starscape
			&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#Starscape rave
			&add_tag("$tmp2 $tmp3"      ,$file,$tmporiginaltag, 0,$mode);		#Starscape 20070731
			$s="";
		} elsif ($s =~ /^(SubGenius)-(devival)-([^\-]*)-([0-9]+)$/i) {			#SubGenius-devival-CITY-DATE
			my $tmp1=$1;															#SubGenius
			my $tmp2=$2;															#devival
			my $tmp3=$3;															#city
			my $tmp4=$4;															#date
			&add_tag("$tmp1"                  ,$file,$tmporiginaltag, 0,$mode);		#SubGenius
			&add_tag("$tmp1 $tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#SubGenius devival
			&add_tag("$tmp1 $tmp2 $tmp3"      ,$file,$tmporiginaltag, 0,$mode);		#SubGenius devival New York City
			&add_tag("$tmp1 $tmp2 $tmp3 $tmp4",$file,$tmporiginaltag, 0,$mode);		#SubGenius devival New York City DATE
			&add_tag("$tmp1 $tmp2 $tmp4"      ,$file,$tmporiginaltag, 0,$mode);		#SubGenius devival DATE
			&add_tag("$tmp2"                  ,$file,$tmporiginaltag, 0,$mode);		#devival
			&add_tag("$tmp2 $tmp4"            ,$file,$tmporiginaltag, 0,$mode);		#devival DATE
			$s="";
		} elsif ($s =~ /^(Parade)-(.*)-(.*)-(.*)-([0-9]*)$/i) {						#:event-Parade-Pride-Washington DC-Capital Pride-2018
			if ($DEBUG_EVENT) { print "<B>[EVCA-PARADE]</B>[s=$s][1=$1,2=$2,3=$3,4=$4,5=$5] "; }
			my $tmp1=$1;																	#parade
			my $tmp2=$2;																	#pride [could also be a holiday parade]
			my $tmp3=$3;																	#Washington DC
			my $tmp4=$4;																	#capital pride
			my $tmp5=$5;																	#2018
			&add_tag("$tmp1"                        ,$file,$tmporiginaltag, 0,$mode);		#parade
			&add_tag("$tmp2"                        ,$file,$tmporiginaltag, 0,$mode);		#Pride
			&add_tag("$tmp2 $tmp1"                  ,$file,$tmporiginaltag, 0,$mode);		#Pride parade
			&add_tag("$tmp2 $tmp1 $tmp5"            ,$file,$tmporiginaltag, 0,$mode);		#Pride parade 2018
			&add_tag("$tmp2 $tmp3"                  ,$file,$tmporiginaltag, 0,$mode);		#Pride Washington DC
			&add_tag("$tmp2 $tmp3 $tmp5"            ,$file,$tmporiginaltag, 0,$mode);		#Pride Washington DC 2018
 			&add_tag("$tmp2 $tmp4"                  ,$file,$tmporiginaltag, 0,$mode);		#Pride Capital Pride
 			&add_tag("$tmp2 $tmp4 $tmp5"            ,$file,$tmporiginaltag, 0,$mode);		#Pride Capital Pride 2018
			&add_tag("$tmp2 $tmp5"                  ,$file,$tmporiginaltag, 0,$mode);		#Pride 2018
			&add_tag("$tmp3"                        ,$file,$tmporiginaltag, 0,$mode);		#Washington DC
			&add_tag("$tmp3 $tmp1"                  ,$file,$tmporiginaltag, 0,$mode);		#Washington DC parade
			&add_tag("$tmp3 $tmp2 $tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#Washington DC pride parade
			&add_tag("$tmp3 $tmp2 $tmp1 $tmp5"      ,$file,$tmporiginaltag, 0,$mode);		#Washington DC pride parade 2018
			&add_tag("$tmp3 $tmp4 $tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#Washington DC capital pride parade
			&add_tag("$tmp3 $tmp4 $tmp2 $tmp1 $tmp5",$file,$tmporiginaltag, 1,$mode);		#Washington DC capital pride parade 2018
			&add_tag("$tmp4"                        ,$file,$tmporiginaltag, 0,$mode);		#Capital Pride
			&add_tag("$tmp4 $tmp5"                  ,$file,$tmporiginaltag, 0,$mode);		#Capital Pride 2018
			&add_tag("$tmp4 $tmp1"                  ,$file,$tmporiginaltag, 0,$mode);		#Capital Pride parade
			&add_tag("$tmp4 $tmp1 $tmp5"            ,$file,$tmporiginaltag, 0,$mode);		#Capital Pride parade 2018
			&add_tag("$tmp4 $tmp2 $tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#Capital Pride Pride parade
			&add_tag("$tmp4 $tmp2 $tmp1 $tmp5",     ,$file,$tmporiginaltag, 0,$mode);		#Capital Pride Pride parade 2018
			&add_tag("$tmp5"                        ,$file,$tmporiginaltag, 0,$mode);		#2018
			$s="";
		} elsif ($s =~ /^(SubGenius)-(devival)-([^\-]*)-([0-9]+)-([^\-]*)$/i) {		#SubGenius-devival-CITY-DATE-clench
			my $tmp1=$1;																#SubGenius
			my $tmp2=$2;																#devival
			my $tmp3=$3;																#city
			my $tmp4=$4;																#date
			my $tmp5=$5;																#clench
			&add_tag("$tmp1"                  ,$file,$tmporiginaltag, 0,$mode);		#SubGenius
			&add_tag("$tmp1 $tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#SubGenius devival
			&add_tag("$tmp1 $tmp2 $tmp3"      ,$file,$tmporiginaltag, 0,$mode);		#SubGenius devival New York City
			&add_tag("$tmp1 $tmp2 $tmp3 $tmp4",$file,$tmporiginaltag, 0,$mode);		#SubGenius devival New York City DATE
			&add_tag("$tmp1 $tmp2 $tmp4"      ,$file,$tmporiginaltag, 0,$mode);		#SubGenius devival DATE
			&add_tag("$tmp1 $tmp5 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#SubGenius GFY devival
			&add_tag("$tmp1 $tmp5 $tmp2 $tmp4",$file,$tmporiginaltag, 0,$mode);		#SubGenius GFY devival DATE
			&add_tag("$tmp2"                  ,$file,$tmporiginaltag, 0,$mode);		#devival
			&add_tag("$tmp2 $tmp4"            ,$file,$tmporiginaltag, 0,$mode);		#devival DATE
			&add_tag("$tmp2 $tmp5"            ,$file,$tmporiginaltag, 0,$mode);		#devival GFY
			&add_tag("$tmp2 $tmp5 $tmp4"      ,$file,$tmporiginaltag, 0,$mode);		#devival GFY DATE
			&add_tag("$tmp5 $tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#GFY devival
			&add_tag("$tmp5 $tmp2 $tmp4"      ,$file,$tmporiginaltag, 0,$mode);		#GFY devival DATE
			$s="";

			
		} elsif ($s =~ /^(wars*)-([^\-]*)$/i) {						#event1-event2-date tagged as "event1,event2"
																				
			$tmp1=$1;		#
			$tmp2=$2;		#	
			#tmp3=$3;		#
			&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#
			$s="";


			
		} elsif ($s =~ /^(Dark Odyssey)-([^\-]*)-([^\-]*)$/i) {						#event1-event2-date tagged as "event1,event1 event2,event1 event2 event3,event1 event3,event1 event3 event2,event3,event3 event2"
																				#
			$tmp1=$1;		#
			$tmp2=$2;		#	
			$tmp3=$3;		#
			&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp1 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp1 $tmp2 $tmp3",$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp1 $tmp3"      ,$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp1 $tmp3 $tmp2",$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp3"            ,$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#

			$s="";
		} elsif ($s =~ /^(ceremony)-([^\-]*)-([^\-]*)$/i) {						#event1-event2-date tagged as "event1,event2,event2 event1,event3,event3 event1,event3 event2,event3 event2 event1"
																				#only tested for event2=anniversary, event3=DDay ******
			$tmp1=$1;		#
			$tmp2=$2;		#	
			$tmp3=$3;		#
			&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp2"            ,$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp3"            ,$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#
			&add_tag("$tmp3 $tmp2 $tmp1",$file,$tmporiginaltag, 0,$mode);		#
			$s="";
		} elsif ($s =~ /^(standup comedy)-([^\-]*)-([0-9]+)$/i) {				#event1-event2-date tagged as "event1,event1 date,event2 event1,event2 event1 date,event2 date"
			$tmp1=$1;		#standup comedy
			$tmp2=$2;		#Brian Posehn
			$tmp3=$3;		#event date
			$tmp2=&fix_name_of_any_form($tmp2);
			&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#standup comedy
			&add_tag("$tmp1 $tmp3"      ,$file,$tmporiginaltag, 0,$mode);		#standup comedy 20071231
			&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#Brian Posehn standup comedy
			&add_tag("$tmp2 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#Brian Posehn standup comedy 20070131
			&add_tag("$tmp2 $tmp1 $tmp3",$file,$tmporiginaltag, 0,$mode);		#Brian Posehn standup comedy 20070131
			&add_tag("$tmp2 $tmp3"      ,$file,$tmporiginaltag, 0,$mode);		#Brian Posehn 20070123
			$s="";
		} elsif ($s =~ /^(surgery)-([^\-]*)-([^\-]*)-([0-9]+)$/i) {				#surgery events
			$tmp1=                      $1;		                                #surgery
			$tmp2=&fix_name_of_any_form($2);                                    #John Smith
			$tmp3=                      $3;		                                #gallbladder
			$tmp4=                      $4;		                                #19991231
			if ($DEBUG_EVENT) { print "<B>[EVCA-SURGERY]</B>[s=$s][1=$tmp1,2=$tmp2,3=$tmp3,4=$tmp4] "; }
			&add_tag("$tmp1"                       ,$file,$tmporiginaltag, 0,$mode);		#surgery
			&add_tag("$tmp1 $tmp2"                 ,$file,$tmporiginaltag, 0,$mode);		#surgery John Smith
			&add_tag("$tmp1 $tmp2 $tmp3"           ,$file,$tmporiginaltag, 0,$mode);		#surgery John Smith gallbladder
			&add_tag("$tmp1 $tmp2 $tmp3 $tmp4"     ,$file,$tmporiginaltag, 0,$mode);		#surgery John Smith gallbladder 20070131
			&add_tag($tmp2 . "'s $tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#John Smith's surgery
			&add_tag($tmp2 . "'s $tmp1 $tmp4"      ,$file,$tmporiginaltag, 0,$mode);		#John Smith's surgery 20071031
			&add_tag($tmp2 . "'s $tmp3 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#John Smith's gallbladder surgery
			&add_tag($tmp2 . "'s $tmp3 $tmp1 $tmp4",$file,$tmporiginaltag, 0,$mode);		#John Smith's gallbladder surgery 20071031
			&add_tag("$tmp3 $tmp1"                 ,$file,$tmporiginaltag, 0,$mode);		#gallbladder surgery 
			&add_tag("$tmp3 $tmp1 $tmp4"           ,$file,$tmporiginaltag, 0,$mode);		#gallbladder surgery 20071031
			$s="";
		} elsif ($s =~ /^(rave)-([0-9]+)-([^\-]*)$/i) {				#event1-date-event3 tagged as "event1,event1 date,event1 date event3,event1 event3,event1 event3 date,event3,event3 event1,event3 date,event3 event1 date,event3 date event1"	#this could end up being the event catchall for all EVENT-TYPE-YYYYMMDD-TITLE type events!!!
			$tmp1=$1;		#rave
			$tmp2=$2;		#DATE
			$tmp3=$3;		#TITLE
			&add_tag("$tmp1"            ,$file,$tmporiginaltag, 0,$mode);		#rave
			&add_tag("$tmp1 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#rave 20071231
			&add_tag("$tmp1 $tmp2 $tmp3",$file,$tmporiginaltag, 0,$mode);		#rave 20071231 TITLE
			&add_tag("$tmp1 $tmp3"      ,$file,$tmporiginaltag, 0,$mode);		#rave TITLE
			&add_tag("$tmp1 $tmp3 $tmp2" ,$file,$tmporiginaltag, 0,$mode);		#rave TITLE DATE
			&add_tag("$tmp3"            ,$file,$tmporiginaltag, 0,$mode);		#TITLE
			&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#TITLE rave
			&add_tag("$tmp3 $tmp2"      ,$file,$tmporiginaltag, 0,$mode);		#TITLE date
			&add_tag("$tmp3 $tmp1 $tmp2",$file,$tmporiginaltag, 0,$mode);		#TITLE rave date
			&add_tag("$tmp3 $tmp1 $tmp2",$file,$tmporiginaltag, 0,$mode);		#TITLE date rave
			$s="";
		} else {
			#EVENT CATCHALL / EVENT CATCH-ALL / GENERIC EVENT
			#general event-Whatever-1998
			#catch all event
			if ($DEBUG_EVENT) { print "[EVCA-PRE-IF][s=<i>$s</i>]  <BR>\n"; }
			if ($s =~  /^([^\-]*)-([^\-]*)-([12][0-9][0-9][0-9][01]*[0-9]*[0-3]*[0-9]*)$/i) {
				if ($DEBUG_EVENT) { print "<B>[EVCA-IF-1]</B>[s=$s][1=$1,2=$2,3=$3] "; }
				$tmp1=$1; $tmp2=$2; $tmp3=$3;

				### this may be if tmp1=anniversary...
				$tmp2=&fix_name_of_any_form($tmp2);
				&add_tag("$tmp1"                   ,$file,$tmporiginaltag, 0,$mode);		#anniversary
				&add_tag("$tmp2" . "'s $tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#Clio and Carolyn's anniversary
				&add_tag("$tmp2" . "'s $tmp1 $tmp3",$file,$tmporiginaltag, 0,$mode);		#Clio and Carolyn's anniversary
				&add_tag("$tmp1 $tmp2"             ,$file,$tmporiginaltag, 0,$mode);		#anniversary Clio and Carolyn's
				&add_tag("$tmp1 $tmp2 $tmp3"       ,$file,$tmporiginaltag, 0,$mode);		#anniversary Clio and Carolyn's 1998
				$s="";
			} elsif ($s =~  /^([^\-]*)-([12][0-9][0-9][0-9][01]*[0-9]*[0-3]*[0-9]*)$/i) { 
				$tmp1=$1; $tmp2=$2; $tmp3=$3;
				if ($DEBUG_EVENT) { print "[EVCA-IF-7][s=$s][tmp1=$tmp1,tmp2=$tmp2,tmp3=$tmp3] "; }
				$s =~ s/^(.*)\-([12][0-9][0-9][0-9][01]*[0-9]*[0-3]*[0-9]*)-*(.*)$/$1 $2 $3/;	
			} elsif ($s =~  /^([^\-]*)-([^\-]*)$/i) {										#ONLY ONE USED SO FAR: event-yard sale-goth = yard sale + goth yardsale
				$tmp1=$1; $tmp2=$2;
				if ($DEBUG_EVENT) { print "[EVCA-IF-10][s=$s][tmp1=$tmp1,tmp2=$tmp2] "; }
				&add_tag("$tmp1"      ,$file,$tmporiginaltag, 0,$mode);		#
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag, 0,$mode);		#
				$s="";
			} else {
				if ($DEBUG_EVENT) { print "[EVA CATCHALL WHICH MAY MEAN FAILURE][EVCA-IF-9][s=$s][1=$1,2=$2] "; }
				$s =~ s/^([^\-]*)\-([^\-]*)-([12][0-9][0-9][0-9][01]*[0-9]*[0-3]*[0-9]*)$/$1 $2 $3/;	
				if ($DEBUG_EVENT) { print "[AFTER:s now $s] "; }
			}
			$tmp1=$1;	$tmp2=$2;	$tmp3=$3;
			if ($DEBUG_EVENT) { print "<BR>\n[EVCA-POST-IF][\$s=$s/\$tmp1=$tmp1/\$tmp2=$tmp2/\$tmp3=$tmp3]<BR>\n";}

			#EVENTS WHICH DON'T HAVE DATES will end up with tmp1/2/3 all being "" ... utter failure. Collect the new $tmp1/2 here:
			if (($tmp1 eq "") && ($tmp2 eq "") && ($tmp3 eq "")) {
				if ($DEBUG_EVENT) { print "<BR>\n[EVCA-FIX-PRE][tmp1/2/3=\"\"!][s=$s]<BR>\n"; }
				if ($s =~ /^([^\-]+)-([^\-]+)$/) {
					$tmp1=$1;
					$tmp2=$2;
					$tmp3="";
				}
				if ($DEBUG_EVENT) { print "[EVCA-FIX-POST][tmp1/2=$tmp1/$tmp2]<BR>\n"; }
			}

			##### DO WE TAG TMP1?
			#we will usually also tag it without the date, but 
			#there are some exceptions we must accomodate -- for example, 
			#if the name of the event, "skiing", could be confused for an activity, "skiing"
			if ($tmp1 =~ /^skiing$/i) {		
				#do nothing					#don't tag it
			} else {						#do    tag it
				&add_tag("$tmp1",$file,$tmporiginaltag,0,$mode);
			}

			##### DO WE TAG TMP1 YYYYMMDD?
			#if it's just event1-YYYYMMDD we can finish up our business quickly
			if ($tmp2 =~ /^[12][0-9][0-9][0-9][1-2][0-9][0-3][0-9]$/) {
				&add_tag("$tmp1 $tmp2",$file,$tmporiginaltag,0,$mode);
				$s="";
			}

			if ($tmp1 =~ /^movie night$/) {
				&add_tag("$tmp1 $tmp2"      ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$tmp3 $tmp1"      ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$tmp3 $tmp1 $tmp2",$file,$tmporiginaltag,0,$mode);
			}
			if ($tmp1 =~ /^wedding shower$/) {
				$tmp2=&fix_name_of_any_form($tmp2);
				&add_tag("$tmp1 $tmp2"      ,$file,$tmporiginaltag,0,$mode);	#wedding shower name
				&add_tag($tmp2 . "'s $tmp1" ,$file,$tmporiginaltag,0,$mode);	#name's wedding shower
				$s="";
			}

		}
	}#endif event

	if ($s =~ /^(cameraperson)[\-\s](.*)/i) {
		if ($DEBUG_CAMERAPERSON) { print "<B>[CAMERAPERSON-DETECT-1]</B> [\$s=$s]<BR>\n"; }
		$TYPE = "cameraperson";
		$SUBTYPE = "";
		my $tmp1=$1; my $tmp2=$2;
		$tmp2 = &fix_name_of_any_form($tmp2);
		$s = "$tmp1 $tmp2";
		if ($DEBUG_CAMERAPERSON) { print "<B>[CAMERAPERSON-DETECT-2]</B> [\$s=$s]<BR>[\$cameraperson{\"$file$DELIMITER$tmp2\"}=\"1\";]<BR>\n"; }
		$cameraperson{"$file$DELIMITER$tmp2"}="1";
	}
	#elsif (($s =~ /^cameraperson /i) || ($s =~ /^cameraperson_SPC_/i)) {
		#This section used to be important, but nowadays, if we get here, it's only because we've successfully tagged it correctly.
		#OLD: die("FATAL ERROR: cameraperson tag needs a hyphen after, not a space! (s=$s)\n");
		#NO!: print "Discarding $s...\n";
		#NO!: &add_tag("$s",$file,$tmporiginaltag,0,$mode);
		#NO!: $s="";
	#}#endif cameraperson
	

	if ($s =~ /^entertainment-/i) {
		&add_tag("entertainment",$file,$tmporiginaltag,0,$mode);
		$TYPE = "entertainment";
		$SUBTYPE = "";
		$s =~ s/^entertainment-//;
		if ($s =~ /^video-/i) {
			&add_tag("video",$file,$tmporiginaltag,0,$mode);
			$s =~ s/^video-//;		
			if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[18] $file$DELIMITER"."video onto \%entertainment<BR>\n"; }
			$entertainment{"$file$DELIMITER" . "video"}=1;
		} elsif ($s =~ /^TV-/i) {
			$STOP_SYNONYM_ALIASES=1; &add_tag("TV",     $file,$tmporiginaltag, 0,$mode);
			$STOP_SYNONYM_ALIASES=0; &add_tag("TV show",$file,$tmporiginaltag,"",$mode);
			$s =~ s/^TV-//i;		
			if ($s =~ /^cartoons?-/i) {
				$s =~ s/^cartoons?-//i;
				&add_tag("cartoon",     $file,$tmporiginaltag,0,$mode);
				&add_tag("cartoons",    $file,$tmporiginaltag,0,$mode);
				&add_tag("cartoon show",$file,$tmporiginaltag,0,$mode);
				$entertainment{"$file$DELIMITER" . "cartoon"}=1;
			} 
			#NOT elsif:
			if ($s =~ /^anime\-?/i) {
				&add_tag("anime",             $file,$tmporiginaltag,0,$mode);
				&add_tag("Japanese",          $file,$tmporiginaltag,0,$mode);
				&add_tag("Japanese animation",$file,$tmporiginaltag,0,$mode);
				$s =~ s/^anime-?//i;
				$entertainment{"$file$DELIMITER" . "anime"}=1;
			}
			if ($s =~ /^live[ \-]action\-?/i) {
				die("FATAL ERROR: entertainment-TV-live action-ShowName tag used, should be entertainment-TV-live-ShowName \n\n tag=$s");
			}
			if ($s =~ /^live\-?/i) {
				&add_tag("live",            $file,$tmporiginaltag,0,$mode);
				&add_tag("live-action",     $file,$tmporiginaltag,0,$mode);
				&add_tag("live-action show",$file,$tmporiginaltag,0,$mode);
				$s =~ s/^live-?//i;
				$entertainment{"$file$DELIMITER" . "TV show"}=1;
			}
			#At this point, at least if it's a cartoon, we're left with $s that is either showname "South Park" or showname-charactername "South Park-Kenny"
			#If it's a character name, that's the only thing we really want captioned, right? I think. So we will treat it like a "thing chain", where only the last part is captioned
			#a thing chain is something that has 3-4 hyphens, but we only have 1, so we can kludge this to happen by adding thing---- in front of $s:
			if ($s =~ /\-/) {
				&add_tag("thing-----$s",$file,$tmporiginaltag,0,$mode);		$s = "";				#force it into thing chain catchall mode - tested and works!
			}
		} elsif ($s =~ /^movies?-?/i) {
			&add_tag("movies",$file,$tmporiginaltag, 0,$mode);					#200805 changed caption to 0	
			&add_tag("movie" ,$file,$tmporiginaltag, 0,$mode);					#200805 changed caption to 0	
			$s =~ s/^movies?-?//;		
			if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[7] $file$DELIMITER"."movie onto \%entertainment<BR>\n"; }
			$entertainment{"$file$DELIMITER" . "movie"}=1;
			#&add_tag("",$file,$tmporiginaltag,"",$mode);
		} elsif ($s =~ /^(play)-?(.*)$/i) {
			$tmp1=$1; $tmp2=$2;													#DEBUG:print "DEBUG023942 tmp1=$tmp1 tmp2=$tmp2 ...";
			$STOP_ALL_CAPTIONING=1;
			&add_tag("play"       ,$file,$tmporiginaltag,0,$mode);					
			if ($tmp2 ne "") {
				&add_tag("play: $tmp2",$file,$tmporiginaltag,1,$mode);	$STOP_ALL_CAPTIONING=0;
				&add_tag("$tmp2"      ,$file,$tmporiginaltag,0,$mode);					
			}
			$entertainment{"$file$DELIMITER" . "play"}=1;
			$s=""; $STOP_ALL_CAPTIONING=0;
		} elsif ($s =~ /^(magazine)-?(.*)$/i) {			#"entertainment1-entertainment2" tagged as "entertainment1,entertainment2,entertainment2 entertainment1" and captioned as "entertainment2 entertainment1"
			$tmp1=$1; $tmp2=$2;																	#DEBUG:print "DEBUG028742 tmp1=$tmp1 tmp2=$tmp2 ...";
			$STOP_ALL_CAPTIONING=1;
			&add_tag("$tmp1"       ,$file,$tmporiginaltag,0,$mode);								#magazine
			if ($tmp2 ne "") {
				&add_tag("$tmp2 $tmp1",$file,$tmporiginaltag,1,$mode);	$STOP_ALL_CAPTIONING=0;	#People Magazine
				&add_tag("$tmp2"      ,$file,$tmporiginaltag,0,$mode);							#People
			}
			$entertainment{"$file$DELIMITER" . "$tmp1"}=1;
			$s=""; $STOP_ALL_CAPTIONING=0;
		} elsif ($s =~ /^books?-?/i) {
			$STOP_ALL_CAPTIONING=1;
			&add_tag("books",$file,$tmporiginaltag,0,$mode);					
			&add_tag("book" ,$file,$tmporiginaltag,0,$mode);					
			$STOP_ALL_CAPTIONING=0;
			$s =~ s/^books?-?//;		
			if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[8] $file$DELIMITER"."movie onto \%entertainment<BR>\n"; }
			if ($s =~ /^([^\-]*)-([^\-]*)$/) {
				my $tmp1=$1;	#author 
				my $tmp2=$2;	#book
				$tmp1=&fix_name_of_any_form($tmp1);#
				#DEBUG: print "GOT HERE BOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOK[1] \"$s\" /$tmp1/$tmp2/";
				&add_tag("$tmp1"         ,$file,$tmporiginaltag,0,$mode);					
				&add_tag("$tmp2"         ,$file,$tmporiginaltag,0,$mode);					
				$s="$tmp1 - $tmp2";
				&add_tag("$tmp1 - $tmp2" ,$file,$tmporiginaltag,1,$mode);					
			} elsif ($s =~ /^([^\-]*)-([^\-]*)-([^\-]*)$/) {		#series
				my $tmp1=$1;	#author 
				my $tmp2=$2;	#book series
				my $tmp3=$3;	#book title
				$tmp1=&fix_name_of_any_form($tmp1);										#for the author name, not the book name
				#DEBUG: 		print "BOOK[2] \"$s\" tmp1/2/3=/$tmp1/$tmp2/$tmp3/";#
				&add_tag("$tmp1"              ,$file,$tmporiginaltag,0,$mode);		#author
				&add_tag("$tmp2"              ,$file,$tmporiginaltag,0,$mode);		#book series	
				&add_tag("$tmp2"              ,$file,$tmporiginaltag,0,$mode);		#book title
				&add_tag("book: $tmp2"        ,$file,$tmporiginaltag,0,$mode);		#book title "book"
				&add_tag("$tmp2 book"         ,$file,$tmporiginaltag,0,$mode);		#"book:" book title
				&add_tag("$tmp2: $tmp3"       ,$file,$tmporiginaltag,0,$mode);		#book series: book title
				&add_tag("$tmp1: $tmp2"       ,$file,$tmporiginaltag,0,$mode);		#author: book series
				&add_tag("$tmp1: $tmp3"       ,$file,$tmporiginaltag,0,$mode);		#author: book title
				&add_tag("$tmp1: $tmp2: $tmp3",$file,$tmporiginaltag,1,$mode);		#author: book series: book title
				$s="";
			} elsif ($s =~ /^([^\-]*)$/) {									#title only
				my $tmp1=$1;												#book title
				&add_tag("$tmp1"      ,$file,$tmporiginaltag,0,$mode);		#The Last Unicorn
				&add_tag("$tmp1 book" ,$file,$tmporiginaltag,0,$mode);		#The Last Unicorn book
				&add_tag("book: $tmp1",$file,$tmporiginaltag,1,$mode);		#book: The Last Unicorn [this one used for caption]
				$s="";
			} else {
				print "<B> ERROR! BOOK NOT PROPERLY DETECED; CODING NEEDED. \$s=$s <BR><BR>\n";
			}
			$entertainment{"$file$DELIMITER" . "book"}=1;
			#&add_tag("",$file,$tmporiginaltag,"",$mode);
		} elsif ($s =~ /^poems?-?/i) {
			$STOP_ALL_CAPTIONING=1;
			&add_tag("poems",$file,$tmporiginaltag, 0,$mode);					
			&add_tag("poem" ,$file,$tmporiginaltag, 0,$mode);					
			$STOP_ALL_CAPTIONING=0;
			$s =~ s/^poems?-?//;		
			if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[8.5] $file$DELIMITER"."movie onto \%entertainment<BR>\n"; }
			if ($s =~ /(.*)-(.*)/) {
				my $tmp1=$1;	#author 
				my $tmp2=$2;	#poem
				$tmp1=&fix_name_of_any_form($tmp1);#
				#DEBUG: print "GOT HERE POOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOEM \"$s\" /$tmp1/$tmp2/";
				&add_tag("$tmp1"         ,$file,$tmporiginaltag,0,$mode);					
				&add_tag("$tmp2"         ,$file,$tmporiginaltag,0,$mode);					
				$s="$tmp1 - $tmp2";
				&add_tag("$tmp1 - $tmp2" ,$file,$tmporiginaltag,1,$mode);					
			}
			$entertainment{"$file$DELIMITER" . "poem"}=1;
			#&add_tag("",$file,$tmporiginaltag,"",$mode);
		} elsif ($s =~ /^game-/i) {												#entertainment-game
			&add_tag("game",$file,$tmporiginaltag,0,$mode);
			$s =~ s/^game-//;
			if (($s =~ /^(video games*)-/i) || ($s =~ /^(online games*)-/i) || ($s =~ /^(board games*)-/i) || ($s =~ /^(card games*)-/i) || ($s =~ /^(role\-*playing games*)-/i) || ($s =~ /^(dice games*)-/i) || ($s =~ /^(gambling games*)-/i)) {

				$tmp5=$1;
				&add_tag("$tmp5",$file,$tmporiginaltag,0,$mode);
				$s =~ s/^$tmp5-//;
				&add_tag("$s",$file,$tmporiginaltag,"",$mode);
				$s="";
			}
			#todo perhaps add board games and playing cards and suc
		} elsif ($s =~ /^music-/i) {
			if ($DEBUG_SONG) { print "is this where music happens? [A]"; }
			&add_tag("music",$file,$tmporiginaltag,0,$mode);
			$s =~ s/^music-//;
			$entertainment{"$file$DELIMITER" . "music"}=1;
#			##### B.S. N/A section tha doesn't follow standards & practices, accidentally developed because Carolyn didn't follow S&P :P
#			if ($s =~  /(.*)-(album)-(.*)$/i) {
#				my $title1 = $1;			#band title
#				my $format = $2;
#				my $title2 = $3;			#album title
#				$s =~ s/-$format-.*$//i;
#				if ($DEBUG_THING) { print "[ENTERTAINMENT-MUSIC-XXX1] format=$format, title=$title1, title2=$title2 <BR>\n"; }
#				&add_tag($format                                   ,$file,$tmporiginaltag,0,$mode);	#album
#				&add_tag($format . ": " . $title1                  ,$file,$tmporiginaltag,0,$mode);	#album: Hole
#				&add_tag($format . ": " . $title1 . " - " . $title2,$file,$tmporiginaltag,1,$mode);	#album: Hole - Ask For It
#				&add_tag($format . ": " .                   $title2,$file,$tmporiginaltag,0,$mode);	#album: Ask For It
#				&add_tag($title1                                   ,$file,$tmporiginaltag,0,$mode); #Hole
#				&add_tag($title1 . " "  . $format                  ,$file,$tmporiginaltag,0,$mode); #Hole album
#				&add_tag($title2 . " "  . $format                  ,$file,$tmporiginaltag,0,$mode); #Ask For It album
#				&add_tag($title2                                   ,$file,$tmporiginaltag,0,$mode); #Ask For It 
#				if ($DEBUG_SONG) { print "s is now $s!! [SONG1]<BR>\n"; }
#				$s="";
#			} els
			if (($s =~  /(song)-(.*)$/i) || ($s =~  /(album)-(.*)$/i) || ($s =~  /(riff)-(.*)$/i)) {
				my $format = $1;
				my $title  = $2;			#song OR album OR riff title
				$s =~ s/-$format-.*$//i;
				if ($DEBUG_THING) { print "[ENTERTAINMENT-MUSIC-XXX1] format=$format, title=$title <BR>\n"; }
				&add_tag($format . ": " . $title ,$file,$tmporiginaltag,1,$mode);
				&add_tag($format                 ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$title"                ,$file,$tmporiginaltag,0,$mode);
				&add_tag("$title $format"        ,$file,$tmporiginaltag,0,$mode);
				if ($DEBUG_SONG) { print "s is now $s!! [SONG1]<BR>\n"; }
				$s="";
			}
			&add_tag("$s",$file,$tmporiginaltag,"",$mode);
			$s="";
		} elsif ((($s =~ /^comics?-?/i) || ($s =~ /^comic books-?/i)) && ($s !~ /^comic strip/i)) {
			&add_tag("comic"      ,$file,$tmporiginaltag,0,$mode);
			&add_tag("comics"     ,$file,$tmporiginaltag,0,$mode);
			&add_tag("comic book" ,$file,$tmporiginaltag,0,$mode);
			&add_tag("comic books",$file,$tmporiginaltag,0,$mode);
			$s =~  s/^comics* books*-?//i;
			$s =~  s/^comics*-?//i;
			$entertainment{"$file$DELIMITER" . "comic books"}=1;
			&add_tag($s,$file,$tmporiginaltag,"",$mode);
			$s="";
		} elsif ($s =~ /^comics* strips*-/i) {
			&add_tag("comic"       ,$file,$tmporiginaltag,0,$mode);
			&add_tag("comics"      ,$file,$tmporiginaltag,0,$mode);
			&add_tag("comic strip" ,$file,$tmporiginaltag,0,$mode);
			&add_tag("comic strips",$file,$tmporiginaltag,0,$mode);
			$s =~  s/^comics* strips*-?//i;
			$s =~  s/^comics*-?//i;
			$entertainment{"$file$DELIMITER" . "comic strip"}=1;
			&add_tag($s,$file,$tmporiginaltag,"",$mode);
			$s="";
		} elsif ($s =~ /^(toys*)-/i) {
			&add_tag("toy" ,$file,$tmporiginaltag,0,$mode);
			&add_tag("toys",$file,$tmporiginaltag,0,$mode);
			$s =~  s/^toys*-?//i;
			&add_tag(   $s ,$file,$tmporiginaltag,0,$mode);
			$entertainment{"$file$DELIMITER" . "toy"}=1;
			if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[8] $file$DELIMITER"."toy onto \%entertainment<BR>\n"; }
			&add_tag("toy: $s",$file,$tmporiginaltag,"",$mode);
			$s="";
		}		
		#&add_tag("",$file,$tmporiginaltag,"",$mode);
	}

	if ($DEBUG_THING) { print "[DT-remainder-code-1][s=$s]<BR>\n";  }


	#something1-something2 to be tagged as "something1,something1: something2,something 2" and captioned as "something1: something2"
	if ($s =~ /^(Grand Theft Auto)-(Vice City)$/) {
		&add_tag("$1"    ,$file,$tmporiginaltag, 0,$mode);
		&add_tag("$2"    ,$file,$tmporiginaltag, 0,$mode);
		&add_tag("$1: $2",$file,$tmporiginaltag,"",$mode);
		$s="";
	}


	if (!$STOP_SYNONYM_ALIASES) {
		if ($DEBUG_THING>1) { print " [synonym-checking,s=\"$s\"] "; }
		##### WEIRD LEFTOVER THINGS / synonym catch-alls:
		### One-way synonyms things:
		$STOP_ALL_CAPTIONING=1;
		if  ($s =~ /^school buses$/i			 ) { &add_tag("school bus",					        $file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^buses$/i					 ) { &add_tag("bus",								$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^geese$/i					 ) { &add_tag("goose",								$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^waves$/i					 ) { &add_tag("wave",								$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^feet$/i					 ) { &add_tag("foot",								$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^people$/i					 ) { &add_tag("person",								$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^women$/i					 ) { &add_tag("woman",								$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^men$/i					     ) { &add_tag("man",								$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^teeth$/i					 ) { &add_tag("tooth",								$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^harddrives$/i  			 ) { &add_tag("harddrive",							$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^gloves$/i					 ) { &add_tag("glove",								$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^fetuses$/i                  ) { &add_tag("fetus",								$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^tomatoes$/i                 ) { &add_tag("tomato",								$file,$tmporiginaltag,0,$mode); }	#irregular singulars need to happen here
		if  ($s =~ /^SubGenius Devival$/i		 ) { &add_tag("devival",							$file,$tmporiginaltag,0,$mode); }	
		if  ($s =~ /^banana boat$/i				 ) { &add_tag("thing-banana",						$file,$tmporiginaltag,0,$mode); }	
		if  ($s =~ /^wine$/i					 ) { &add_tag("thing-alcohol",						$file,$tmporiginaltag,0,$mode); }	
		if  ($s =~ /^liquor$/i					 ) { &add_tag("thing-alcohol",						$file,$tmporiginaltag,0,$mode); }	
		if  ($s =~ /^beer$/i					 ) { &add_tag("thing-alcohol",						$file,$tmporiginaltag,0,$mode); }	
		if  ($s =~ /^beer pong$/i				 ) { &add_tag("thing-drink-beer",					$file,$tmporiginaltag,0,$mode); }	
		if  ($s =~ /^beer pong$/i				 ) { &add_tag("activity-game-pong",					$file,$tmporiginaltag,0,$mode); }	
		if  ($s =~ /^Glen Danzig$/i              ) { &add_tag("Danzig",								$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^beef jerky$/i               ) { &add_tag("beef",								$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^beef jerky$/i               ) { &add_tag("jerky",								$file,$tmporiginaltag,0,$mode); }	#maybe need a jerky catch-all
		if  ($s =~ /^liquor$/i                   ) { &add_tag("alcohol",							$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^alcohol$/i                  ) { &add_tag("drink",								$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^Towelie$/i                  ) { &add_tag("towel",								$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^mini golf$/i                ) { &add_tag("golf",								$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^paper plate$/i              ) { &add_tag("plate",								$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^glowing in the blacklight$/i) { &add_tag("activity-glowing",					$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^Rocky Horror Picture Show$/i) { &add_tag("Rocky Horror",						$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^Guitar Hero$/i              ) { &add_tag("guitar",								$file,$tmporiginaltag,0,$mode); }	#is this a safe assumption? a screenshot of guitar hero might not have a guitar!
		if  ($s =~ /^Guitar Hero [1-9IVX+]$/i    ) { &add_tag("thing-game-video game-Guitar Hero",	$file,$tmporiginaltag,0,$mode); }	#is this a safe assumption? a screenshot of guitar hero might not have a guitar!
		if  ($s =~ /^pictures* of pictures$/i    ) { &add_tag("thing-pictures",						$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^picture of picture$/i       ) { &add_tag("thing-picture",						$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^laser pointer$/i            ) { &add_tag("laser",								$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^laser pointer$/i            ) { &add_tag("pointer",							$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^Xbox 360$/i                 ) { &add_tag("Xbox",								$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^counting down$/i            ) { &add_tag("thing-countdown",					$file,$tmporiginaltag,0,$mode); }
		#if  ($s =~ /^sunset$/i                  ) { &add_tag("thing-sun",							$file,$tmporiginaltag,0,$mode); }	#Not necessarily!
		#if  ($s =~ /^sunrise$/i                 ) { &add_tag("thing-sun",							$file,$tmporiginaltag,0,$mode); }	#Not necessarily!
		if  ($s =~ /^The Hulk$/i                 ) { &add_tag("Hulk",								$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^Fantasy TeeVee$/i           ) { &add_tag("Fantasy TV",							$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^My Little Pony Friendship Is Magic$/i) { &add_tag("My Little Pony: Friendship Is Magic",	$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^My Little Pony Friendship Is Magic$/i) { &add_tag("My Little Pony",			$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^My Little Pony Equestria Girls.*$/i  ) { &add_tag("My Little Pony",			$file,$tmporiginaltag,0,$mode); }
		if  ($s =~ /^Prius V$/i  )                          { &add_tag("Prius",			            $file,$tmporiginaltag,0,$mode); }
		$STOP_ALL_CAPTIONING=0;

		#DEBUG:		print "<b>SYN:</b> s is $s<BR>\n";#

		### Thing synonyms should be listed 2 ways: too common not to list "with The" and "without The":
		if (($s =~ /^Simpsons$/i                 ) && ($STOP_RECURSION[ 0] != 1)) { $STOP_RECURSION[ 0]=1; &add_tag("The Simpsons"                    ,$file,$tmporiginaltag,"",$mode); }
		if (($s =~ /^The Simpsons$/i             ) && ($STOP_RECURSION[ 1] != 1)) { $STOP_RECURSION[ 1]=1; &add_tag("Simpsons"                        ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^Misfits$/i                  ) && ($STOP_RECURSION[ 2] != 1)) { $STOP_RECURSION[ 2]=1; &add_tag("The Misfits"                     ,$file,$tmporiginaltag,"",$mode); }
		if (($s =~ /^The Misfits$/i              ) && ($STOP_RECURSION[ 3] != 1)) { $STOP_RECURSION[ 3]=1; &add_tag("Misfits"                         ,$file,$tmporiginaltag, 0,$mode); }
		### Thing synonyms should be listed 2 ways:
		if (($s =~ /^SubGenius$/i                ) && ($STOP_RECURSION[ 4] != 1)) { $STOP_RECURSION[ 4]=1; &add_tag("Church Of The SubGenius"         ,$file,$tmporiginaltag,"",$mode); }
		if (($s =~ /^Church Of The SubGenius$/i  ) && ($STOP_RECURSION[ 5] != 1)) { $STOP_RECURSION[ 5]=1; &add_tag("SubGenius"                       ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^Jesus$/i                    ) && ($STOP_RECURSION[ 6] != 1)) { $STOP_RECURSION[ 6]=1; &add_tag("Jesus Christ"                    ,$file,$tmporiginaltag, 0,$mode); }	#thing-figurine-Jesus Christ double-captions "Jseus Christ" unless you set this to 0 instead of "" ... if this is unacceptable, may have to make a f1nal capti0n edit instead
		if (($s =~ /^Jesus Christ$/i             ) && ($STOP_RECURSION[ 7] != 1)) { $STOP_RECURSION[ 7]=1; &add_tag("Jesus"                           ,$file,$tmporiginaltag, 0,$mode); }
#		##### NO LONGER 100% TRUE -- some comics are comic strips and not comic books, so let's stop doing this:
#		if (($s =~ /^comics$/i                   ) && ($STOP_RECURSION[ 8] != 1)) { $STOP_RECURSION[ 8]=1; &add_tag("comic books"                     ,$file,$tmporiginaltag, 0,$mode); }
#		if (($s =~ /^comic books$/i              ) && ($STOP_RECURSION[ 9] != 1)) { $STOP_RECURSION[ 9]=1; &add_tag("comics"                          ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^TV$/i                       ) && ($STOP_RECURSION[10] != 1)) { $STOP_RECURSION[10]=1; &add_tag("television"                      ,$file,$tmporiginaltag, 0,$mode); }	
		if (($s =~ /^television$/i               ) && ($STOP_RECURSION[11] != 1)) { $STOP_RECURSION[11]=1; &add_tag("TV"                              ,$file,$tmporiginaltag,"",$mode); }
		#NOT NECESSARILY TRUE: if (($s =~ /^George Bush$/i) && ($STOP_RECURSION[13] != 1)) { $STOP_RECURSION[13]=1; &add_tag("person-politician-Bush George W.",$file,$tmporiginaltag,"",$mode); }
		if (($s =~ /^George W\. Bush$/i          ) && ($STOP_RECURSION[12] != 1)) { $STOP_RECURSION[12]=1; &add_tag("person-politician-Bush George"   ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^gothic$/i                   ) && ($STOP_RECURSION[14] != 1)) { $STOP_RECURSION[14]=1; &add_tag("goth"                            ,$file,$tmporiginaltag,"",$mode); }
		if (($s =~ /^goth$/i                     ) && ($STOP_RECURSION[13] != 1)) { $STOP_RECURSION[13]=1; &add_tag("gothic"					      ,$file,$tmporiginaltag, 0,$mode); }	
		if (($s =~ /^black and red$/i            ) && ($STOP_RECURSION[15] != 1)) { $STOP_RECURSION[15]=1; &add_tag("red and black"                   ,$file,$tmporiginaltag, 0,$mode); }	
		if (($s =~ /^red and black$/i            ) && ($STOP_RECURSION[16] != 1)) { $STOP_RECURSION[16]=1; &add_tag("black and red"                   ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^black and yellow$/i         ) && ($STOP_RECURSION[17] != 1)) { $STOP_RECURSION[17]=1; &add_tag("yellow and black"                ,$file,$tmporiginaltag, 0,$mode); }	
		if (($s =~ /^yellow and black$/i         ) && ($STOP_RECURSION[18] != 1)) { $STOP_RECURSION[18]=1; &add_tag("black and yellow"                ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^auctioning$/i               ) && ($STOP_RECURSION[19] != 1)) { $STOP_RECURSION[19]=1; &add_tag("auction"                         ,$file,$tmporiginaltag, 0,$mode); }	
		if (($s =~ /^auction$/i                  ) && ($STOP_RECURSION[20] != 1)) { $STOP_RECURSION[20]=1; &add_tag("auctioning"                      ,$file,$tmporiginaltag, 0,$mode); }	
		if (($s =~ /^Christmas lights$/i         ) && ($STOP_RECURSION[21] != 1)) { $STOP_RECURSION[21]=1; &add_tag("Christmas light"                 ,$file,$tmporiginaltag, 0,$mode); }	
		if (($s =~ /^Christmas light$/i          ) && ($STOP_RECURSION[22] != 1)) { $STOP_RECURSION[22]=1; &add_tag("Christmas lights"                ,$file,$tmporiginaltag,"",$mode); }	
		if (($s =~ /^Halloween lights$/i         ) && ($STOP_RECURSION[23] != 1)) { $STOP_RECURSION[23]=1; &add_tag("Halloween light"                 ,$file,$tmporiginaltag, 0,$mode); }	
		if (($s =~ /^Halloween light$/i          ) && ($STOP_RECURSION[24] != 1)) { $STOP_RECURSION[24]=1; &add_tag("Halloween lights"                ,$file,$tmporiginaltag,"",$mode); }	
		if (($s =~ /^smile$/i                    ) && ($STOP_RECURSION[25] != 1)) { $STOP_RECURSION[25]=1 ; &add_tag("activity-smiling"				  ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^Jetsons$/i                  ) && ($STOP_RECURSION[26] != 1)) { $STOP_RECURSION[26]=1; &add_tag("The Jetsons"                     ,$file,$tmporiginaltag,"",$mode); }
		if (($s =~ /^The Jetsons$/i              ) && ($STOP_RECURSION[27] != 1)) { $STOP_RECURSION[27]=1; &add_tag("Jetsons"                         ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^red and blue$/i             ) && ($STOP_RECURSION[28] != 1)) { $STOP_RECURSION[28]=1; &add_tag("blue and red"                    ,$file,$tmporiginaltag,"",$mode); }	
		if (($s =~ /^blue and red$/i             ) && ($STOP_RECURSION[29] != 1)) { $STOP_RECURSION[29]=1; &add_tag("red and blue"                    ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^smirk$/i                    ) && ($STOP_RECURSION[30] != 1)) { $STOP_RECURSION[30]=1 ; &add_tag("activity-smirking"			  ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^purple and green$/i         ) && ($STOP_RECURSION[31] != 1)) { $STOP_RECURSION[31]=1; &add_tag("green and purple"                ,$file,$tmporiginaltag, 0,$mode); }	
		if (($s =~ /^green and purple$/i         ) && ($STOP_RECURSION[32] != 1)) { $STOP_RECURSION[32]=1; &add_tag("purple and green"                ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^crescent wrench$/i          ) && ($STOP_RECURSION[33] != 1)) { $STOP_RECURSION[33]=1; &add_tag("basin wrench"                    ,$file,$tmporiginaltag, 0,$mode); }	
		if (($s =~    /^basin wrench$/i          ) && ($STOP_RECURSION[34] != 1)) { $STOP_RECURSION[34]=1; &add_tag("crescent wrench"                 ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^orange and red$/i           ) && ($STOP_RECURSION[35] != 1)) { $STOP_RECURSION[35]=1; &add_tag("red and orange"                  ,$file,$tmporiginaltag,"",$mode); }	
		if (($s =~ /^red and orange$/i           ) && ($STOP_RECURSION[36] != 1)) { $STOP_RECURSION[36]=1; &add_tag("orange and red"                  ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^pink and red$/i             ) && ($STOP_RECURSION[37] != 1)) { $STOP_RECURSION[37]=1; &add_tag("red and pink"                    ,$file,$tmporiginaltag,"",$mode); }	
		if (($s =~ /^red and pink$/i             ) && ($STOP_RECURSION[38] != 1)) { $STOP_RECURSION[38]=1; &add_tag("pink and red"                    ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^blue and purple$/i          ) && ($STOP_RECURSION[39] != 1)) { $STOP_RECURSION[39]=1; &add_tag("purple and blue"                 ,$file,$tmporiginaltag,"",$mode); }
		if (($s =~ /^purple and blue$/i          ) && ($STOP_RECURSION[40] != 1)) { $STOP_RECURSION[40]=1; &add_tag("blue and purple"                 ,$file,$tmporiginaltag, 0,$mode); }	
		if (($s =~ /^purple and red$/i           ) && ($STOP_RECURSION[41] != 1)) { $STOP_RECURSION[41]=1; &add_tag("red and purple"                  ,$file,$tmporiginaltag,"",$mode); }	
		if (($s =~ /^red and purple$/i           ) && ($STOP_RECURSION[42] != 1)) { $STOP_RECURSION[42]=1; &add_tag("purple and red"                  ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^pink and blue$/i            ) && ($STOP_RECURSION[43] != 1)) { $STOP_RECURSION[43]=1; &add_tag("blue and pink"                   ,$file,$tmporiginaltag,"",$mode); }	
		if (($s =~ /^blue and pink$/i            ) && ($STOP_RECURSION[44] != 1)) { $STOP_RECURSION[44]=1; &add_tag("pink and blue"                   ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^playing drums$/i            ) && ($STOP_RECURSION[45] != 1)) { $STOP_RECURSION[45]=1; &add_tag("activity-drumming"               ,$file,$tmporiginaltag,"",$mode); }	
		if (($s =~ /^drumming$/i                 ) && ($STOP_RECURSION[46] != 1)) { $STOP_RECURSION[46]=1; &add_tag("activity-playing drums"          ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^electronic cigarette(s*)$/i ) && ($STOP_RECURSION[47] != 1)) { $STOP_RECURSION[47]=1; &add_tag("thing-ecigarette$1"              ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^Quake Live$/i               ) && ($STOP_RECURSION[48] != 1)) { $STOP_RECURSION[48]=1; &add_tag("Quake"                           ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^Quake$/i                    ) && ($STOP_RECURSION[49] != 1)) { $STOP_RECURSION[49]=1; &add_tag("Quake Live"                      ,$file,$tmporiginaltag, 0,$mode); }
		if (($s =~ /^Toxic Avenger$/i            ) && ($STOP_RECURSION[50] != 1)) { $STOP_RECURSION[51]=1; &add_tag("The Toxic Avenger"               ,$file,$tmporiginaltag,"",$mode); }
		if (($s =~ /^The Toxic Avenger$/i        ) && ($STOP_RECURSION[51] != 1)) { $STOP_RECURSION[51]=1; &add_tag("Toxic Avenger"                   ,$file,$tmporiginaltag, 0,$mode); }
		$STOP_RECURSION_MAX_INDEX=51;
	}




	################ CLEAN TAG MEAT - END ##################
	################ CLEAN TAG MEAT - END ##################
	################ CLEAN TAG MEAT - END ##################


	#stubborn / non-thing re-hyphenization / rehyphenization / stubborn rehyphenization / stubborn re-hyphenization
	$s = &rehyphenate($s);



	#DEBUG: Print out the cleaning of tags, once per tag, if the debug is on:
	if ($DEBUG_TAG_CLEANER) { 
		if ($cleaned{$_[0]} ne "") {
			#do nothing
		} else {
			$cleaned{$_[0]}="%s";
			if ($DEBUG_TAGCLEAN_RECURSION_PAIN) { print "====> [MM] setting \$cleaned($_[0])=$s  <BR>\n"; }
			print "* Cleaning   ".sprintf("%-20s",$_[0])."\n    INTO:   \"$s\"...\t<BR>\n";
			if ($from ne "") {
				print "    FROM:    $from             <BR>\n";
			}
			print "\n";
		}
	}

	#Lastly, substitute spaces for our API workaround hack:
	$s =~ s/ /_SPC_/g;

	if ($DEBUG_THING) { print "[DT-retval] [s=$s]<BR>\n"; }

	##### NEW WAVE OF SINGULARIZATION/PLURALS TEST:						#OHOHOH - not sure if this is a good idea to apply to non-things or not!
	if ($s =~ /^.*[^\s]s$/) { 
		$tmp = &singular($s,1);
		$tmp2 = $tmp;
		$tmp2 =~ s/ /_SPC_/g;
		#DEBUG: print "if $tmp2 ne $s...\n";
		if ($tmp2 ne $s) {												#prevent infinite loops
			&add_tag($tmp,$file,$tmporiginaltag,0,$mode); 
		}
	}				

	
	return($s);
}#endusb clean_tag
############################################################################################################
############################################################################################################
###########################################################









#######################################################################################################################
sub assemble_all_captions {
	if ($DEBUG_AUTOCAPTION) { print "<p align=left>"; }
	my $i=@FILES; my $tot=@FILES; my $j=1;
	print "\n<!-- \n\n\n\n\n\n\n\n";
	foreach my $tmpfile2findcaptionfor (@FILES) {
		print "... " . $i-- . " ...\n";					#countdown for captions that we assemble
		if ($DEBUG_AUTOCAPTION) { print "Checking file $tmpfile for caption...<BR>\n"; }
		$tmp = &assemble_caption($tmpfile2findcaptionfor);
		$captions{"$tmpfile2findcaptionfor"} = $tmp;
		$last_caption_assembled              = $tmp;
		$last_caption_assembled =~ s/^ +$//;
		if ($DEBUG_AUTOCAPTION) { print "Set caption for $tmpfile2findcaptionfor to \"$tmp\"...<BR>\n"; }
		&countdownNoise($j++,$tot);

	}
	print "...\n\n\n\n\n\n\n\n\n-->\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
}
#######################################################################################################################
###########################################################
sub assemble_caption {				#clean caption / caption clean
	my $file = $_[0];
	#######my $STATE="[place, town, state]\n";
	my $s="";
	my $tmps="";
	my $SKIP=0;
	my $uncaptionable_thing="";
	#print "[-A]";

	##### CAPTION PEOPLE:
	if ($DEBUG_ASSEMBLE_CAPTION>1) { $s  .= "[people: ]"; }
	foreach $tmpkey (sort keys %people) {
		if (($tmpkey eq "") || ($people{$tmpkey} eq "")) { next; }
		($tmpfile,$tmpthing)=split(/$DELIMITER/,"$tmpkey");
		$tmpthing =~ s/_SPC_/ /g;
		if ((0) || ($DEBUG_AUTOCAPTION) || ($DEBUG_AUTOCAPTION_PEOPLE)) { print "[caption=people] comparing \$people{".$tmpkey."} to current file of $file ... <B>tmpthing is $tmpthing</B><BR>\n"; }
		if ($tmpfile eq $file) { $s .= "$tmpthing, ";	}
	}
	$s =~ s/, *$/.\n/;																			#DEBUG: print "<B>[[s=$s]]</B><BR>\n";
	$s =~ s/^[\s\t,]+//g;
	#print "[-B]";

	##### CAPTION ACTIVITIES:
	my $num_activities=0;
	if ($DEBUG_ASSEMBLE_CAPTION>1) { $s .= "[activities: ]"; }
	foreach $tmpkey (sort keys %activities) {
		if (($tmpkey eq "") || ($activities{$tmpkey} eq "")) { next; }
		($tmpfile,$tmpthing)=split(/$DELIMITER/,"$tmpkey");
		$tmpthing=~ s/_SPC_/ /g;
		if (($tmpfile eq $file) && ($tmpthing ne "")) { $s .= "$tmpthing, "; $num_activities++;	}
	}
	$s =~ s/, *$/.\n/;
	#print "[-C]";

	##### CAPTION THINGS:
	my $num_things=0;
	if ($DEBUG_ASSEMBLE_CAPTION>1) { $s .= "[things: ]"; }
	foreach $tmpkey (sort keys %things) {
		if (($tmpkey eq "") || ($things{$tmpkey} eq "")) { next; }
		($tmpfile,$tmpthing)=split(/$DELIMITER/,"$tmpkey");
		$tmpthing=~ s/_SPC_/ /g;
		if (($tmpfile eq $file) && ($tmpthing ne "")) { $s .= "$tmpthing, "; $num_things++; }
	}
	#print "[-D]";

	#kludgey cleanup								#caption things cleanup		#cleanup things	#cleanup caption things
	if ($num_things > 0) {																										#DEPRECATED
		## the old kludgey sucky way, ones left over:																			#DEPRECATED	
		#plural tags that end up giving us the same thing twice:																#DEPRECATED
		$s =~ s/letter, letters/letters/i;																						#DEPRECATED
		$s =~ s/power line, power lines/power lines/i;																			#DEPRECATED
		$s =~ s/(bread pudding, )(.*)(pudding[\.,]? ?)/$1$2/i;																	#DEPRECATED
		$s =~ s/horse, pony/horse\/pony/ig;																						#DEPRECATED
		$s =~ s/pony the horse/horse\/pony/ig;																					#DEPRECATED
		#$s =~ s/picnic table(.*), table,*/picnic table$1, /;																	#DEPRECATED
		$s =~ s/bookstore, bookstore/bookstore, /;																				#DEPRECATED
		#^^ stop this madness. a better way has been developed.																	#DEPRECATED
		#^^     at least, for items that should never be captioned.																#DEPRECATED
		$s =~ s/(40)(.*,) beer(,*)/$1$2/;							#new pattern; use this from here on							#DEPRECATED
#		$s =~ s/(fallen tree)(.*,) tree(,*)/$1$2/;					#new pattern; use this from here on							#DEPRECATED
		$s =~ s/backyard(.*,) yard(,*)/backyard$1/;									#old pattern								#DEPRECATED
		$s =~ s/kiddie pool(.*,) pool(,*)/kiddie pool$1/;							#old pattern								#DEPRECATED
		$s =~ s/Duck Pond(.*,) pond(,*)/Duck Pond$1/;								#old pattern								#DEPRECATED
		$s =~ s/Gorilla *pod(.*,) tripod(,*)/Gorillapod$1/i;						#old pattern								#DEPRECATED
		$s =~ s/abandoned building(.*,) building(,*)/abandoned building$1/;			#old pattern								#DEPRECATED
		$s =~ s/head shop(.*,) store(,*)/head shop$1/;								#old pattern								#DEPRECATED
		$s =~ s/(mock post office)(.*,) post office(,*)/$1$2/;		#new pattern; use this from here on							#DEPRECATED
		$s =~ s/(stuffed tiger toy)(.*,) tiger(,*)/$1$2/;			#new pattern; use this from here on							#DEPRECATED
		$s =~ s/(stuffed tiger)(.*,) tiger(,*)/$1$2/;				#new pattern; use this from here on							#DEPRECATED
		$s =~ s/(stuffed turtle)(.*,) turtle(,*)/$1$2/;				#new pattern; use this from here on							#DEPRECATED
		#synonyms where we keep the alphabetically later one:																	#DEPRECATED
		$s =~ s/rattlesnake(.*), snake(,*)/rattlesnake$1, $2/;																	#DEPRECATED
		$s =~ s/cooking(.*), cooking pancakes(,*)/$1, cooking pancakes$2/;														#DEPRECATED
		$s =~ s/flashlight(.*), light(,*)/flashlight$1, /;																		#DEPRECATED
		$s =~ s/office(.*), rental office(,*)/$1, rental office$2, /;															#DEPRECATED
		$s =~ s/sign(.*), street sign(,*)/$1, street sign$2, /;																	#DEPRECATED
		$s =~ s/light(.*), street light(,*)/$1, street light$2, /;																#DEPRECATED

		#finishing touches:
		if ($num_things == 1) { $s =~ s/.$//; }
		## something we always want to do:
		$s =~ s/, *$/.\n/;	
		$s =~ s/^ *, //;
		$s =~ s/, <BR>/.\n/;	
	}
	#print "[-E]";



	
	##### CAPTION ENTERTAINMENT: 
	if ($DEBUG_ASSEMBLE_CAPTION>1) { $s .= " [entertainment: ] "; }
	my $num_entertainment=0; $tmps="";
	foreach $tmpkey (sort keys %entertainment) {
		if (               $tmpkey  eq "") { next; }
		if ($entertainment{$tmpkey} eq "") { next; }
		($tmpfile,$tmpthing)=split(/$DELIMITER/,"$tmpkey");
		if ($DEBUG_AUTOCAPTION) { print "\n[DEBUG_AUTOCAPTION] tmpthing=$tmpthing,tmpfile=$tmpfile \n"}
		$tmpthing=~ s/_SPC_/ /g;
		$SKIP=0;
		foreach $uncaptionable_thing (@UNCAPTIONABLE_ENTERTAINMENT) {
			#DEBUG: print "<BR>Checking to see if $tmpthing =~ $uncaptionable_thing...";
			if ($tmpthing =~ /^$uncaptionable_thing$/i) { $SKIP=1; }
		}
		if (($tmpfile eq $file) && ($SKIP==0)) { 
			$num_entertainment++;
			$tmps .= "$tmpthing. ";	
		}
	}
	if ($num_entertainment > 0) {
		#kludgefixes:
		$tmps =~ s/\. *$/.\n/;
		$tmps =~ s/TV. (TV show:)/$1/;
		$tmps =~ s/movie\. *movie:/movie:/;
		$tmps =~ s/video\. *video:/video:/;
		$tmps =~ s/toy\. *toy:/toy:/;
		#new entertainment types may need a line here	
	}
	$s .= $tmps;
	#print "[-F]";




	##### CAPTION OTHER: 
	if ($DEBUG_ASSEMBLE_CAPTION>1) { $s .= "[other: ]"; }
	my $num_other=0;
	foreach $tmpkey (sort keys %other) {
		if ($tmpkey eq "") { next; }
		if ($other{$tmpkey} eq "") { next; }
		($tmpfile,$tmpthing)=split(/$DELIMITER/,"$tmpkey");
		$tmpthing=~ s/_SPC_/ /g;
		if ($tmpfile eq $file) { 
			$num_other++;
			$s .= "$tmpthing. ";	
		}
	}
	if ($num_other > 0) {
		$s =~ s/close-up[\.,] (.*extreme close-up)/$1/i;
		$s =~ s/\. *$/.\n/;
	}
	#DEBUG:	print "<B>AM I HERE? s=$s, num_things=$num_things<BR>\n";
	if ($num_things > 0) {		#kludgey fixes
		if ($s =~  /doing jello syringe shots/i) {
			$s =~ s/doing jello shots[\.,]? ?//i;
			$s =~ s/jello syringe[\.,]? ?//i;
			$s =~ s/jello[\.,]? ?//i;
#			$s =~ s/drinking[\.,]? ?//i;
			$s =~ s/alcohol[\.,]? ?//i;
			$s =~ s/shot[\.,]? ?//i;
			$s =~ s/syringe[\.,]? ?//i;
		}
		$s =~ s/statue,(.*)statue/$1statue/i;
		### TD the bird cage resulted from this, which made no sense: it was supposed to be "TD the bird" and "Bird cage"..
		### A lot of this massaging is becoming obsolete due to my catch-a1l development in add_tag... so this can probably go away now:
		#$s =~ s/bird,(.*)bird/$1bird/i;
	}

	$s =~ s/, *$/./;
	$s =~ s/, *\n/.\n/g;
	$s =~ s/, *<BR>/.<BR>/g;
	$s =~ s/, *\.\n/.\n/;
	$s =~ s/\n, */\n/;

	#print "[-G]";


	##### CAPTION KLUDGES:
	#elvis action figures were both person AND thing of elvis, making elvis show up twice in captions...
	if ($s =~ /Elvis/i) {
		$s =~ s/(Elvis\..*)(Elvis)/$2/igs;					#the /s is absolutely crucial here!
	}


	##### RE-COLON / RECOLONING:
	$s =~ s/My Little Pony Friendship Is Magic/My Little Pony: Friendship Is Magic/;
	$s =~ s/My Little Pony Equestria Girls/My Little Pony: Equestria Girls/;



	
	##### CAPTION PLACES:
	if ($DEBUG_ASSEMBLE_CAPTION>1) { $s .= "[place: ]"; }
	$tmp = $place{$file};
	if ($tmp ne "") {				#fix anything bad leftover
		$tmp =~ s/_PLACE_, //;
		$tmp =~ s/_CITY_, //;
		$tmp =~ s/, _STATE_//;
		$s .= "\n" . $tmp . ".";
		$s =~ s/\.\.$/./;
		$s .= "\n";
		$s =~ s/apartment, apartment, /apartment, /;
	}
	$s =~ s/Terrace View, *Terrace View/Terrace View, /ig;
	$s =~ s/Airport, airport/airport/i;
	$s =~ s/zoo, zoo/zoo/i;
	$s =~ s/Inn, hotel/Inn, /i;
	$s =~ s/front, yard/front yard/i;
	$s =~ s/back, yard/back yard/i;
	$s =~ s/side, yard/side yard/i;


	#DEBUG: print "s[555]=$s<BR>\n";
	$s =~ s/Burke, Brandon_SPC_Gotwalt_SPC_and_SPC_Becky_SPC_Stewart's_SPC_apartment/Becky and Brandon's apartment, Burke/i;

	#print "[-H]";

	##### CAPTION DATES == on same line as place
	#DEBUG: 	print "* \$date{".$file."}==\"".$date{$file}."\".\n";		#OHOH

	if ($date{$file} ne "") {
		$s =~ s/\n$//;
		$s .= "_ENT_";
		$tmp = $date{$file};
		if ($tmp =~ /([0-9][0-9])([0-9][0-9])([0-9][0-9])/) {
			#DEBUG: 			print "* Calling reformat date on $tmp\n";	#OHOH
			$tmp = &reformat_date($tmp);			#calls break_date
		}
		$s .= "\n  $tmp.\n";
	}

	##### CAPTION ARTBY:
	#if ($DEBUG_ASSEMBLE_CAPTION) { $s .= ""; }
	foreach $tmpkey (sort keys %artby) {
		if ($tmpkey eq "") { next; }
		if ($artby{$tmpkey} eq "") { next; }
		($tmpfile,$tmpthing)=split(/$DELIMITER/,"$tmpkey");
		$tmpthing=~ s/_SPC_/ /g;
		$tmp = $artby{$tmpkey};
		if (($tmpfile eq $file) && ($tmp ne "")) { $s .= "  Art by $tmp.\n";	}
	}
	#print "[-I]";


	##### CAPTION CAMERAPERSON:
	#if ($DEBUG_ASSEMBLE_CAPTION) { $s .= ""; }
	$MediaType="Pic";
	if (&is_video($file)) { $MediaType="Video";	}
	my $cameraperson_exists=0;
	foreach $tmpkey (sort keys %cameraperson) {
		if ($tmpkey                eq "") { next; }
		if ($cameraperson{$tmpkey} eq "") { next; }
		$cameraperson_exists=1;
		($tmpfile,$tmpthing)=split(/$DELIMITER/,"$tmpkey");
		$tmpthing=~ s/_SPC_/ /g;
		if ($tmpthing eq "unknown") { $tmpthing="??????"; }
		else {																			#i used to ad "Pic by ??????." to unknown photopeople, but the idea of having to someday correct those is horrible.
			#DEBUG: print "tmpthing is $tmpthing<BR>";
			if (($tmpthing eq "Dad")   || ($tmpthing eq "Mom") || ($tmpthing eq "Britt") || 
				($tmpthing eq "Vicky")) { 
					$DO_NOT_SOURCE{$tmpfile}=1;			#privacy protection from stalkers finding family as easily						#DEBUG: print "set \$DO_NOT_SOURCE{".$tmpfile."}=\"1\";<BR>";
			}
			if (($tmpfile eq $file) && ($tmpthing ne "") && ($tmpthing ne "Dad") && ($tmpthing ne "Mom") && ($tmpthing ne "Britt") && ($tmpthing ne "Vicky")) { 
				$s .= "$MediaType by ".&censor_tag($tmpthing).".\n";							#just added censor_tag 20080623

		#		##### This code moved to below, since we even want to execute it on pictures that DON'T have the cameraperson tagged:
		#		#DEBUG: $s .= "filename is $file\n";#
		#		while ($file =~ /([0-9]{10})_[0-9a-f]{10}[_ ][a-z]/i) {
		#			$tmpid = $1;														#DEBUG:	#$s .= "\nID is $1";
		#			$s .= "Originally posted at $FLICKR_PHOTOID_TO_URL_PREFIX$tmpid\n";
		#		}

			}		
		}
	}
	##### EVEN IF THERE IS NO CAMERAPERSON CAPTION, IT MAKES SENSE TO RUN THE CODE TO LINK TO ORIGINALS:
	#if (!$cameraperson_exists) {
		my @matches = $file =~ /[^0-9]([0-9]{10})_[0-9a-f]{10}[_ ][a-z]/ig;
		my $matchNum = 0;
		foreach $tmpmatch (@matches) {
			#DEBUG: print "match is $tmpmatch, @matches is ".@matches."\n";
			$tmpid = $tmpmatch;														#DEBUG:	#$s .= "\nID is $1";
			$matchNum++;
			#DEBUG: print "Checking DO_NOT_SOURCE{".$tmpfile."} ... it is $DO_NOT_SOURCE{$tmpfile} <BR>\n";
			if ($DO_NOT_SOURCE{$tmpfile} == 1) {
				#do not source it, for antistalker family privacy reasons
			} else {
				if ($matchNum == 1) {
					$s .= "Originally posted at $FLICKR_PHOTOID_TO_URL_PREFIX$tmpid";
				} elsif ($matchNum == @matches) {
					if (@matches > 2) { $s .= "	, ";	}
					$s .= " and $FLICKR_PHOTOID_TO_URL_PREFIX$tmpid";
				} else {
					$s .= " , $FLICKR_PHOTOID_TO_URL_PREFIX$tmpid";
				}
			}
		}
		if (@matches > 0) { $s .= "\n"; }	
	#}


	#print "[-J]";

	$s =~ s/_SPC_/ /isg;				#not sure why this suddenly became necessary in 200810 - probably due to the now rampant re-feeding of tags back into the clean_tag in an occasionally-recursive fashion
	if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "<BR>\n[FINAL CAPTI0N KLUDGE BEGIN] s(3) is $s<BR>\n"; }
	$s =~ s/music. music:/music:/i;																### SPECIAL ###
	$s =~ s/(playing guitar[\.,]?)(.*)(double guitar[,\.])/$1$2/isg;							#keep first one			#moved to earlier because it was necessary
	my $FOUND;
	do {
		$FOUND=0;
		#playing harp, harp - we just keep playing harp
		#cutting cake, cake
		#wedding cake, cake		TESTING - FAIL?
		#broken mirror, mirror - we just keep broken mirror
		if (
			($s =~  /(eating )([a-z\s]+)[\.,]?/i) ||
			($s =~ /(cooking )([a-z\s]+)[\.,]?/i) ||
			($s =~ /(cutting )([a-z\s]+)[\.,]?/i) ||
			($s =~ /(feeding )([a-z\s]+)[\.,]?/i) ||
			($s =~ /(holding )([a-z\s]+)[\.,]?/i) ||
			($s =~ /(playing )([a-z\s]+)[\.,]?/i) ||
			($s =~ /(pulling )([a-z\s]+)[\.,]?/i) ||
			($s =~ /(singing )([a-z\s]+)[\.,]?/i) ||
			($s =~ /(wearing )([a-z\s]+)[\.,]?/i) ||
			($s =~  /(broken )([a-z\s]+)[\.,]?/i) 
#			($s =~ /(wedding )([a-z\s]+)[\.,]?/i) 
			) {								#if we're playing something...make sure that something isn't also redundantly mentioned later in the caption...
			$tmp1=$1;	$tmp2=$2;												#DEBUG: print "[CCFP] tmp1=$tmp1,tmp2=$tmp2<BR>\n";
			if ($s =~  /($tmp1$tmp2[\.,]?)(.*)($tmp2[,\.])/is) {				#DEBUG:print "[CCFP] GOT HERE! [a]<BR>\n";
				$s =~ s/($tmp1$tmp2[\.,]?)(.*)($tmp2[,\.])/$1$2/isg;			#keep first one
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND1]"; }
			}

			#also, we want to stop things like "reading, reading blah" ... so if the same verb appears twice in a row, nuke it:
			$tmp3 = $tmp1;
			$tmp3 =~ s/ *$//g;
			$s =~ s/$tmp3, *$tmp3/$tmp3/i;														
		}

		#dancing, moonwalk dancing
		if ($s =~ /([a-z\s]+) (dancing)[\.,]?/i) {								#if we're playing something...make sure that something isn't also redundantly mentioned later in the caption...
			$tmp1 = &remove_leading_and_trailing_spaces($1);
			$tmp2 = &remove_leading_and_trailing_spaces($2);					#DEBUG:print "[CCFQ] tmp1=\"$tmp1\",tmp2=\"$tmp2\"<BR>\n"; #tmp1="moonwalk",tmp2="dancing"
			if ($s =~  /($tmp2[\.,]?)(.*)($tmp1 $tmp2[,\.])/is) {				#DEBUG:print "[CCFQ] GOT HERE! <BR>\n";
				$s =~ s/($tmp2[\.,]?)(.*)($tmp1 $tmp2[,\.])/$3/isg;				#keep SECOND one ----
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND2]"; }
			}
		}

		#Freezepop autograph, Freezepop
		if ($s =~ /([a-z\s]+) (autograph)[\.,]?/i) {							#if we have a band autograph...make sure that bandname isn't also redundantly mentioned later in the caption...
			$tmp1=$1;	$tmp2=$2;												#DEBUG:print "[CCFR] tmp1=$tmp1,tmp2=$tmp2<BR>\n";
			if ($s =~  /($tmp1 $tmp2[\.,]?)(.*)($tmp1[,\.])/is) {				#DEBUG:print "[CCFR] GOT HERE! [a]<BR>\n";
				$s =~ s/($tmp1 $tmp2[\.,]?)(.*)($tmp1[,\.])/$1$2/isg;			#keep first one
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND3.0]"; }
			}
		}
		#MovieName poster, movie: MovieName [also music poster]
		if ($s =~ /([a-z][a-z\s]+) (poster)[\.,]?/i) {							#movie poster should not be mentioned again as movie:
			$tmp1=$1;	$tmp2=$2;												#DEBUG: print "[CCGR] tmp1=\"$tmp1\",tmp2=\"$tmp2\"<BR>\n";#
			if (
				($s =~  /($tmp1 $tmp2[\.,]?)(.*)(movie:[ ]$tmp1[,\.])/is) ||
				($s =~  /($tmp1 $tmp2[\.,]?)(.*)(TV Show: $tmp1[,\.])/is) ||
				($s =~  /($tmp1 $tmp2[\.,]?)(.*)(music: $tmp1[,\.])/is)
				) {	
				$tmp3 = $1;
				$tmp4 = $3;														#DEBUG: print "[CCGR] GOT HERE! [a]<BR>\n";#
				$s =~ s/($tmp3)(.*)($tmp4)/$1$2/isg;	$FOUND=1;				#keep first one	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND3.1]"; }
			}
		}
		#Descendents - Albumname album cover, music: Descendents
		if ($s =~ /([a-z\s]+)( - .* album cover)[\.,]?/i) {						#if we have an album cover...make sure that bandname isn't also redundantly mentioned later in the caption...
			$tmp1=$1;	$tmp2=$2;												#DEBUG:print "[CCGR] tmp1=$tmp1,tmp2=$tmp2<BR>\n";
			if ($s =~  /($tmp1$tmp2[\.,]?)(.*)($tmp1[,\.])/is) {				#DEBUG:print "[CCGR] GOT HERE! [a]<BR>\n";
				$s =~ s/($tmp1$tmp2[\.,]?)(.*)(music: $tmp1[,\.])/$1$2/isg;		#keep first one
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "<B>[FOUND3.5/tmp1=$tmp1/tmp2=$tmp2]<BR>\n[s is now $s]</B><BR>\n"; }
			}
		}
		#Descendents - Albumname album cover, Descendents poster
		if ($s =~ /([a-z\s]+)( - .* album cover)[\.,]?/i) {						#if we have an album cover...make sure that bandname isn't also redundantly mentioned later in the caption...
			$tmp1=$1;	$tmp2=$2;												#DEBUG:			print "[CCHR] tmp1=$tmp1,tmp2=$tmp2<BR>\n";
			if ($s =~  /($tmp1$tmp2[\.,]?)(.*)($tmp1 poster[,\.])/is) {			#DEBUG:			print "[CCHR] GOT HERE! [a]<BR>\n";
				$s =~ s/($tmp1$tmp2[\.,]?)(.*)($tmp1 poster[,\.])/$2$3/isg;		#keep SECOND one 
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "<B>[FOUND3.7/tmp1=$tmp1/tmp2=$tmp2]<BR>\n[s is now $s]</B><BR>\n"; }
			}
		}
		#Freezepop - Albumname album cover, Freezepop
		if ($s =~ /([a-z\s]+)( - .* album cover)[\.,]?/i) {						#if we have an album cover...make sure that bandname isn't also redundantly mentioned later in the caption...
			$tmp1=$1;	$tmp2=$2;												#DEBUG:print "[CCFR] tmp1=$tmp1,tmp2=$tmp2<BR>\n";
			if ($s =~  /($tmp1$tmp2[\.,]?)(.*)($tmp1[,\.])/is) {				#DEBUG:print "[CCFR] GOT HERE! [a]<BR>\n";
				$s =~ s/($tmp1$tmp2[\.,]?)(.*)($tmp1[,\.])/$1$2/isg;			#keep first one
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "<B>[FOUND4/tmp1=$tmp1/tmp2=$tmp2]<BR>\n[s is now $s]</B><BR>\n"; }
			}
		}
		#Freezepop - Albumname CD, Freezepop
		if ($s =~ /([a-z\s]+)( - .* CD)[\.,]?/i) {								#if we have an album cover...make sure that bandname isn't also redundantly mentioned later in the caption...
			$tmp1=$1;	$tmp2=$2;												#DEBUG:print "[CCFS] tmp1=$tmp1,tmp2=$tmp2<BR>\n";
			if ($s =~  /($tmp1$tmp2[\.,]?)(.*)($tmp1[,\.])/is) {				#DEBUG:print "[CCFS] GOT HERE! [a]<BR>\n";
				$s =~ s/($tmp1$tmp2[\.,]?)(.*)($tmp1[,\.])/$1$2/isg;			#keep first one
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND5]"; }
			}
		}
		#Freezepop - Albumname CD, Freezepop - Albumname album cover			
		if ($s =~ /([a-z\s]+)( - .*) CD[\.,]?/i) {								#if we have an CD AND its cover...make sure that both aren't redundantly mentioned in the caption...
			$tmp1=$1;	$tmp2=$2;												#DEBUG:print "[CCFT] tmp1=$tmp1,tmp2=$tmp2<BR>\n";
			if ($s =~  /($tmp1$tmp2 CD[\.,]?)(.*)($tmp1$tmp2 album cover[,\.])/is) {				#DEBUG:print "[CCFT] GOT HERE! [a]<BR>\n";
				$s =~ s/($tmp1$tmp2 CD[\.,]?)(.*)($tmp1$tmp2 album cover[,\.])/$1$2/isg;			#keep first one				#do it both ways because alphabetically...
				#$s =~ s/($tmp1$tmp2 CD[\.,]?)(.*)($tmp1$tmp2 album cover[,\.])/$2/isg;				#keep SECOND one ----		#..."CD" is before "album cover" is before "cd"
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND6]"; }
			}
		}
		#Freezepop - album cover, Freezepop.			The flaw is this only works for the first one, as that one is the one that will get matched; manual adds are still needed for multiple album covers.
		if ($s =~ /([a-z][a-z\s]+)( - .*?)( album cover)[\.,]?/i) {									#if we have an CD cover...the band doesn't need to be mentioned as 'entertainment' since it's already mentioned as the cover
			$tmp1=$1;	$tmp2=$2;	$tmp3=$3;														#DEBUG:print "[CCFU] /tmp1=$tmp1/tmp2=$tmp2/tmp3=$tmp3/<BR>Checking if \$s =~ /(".$tmp1.$tmp2.$tmp3.")(.*)(".$tmp1."[\.])/<BR>\n";#
			if ($s =~  /($tmp1$tmp2$tmp3)(.*)($tmp1[\.])/is) {										#DEBUG:print "[CCFU] GOT HERE! [a]<BR>s/(".$tmp1.$tmp2.$tmp3.")(.*)(".$tmp1."[\.])/\$1\$2/isg<BR>\n";#
				$s =~ s/($tmp1$tmp2$tmp3)(.*)($tmp1[\.])/$1$2/isg;									#keep first one				
				#$s =~ s/($tmp1$tmp2 CD[\.,]?)(.*)($tmp1$tmp2 album cover[,\.])/$2/isg;				#keep SECOND one ----		
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND7]"; }
			}
		}


			
		#Masculinized Females display, masculinized females						#this happened with Museum Of Sex pictures in Manhattan
		if ($s =~ /([a-z\s]+) (display),(.*?)([a-z\s]+)[\.,]?/i) {
			$tmp1=$1;	$tmp2=$2;												#DEBUG:print "[CCFR] tmp1=$tmp1,tmp2=$tmp2<BR>\n";
			if ($s =~  /($tmp1 $tmp2[\.,]?)(.*)($tmp1[,\.])/is) {				#DEBUG:print "[CCFR] GOT HERE! [a]<BR>\n";
				$s =~ s/($tmp1 $tmp2[\.,]?)(.*)($tmp1[,\.])/$1$2/isg;			#keep first one
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND3.10A]"; }
			}
		}


		#dead duck, duck
		if ($s =~ /(dead) ([a-z\s]+)[\.,]?/i) {
			my $tmp1=$1;	my $tmp2=$2;											#DEBUG:print "[CCFR] tmp1=$tmp1,tmp2=$tmp2<BR>\n";			#DEBUG: print "if ($s =~  /(".$tmp1." ".$tmp2."[\.,]?)(.*)(".$tmp1."[,\.])/is) <BR>\n";
			if ($s =~  /($tmp1 $tmp2[\.,]?)(.*)($tmp2[,\.])/is) {				#DEBUG:print "[CCFR] GOT HERE! [a]<BR>\n";
				$s =~ s/($tmp1 $tmp2[\.,]?)(.*)($tmp2[,\.])/$1$2/isg;			#keep first one
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND3.11]"; }
			}
		}


		#Very Hungry Caterpillar, book: Very Hungry Caterpillar
		if ($s =~ /book: *([a-z\s]+)[\.,]?/i) {									#if we have a book...make sure that book isn't also redundantly mentioned later in the caption...
			$tmp1=$1;	#$tmp2=$2;												#DEBUG:			print "[BOOKC] tmp1=$tmp1<BR>\n";#
			if ($s =~  /($tmp1)(.*)(book: $tmp1)/is) {							#DEBUG:		print "[BOOKC] GOT HERE! [a]<BR>\n";#ohoh
				$s =~ s/($tmp1)(.*)(book.)(.*)(book: $tmp1)/$1$2$4/isg;			#in case there is a "book." also
				$s =~ s/($tmp1)(.*)(book: $tmp1)/$1$2/isg;						#and in case there is no "book."
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND8]"; }
			}
		}

		#"Hunter S. Thopmson.<BR>Hunter S. Thompson quote."						#if we have a quote - the name will be mentioned twice (person, and quote) -- suppress this behavior by stripping out the first occurrence of the two
		if ($s =~ /([\.a-z\s^\n]+)? quote[\.,]?/i) {								
			$tmp1=$1;		
			$tmp1 =~ s/^.*\n//;														#I don't understand why newlines are matching up if /s is not applied?!?! but they are. which makes no sense. including periods made it also include newlines, even though the perl spec says that's not supposed to happen! no choice but to strip everything up to and including the newline!																		#DEBUG:			print "[QUOTEA] ///tmp1=$tmp1///<BR>\n";#
			if ($s =~  /($tmp1[\.,])(.*)($tmp1 quote)/is) {							#DEBUG:						print "[QUOTEB] GOT HERE! [bx21g98a]<BR>\n";#
				$s =~ s/($tmp1[\.,])(.*)($tmp1 quote)/$2$3/is;
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND9]"; }
			}
		}

		#"crows painting, painting."	and "crows, crow painting"
		if ($s =~ /([\.a-z\s^\n]+)? paintings*[\.,]?/i) {								
			$tmp1=$1;		
			$tmp1 =~ s/^.+\n//;														#I don't understand why newlines are matching up if /s is not applied?!?! but they are. which makes no sense. including periods made it also include newlines, even though the perl spec says that's not supposed to happen! no choice but to strip everything up to and including the newline!																		#DEBUG:			print "[QUOTEA] ///tmp1=$tmp1///<BR>\n";#
			if ($tmp1 ne "") {
				if ($s =~  /($tmp1 paintings*[\.,])(.*)(paintings*[\.,])/is) {							#DEBUG:						print "[QUOTEB] GOT HERE! [bx21g98a]<BR>\n";#
					$s =~ s/($tmp1 paintings*[\.,])(.*)(paintings*[\.,])/$1$2/is;
					$FOUND=1;	
					if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND10]"; }
				}
				if ($s =~  /($tmp1 paintings*[\.,])(.*)(${tmp1}s*)([\.,])/is) {							#DEBUG:						print "[QUOTEB] GOT HERE! [bx21g98a]<BR>\n";#
					if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "<BR>\n[FOUND11][tmp1=$tmp1/\$1=$1/\$2=$2/\$3=$3]<BR>\n"; }
					if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[s=$s]<BR>\n"; }
					$s =~ s/($tmp1 paintings*[\.,])(.*)(${tmp1}s*)([\.,])/$1$2$3/is;
					if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[s=$s]<BR>\n"; }
					$FOUND=1;	
				}
			}
		}

		#Bender cake, Bender character
		#DEBUG: print "s=$s<BR>\n";#Bender cake, Bender character, birthday cake, candles, cupcakes
		if ($s =~ /([A-Z][a-z\s]+ cake)[,\.].*?([A-Z][a-z\s]+ character)[\.,]?/i) {									#if we have an cake based on a character - we don't need to mention both
			$tmp1=$1;	$tmp2=$2;	$tmp3=$3;														#DEBUG:				print "[CCGU] /tmp1=$tmp1/tmp2=$tmp2/tmp3=$tmp3/<BR>Checking if \$s =~ /".$tmp1.".*".$tmp2."/<BR>\n";#
			if ($s =~  /($tmp1.*$tmp2)/is) {														#DEBUG:				print "[CCGU] FOUND! [a]<BR>s/(".$tmp1.")(.*)(".$tmp2."[\.])/\$1\$2/isg<BR>\n";#
				$s =~ s/($tmp1)(.*)($tmp2)/$1$2/isg;												#keep first one				
#				#$s =~ s/($tmp1$tmp2 CD[\.,]?)(.*)($tmp1$tmp2 album cover[,\.])/$2/isg;				#keep SECOND one ----		
				$FOUND=1;	
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND13]"; }
			}
		}

		#The Jetsons, The Jetsons shirt				
		if ($s =~ /([a-z\s]+),(.*?)([a-z\s]+)( shirts*)[\.,]?/i) {							
			$tmp1 = &remove_leading_and_trailing_spaces($1);
			$tmp2 = &remove_leading_and_trailing_spaces($3);										#DEBUG: print "[CCFW-IF] tmp1=\"$tmp1\",tmp2=\"$tmp2\"<BR>\n"; 
			if ($tmp1 =~ /^$tmp2/i) {																#DEBUG: print "[CCFW-THEN-A] tmp1=\"$tmp1\",tmp2=\"$tmp2\",s=\"$s\"<BR>\n";
				$s =~ s/($tmp1[\.,]?)(.*)($tmp2 shirt*[,\.])/$2$3/isg;								#keep SECOND one ----
				$FOUND=1;																			#DEBUG:	print "[CCFW-THEN-Z] s=\"$s\"<BR>\n";
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND14]"; }
			}
		}


		#something, something shell -> only show "something shell"
		if ($s =~ /([a-z\s]+),(.*?)([a-z\s]+)( shells*)[\.,]?/i) {							
			$tmp1 = &remove_leading_and_trailing_spaces($1);
			$tmp2 = &remove_leading_and_trailing_spaces($3);										#DEBUG: print "[CCFW-IF] tmp1=\"$tmp1\",tmp2=\"$tmp2\"<BR>\n"; 
			if ($tmp1 =~ /^$tmp2/i) {																#DEBUG: print "[CCFW-THEN-A] tmp1=\"$tmp1\",tmp2=\"$tmp2\",s=\"$s\"<BR>\n";
				$s =~ s/($tmp1[\.,]?)(.*)($tmp2 shells*[,\.])/$2$3/isg;								#keep SECOND one ----
				$FOUND=1;																			#DEBUG:	print "[CCFW-THEN-Z] s=\"$s\"<BR>\n";
				if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FOUND15]"; }
			}
		}


	} until (!$FOUND);


	if (($DEBUG_FINAL_CAPTION_KLUDGE>0)||($DEBUG_ASSEMBLE_CAPTION)) { print "[<I>FINAL CAPTI0N KLUDGE</i> RR010] s is $s<BR>\n"; }

	$s =~ s/seagulls birds/seagulls/i;
	$s =~ s/seagull bird/seagull/i;
	$s =~ s/(Church Universal And Triumphant cult[\.,]?)(.*)(Church Universal And Triumphant religion*[,\.])/$1$2/isg;		#keep first one
	$s =~ s/(hair[\.,]?)(.*)(hairy[,\.])/$3/isg;												#keep SECOND one ----
	$s =~ s/(SATA[\.,]?)(.*)(SATA controller card[,\.])/$3/isg;									#keep SECOND one ----
	$s =~ s/(braid[\.,]?)(.*)(pig[\-\ ]*tails[,\.])/$3/isg;										#keep SECOND one ----
	$s =~ s/(bassist[\.,]?)(.*)(playing bass[,\.])/$3/isg;										#keep SECOND one ----
	$s =~ s/(drumming[\.,]?)(.*)(playing drums*[,\.])/$1$2/isg;								#keep first one
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV19K]{{{{{CAPTION=$s}}}}}"; }
	$s =~ s/(drumming[\.,]?)(.*)([a-z ]*drums*[,\.])/$1$2/isg;									#keep first one				#modified from default to be stronger after "drumming, fire twirling, playing drums. glowsticks" became "drumming, fire twirling, playing glowsticks"
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV19L]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(playing bass[\.,]?)(.*)(bass guitar[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(denim jacket[\.,]?)(.*)(jean jacket[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(playing pool[\.,]?)(.*)(pool table[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(SubGenius icon[\.,]?)(.*)(SubGenius[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(lighters* shrine[\.,]?)(.*)(lighters*[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(skulls* shrine[\.,]?)(.*)(skulls*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(flying kite[\.,]?)(.*)(kite[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(playing beer pong[\.,]?)(.*)(playing pong[,\.])/$1$2/isg;							#keep first one
	$s =~ s/([a-z]+ cake[\.,]?)(.*)(birthday cake[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(politician: George Bush[\.,]?)(.*)(politician: George W. Bush[,\.])/$3/isg;		#keep SECOND one ----
	$s =~ s/(holding beer[\.,]?)(.*)(Yuengling beers[,\.])/$1$2/isg;							#keep first one
	$s =~ s/(blood[\.,]?)(.*)(bloody[,\.])/$3/isg;												#keep SECOND one ----
	$s =~ s/(crab[\.,]?)(.*)(crab legs*[,\.])/$3/isg;											#keep SECOND one ----
	$s =~ s/(Norway[\.,]?)(.*)(Norwegian[,\.])/$3/isg;											#keep SECOND one ----
	$s =~ s/(moth[\.,]?)(.*)(Mothra[,\.])/$3/isg;												#keep SECOND one ----
	$s =~ s/(beer[\.,]?)(.*)(beer bottle[,\.])/$3/isg;											#keep SECOND one ----
	$s =~ s/(bird[\.,]?)(.*)(bird corpse[,\.])/$3/isg;											#keep SECOND one ----
	$s =~ s/(shrine[\.,]?)(.*)(tiki shrine[,\.])/$3/isg;										#keep SECOND one ----
	if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FINAL CAPTI0N KLUDGE RR011] s is $s<BR>\n"; }
	#s =~ s/( tree[\.,]?)(.*)(trees[,\.])/$3/isg;												#keep SECOND one ----
	$s =~ s/( tree[\.,]?)(.*)(trees[,\.])/$2$3/isg;												#keep SECOND one ----
	if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FINAL CAPTI0N KLUDGE RR012] s is $s<BR>\n"; }
	$s =~ s/(worker[\.,]?)(.*)(workers[,\.])/$3/isg;											#keep SECOND one ----
	$s =~ s/(breast[\.,]?)(.*)(cleavage[,\.])/$3/isg;											#keep SECOND one ----
	$s =~ s/(cookie[\.,]?)(.*)(go[a]tse cookie[,\.])/$3/isg;									#keep SECOND one ----
	$s =~ s/(Easter egg[\.,]?)(.*)(Easter eggs[,\.])/$3/isg;									#keep SECOND one ----
	$s =~ s/(glowing[\.,]?)(.*)(glowing in the blacklight[,\.])/$3/isg;							#keep SECOND one ----
	$s =~ s/(Christmas holiday[\.,]?)(.*)(Christmas tree[,\.])/$3/isg;							#keep SECOND one ----
	$s =~ s/(Cabbage Patch Kids doll[\.,]?)(.*)(Cabbage Patch Kids dolls[,\.])/$3/isg;			#keep SECOND one ----
	$s =~ s/(Easter[\.,]?)(.*)(Easter eggs*[,\.])/$3/isg;										#keep SECOND one ----
	$s =~ s/(cake cutting[\.,]?)(.*)(cutting cake[,\.])/$3/isg;									#keep SECOND one ----
	$s =~ s/(cake[\.,]?)(.*)(cutting cake[,\.])/$3/isg;											#keep SECOND one ----
	$s =~ s/(Rubik Homer Simpson puzzle[\.,]?)(.*)(Rubik's Homer Simpson puzzle[,\.])/$3/isg;	#keep SECOND one ----
	$s =~ s/(cutting[\.,]?)(.*)(cutting cake[,\.])/$3/isg;										#keep SECOND one ----
	$s =~ s/(Homer Simpson[\.,]?)(.*)(Homer Simpson tin toy[,\.])/$2$3/isg;						#keep SECOND one ----
	$s =~ s/(Ozzy Osbourne No Rest For The Wicked album[\.,]?)(.*)(Ozzy Osbourne clipping[,\.])/$1$2/isg;		#keep first one
	$s =~ s/(air shrine[\.,]?)(.*)(shrine[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(noodle fighting[\.,]?)(.*)(pool noodle[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(bodily contortion[\.,]?)(.*)(contortion[,\.])/$1$2/isg;							#keep first one
	$s =~ s/(playing theramin[\.,]?)(.*)(theramin[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(skiing[\.,]?)(.*)(ski poles*[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(glowing in the blacklight[\.,]?)(.*)(glowing[,\.])/$1$2/isg;						#keep first one
	$s =~ s/(Voltron lion[\.,]?)(.*)(cartoon: Voltron[,\.])/$1$2/isg;							#keep first one
	$s =~ s/(glowing in the blacklight[\.,]?)(.*)(blacklight[,\.])/$1$2/isg;					#keep first one
	$s =~ s/(kayaking[\.,]?)(.*)(kayaks*[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(introducing[\.,]?)(.*)(introduction[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(boating[\.,]?)(.*)(water[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(snowing[\.,]?)(.*)(snow[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(kayaking[\.,]?)(.*)(water[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(drinking[\.,]?)(.*)(drink[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(drumming[\.,]?)(.*)(drumsticks[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(teeth[\.,]?)(.*)(tooth[,\.])/$1$2/isg;												#keep first one
	$s =~ s/(playing harp[\.,]?)(.*)(harp[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(fire shrine[\.,]?)(.*)(shrine[,\.])/$1$2/isg;										#keep first one
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV20P]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(playing guitar[\.,]?)(.*)(guitar[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(studying caterpillar[\.,]?)(.*)(caterpillar[,\.])/$1$2/isg;						#keep first one
	$s =~ s/(humping tree[\.,]?)(.*)(tree[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(stabbing cake[\.,]?)(.*)(wedding cake[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(stabbing cake[\.,]?)(.*)(knife[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(cutting cake[\.,]?)(.*)(knife[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(cutting cake[\.,]?)(.*)(wedding cake[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(eating veil[\.,]?)(.*)(veil[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(costume contest[\.,]?)(.*)(costumes[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(eating tie[\.,]?)(.*)(tie[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(spiral stairs[\.,]?)(.*)(stair[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(26H Terrace View[\.,]?)(.*)(Terrace View[,\.])/$1$2/isg;							#keep first one
	$s =~ s/(wood staining[\.,]?)(.*)(wood[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(sliding[\.,]?)(.*)(slide[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(smoking[\.,]?)(.*)(smoke[,\.])/$1$2/isg;											#keep first one
	$s =~ s/([^,]* tree[\.,]?)(.*)(tree[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(brushing hair[\.,]?)(.*)(hair[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(bouquet toss[\.,]?)(.*)(toss[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(bouquet toss[\.,]?)(.*)(bouquet[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(eating hair[\.,]?)(.*)(hair[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(setting up hammock[\.,]?)(.*)(hammock[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(gathering wood[\.,]?)(.*)(wood[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(caterer[\.,]?)(.*)(catering[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(Testament Poster[\.,]?)(.*)(Testament[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(looking evil[\.,]?)(.*)(evil[,\.])/$1$2/isg;										#keep first one
	$s =~ s/([^,]* clipping[\.,]?)(.*)(clippings[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(blowing smoke[\.,]?)(.*)(smoking[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(opening present[\.,]?)(.*)(present[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(using computer[\.,]?)(.*)(laptop computer[,\.])/$1$2/isg;							#keep first one
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV19Y2Z]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(using computer[\.,]?)(.*)(computer[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(hunting eggs[\.,]?)(.*)(easter eggs*)([,\.])/$2hunting Easter eggs$4/isg;			#keep SECOND one ---- SPECIAL - puts activities on same line as things which could be considered bad
	$s =~ s/(Dr\. Pepper[\.,]?)(.*)(Dr\. Pepper cans*[,\.])/$2$3/isg;							#keep SECOND one 
	$s =~ s/(Mr\. Pibb[\.,]?)(.*)(Mr\. Pibb cans*[,\.])/$2$3/isg;								#keep SECOND one 
	$s =~ s/(Mountain Dew[\.,]?)(.*)(Mountain Dew cans*[,\.])/$2$3/isg;							#keep SECOND one 
	$s =~ s/(Fresca[\.,]?)(.*)(Fresca cans*[,\.])/$2$3/isg;										#keep SECOND one 
	$s =~ s/(Sprite[\.,]?)(.*)(Sprite cans*[,\.])/$2$3/isg;										#keep SECOND one 
	$s =~ s/(Coke[\.,]?)(.*)(Coke cans*[,\.])/$2$3/isg;											#keep SECOND one 
	$s =~ s/(Jolt[\.,]?)(.*)(Jolt cans*[,\.])/$2$3/isg;											#keep SECOND one 
	$s =~ s/(Homer Simpson[\.,]?)(.*)(Rubik\'s Homer Simpson puzzles*[,\.])/$2$3/isg;			#keep SECOND one 
	$s =~ s/(Church Of The SubGenius[\.,]?)(.*)(SubGenius expansion packs*[,\.])/$2$3/isg;		#keep SECOND one 
	$s =~ s/(assassins[\.,]?)(.*)(assassins booster packs*[,\.])/$2$3/isg;						#keep SECOND one 
	$s =~ s/(handwriting[\.,]?)(.*)(handwritten letter*[,\.])/$2$3/isg;							#keep SECOND one 
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV19Z]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(Ratos De Porao - )(.*)(Ratos De Porao\.)/$1$2/isg;									### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Violent Femmes - )(.*)(Violent Femmes\.)/$1$2/isg;									### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Type O Negative - )(.*)(Type O Negative\.)/$1$2/isg;								### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Ministry - )(.*)(Ministry\.)/$1$2/isg;												### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Jane's Addiction - )(.*)(Jane's Addiction\.)/$1$2/isg;								### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Gwar - )(.*)(Gwar\.)/$1$2/isg;														### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Danzig - )(.*)(Danzig\.)/$1$2/isg;													### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Kreator - )(.*)(Kreator\.)/$1$2/isg;												### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Sex Pistols - )(.*)(Sex Pistols\.)/$1$2/isg;										### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Danzig - )(.*)(Danzig\.)/$1$2/isg;													### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Primus - )(.*)(Primus\.)/$1$2/isg;													### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Sabbat - )(.*)(Sabbat\.)/$1$2/isg;													### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Samhain - )(.*)(Samhain\.)/$1$2/isg;												### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
#???$s =~ s/(SubGenius )(.*)(SubGenius\.)/$1$2/isg;												### SPECIAL ###		(keep first one) (no delimiter on first one, period only after second one, but that may break someday)
	$s =~ s/(Maria[\.,]?)(.*)(Ronnie*)([,\.])/$2Grandma$4/isg;									### SPECIAL ###		(keep SECOND one) (grandma-specific)
	$s =~ s/(comic books[\.,]?)(.*)(comics[\:,\.])/$3/isg;										### SPECIAL ###		(keep SECOND one) (SPECIAL because colon delimiter is used)
	$s =~ s/(bodily comedy[\.,]?)(.*)(bodily contortion)([,\.])/funny bodily contortion$4/isg;	### SPECIAL ###		(keep  first one)
	$s =~ s/Wrathchild America clipping, Wrathchild America letter/Wrathchild America clipping and letter/i;		### SPECIAL ###
	$s =~ s/cartoon. *(Cartoon:)/$1/i;															### SPECIAL ###
	$s =~ s/_STATE_\.*, Canada/Canada/i;														### SPECIAL ###
	$s =~ s/Catholic, church/Catholic church/i;													### SPECIAL ###
	$s =~ s/Antarctica, Antarctica/Antarctica/i;												### SPECIAL ###
	$s =~ s/music: *song:/song:/i;																### SPECIAL ###		kind of a kludge!
	$s =~ s/(F)amily crest, family crest,/$1amily crest,/i;										### SPECIAL ###		family crest, family crest
	$s =~ s/(C)hurch, church,/$1hurch,/i;														### SPECIAL ###		church, church
	$s =~ s/(C)hurch, (.*,) church,/$1hurch, $2/i;												### SPECIAL ###		blahblah Church, Stafford, church
	$s =~ s/(C)lintopia, Clintopia/$1lintopia/i;												### SPECIAL ###		Clintopia, Clintopia
	$s =~ s/(C)liopia, Cliopia/$1liopia/i;														### SPECIAL ###		Cliopia  , Cliopia
	$s =~ s/(C)lub, club,/$1lub,/i;																### SPECIAL ###		Club, club
	$s =~ s/(C)onvention (C)enter, convention center,/$1onvention $2enter,/i;					### SPECIAL ###		Convention Center, convention center
	$s =~ s/(M)edical scan, medical scan,/$1edical scan,/i;										### SPECIAL ###		church, church
	$s =~ s/(M)arket, market,/$1arket,/i;														### SPECIAL ###		market, market
	$s =~ s/(P)ark, park,/$1ark,/i;																### SPECIAL ###		Park, park
	$s =~ s/(S)tore, store,/$1tore,/i;															### SPECIAL ###		store, store
	$s =~ s/(F)uneral (H)ome, funeral home,/$1uneral $2ome,/i;									### SPECIAL ###		Funeral Home, funeral home,
	$s =~ s/(H)ospital, hospital,/$1ospital,/i;													### SPECIAL ###		hospital, hospital
	$s =~ s/(H)otel, hotel/$1otel/i;															### SPECIAL ###		hotel, hotel
	$s =~ s/(S)chool, school,/$1chool,/i;														### SPECIAL ###		school, school
	$s =~ s/(Theat[er][re],) theater,/$1/i;														### SPECIAL ###		theatre, theatre
	$s =~ s/CD, CD,/CD,/i;																		### SPECIAL ###		Cd, CD
	$s =~ s/corpse, dead/dead/i;																### SPECIAL ###		makes sense now, but may not be sophisticated enough for future situations
	$s =~ s/rock, rocks([,\.])/rocks$1/i;														### SPECIAL ###
	$s =~ s/(Caves*), cave,/$1,/i;																### SPECIAL ###
	$s =~ s/Terrace View, Terrace View/Terrace View/i;											### SPECIAL ###
	$s =~ s/Easter, Easter/Easter/i;															### SPECIAL ###
	$s =~ s/playing,* playing/playing/i;														### SPECIAL ###
	$s =~ s/The Simpsons, (The Simpsons:)/$1/i;													### SPECIAL ###
	$s =~ s/Montgomery Burns/Mr. Burns/i;														### SPECIAL ###
	$s =~ s/character: //ig;																	### SPECIAL ###
	$s =~ s/(G)oth, goth/$1oth/i;																### SPECIAL ###		goth, goth
	$s =~ s/book\. (book: )/$1/ig;																### SPECIAL ###		#may need updating 
	$s =~ s/Church Of The SubGenius, SubGenius/SubGenius$1/i;									### SPECIAL ###	
	$s =~ s/(, costume, )(costumes*),/$2/i;														### SPECIAL ###
	$s =~ s/Thanksgiving [0-9][0-9][0-9][0-9] holiday/Thanksgiving/i;							### SPECIAL ###		#very lazy programming here
	$s =~ s/Christmas [0-9][0-9][0-9][0-9] holiday/Christmas/i;									### SPECIAL ###		#very lazy programming here
	$s =~ s/Halloween [0-9][0-9][0-9][0-9] holiday/Halloween/i;									### SPECIAL ###		#very lazy programming here
	$s =~ s/Easter [0-9][0-9][0-9][0-9]i*s*h* holiday/Easter/i;									### SPECIAL ###		#very lazy programming here
	$s =~ s/(Halloween .* holiday, )(Halloween)/$2/i;											### SPECIAL ###
	$s =~ s/(costume, )(costumes*)([,\.])/$1$3/i;												### SPECIAL ###	
	$s =~ s/Halloween, Halloween /Halloween /i;													### SPECIAL ###
	$s =~ s/(Halloween) (costume[\.,]?)(.*, )([^,]* costume[,\.])/$1 $4/isg;					### SPECIAL ###		(keep modified SECOND one) (SPECIAL because second one has a [^,]*)
	$s =~ s/(nail art[\.,]?)(.*)Art by James Bernard Lipinski([,\.])/$2 Nail art by Grandad$3/isg;#	SPECIAL ###		#keep SECOND one 
	$s =~ s/costumes, costumes/costumes/i;														### SPECIAL ###
	$s =~ s/([Mm])useum, museum/$1useum/i;														### SPECIAL ###
	$s =~ s/The Misfits, The Misfits/The Misfits/i;												### SPECIAL ###
	$s =~ s/Updated Flats Sorting Machine UFSM/UFSM (Updated Flats Sorting Machine)/i;			### SPECIAL ###
	$s =~ s/Automated Flats Sorting Machine AFSM/AFSM (Automated Flats Sorting Machine)/i;		### SPECIAL ###
	$s =~ s/Small Parcel Bundle Sorter SPBS/Small Parcel Bundle Sorter (SPBS)/i;				### SPECIAL ###
	$s =~ s/360\. great view\. panoramic\. video\./360-degree panoramic video (great view!)./i;	### SPECIAL ###
	$s =~ s/360\. panoramic\. video\./360-degree panoramic video./i;							### SPECIAL ###
	$s =~ s/360\. panoramic\./360-degree panoramic./i;											### SPECIAL ###
	$s =~ s/INWO, Illuminati: New World Order/INWO (Illuminati: New World Order)/i;				### SPECIAL ###
	$s =~ s/INWO \(Illuminati: New World Order\), Steve Jackson/Steve Jackson\'s INWO (Illuminati: New World Order) game/i;				### SPECIAL ###
	$s =~ s/(Christmas[\.,]?)(.*)(Christmas tree*[,\.])/$2$3/isg;  								#keep SECOND one			#post-special!
	$s =~ s/(sticking out tongue[\.,]?)(.*)(tongue[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(trying on dresses[\.,]?)(.*)(dresses[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(trying on dresses[\.,]?)(.*)(dress[,\.])/$1$2/isg;									#keep first one
	$s =~ s/James Lipinski's house and Ronnie/Nanny and Grandad's house/isg;					### SPECIAL ###		#DO NOT COPY#
	$s =~ s/(TV[\.,]?)(.*)(television shows*[,\.])/$2$3/isg;									#keep SECOND one 
	$s =~ s/(underwear[\.,]?)(.*)(underwear strap*[,\.])/$2$3/isg;								#keep SECOND one 
	$s =~ s/(high scores list[\.,]?)(.*)(scores[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(Homer Simpson[\.,]?)(.*)(Homer Simpson slipper*[,\.])/$2$3/isg;					#keep SECOND one 
	$s =~ s/(LOL[\.,]?)(.*)(LOLThing*[,\.])/$2$3/isg;											#keep SECOND one 
	$s =~ s/(holding cups[\.,]?)(.*)(cups[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(blowing bubbles[\.,]?)(.*)(bubbles[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(catching bouquet[\.,]?)(.*)(bouquet[,\.])/$1$2/isg;								#keep first one
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV20Z]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(catching bouquet[\.,]?)(.*)(bouquet toss[,\.])/$1$2/isg;							#keep first one
	$s =~ s/(bouquets*[\.,]?)(.*)(bouquet toss[,\.])/$2$3/isg;									#keep SECOND one 
	$s =~ s/(throwing[\.,]?)(.*)(bouquet[,\.])/$2$3/isg;										#keep SECOND one 
	$s =~ s/(throwing[\.,]?)(.*)(bouquet toss[,\.])/$2$3/isg;									#keep SECOND one 
	$s =~ s/(bouquet[\.,]?)(.*)(bouquet toss[,\.])/$2$3/isg;									#keep SECOND one 
	##
	$s =~ s/wedding dress train/KEEPITKLUDGE101/;
	$s =~ s/wedding dress//i;																	### SPECIAL ### @UNCAPTIONABLE_THINGS didn't seem to work well with things that were actually 2 tags (dress-wedding in this case)
	$s =~ s/KEEPITKLUDGE101/wedding dress train/i;
	##
	$s =~ s/(conga dancing[\.,]?)(.*)(conga line[,\.])/$2$3/isg;								#keep SECOND one 
	$s =~ s/(dancing[\.,]?)(.*)(conga line[,\.])/$2$3/isg;										#keep SECOND one 
	$s =~ s/holding, *holding/holding/i;														### SPECIAL ###
	$s =~ s/eating, *eating/eating/i;															### SPECIAL ###
	$s =~ s/dancing, *dancing/dancing/i;														### SPECIAL ###
	$s =~ s/feeding, *feeding/feeding/i;														### SPECIAL ###
	$s =~ s/bouquet, *bouquet/bouquet/i;														### SPECIAL ###
	$s =~ s/(cutting cake[\.,]?)(.*)(standing[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(feeding cake[\.,]?)(.*)(standing[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(eating[\.,]?)(.*)(sitting[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(crowning[\.,]?)(.*)(standing[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(matchbooks*[\.,]?)(.*)(matche*s*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(flower girls*[\.,]?)(.*)(flowers*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(signing guestbooks*[\.,]?)(.*)(guestbooks*[,\.])/$1$2/isg;							#keep first one
	$s =~ s/(fires*[\.,]?)(.*)(outdoor fireplaces*[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(cutting cakes*[\.,]?)(.*)(sittings*[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(mirrors*[\.,]?)(.*)(reflections*[,\.])/$2$3/isg;									#keep SECOND one 
	$s =~ s/(Christmas lights[\.,]?)(.*)(christmas lights[,\.])/$2$3/sg;						#keep SECOND one 
	$s =~ s/(reclining*[\.,]?)(.*)(recliner[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(singing Happy Birthday*[\.,]?)(.*)(standing[,\.])/$1$2/isg;						#keep first one
	$s =~ s/(creepy eyes*[\.,]?)(.*)(creepy[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(creepy eyes*[\.,]?)(.*)(eyes*[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(huge tails*[\.,]?)(.*)(tails*[,\.])/$1$2/isg;										#keep first one
	$s =~ s/spiral stair railing, spiral stairs/spiral stairs (and railing)/isg;				### SPECIAL ###
	$s =~ s/([a-z ]* country club[\.,]?)(.*)(country club[,\.])/$1$2/isg;						### SPECIAL ###		#keep first one
	$s =~ s/(Guitar Hero[\.,]?)(.*)(Guitar Hero [0-9IVX]+)([,\.])/$3$4/isg;						### SPECIAL ###		#keep SECOND one 
	$s =~ s/(people[\.,]?)(.*)(ravers[,\.])/$2$3/sg;											#keep SECOND one 
	$s =~ s/(, girls*[\.,]?)(.*)(people[,\.])/$2$3/sg;											#keep SECOND one	#modified 2009
	$s =~ s/(ravers[\.,]?)(.*)(rave[,\.])/$2$3/sg;												#keep SECOND one 
	$s =~ s/(Mario[\.,]?)(.*)(Mario Brothers[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(Sonic The Hedgehog[\.,]?)(.*)(Sonic The Hedgehog[,\.])/$1$2/isg;					#keep first one
	$s =~ s/([\.,] *)(cosplay[\.,]?)(.*[\.,]? *)(costumes*[,\.])/$1$3$4/isg;					### SPECIAL ###		#keep first one --- stronger delimiters
	$s =~ s/(cosplay[\.,]?)(.*)([a-z\s]+ costume[,\.])/$2$3/sg;									#keep SECOND one 
	$s =~ s/( cake[\.,]?)(.*)(wedding cake*[,\.])/$2$3/isg;										#keep SECOND one	#added a space before cake 2009 to make cupcakes, wedding cake not set this off
	$s =~ s/^(cake[\.,]?)(.*)(wedding cake*[,\.])/$2$3/isg;										#keep SECOND one	#added a space above necesitated adding a case for when it's the 1st character [so no space before]
	$s =~ s/(karaoke[\.,]?)(.*)(singing karaoke[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(doing jello shot[\.,]?)(.*)(doing jello shots[,\.])/$2$3/isg;						#keep SECOND one 
	$s =~ s/([^a-z]person[\.,]?)(.*)(w*o*man[,\.])/$2$3/isg;									#keep SECOND one	#had to add a space before person so it doesn't affect impersonating
	$s =~ s/(singing[\.,]?)(.*)(microphones*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(doing jello shots*[\.,]?)(.*)(jello shots*[,\.])/$1$2/isg;							#keep first one
	$s =~ s/(naked girls*[\.,]?)(.*)(naked women*[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(naked girls*[\.,]?)(.*)(women*[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(bicycling*[\.,]?)(.*)(riding bicycle*[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(acrobatics*[\.,]?)(.*)(acrobats*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(pumping gas*[\.,]?)(.*)(gas pump*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(pumping gas*[\.,]?)(.*)(gas station*[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(garters*[\.,]?)(.*)(stockings*[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(naked girls*[\.,]?)(.*)(people*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(bicycling[\.,]?)(.*)(tandem bicycle[,\.])/$2$3/isg;								#keep SECOND one 
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV21Z]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/([^a-z]book[\.,]?)(.*)(book[,\.])/$2$3/isg;											#keep SECOND one	#this messes up "scrapbooking" though, so [^a-z] was added many years later
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV21Z1]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(whipping*[\.,]?)(.*)(whip*[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(setting up Gnostica[\.,]?)(.*)(Gnostica board game*[,\.])/$1$2/isg;				#keep first one
	$s =~ s/(setting up Gnostica[\.,]?)(.*)(Gnostica card game*[,\.])/$1$2/isg;					#keep first one
	$s =~ s/(Gnostica[\.,]?)(.*)(Gnostica card game[,\.])/$2$3/isg;								#keep SECOND one 
	$s =~ s/(Gnostica[\.,]?)(.*)(Gnostica medal*[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(tarot card[\.,]?)(.*)(tarot cards*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(setting up Gnostica[\.,]?)(.*)(Gnostica*[,\.])/$1$2/isg;							#keep first one
	$s =~ s/(plow truck[\.,]?)(.*)(snow plow[,\.])/$2$3/isg;									#keep SECOND one 
	$s =~ s/(plowing[\.,]?)(.*)(snow plow[,\.])/$2$3/isg;										#keep SECOND one 
	$s =~ s/(futile[\.,]?)(.*)(futility[,\.])/$2$3/isg;											#keep SECOND one 
	$s =~ s/(clearing icicles[\.,]?)(.*)(cutting icicles[,\.])/$2$3/isg;						#keep SECOND one 
	$s =~ s/(ice[\.,]?)(.*)(icicles[,\.])/$2$3/isg;												#keep SECOND one 
	$s =~ s/(drug[\.,]?)(.*)(drugs[,\.])/$2$3/isg;												#keep SECOND one 
	$s =~ s/(impersonating[\.,]?)(.*)(impersonation contest[,\.])/$2$3/isg;						#keep SECOND one 
	$s =~ s/(playing coin toss[\.,]?)(.*)(tossing coins[,\.])/$2$3/isg;							#keep SECOND one 
	$s =~ s/(bacon[\.,]?)(.*)(bacon-wrapped [^,]+[,\.])/$2$3/isg;								#keep SECOND one  - no need to mention bacon before bacon-wrapped
	$s =~ s/(e-cigarettes*[\.,]?)(.*)(electronic cigarettes*[,\.])/$1$2/isg;					#keep first one
	$s =~ s/(Simpsons Life board game*[\.,]?)(.*)(The Simpsons*[,\.])/$1$2/isg;					#keep first one
	$s =~ s/(raising fists*[\.,]?)(.*)(fist*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(flicking off[\.,]?)(.*)(middle finger*[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(lighting fires*[\.,]?)(.*)(fire*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(grilling[\.,]?)(.*)(grill*[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(missing tiles*[\.,]?)(.*)(tiles*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(passed out[\.,]?)(.*)(sleeping*[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(smoking[\.,]?)(.*)(cigarettes*[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(hate balloons*[\.,]?)(.*)(hot air balloons*[,\.])/$1$2/isg;						#keep first one
	$s =~ s/(hammering*[\.,]?)(.*)(hammer*[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(boating[\.,]?)(.*)(boat[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(boats*[\.,]?)(.*)(sailboat boat[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(smallest waves[\.,]?)(.*)(waves[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(drink menu[\.,]?)(.*)(menu[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(crowdsurfing[\.,]?)(.*)(crowd[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(photobombing[\.,]?)(.*)(photobomb[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(audience[\.,]?)(.*)(people[,\.])/$1$2/isg;											#keep first one
	$s =~ s/(raping[\.,]?)(.*)(rape[,\.])/$1$2/isg;												#keep first one
	$s =~ s/(cybersex[\.,]?)(.*)(, sex[,\.])/$1$2/isg;											#keep first one		#variant modification was required to make this one work well	#DEBUG:	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV21Z2]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(having sex[\.,]?)(.*)(, sex[,\.])/$1$2/isg;										#keep first one		#variant modification was required to make this one work well	#DEBUG: if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV21Z3]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(dolphin statues*[\.,]?)(.*)(dolphins*[,\.])/$1$2/isg;								#keep first one		#DEBUG:	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV21Z4]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(Catholicism religion*[\.,]?)(.*)(Christianity religion*[,\.])/$1$2/isg;			#keep first one		#DEBUG:	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV21Z5]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(threesome*[\.,]?)(.*)(threesome sex*[,\.])/$1$2/isg;								#keep first one		#DEBUG:	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV21Z6]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(homosexuality*[\.,]?)(.*)(gay*[,\.])/$1$2/isg;										#keep first one
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV21Z77]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/(ramp[\.,]?)(.*)(unnecessary ramp[^,]+[,\.])/$2$3/isg;								#keep SECOND one 
	$s =~ s/(animal face[\.,]?)(.*)(animal head[^,]+[,\.])/$2$3/isg;							#keep SECOND one 
	$s =~ s/(fire[\.,]?)(.*)(green fire[^,]+[,\.])/$2$3/isg;									#keep SECOND one 
	$s =~ s/(punishing[\.,]?)(.*)(punishment[^,]+[,\.])/$2$3/isg;								#keep SECOND one 
	$s =~ s/(peace sign[\.,]?)(.*)(victory sign[^,]+[,\.])/$2$3/isg;							#keep SECOND one 
	$s =~ s/(seagull[\.,]?)(.*)(seagulls[,\.])/$2$3/isg;										#keep SECOND one 
	$s =~ s/(taking picture[\.,]?)(.*)(taking pictures[,\.])/$2$3/isg;							#keep SECOND one 
	$s =~ s/(croquet mallot[\.,]?)(.*)(croquet mallots[,\.])/$2$3/isg;							#keep SECOND one 
	$s =~ s/(lobster[\.,]?)(.*)(lobsters[,\.])/$2$3/isg;										#keep SECOND one 
	$s =~ s/(bartender[\.,]?)(.*)(bartenders[,\.])/$2$3/isg;									#keep SECOND one 
	$s =~ s/(Grey Poupon[\.,]?)(.*)(Grey Poupon mustard[,\.])/$2$3/isg;							#keep SECOND one 
	$s =~ s/(bush[\.,]?)(.*)(bushes[,\.])/$2$3/isg;												#keep SECOND one 
	$s =~ s/(seal[\.,]?)(.*)(seals[,\.])/$2$3/isg;												#keep SECOND one 
	$s =~ s/(reflection[\.,]?)(.*)(reflections[,\.])/$2$3/isg;									#keep SECOND one 
	$s =~ s/(water[\.,]?)(.*)(water bottle[,\.])/$2$3/isg;										#keep SECOND one 
	$s =~ s/(boner[\.,]?)(.*)(erection[,\.])/$2$3/isg;											#keep SECOND one 
	$s =~ s/([^a-z])(bag[\.,]?)(.*)(bags[,\.])/$3$4/isg;										#keep SECOND one ------- more bugproof format--but not suitable for general re-use
	$s =~ s/(busker[\.,]?)(.*)(busking[,\.])/$2$3/isg;											#keep SECOND one 
	$s =~ s/(breakdancing[\.,]?)(.*)(dancing[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(LOLanimal[\.,]?)(.*)(LOLthing[,\.])/$1$2/isg;										#keep first one
	$s =~ s/(In20Years[\.,]?)(.*)(In20Years\.com[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(installing attic ladder[\.,]?)(.*)(attic ladder[,\.])/$1$2/isg;					#keep first one
	$s =~ s/(living room window[\.,]?)(.*)(window[,\.])/$1$2/isg;								#keep first one
	$s =~ s/(medical scan[\.,]?)(.*)(medical[,\.])/$1$2/isg;									#keep first one
	$s =~ s/(LOLanimal[\.,]?)(.*)(LOLelephant[,\.])/$2$3/isg;									#keep SECOND one 
	$s =~ s/(ladder[\.,]?)(.*)(ladders[,\.])/$2$3/isg;											#keep SECOND one 
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV22Z]{{{{{CAPTION=$s}}}}}<BR>"; }
	

	


	
	#caption clean final / final caption clean / caption final clean / caption final kludges / final caption kludges / final caption kludges

	if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FINAL CAPTION KLUDGE 00] s(2) is $s<BR>\n"; }

	##### FINAL CAPTION FORMATTING KLUDGES/FIXES:
	$s =~ s/(Museum Of .*,) museum,/$1/i;					#"Museum Of Sex, museum, Manhattan" doesn't quite have the correct ring to it. Basically, the word museum should only be in the caption of the museum itself doesn't have the word "museum" in the title. Otherwise, it gets redundant.
	$s =~ s/sailboat boat/sailboat/ig;
	$s =~ s/, *shopping center/ shopping center/i;			#We want "Bradlick shopping center" not "Bradlick, shopping center"
	$s =~ s/music:[ \n]*([a-z])/$1/sg;						#line consisting of "music: lowercasesomething" are leftover badness from the kludge to remove duplicate music references. Bands don't start with lowercase letters, so this is always bad when this happens.
	$s =~ s/movie: James Bond. movie:/movie: James Bond:/;	#This happened, and shouldn't have.
	$s =~ s/movie\.//;					#it may say "movie: Brazil" but then someone will add "Brazil shirt" which will trigger code to remove the dupliate "Brazil", ending up with simply "Movie.", which doesn't make as much sense. So remove it.
	$s =~ s/cartoon\.//;				#same as above, but with   "cartoon."   instead of "movie."
	$s =~ s/comic books\.//;			#same as above, but with "comic books." instead of "movie."
	$s =~ s/ *\n/\n/g;					#lines shouldn't end in trailing spaces -- this can mess up the rest of the cleanup!
	$s =~ s/, *\n/.\n/g;				#comma before end of line - v2
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "<BR>[CV3A]{{{{{CAPTION=$s}}}}}<BR>"; }
	$s =~ s/, *_ENT_/._ENT_/isg;		#comma before end of line - v3
	if ($DEBUG_FINAL_CAPTION_KLUDGE || 0) { print "[CV3B]{{{{{CAPTION=$s}}}}}<BR><BR>"; }
	$s =~ s/, *,/,/g;					#comma duplicates / duplicate commas
	$s =~ s/(\n) *\. *\n/$1/g;			#period all alone on a line
	$s =~ s/(<BR>)\.<BR>/$1/g;			#period all alone on a line
	$s =~ s/(\.) *\./$1/g;				#period duplicates / duplicate periods
	$s =~ s/ (\.)/$1/g;					#period with a bad space before it 
	$s =~ s/([\?\!])\.(<BR>)/$1$2/g;	#lines shouldn't end in "!." or "?."
	$s =~ s/([\?\!])\.(\n)/$1$2/g;		#lines shouldn't end in "!." or "?."
	$s =~ s/([a-z])\n/$1./ig;			#lines SHOULD end in a period rather than nothing
	$s =~ s/_SPC_/ /g;					#just in case							#special
	$s =~ s/ *, /, /sg;					#space before comma
	$s =~ s/(http:\/\/[^\s]+),/$1 ,/g;	#space before comma removal is problematic with URLs, which need a space after them or they wont auto-highlight correctly
	$s =~ s/\.*, /, /sg;				#period before comma
	$s =~ s/,(\.)/$1/g;					#comma before period
	$s =~ s/music: *_ENT_//ig;			#line consisting solely of "music:", due to previous transformations
	$s =~ s/music: *\n//ig;				#line consisting solely of "music:", due to previous transformations
	$s =~ s/before. before/before/i;
	$s =~ s/after. after/after/i;
	$s =~ s/music: TV show/TV show/i;
	$s =~ s/playing *playing/playing/i;
	$s =~ s/playing\.Gnostica/playing Gnostica/i;												### SPECIAL ###
	$s =~ s/Building building/Building/i;
	$s =~ s/comic strip. comic strip/comic strip/i;
	$s =~ s/Floristree,Baltimore/Floristree, Baltimore/i;										#probably some tree-related code was killing that space...
	$s =~ s/Taco Bell, KFC, restaurant/Taco Bell\/KFC restaurant/i;
	$s =~ s/music\.//i;																			### SPECIAL ###			# 201001		#tired of seeing   "music." alone - maybe taking it out is the right thing to do
	$s =~ s/TV show\.//i;																		### SPECIAL ###			# 201001		#tired of seeing "TV show." alone - maybe taking it out is the right thing to do
	$s =~ s/after derecho. after storm/after derecho storm/i;
#	$s =~ s/telephone pole,s/telephone poles/i;						#don't feel like figuring this one out today
	if ($DEBUG_FINAL_CAPTION_KLUDGE>0) { print "[FINAL CAPTION KLUDGE 99] s(2) is $s<BR>\n"; }
	#print "[-X]";

	##### IMPORT ANY CAPTIONS FROM THE TAGFILE, AND PUT AT THE BEGINNING:
	##### (Why not do this first? Because then the transformations above, meant for auto-captioned tags, will also apply to typed up captions -- which should be JUST FINE:
	$tmp=$captionsFromTagfile{$file};
	if ($tmp ne "") { $s = &make_caption_safe_for_command_line($tmp) . "<BR><BR>" . $s;	}
	#print "[-Y]";


	##### Use &linkify to auto-link anything in the caption that deserves this:
	my @CAPTION_LINES=split(/\n/,"$s");
	my $retval="";
	my $anotherTemp;
	my $yetAnotherTemp;
	foreach $tmp (@CAPTION_LINES) { 
		#DEBUG:	print "[1]";
		if ($tmp =~ /Pic by (flickr user )([0-9a-z\_\-\s]+?)\./i) {
			$tmp1=$1; $tmp2=$2;													#DEBUG: print "Here we are! tmp1=$tmp1/tmp2=$tmp2!<BR>";#
			$tmpname = $tmp2;
			$tmpname =~ s/ /\+/g;												#URLify the name [basic]
			$tmplink = qq[<a target="_$tmpname" href="http://www.flickr.com/search/people/?q=\%22$tmpname\%22&m=names">$tmp1$tmp2</a>];			#DEBUG: print "tmp1tmp2=$tmp1$tmp2 and tmplink=$tmplink!<BR><BR>";#
			$tmp =~ s/$tmp1$tmp2/$tmplink/i;
		}
		#DEBUG: print "[2]";
		$anotherTemp=&censor_caption($tmp);		
		                      $yetAnotherTemp =          $anotherTemp;
		if (!$STOP_LINKIFY) { $yetAnotherTemp = &linkify($anotherTemp); }

		$retval .= "$yetAnotherTemp \n";
	}
	#print "[-Z]";


	##### RETURN THE ASSEMBLED CAPTION:
	return($retval);
}#endsub assemble_caption 
###########################################################
###########################################################


##########################################################################
sub remove_leading_and_trailing_spaces {
	my $s = $_[0];
	$s =~ s/^\s+//g;
	$s =~ s/\s+$//g;
	return($s);
}#endsub remove_leading_and_trailing_spaces
##########################################################################


###########################################################
sub add_tag {
	my $dirtytag = $_[0];
	my $file     = $_[1];
	my $from     = $_[2];		#used for recursion-y verbosity (debug)
	my $capture  = $_[3];		#set to 0 to NOT capture any information for auto-captioning
	my $MODE     = $_[4];		#sometimes we inherit mode. don't ask 
	#ASSUME GLOBAL $current_full_tag;		#space is " "       in $current_full_tag
	#ASSUME GLOBAL $global_tag;
	#IS USED HERE A LOT:	$tmp			#space is "_SPC_" in $tmp
	if (($DEBUG_REMOVE>0) ||($DEBUG_ADDTAG_CALL>0) || ($DEBUG_THING>0)) { print "<B>=>[&AT] &add_tag($_[0],$_[1],$_[2],$_[3],$_[4]); TYPE=$TYPE \t</B><BR>\n"; }
	my $DO_IT	 = 1;			#0 = don't bother,  -2 = blacklisted
	my $mode     = "add";
	if ($MODE eq "noadd") { return; }


	###### dehyphenate [helps reduce typos breaking things]
	$dirtytag =~ s/WASR-10/WASR 10/;					#for gun makes and models, you absolutely need hyphens in the tags, and hyphens are special characters in my system, so we take them out now and put them back in later
	$dirtytag =~ s/Mosin-Nagant/MosinNagant/;			#for gun makes and models, you absolutely need hyphens in the tags, and hyphens are special characters in my system, so we take them out now and put them back in later


	if (($dirtytag =~ /^-+/) || ($MODE eq "remove") || ($MODE eq "blacklist")) { 
		#We gotta deal with it, right here, right now.
		my $tmptagclean = "";

		#Determine if it's remove or blacklist:
		$mode = "remove"; 
		if ($dirtytag =~ /^--/) { 
			$mode="blacklist"; 
			if ($DEBUG_REMOVE>0) { print "* Mode set to blacklist for $dirtytag....<BR>\n"; }
		}
		$dirtytag =~ s/^-+//;
		$dirtytag =~ s/ /_SPC_/g;
		#DEBUG: print "dirtytag is now $dirtytag \n";

		#Now, get rid of the association:
		my $REMOVE_IT=0;
		if ($mode eq "remove") {
			$REMOVE_IT=1;
		} elsif ($mode eq "blacklist") {		#blacklist not implemented properly
			$REMOVE_IT=1;
		}
		if ($DEBUG_REMOVE>0) { print "<B>And now[0]: ".$tags{$file}."</B> (REMOVE_IT=$REMOVE_IT)<BR>\n"; }
		if ($REMOVE_IT) {
			if ($DEBUG_REMOVE>0) { print "We need to remove $dirtytag so lets try cleaning it.<BR>\n"; }

			$tmptagclean = &clean_tag($dirtytag,$file,$from,$mode);	
			if ($DEBUG_REMOVE>0) { print "<BR>\nWe now remove tmpcleantag=\"$tmpcleantag\",tmptagclean=\"$tmptagclean\" from [TT3]\$tags for \"$file\" which is ".$tags{$file}.".  <BR>\n(dirtytag=$dirtytag,file=$file,from=$from) <BR>\n"; }

			$tags{$file} =~ s/^$tmptagclean$//i;
			if ($DEBUG_REMOVE>0) { print "<B>And now[1]: ".$tags{$file}."</B><BR>\n"; }

			$tags{$file} =~ s/^$tmptagclean,//i;
			if ($DEBUG_REMOVE>0) { print "<B>And now[O2]: ".$tags{$file}."</B><BR>\n"; }

			$tags{$file} =~ s/,$tmptagclean,//i;
			if ($DEBUG_REMOVE>0) { print "<B>And now[3]: ".$tags{$file}."</B><BR>\n"; }

			$tags{$file} =~ s/,$tmptagclean$//i;
			if ($DEBUG_REMOVE>0) { print "<B>And now[4B]: ".$tags{$file}."</B><BR>\n"; }

			#anti-autocaption anti autocaption -  UNFINISHED TODO OH
			#DO NOT DO THIS! $tmptagclean =~ s/_SPC_/ /g;:thing-toy-Voltron-large
			$things{"$file$DELIMITER$tmptagclean"}="";
			$people{"$file$DELIMITER$tmptagclean"}="";
			$place{"$file$DELIMITER$tmptagclean"}="";	#wrong but un-damaging
			$place{"$file"} =~ s/$tmptagclean//i;		#right
			if ($DEBUG_REMOVE>1) { print "<i>\$place{\$file}=".$place{$file}."</i><BR>\n"; }
			$activities{"$file$DELIMITER$tmptagclean"}="";
			$other{"$file$DELIMITER$tmptagclean"}="";
			$cameraperson{"$file$DELIMITER$tmptagclean"}="";
			$entertainment{"$file$DELIMITER$tmptagclean"}="";
			$date{"$file$DELIMITER$tmptagclean"}="";
			$artby{"$file$DELIMITER$tmptagclean"}="";
			$animals{"$file$DELIMITER$tmptagclean"}="";

			#all this probably not necessary, doing it
			#for tmptagCLEAN is all that's truly necessary:
			$things{"$file$DELIMITER$tmptag"}="";
			$people{"$file$DELIMITER$tmptag"}="";
			$place{"$file$DELIMITER$tmptag"}="";	#wrong but un-damaging
			$place{"$file"} =~ s/$tmptag//i;		#right
			$activities{"$file$DELIMITER$tmptag"}="";
			$other{"$file$DELIMITER$tmptag"}="";
			$cameraperson{"$file$DELIMITER$tmptag"}="";
			$entertainment{"$file$DELIMITER$tmptag"}="";
			$date{"$file$DELIMITER$tmptag"}="";
			$artby{"$file$DELIMITER$tmptag"}="";
			$animals{"$file$DELIMITER$tmptag"}="";
		}
		return;
	}
	if ($file eq "") { print "BAD ERROR 1X19U: No \$file given to \&add_tag(".$dirtytag.")!"; }
	if ($capture     eq    "") { $capture=1; }
	if ($FORCE_ALL_CAPTIONING) { $capture=1; }
	if ( $STOP_ALL_CAPTIONING) { $capture=0; }


	#DEBUG:	print "capture is currently $capture for $dirtytag!<BR>\n";#ohoh

	$tmpcleantag = &clean_tag($dirtytag,$file,$from,$mode);
	if ($tmpcleantag eq "") { return; }
	if ($DEBUG_TAGCLEAN_RECURSION_PAIN) { print "====> [TC] \$tmpcleantag is \"$tmpcleantag\" <BR>\n"; }
	if ($DEBUG_TAGCLEAN_RECURSION_PAIN) { print "====> [UF] used_in_this_file{$tmpcleantag}  -IS-  \"".$used_in_this_file{$tmpcleantag}."\" <BR>\n"; }
	#DEBUG-TAG-TYPE-SESING: print "\$TYPE = $TYPE<BR>\n";
	#if ($used_in_this_file{$tmpcleantag} eq "") {

	#SET DO_IT TO 0, IF THE TAG IS ALREADY IN THERE..
	#(THAT WONT STOP US FROM *REMOVING* THE TAG, OF COURSE, 
	# IF THAT'S WHAT WE'RE BEING ASKED TO DO.) 
	if (($tags{$file} =~/^$tmpcleantag$/) || 
	    ($tags{$file} =~/^$tmpcleantag,/) ||
	    ($tags{$file} =~/,$tmpcleantag,/) ||
	    ($tags{$file} =~/,$tmpcleantag$/)) {
		#print "** $tmpcleantag is found in $file. mode is $mode...   <BR>\n";#
			if ($mode ne "remove")    { $DO_IT= 0; }
			if ($mode eq "blacklist") { $DO_IT=-2; }
	}
	if ($DO_IT == -2) {	#if we are --'ing the tag, blacklisting it, it should NEVER be used, even if other rules come up conflicting this one.
		print "mode must be $mode now.  This should never happen.  Lost train of thought.<BR>\n";
	} elsif ($DO_IT) {	#if we are adding or --'ing the tag
		if ($mode eq "add") {
			if ($DEBUG_TAGCLEAN_RECURSION_PAIN) { print "====> [SU] setting \$used_in_this_file{".$tmpcleantag."}=\"1\"; <BR>\n"; }
			#$used_in_this_file{$tmpcleantag}="1";
			if ($tags{$file} ne "") { $tags{$file}.=","; }		#comma-delimited
			$tags{$file} .= $tmpcleantag;
			if ($global_tag) {
				#DEBUG:		if ($globaltags{$tmpcleantag} eq "") { print "adding \$globaltags{$tmpcleantag}...<BR>\n"; }
				$globaltags{$tmpcleantag}="1";	
			}
			if ($DEBUG_TAGCLEAN_RECURSION_PAIN) { print "====> [TT2]\$tags{\$file} .= $tmpcleantag;\n"; }
			$tags{$file} =~ s/,$//;			#just in case of sloppiness elsewhere

			##### AUTO-CAPTION STUFF:
			if ($capture) {
				if ($TYPE eq "thing") {
					$tmppush=1;
					foreach my $uncaptionable_thing (@UNCAPTIONABLE_THINGS) {
						#DEBUG: print "* Checking if $tmpcleantag =~ /^".$uncaptionable_thing."\$/i ... <BR>\n"; #
						if ($tmpcleantag =~ /^$uncaptionable_thing$/i) { $tmppush=0; }
					}
					$tmp = $tmpcleantag;

					##### EXCEPTIONS/MODIFICATIONS TO AUTO-CAPTION FOR THINGS:
					if ( (($tmp =~ /^flag$/i)||($tmp =~ /^pirate$/i) || ($tmp =~ /^pirate flag$/i))  && ($current_full_tag =~ /^thing-flag-pirate$/i  )) { $tmppush=0 ; }
					if ($tmp =~ /^pirate_SPC_flag$/i) { $tmppush=0;	}
					if ($tmp =~ /^Jolly_SPC_Roger$/i) { $tmp="Jolly Roger (pirate flag)";	}
					#DEBUG: print "\$tmp is $tmp... \$current_full_tag is $current_full_tag<BR>\n";
					#a pattern is developing:
					foreach $tmpthing ("fire") {
						if (($tmp =~ /^$tmpthing-?$/i)    && ($current_full_tag =~ /$tmpthing-/i       )) { $tmppush=0; }
					}
					# ^^^ new 
					# vvv old
					if (($tmp =~ /^sculpture-?$/i)        && ($current_full_tag =~ /sculpture-/i       )) { $tmppush=0; }
					if (($tmp =~ /^injury-?$/i)           && ($current_full_tag =~ /injury-/i          )) { $tmppush=0; }
					if (($tmp =~ /^burn-?$/i)             && ($current_full_tag =~ /burn-/i            )) { $tmppush=0; }
					if (($tmp =~ /^grass-?$/i)            && ($current_full_tag =~ /grass-/i           )) { $tmppush=0; }
					if (($tmp =~ /^food-?$/i)             && ($current_full_tag =~ /food-/i            )) { $tmppush=0; }
					if (($tmp =~ /^water-?$/i)            && ($current_full_tag =~ /water-/i           )) { $tmppush=0; }
					if (($tmp =~ /^torch-?$/i)            && ($current_full_tag =~ /torch-/i           )) { $tmppush=0; }
					if (($tmp =~ /^mp3_SPC_player-?$/i)   && ($current_full_tag =~ /mp3 player-iPod/i  )) { $tmppush=0; }
					if (($tmp =~ /^art$/i)                && ($current_full_tag =~ /sculpture-sand/i   )) { $tmppush=0; }					# slight variation of above pattern

					#another pattern is developing:
					#I believe the behavior is that this whole tag
					#will simply become one caption:
					if ( (($tmp =~ /^(foo[sz]ball)$/i) || ($tmp =~ /^table$/i     ))  &&  ($current_full_tag =~ /^thing-table-$1/i            )) { $tmp = "$1 table"            ; }		#remember,
					#f ( (($tmp =~ /^picnic$/i)        || ($tmp =~ /^table$/i     ))  &&  ($current_full_tag =~ /^thing-table-picnic$/i       )) { $tmp = "picnic table"        ; }		#this is still
					if ( (($tmp =~ /^cell$/i)          || ($tmp =~ /^phone$/i     ))  &&  ($current_full_tag =~ /^thing-phone-cell$/i         )) { $tmp = "cell phone"          ; }		#just caption
					if ( (($tmp =~ /^building$/i)      || ($tmp =~ /^abandoned$/i ))  &&  ($current_full_tag =~ /^thing-building-abandoned$/i )) { $tmp = "abandoned building"  ; }		#stuff, NOT 
					if ( (($tmp =~ /^Christmas$/i)     || ($tmp =~ /^light$/i     ))  &&  ($current_full_tag =~ /^thing-light-Christmas$/i    )) { $tmp = "Christmas lights"    ; }		#tag stuff!
					if ( (($tmp =~ /^water$/i)         || ($tmp =~ /^gun$/i       ))  &&  ($current_full_tag =~ /^thing-gun-water$/i          )) { $tmp = "water gun"           ; }
					if ( (($tmp =~ /^toy$/i)           || ($tmp =~ /^bat$/i       ))  &&  ($current_full_tag =~ /^thing-boat-toy$/i           )) { $tmp = "toy boat"            ; }
					if ( (($tmp =~ /^cowboy$/i)        || ($tmp =~ /^hat$/i       ))  &&  ($current_full_tag =~ /^thing-hat-cowboy$/i         )) { $tmp = "cowboy hat"          ; }
					if ( (($tmp =~ /letters$/i)        || ($tmp =~ /^faded$/i     ))  &&  ($current_full_tag =~ /^thing-letters-faded$/i      )) { $tmp = "faded letters"       ; }
					if ($SUBTYPE eq "animal") {	
						$tmp =~ s/ .*$//; 
						if ($DEBUG_AUTOCAPTION) { print "====== [DEBUG_AUTOCAPTION] tmp is \"$tmp\", animal_named is \"$ANIMAL_NAMED\".<BR>&is_animal_name($ANIMAL_NAMED) is ".&is_animal_name($ANIMAL_NAMED)."<BR>\n"; }
						if ($tmp =~ /^$ANIMAL_NAMED$/i) { $tmppush=0; }
						#DEBUG: if ($ANIMAL_NAMED ne "")		{ print " [ANIMAL_NAMED ne \"\"]"; }
						#DEBUG: if ($tmp !~ /^$ANIMAL_NAMED$/i) { print " [\$"."tmp !~ /^\$"."ANIMAL_NAMED"."\$/i] "; }
						if (($ANIMAL_NAMED ne "") && ($tmp !~ /^$ANIMAL_NAMED$/i) && (&is_animal_name($ANIMAL_NAMED))) {
							if ($DEBUG_ASSEMBLE_CAPTION) { print "[IAN_ADD_THE,tmp=$tmp]"; }
							$tmp =~ s/_SPC_[^\s]+$//i;
							$tmp .= " the $ANIMAL_NAMED";
							#moved below, so it's for all things not just animals: if ($APPEND_TO_CAPTION    ne "") { $tmp .= "$APPEND_TO_CAPTION"   ; }
							#moved below, so it's for all things not just animals: if ($REPLACE_CAPTION_WITH ne "") { $tmp  = "$REPLACE_CAPTION_WITH"; }	#perhaps $REPLACE_CAPTION_WITH should be reset to "" here
						}
					}
					if ($APPEND_TO_CAPTION    ne "") { $tmp .= "$APPEND_TO_CAPTION"   ; }
					if ($REPLACE_CAPTION_WITH ne "") { $tmp  = "$REPLACE_CAPTION_WITH"; }	#perhaps $REPLACE_CAPTION_WITH should be reset to "" here
					#f ($REPLACE_CAPTION_WITH ne "") { $tmp  = "$REPLACE_CAPTION_WITH"; $REPLACE_CAPTION_WITH=""; }	#20120529 poposed bug fix for Transformers-Autobot-Blaster showing up on another image simply from tagging it afterward in the attrib.lst file, but it turns out the real problem was I was not resetting $REPLACE_CAPTION_WITH where I normally am supposed to.  This is not necessary. Though it would fix the problem of forgetting to reset $REPLACE_CAPTION_WITH. I suppose this is where object-oriented deconstructor functions come in handy.
					if ($tmppush) {
						$tmp =~ s/_SPC_/ /g;
						if ($DEBUG_ASSEMBLE_CAPTION) { print "setting[1] \%things [$file$DELIMITER$tmp]=1 (subtype = $SUBTYPE)<BR>\n"; }
						$things{"$file$DELIMITER$tmp"}="1";
					}

					if ($REPLACE_CAPTION_WITH ne "") { $tmp  = "$REPLACE_CAPTION_WITH"; }	#perhaps $REPLACE_CAPTION_WITH should be reset to "" here


				#auto-caption stuff continues
				#} elsif ($TYPE eq "animal") {
				} elsif ($TYPE eq "activity") {
					$tmppush=1;
					foreach my $uncaptionable_thing (@UNCAPTIONABLE_ACTIVITIES) {
						if ($tmpcleantag =~ /^$uncaptionable_thing$/i) { $tmppush=0; }
					}
					if (($tmpcleantag =~ /^game$/   ) && ($current_full_tag =~ /^activity-game-/))    { $tmppush=0; }
					if (($tmpcleantag =~ /^sports?$/) && ($current_full_tag =~ /^activity-sports?-/)) { $tmppush=0; }
					$tmp = $tmpcleantag;
					if ($tmppush) {
						$tmp =~ s/_SPC_/ /g;
						if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[X2] $file$DELIMITER$tmp onto \%activities<BR>\n"; }
						$activities{"$file$DELIMITER$tmp"}="1";
					}
				} elsif ($TYPE eq "place") {
					$tmp2=0;		#a flag for if we've used this yet
					#$tmppush=1;	
					#^^^ non-captionable places not implemented yet
					if ($place{$file} eq "") { $place{$file}="_CITY_, _STATE_."; }
					foreach my $state (@STATES) {
						if ($tmpcleantag =~ /^$state$/i) { 
							$tmp2=1;
							$place{"$file"} =~ s/_STATE_/$state/; 
							if ($DEBUG_ASSEMBLE_CAPTION) { print "setting \%place{$file} to ".$place{$file}."<BR>\n"; }
						}
					}
					if ($tmp2==0) {
						foreach my $city (@CITIES) {
							if ($tmpcleantag =~ /^$city$/i) { 
								$tmp2=1;
								$place{"$file"} =~ s/_CITY_/$city/; 
								if ($DEBUG_ASSEMBLE_CAPTION) { print "setting \%place{$file} to ".$place{$file}."<BR>\n"; }
							}
						}
					}
					if ($tmp2==0) {
						foreach my $country (@COUNTRIES) {
							if ($tmpcleantag =~ /^$country$/i) { 
								$tmp2=1;
								$place{"$file"} .= ", $country"; 
								if ($DEBUG_ASSEMBLE_CAPTION) { print "setting \%place{$file} to ".$place{$file}."<BR>\n"; }
							}
						}
					}
					if ($tmp2==0) {
						#if ($tmppush) {
						if ($DEBUG_ASSEMBLE_CAPTION) { print "changing \%place{$file} to $tmpcleantag".", $place{$file}<BR>\n"; }
						$place{$file} = $tmpcleantag . ", " . $place{$file};
						#}
					}
				#auto-caption stuff continues
				} elsif ($TYPE eq "date") {
					if ($DEBUG_AUTOCAPTION_DATE) { $DEBUG_ASSEMBLE_CAPTION=1; }
					#if (($file =~ /^[12][90][0-9][0-9]/) || ($file =~ /[12][90][0-9][0-9]_*[01][0-9]_*[0-3][0-9]/)) {
					#	if ($DEBUG_ASSEMBLE_CAPTION>1) { print "No need to DATEcaption file $file because date is in the filename already...<BR>\n"; }
					#} else {
					#	if ($DEBUG_ASSEMBLE_CAPTION>1) { print "We DO need to caption file $file ...(tmpcleantag = ".$tmpcleantag.") (date{file} is ".$date{$file}.")<BR>\n"; }
						#20080502 - no clue what I broke, but $tmpcleantag is equalling some very untoward things here: "_SPC_200703" "_SPC_Mom'sBirthday20070331" and such
						$tmpcleantag =~ s/^_SPC_//i;
						if ((($date{$file} eq "") || (length($tmpcleantag) > length($date{$file})))
							&&
							($tmpcleantag !~ /[a-z]/i)
							)
							{
							if ($DEBUG_ASSEMBLE_CAPTION) { print "Setting date{$file}=$tmpcleantag<BR>\n"; }
							$date{$file} = $tmpcleantag;
						}
					#}
					if ($DEBUG_AUTOCAPTION_DATE) { $DEBUG_ASSEMBLE_CAPTION=0; }
				} elsif ($TYPE eq "artby") {
					#this one is actually handled elsewhere
				} elsif ($TYPE eq "person") {
					#this one is actually handled elsewhere
				} elsif ($TYPE eq "entertainment") {
					if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[8] $file$DELIMITER$tmpcleantag onto \%entertainment<BR>\n"; }
					#movie, tv, tv show, cartoon, things like that will have to be programmed here later
					#cartoon/anime/tv show
					if ($entertainment{"$file$DELIMITER"."movie"}=="1") {
						$entertainment{"$file$DELIMITER"."movie"}=0;
						$entertainment{"$file$DELIMITER"."movie: ".$tmpcleantag}="1";				
					} elsif ($entertainment{"$file$DELIMITER"."music"}=="1") {
						$entertainment{"$file$DELIMITER"."music"}=0;
						$entertainment{"$file$DELIMITER"."music: ".$tmpcleantag}="1";				
						#DEBUG:						print "\$entertainment{\"$file$DELIMITER\".\"music: $tmpcleantag}=1";	#		
					} elsif ($entertainment{"$file$DELIMITER"."comic books"}=="1") {
						$entertainment{"$file$DELIMITER"."comic books"}=0;
						$entertainment{"$file$DELIMITER"."comics: ".$tmpcleantag}="1";				
					} elsif ($entertainment{"$file$DELIMITER"."comic strip"}=="1") {
						$entertainment{"$file$DELIMITER"."comic strip"}=0;
						$entertainment{"$file$DELIMITER"."comic strip: ".$tmpcleantag}="1";				
					} elsif ($entertainment{"$file$DELIMITER"."cartoon"}=="1") {
						$entertainment{"$file$DELIMITER"."cartoon"}=0;
						$entertainment{"$file$DELIMITER"."cartoon: ".$tmpcleantag}="1";				
					} elsif ($entertainment{"$file$DELIMITER"."anime"}=="1") {
						$entertainment{"$file$DELIMITER"."anime"}=0;
						$entertainment{"$file$DELIMITER"."anime: ".$tmpcleantag}="1";				
					} elsif ($entertainment{"$file$DELIMITER"."book"}=="1") {
						$entertainment{"$file$DELIMITER"."book"}=0;
						$entertainment{"$file$DELIMITER"."book: ".$tmpcleantag}="1";				
					} elsif ($entertainment{"$file$DELIMITER"."poem"}=="1") {
						$entertainment{"$file$DELIMITER"."poem"}=0;
						$entertainment{"$file$DELIMITER"."poem: ".$tmpcleantag}="1";				
					} elsif ($entertainment{"$file$DELIMITER"."TV show"}=="1") {
						$entertainment{"$file$DELIMITER"."TV show"}=0;
						$entertainment{"$file$DELIMITER"."TV show: ".$tmpcleantag}="1";				
					} elsif ($entertainment{"$file$DELIMITER"."video"}=="1") {
						$entertainment{"$file$DELIMITER"."video"}=0;
						$entertainment{"$file$DELIMITER"."video: ".$tmpcleantag}="1";				
					} else {
						$entertainment{"$file$DELIMITER$tmpcleantag"}="1";				
					}
				} elsif ($TYPE eq "cameraperson") {
					#this one is actually handled elsewhere
				} elsif ($TYPE eq "event") {
					#don't really do anything with these, as there are 
					#multiple ones per pic sometimes and that would be 
					#ugly, plus the event is automatically inserted into 
					#the filename we we do "allfiles mv", so having an event
					#listed in the caption itself can be a bit redudant
				#auto-caption stuff continues
				} elsif (($TYPE eq "comedy") || ($TYPE eq "")) {		#"other"
					### ^^^ note, I'm being kinda lazy putting 'comedy' in here. But it works!
						$tmppush=1;
						foreach my $uncaptionable_other (@UNCAPTIONABLE_OTHERS) { if ($tmpcleantag =~ /^$uncaptionable_other$/i) { $tmppush=0; } }
						#DEBUG:	print "tmpcleantag is $tmpcleantag ==== current_full_tag is $current_full_tag  <BR>\n";
						if (($tmpcleantag =~ /^comedy$/) && ($current_full_tag =~ /^comedy-/)) { $tmppush=0; }
						if ($tmppush) {
							$tmp =~ s/_SPC_/ /g;
							if ($DEBUG_ASSEMBLE_CAPTION) { print "pushing[3] $file$DELIMITER$tmpcleantag onto \%other<BR>\n"; }
							$other{"$file$DELIMITER$tmpcleantag"}="1";
						}
				#auto-caption stuff continues
				} else {
					print "UNKNOWN TYPE OF \"$TYPE\" for $tmpcleantag tag with file $file...<BR>\n";
				}
			}#endif capture
		}
	} elsif ($mode eq "remove") {
		print "Should be removing $tmpcleantag for $file right?   <BR>\n";
		$used_in_this_file{$tmpcleantag}="0";
		$tags{$file} =~ s/$tmpcleantag,*//;	#remove tag & trailing commas
		$tags{$file} =~ s/,$//;				#remove trailing comma at end of line, if any
		$used_in_this_file{$tmpcleantag}="";
		if ($TYPE eq "thing") {
			if ($DEBUG_ASSEMBLE_CAPTION) { "unsetting $file$DELIMITER$tmpcleantag, no longer in \%things<BR>\n"; }
			$things{"$file$DELIMITER$tmpcleantag"}="";
		}
	}#endif DO_IT
}#endsub add_tag
###########################################################

###########################################################################
#This one is used internally for various tag exceptions:
#(such as?)
sub censor_w_real_spaces {
	my $s = $_[0];
	$s =~ s/Lipinski James/Grandad/i;
	$s =~ s/Lipinski Vic/Dad/i;
	$s =~ s/Lipinski Becky/Mom/i;
	$s =~ s/Sawyer Vicky/Vicky/i;
	$s =~ s/Mens Eve/Eve/i;
	$s =~ s/Gravely Eve/Eve/i;
	$s =~ s/Bowen Laine/Laine/i;
	return($s);
}
###########################################################################

#######################################################################################################
sub is_video {
	my $file=$_[0];

	if ($file =~ /\.avi$/i) { return(1); }
	if ($file =~ /\.mov$/i) { return(1); }
	if ($file =~ /\.mp4$/i) { return(1); }
	if ($file =~ /\.flv$/i) { return(1); }

	return(0);
}#endsub is_video 
#######################################################################################################

####################################################################################################################################################
sub rehyphenate {			#can also re-commafy tags
	my $s = $_[0];
	my $DEBUG = 0;	#
	
	if ($DEBUG) { print "* rehyphenate checkpoint 001, s=\"$s\"\n"; }

	#recommaate/recommafy -- ACTUALLY THIS WILL BREAK THINGS AND SPLIT THEM INTO TWO TAGS... NOT GOOD...
	$s =~ s/Slow Deep And Hard/Slow, Deep And Hard/ig;											#the Type O Negative album title
	#$s =~ s/Tim And Eric Awesome Show Great Job!*/Tim And Eric Awesome Show, Great Job!/ig;		#the tv show

	$s =~ s/rearended/rear-ended/ig;
	$s =~ s/TiltAWhirl/Tilt-A-Whirl/ig;						#didn't work here, will have to add above
	$s =~ s/K *Fed/K-Fed/ig;
	$s =~ s/^X *box/X-Box/ig;									#used to have no tilde here, but this made "Phoenix Box" become "PhoeniX-Box" which made it become "PhoeniX" and "Box". Bad!
	$s =~ s/double dong/double-dong/ig;
	$s =~ s/X[Dd]ay/X-Day/g;
	$s =~ s/(x)(r)ay/$1-$2ay/ig;
	$s =~ s/X[Mm]en/X-Men/g;
	$s =~ s/^7 *11$/7-11/ig;
	$s =~ s/^Beavis & Butthead$/Beavis & Butt-head/ig;
	$s =~ s/DDay/D-Day/;
	$s =~ s/^Beavis And Butthead$/Beavis And Butt-head/ig;
	$s =~ s/Butt *head/Butt-head/ig;
	$s =~ s/mashup/mash-up/ig;
	$s =~ s/^sci *fi$/sci-fi/ig;
	$s =~ s/^upside down$/upside-down/ig;
	$s =~ s/^freemartin$/free-martin/ig;

	if ($DEBUG) { print "* rehyphenate checkpoint 030\n"; }

	$s =~ s/flip *flops/flip-flops/ig;
	$s =~ s/Spider *Man/Spider-Man/ig;
   #$s =~ s/Artomatic/Art-o-matic/ig;
	$s =~ s/go *[ck]art/go-kart/ig;
	$s =~ s/mini golf/mini-golf/ig;
	$s =~ s/freeze dried/freeze-dried/ig;
	$s =~ s/TiltAWhirl/Tilt-A-Whirl/ig;
	$s =~ s/portapotty/port-a-potty/ig;
	$s =~ s/^Wal *Mart$/Wal-Mart/ig;
	$s =~ s/ViceGrip/Vice-Grip/g;
	$s =~ s/SpiderMan/Spider-Man/gi;
	$s =~ s/WillsonPiper/Willson-Piper/gi;

	if ($DEBUG) { print "* rehyphenate checkpoint 070\n"; }
	
	$s =~ s/^7 11$/7-11/g;
	$s =~ s/(chili) (cook) (off)/$1 $2-$3/ig;
	$s =~ s/([^a-z])X *box/$1X-Box/ig;					#x-box is also handled elsewhere. not sure if this is necessary or not.
	$s =~ s/self portrait/self-portrait/ig;
	$s =~ s/WD40/WD-40/ig;
	$s =~ s/10W30/10W-30/ig;
	$s =~ s/Shub *Niggaruth/Shub-Niggurath/ig;
	$s =~ s/crossstitch/cross-stitch/ig;
	$s =~ s/K 15/K-15/ig;
	$s =~ s/standup comedy/stand-up comedy/ig;
	$s =~ s/qtip(s*)/Q-Tip$1/i;
	$s =~ s/chain *link/chain-link/i;
	$s =~ s/(s)elf(d)efense/$1elf-$2efense/i;
	$s =~ s/LiteBrite/Lite-Brite/i;
	$s =~ s/SmokeIn/Smoke-In/;
	$s =~ s/CocaCola/Coca-Cola/i;
	$s =~ s/DDay/D-Day/;
	$s =~ s/WakAMole/Wak-A-Mole/;
	$s =~ s/^HeMan$/He-Man/i;
	$s =~ s/CDCMP3/CDC-MP3/;							#my car stereo model
	$s =~ s/KwikEMart/Kwik-E-Mart/;
	$s =~ s/one eyed/one-eyed/i;
	$s =~ s/two eyed/two-eyed/i;
	$s =~ s/three eyed/three-eyed/i;
	$s =~ s/four eyed/four-eyed/i;
	$s =~ s/Illuminati New World Order/Illuminati: New World Order/i;	#recolonates go here too
	$s =~ s/coworker/co-worker/i;
	$s =~ s/PacMan/Pac-Man/i;
	$s =~ s/DigDug/Dig-Dug/i;
	$s =~ s/sansserif/sans-serif/i;
	$s =~ s/Super Sprode/Super-Sprode/i;
	$s =~ s/SVideo/S-Video/ig;
	$s =~ s/Tqualizer/T-Qualizer/i;
	$s =~ s/26H Terrace View/26-H Terrace View/i;
	$s =~ s/PostIt/Post-It/i;
	$s =~ s/Justin MeldalJohnsen/Justin Meldal-Johnsen/i;
	$s =~ s/Marty WilsonPiper/Marty Wilson-Piper/i;
	$s =~ s/R2D2/R2-D2/;							
	$s =~ s/RedNosed/Red-Nosed/i;
	$s =~ s/Shriek An Afterword/Shriek: An Afterword/;
	$s =~ s/StarSpangled/Star-Spangled/i;
	$s =~ s/blowup/blow-up/i;
	$s =~ s/openminded/open-minded/i;
	$s =~ s/Team America World Police/Team America: World Police/i;	#recolonize
	$s =~ s/ecigarette/e-cigarette/i;
	$s =~ s/strapon/strap-on/i;
	$s =~ s/^([1-4])(D)$/$1-$2/i;	#"3D"
	$s =~ s/( [1-4])(D)$/$1-$2/i;	#"something 3D"
	$s =~ s/^([1-4])(D )/$1-$2/i;	#"3D something"
	$s =~ s/ecigarette/e-cigarette/i;
	$s =~ s/NB1L/NB-1L/i;
	$s =~ s/bacon wrapped/bacon-wrapped/i;
	$s =~ s/SlackO/Slack-O/;
	$s =~ s/XFactor/X-Factor/;
	$s =~ s/UTurn/U-Turn/i;
	$s =~ s/7Up/7-Up/i;
	$s =~ s/PacMan/Pac-Man/i;
	$s =~ s/WASR *10/WASR-10/;
	$s =~ s/MosinNagant/Mosin-Nagant/i;
	$s =~ s/AnnMarie/Ann-Marie/i;
	$s =~ s/^KMart$/K-Mart/;
	#$s =~ s///i;
	#$s =~ s///i;

#	##### ALBUM NAMES
#	$s =~ s/Nevermind The Bollocks Here's The Sex Pistols/Nevermind The Bollocks, Here's The Sex Pistols/i;	#bad idea - the comma will internally break this into 2 tags later 
#	$s =~ s/Mommy Can I Go Out And Kill Tonight?/Mommy, Can I Go Out And Kill Tonight?/i;					#bad idea - the comma will internally break this into 2 tags later 

	if ($DEBUG) { print "* rehyphenate checkpoint 100\n"; }

	return($s);
}
####################################################################################################################################################


###########################################################################
sub censor_caption {  #aka sub clean_captoin
	my $s = $_[0];
	#use censor tag
	$s =~ s/ /_SPC_/g;
	$s = &censor_tag($s);			#is this really smart? I guess so.
	$s =~ s/_SPC_/ /g;
	$s =~ s/<BR>/_ENT_/gi;			
	$s =~ s/<\/*P>/_ENT__ENT_/gi;	


	$s =~ s/_ENT_, /_ENT_/gi;					#lines sometimes will start with this if a private tag is used
	$s =~ s/\n, /_ENT_/gi;						#lines sometimes will start with this if a private tag is used

	#DEBUG: print "s is $s";

	#clean caption some too... 
	$s = &rehyphenate($s);

	#recomma caption only stuff:
	$s =~ s/Tim And Eric Awesome Show Great Job!*/Tim And Eric Awesome Show, Great Job!/ig;


	#some caption fixes at the last minute
	$s =~ s/Smores/S'mores/i;


	#caption-only censors (not censoring tag):
	#NOTE that these changes will not show up in a local allfiles index
	$s =~ s/Aaron Evans/Aaron/gi;
	$s =~ s/Stacy and Louise McMahon's house/Stacy and Louise's house/i;
	$s =~ s/Bob Sc*hafric*k and Becky Stewart's house/Becky and Bob's house/gi;
	$s =~ s/Brandon Gotwalt and Becky Stewart's /Becky and Brandon's /i;
	$s =~ s/Art by Clint, Pete Jaquay/Art by Pete Jaquay. Concept by ClintJCL./;
	$s =~ s/Art by Clio, Pete Jaquay/Art by Pete Jaquay. Concept by ClioCJS./;
	$s =~ s/Andy Hall and Lauren Julien's /Lauren and Andy's /gi;
	$s =~ s/Adam and Paul Jobson's house/Paul and Adam's house/i;
	$s =~ s/Brent I and Kim I's /Brent and Kim's /i;
	$s =~ s/Carolyn L/Carolyn/;			#no /i here, or "Carolyn loaned" will become "Carolynoaned", haha!
	$s =~ s/Christie Mercogliano/Christie/i;
	$s =~ s/Chris Yates/Chris Y/i;
	$s =~ s/Brad and Mandy Dreisbach/Brad and Mandy/i;
	$s =~ s/Chablis O's house/Happy House/gi;
	$s =~ s/Chuck and Britt Sweet's /Britt and Chuck's /i;
	$s =~ s/Chuck and Britt/Britt and Chuck/i;
	$s =~ s/Chris Belefski's house/Chris B's house/gi;
	$s =~ s/Chris and Britt Neigh's /Britt and Chris's /i;
	$s =~ s/Chris and Britt/Britt and Chris/i;
	$s =~ s/Dave and Lacey Nelson's house/Dave and Lacey N's house/gi;
	$s =~ s/Duke Gravely's /Uncle Duke's /gi;
	$s =~ s/Gerald and Allyson Henrich's house/Ally and Gerald's house/i;
	$s =~ s/G parents*'s*/Evan's parents/;
	$s =~ s/Ian B and Angel Preble's apartment/Angel and Ian's apartment/i;
	$s =~ s/Jason Purdy and Anna Slepetz's /Jason and Anna's /gi;
	$s =~ s/Jason and Anna Purdy's /Jason and Anna's /gi;
	$s =~ s/James and Lib Turnock's/Carolyn's grandparents'/i;
	$s =~ s/Josh WarnerBurke/Josh W-B/i;
	$s =~ s/Jacklyn Jackson/Jacklyn J/i;
	$s =~ s/Jsun Bruner/a pretentious ex-friend of mine/gi;
	$s =~ s/Kevin and Amanda Castellucci's house/Kevin and Amanda's house/gi;
	$s =~ s/Lauren Dubs*'s /Lauren's /i;
	$s =~ s/Lowell and Anne Sawyer's/Carolyn's parents'/i;
	$s =~ s/Matthew Gminski/Matthew G/i;
	$s =~ s/Marissa Jamison/Marissa J/i;
	$s =~ s/Mark and Phyllis Prophet's /Grandma and Grandad's /gi;
	$s =~ s/Margaretha Sawyer's house/Carolyn's Grandma's house/gi;
	$s =~ s/Mike and Jennifer R's house/Jennifer and Mike R's house/i;
	$s =~ s/Ryan Mitchell's apartment/Ryan M's apartment/i;
	$s =~ s/Sean and Vicky's house/Vicky's house/gi;
	$s =~ s/Steve Garland/Steve G/i;
	$s =~ s/Tatiana Prophet/Tatiana/i;
	$s =~ s/Vic's room, Nanny and Grandad's house/Dad's room, Grandparents' house/i;
	$s =~ s/Wayne Howard & Shehab Moustafa's /Wayne & Shehab's /gi;

	
	#caption alias for grandparents:
	$s =~ s/Phyllis/Grandma/i;				#I really doubt I'll ever know any other Phyllis'es
	
	#employer names to censor out:
	$s =~ s/census training/training/i;
	$s =~ s/iWorks, //i;
	$s =~ s/WindWalker, //i;
	$s =~ s/Grainger, /Carolyn's work, /i;
	$s =~ s/Discovery Communications, /Carolyn's work, /i;
	$s =~ s/Miller's Office Products, //i;
	$s =~ s/United States Postal Inspection Service, //i;
	$s =~ s/TODO TAG[^,]*, //i;
	$s =~ s/TODO TAG 2004-2008 EMPLOYER NAME, //i;
	$s =~ s/TODO[^,]+, //i;

	#personal stuff to censor out:
	$s =~ s/Braddock Rd, //i;
	$s =~ s/B Road, street/B Road/i;

	#people with changed names:
	$s =~ s/Eric Mens/Penny/i;

	#because our tagging code is USA-centric, it doesn't yet know how 
	#to deal with being in a country without also being in a state:
	$s =~ s/_STATE_, Mexico./Mexico./;
	$s =~ s/_STATE_, France./France./;

	#kludges
	$s =~ s/Normandy, Arlington Cemetery, Virginia, France/Arlington Cemetery, Virginia/i;
	$s =~ s/Normandy, Ellipse, Washington D.C.*, France/Ellipse, Washington D.C./i;
	$s =~ s/Normandy, Holocaust Museum, Washington D.C.*, France/Holocaust Museum, Washington D.C./i;

	
	$s =~ s/\n/_ENT_/g;		#hack to get around fact that \n and \\n at command-line simply do not translate do results (neither does the HTML \n or \n\r error codes)
	return($s);
}#endsub censor_caption
###########################################################################



###########################################################################
sub sponsor_caption {
	my $file = $_[0];
	my $s    = "";

	##### Also we'll do the sponsored link stuff here:
	%sponsored=();	#reset the hash
	#DEBUG:print "\$tags{\$file} is $tags{$file}<BR>\n";
	@looptmptags = split(/,/,"$tags{$file}");

	foreach my $key (keys %globaltags) { 
		#The subloop splits things on " and ", so something like "John Smith and Jane Doe's apartment" will split into "John Smith" and "Jane Doe's Apartment", causing both people to be sponsor-tagged...
		#DEBUG:		print "Checking key $key            <BR>\n";#
		foreach $tmpkey (split(/_SPC_and_SPC_/i,$key)) {
			push(@looptmptags,$tmpkey); 
			if ($DEBUG_SPONSOR_CAPTION>0) { print "[PTT] pushed $tmpkey to looptmptags...<BR>\n"; }
		}
	}
	
	foreach my $tmptag (sort @looptmptags) {
		$tmptag =~ tr/[a-z]/[A-Z]/;
		$tmptag =~ s/_SPC_/ /gi;
		if ($DEBUG_SPONSOR_CAPTION>0) { print "Checking tag $tmptag        <BR>\n"; }
		$tmptag =~ s/^cameraperson[\s\-]//i;		#take off 'cameraperson' so that it is just the person who took it, so we can credit our photographers
		$tmptag =~ s/^cameraperson_SPC_//i;			#take off 'cameraperson' so that it is just the person who took it, so we can credit our photographers
		$tmptag =~ s/BRITT SWEET/BRITT/i;		
		$tmptag =~ s/BRITT NEIGH/BRITT/i;		
		$tmptag =~ s/'s house$//i;		
		$tmptag =~ s/'s apartment$//i;
		$tmptag =~ s/^by //i;						#I think this will sponsor-link for artwork and such
		$tmptag =~ s/birthday //i;					#if it's someone's birthday, they should probably get a sponsor link in the whole set
		
		$tmp = $sponsored_link{$tmptag};

		if ($DEBUG_SPONSOR_CAPTION>0) { print "[SPONSOR_TAG] Hey! tmptag = \"$tmptag\" / \tlink: \"$sponsored_link{$tmptag}\"<BR>\n"; }
		if (($sponsored_link{$tmptag} ne "") && ($sponsored{$tmp}=="")) {
			if ($DEBUG_SPONSOR_CAPTION>0) { print "Using it.\n"; }
			$s .= $tmp;
			$sponsored{$tmp}=1;
		}
	}

	##### If this gets too manageable... I could simply hash (key=the full sponsor string) each one and only add them if it's not in the hash...		  
	#s =~ s/(\.\.\. View Greg and Nicole's photos at http:\/\/www\.flickr\.com\/photos\/17102271\@N00\/\n)(.*)(\.\.\. View Greg and Nicole's photos at http:\/\/www\.flickr\.com\/photos\/17102271\@N00\/\n*)/$1$2/isg;
	$s =~ s/(\.\.\. View my parents' photos at http:\/\/www\.flickr\.com\/photos\/vic-and-becky\/\n)(.*)(\.\.\. View my parents' photos at http:\/\/www\.flickr\.com\/photos\/vic-and-becky\/)/$1$2/isg;
	$s =~ s/(\.\.\. View Jess's photos at http:\/\/www\.flickr\.com\/photos\/mightykins\/\n)(.*)(\.\.\. View Jess's photos at http:\/\/www\.flickr\.com\/photos\/mightykins\/\n)/$1$2/isg;

	##### At least while using abusing my sponsored links functionality as a way to put deceased people's bios into every picture of them, I should linkify those:
	$s = &linkify($s);

	return($s);
}#endsub sponsor_caption
###########################################################################


###########################################################################
sub censor_tag {	#aka censortag		#could also be considered fix_tag/fixtag - if tags come out and you just want to kludge-fix them off the back end (i.e. change "Makepeace Manor's house" to "Makepeace Manor", this is a good place to do that while avoiding facing all of the immense logic in this file)
	my $s = $_[0];

	$s =~ s/ /_SPC_/g;		#some intermediate values introduced might not be _SPC_'ed yet

	##### MAIN LIST:
	$s =~ s/Asa_SPC_Akers_SPC_and_SPC_Eve_SPC_Gravely/Eve_SPC_and_SPC_Asa/i;
	$s =~ s/Ace_SPC_Wright/Ace_SPC_W/i;
	$s =~ s/Asa_SPC_Akers/Asa_SPC_A/i;
	$s =~ s/Adam_SPC_Conn*ell*y/Adam_SPC_C/i;
	$s =~ s/Alex_SPC_Van_SPC_Massenhove/Alex_SPC_Van_SPC_M/i;
	$s =~ s/Ally_SPC_Henrich/Allyson_SPC_H/i;
	$s =~ s/Allyson_SPC_Henrich/Allyson_SPC_H/i;
	$s =~ s/Amanda_SPC_Jagusiak/Amanda_SPC_J/i;
	$s =~ s/Andras_SPC_Balazsy/Andras_SPC_B/i;
	$s =~ s/Andrew_SPC_Hollingsworth/Andrew_SPC_H/i;
	$s =~ s/Andrea_SPC_Kubiak/Andrea_SPC_K/i;
	$s =~ s/Aned_SPC_Ruiz/Aned_SPC_R/i;
	$s =~ s/Anna_SPC_Purdy/Anna_SPC_S/i;
	$s =~ s/Anna_SPC_Slepetz/Anna_SPC_S/i;
	$s =~ s/Anna_SPC_SlepetzPurdy/Anna_SPC_S/i;
	$s =~ s/Andy_SPC_Hall/Andy_SPC_H/i;
	$s =~ s/Angela_SPC_Kapetanakis/Angela_SPC_K/i;
	$s =~ s/Aspen_SPC_Hayden/Aspen_SPC_H/i;
	$s =~ s/Aubrey_SPC_Swenson/Aubrey_SPC_S/i;				#cousins kids get last name censored
	$s =~ s/Aurelie_SPC_Evans/Aurelie_SPC_E/i;
	$s =~ s/Barney_SPC_Cope/Barney_SPC_C/i;					
	$s =~ s/Beavis_SPC_Lipinski/Beavis/i;
	$s =~ s/Becky_SPC_Lipinski/Mom/i;
	$s =~ s/Becky_SPC_Prophet/Mom/i;
	$s =~ s/Becky_SPC_Stewart/Becky_SPC_S/i;
	$s =~ s/Beth_SPC_Bowen/Beth/i;
	$s =~ s/Beth_SPC_Hatch/Beth_SPC_H/i;
	$s =~ s/Dee_SPC_Hatch/Dee_SPC_H/i;
	$s =~ s/Eric_SPC_Hatch/Eric_SPC_S/i;
	$s =~ s/Eric_SPC_Sedlacek/Eric_SPC_S/i;
	$s =~ s/Brewster_SPC_Thackery/Brewster_SPC_T/i;
	$s =~ s/Kate_SPC_Thackery/Kate_SPC_T/i;
	$s =~ s/Kate_SPC_Day/Kate_SPC_T/i;				#cheating the functionality of 2 post-marriage meta-rules that would only take effect during indexing, to do it this way, which takes effect instantly, during tagging
#	$s =~ s/Ben_SPC_Weaver/Ben_SPC_W/i;				#nah. they have found their pics of me this way and didn't say anything about minding. at least, Joy did. dunno if Ben did.
	$s =~ s/Blake_SPC_Bowen/Blake/i;
	$s =~ s/Bob_SPC_Orton/Bob_SPC_O/i;
	$s =~ s/Bob_SPC_Sc*hafric*k/Bob_SPC_S/i;
	$s =~ s/Brandon_SPC_Gotwalt/Brandon_SPC_G/i;
	$s =~ s/Brandon_SPC_Henrich/Brandon/i;
	$s =~ s/Brianna_SPC_Young/Brianna_SPC_Y/i;
	$s =~ s/Brent_SPC_Ingebretsen/Brent_SPC_I/i;
	$s =~ s/Britt_SPC_Sweet/Britt/i;
	$s =~ s/Britt_SPC_Neigh/Britt/i;
	$s =~ s/Callan_SPC_Langsdorf/Callan_SPC_L/i;
	$s =~ s/cameraperson_SPC_Lipinski_SPC_Clint/cameraperson_SPC_Clint/i;	
	$s =~ s/cameraperson_SPC_Lipinski_SPC_Clio/cameraperson_SPC_Clio/i;	
	$s =~ s/cameraperson_SPC_Sawyer_SPC_Clio/cameraperson_SPC_Clio/i;	
	$s =~ s/cameraperson_SPC_Lipinski_SPC_Vic/cameraperson_SPC_Dad/i;	
	$s =~ s/cameraperson_SPC_Ken_SPC_Michalzuk/cameraperson_SPC_Ken_SPC_M/i;
	$s =~ s/Carolyn_SPC_Sawyer/Carolyn/i;
	$s =~ s/Carolyn_SPC_Lipinski/Carolyn/i;
	$s =~ s/Celia_SPC_Wells/Celia_SPC_W/i;
	$s =~ s/Ben_SPC_Mathes/Ben_SPC_M/i;
	$s =~ s/Chablis_SPC_Owens/Chablis_SPC_O/i;
	$s =~ s/Chad_SPC_Durbin/Chad_SPC_D/i;
	$s =~ s/Charlotte_SPC_Swenson/Charlotte_SPC_S/i;		#cousins kids get last name censored
	$s =~ s/Chris_SPC_Mitchell/Chris_SPC_M/i;
	$s =~ s/Chris_SPC_Neigh/Chris_SPC_N/i;
	$s =~ s/Chris_SPC_Swenson/Chris_SPC_S/i;
	$s =~ s/Chris_SPC_Zincke/Chris_SPC_Z/i;
	$s =~ s/Christian_SPC_Zincke/Chris_SPC_Z/i;
	$s =~ s/Christian_SPC_Diaz/Christian_SPC_D/i;
	$s =~ s/Christina_SPC_Chasen/Christina_SPC_C/i;
	$s =~ s/Christi_SPC_Sabin/Christi_SPC_S/i;
	$s =~ s/Clint_SPC_Lipinski/Clint/i;
	$s =~ s/Clio_SPC_Lipinski/Clio/i;
	$s =~ s/Clio_SPC_Sawyer/Clio/i;
	$s =~ s/Claire_SPC_Sawyer/Claire/i;
	$s =~ s/Clint_SPC_and_SPC_Carolyn_SPC_Lipinski/Clint_SPC_and_SPC_Carolyn/i;
	$s =~ s/Clio_SPC_and_SPC_Carolyn_SPC_Lipinski/Clio_SPC_and_SPC_Carolyn/i;
	$s =~ s/Clio_SPC_Sawyer_SPC_and_SPC_Carolyn_SPC_Lipinski/Clio_SPC_and_SPC_Carolyn/i;
	$s =~ s/Clio_SPC_and_SPC_Carolyn_SPC_Sawyer/Clio_SPC_and_SPC_Carolyn/i;
	$s =~ s/Claire_SPC_and_SPC_Carolyn_SPC_Lipinski/Claire_SPC_and_SPC_Carolyn/i;
	$s =~ s/Claire_SPC_Sawyer_SPC_and_SPC_Carolyn_SPC_Lipinski/Claire_SPC_and_SPC_Carolyn/i;
	$s =~ s/Claire_SPC_and_SPC_Carolyn_SPC_Sawyer/Claire_SPC_and_SPC_Carolyn/i;
	$s =~ s/Corey_SPC_Dillard/Corey_SPC_D/i;
	$s =~ s/Crystal_SPC_Penland/Crystal_SPC_P/i;	
	$s =~ s/Crystal_SPC_Stephan/Crystal_SPC_S/i;			#
	$s =~ s/Cynthia_SPC_Vasques/Cynthia_SPC_V/i;
	$s =~ s/Dan_SPC_Cooper/Dan_SPC_C/i;
	$s =~ s/Danielle_SPC_Quick/Danielle_SPC_Qu/i;
	$s =~ s/Dave_SPC_Nelson/Dave_SPC_N/i;
	$s =~ s/Danielle_SPC_Quick/Danielle_SPC_Q/i;
	$s =~ s/Darren_SPC_Moore/Darren_SPC_M/i;
	$s =~ s/Debbie_SPC_Moore/Debbie_SPC_M/i;
	$s =~ s/Dana_SPC_McIntosh/Dana_SPC_M/i;
	$s =~ s/David_SPC_Douglas/David_SPC_D/i;
	$s =~ s/Diaz_SPC_Christian_SPC_and_SPC_Shannon/Christian_SPC_and_SPC_Shannon/i;
	$s =~ s/Diane_SPC_De_SPC_Bernardo/Diane_SPC_De_SPC_B/i;
	$s =~ s/Discovery_SPC_Communications/Carolyn's_SPC_work_SPC_2014/i;
	$s =~ s/Adam_SPC_Sowar/Adam_SPC_S/i;					
	$s =~ s/Effie_SPC_Eveland/Effie_SPC_E/i;					
	$s =~ s/Eli_SPC_Sowar/Eli_SPC_S/i;					
	$s =~ s/Erica_SPC_Nemmers/Erica_SPC_N/i;
	$s =~ s/Erin_SPC_Cooper/Erin_SPC_C/i;
	$s =~ s/Erin_SPC_Prophet/Erin_SPC_P/i;					
	$s =~ s/Evan_SPC_Burdiss/Evan_SPC_B/i;					
	$s =~ s/Evan_SPC_Goldstein/Evan_SPC_G/i;					
	$s =~ s/Eve_SPC_Cope/Eve_SPC_C/i;					
	$s =~ s/Eve_SPC_Akers/Eve/i;							#cousins only go by first name. 
	$s =~ s/Eve_SPC_Gravely/Eve/i;							#cousins only go by first name. 
	$s =~ s/Emily_SPC_Swenson/Emily/i;						#cousins only go by first name. 
	$s =~ s/Emily_SPC_Henrich/Emily/i;						#cousins only go by first name. 
	$s =~ s/Emily_SPC_Rincione/Emily_SPC_Ri/i;				#her being divorced from J makes me not really want to mention her name publicly even tho he doesn't mind his being mentioned
	$s =~ s/Faith_SPC_Hendon/Faith_SPC_H/i;
	$s =~ s/Felicia_SPC_Overton/Felicia_SPC_Ov/i;
	$s =~ s/Frank_SPC_Brickfield/Frank_SPC_B/i;
	$s =~ s/_SPC_FoxRabinovich/_SPC_F/i;
	$s =~ s/Gail_SPC_Breed/Gail_SPC_B/i;
	$s =~ s/Gerald_SPC_Henrich/Gerald_SPC_H/i;
	$s =~ s/Glenda_SPC_Monet/Glenda_SPC_Mo/i;
	$s =~ s/Greg_SPC_Zumbrook/Greg_SPC_Z/i;
	$s =~ s/Heather_SPC_Katz/Heather_SPC_K/i;
	$s =~ s/Heather_SPC_Koepf/Heather_SPC_Love/i;
	$s =~ s/Heather_SPC_Nielson/Heather_SPC_N/i;
	$s =~ s/Heather_SPC_Purrington/Heather_SPC_P/i;
	$s =~ s/Ian_SPC_Buckwalter/Ian_SPC_B/i;
	$s =~ s/Jacobe_SPC_Moore/Jake_SPC_M/i;
	$s =~ s/Jake_SPC_Moore/Jake_SPC_M/i;
	$s =~ s/Jason_SPC_Purdy/Jason_SPC_P/i;
	$s =~ s/Jason_SPC_Slepetz/Jason_SPC_P/i;
	$s =~ s/Jason_SPC_Greenwalt/Jason_SPC_G/i;
	$s =~ s/Joe_SPC_Rincione/Joe_SPC_R/i;
	$s =~ s/Joe_SPC_Zentmyer/Joe_SPC_Ze/i;
	$s =~ s/Johny_SPC_Hyunh/Johny_SPC_H/i;				
	$s =~ s/Johny_SPC_Zumbrook/Johny_SPC_H/i;				#### But that's not his last name. will figure it out later
	$s =~ s/John_SPC_Osipchak/John_SPC_O/i;				
	$s =~ s/Lauren_SPC_Osipchak/Lauren_SPC_O/i;				
	$s =~ s/James_SPC_and_SPC_Ronnie_SPC_Lipinski's_SPC_house/Nanny_SPC_and_SPC_Grandad's_SPC_house/i;
	$s =~ s/James_SPC_Lipinski's_SPC_house_SPC_and_SPC_Ronnie/Nanny_SPC_and_SPC_Grandad's_SPC_house/i;
	$s =~ s/Jeanne_SPC_Joy/Jeanne_SPC_J/i;
	$s =~ s/Joel_SPC_Benson/Joel_SPC_B/i;
	$s =~ s/Jon_SPC_Bergfeld/Jon_SPC_B/i;
	$s =~ s/Jason_SPC_Katz/Jason_SPC_K/i;
	$s =~ s/James_SPC_Lipinski/Grandad/i;
	$s =~ s/James_SPC_Bernard_SPC_Lipinski/Grandad/i;
	$s =~ s/James_SPC_Prophet/James/i;						#cousins are firstname only
	$s =~ s/Jay_SPC_Sawyer/Jay/i;							#brother/sister-in-laws are firstname only
	$s =~ s/Jen_SPC_Bond/Jen_SPC_B/i;
	$s =~ s/Jennifer_SPC_Prophet/Jennifer/i;				#cousins are firstname only
	$s =~ s/Jennifer_SPC_Rafter/Jennifer_SPC_R/i;
	$s =~ s/Jennifer_SPC_Terrill/Jennifer/i;				#cousins are firstname only
	$s =~ s/Jason_SPC_Davis_SPC_and_SPC_Val_SPC_Watkins/Val_SPC_and_SPC_Jason/i;
	$s =~ s/Jenny_SPC_Hitchcock/Jenny_SPC_H/i;
	$s =~ s/Jenny_SPC_Tiller/next_SPC_door_SPC_neighbor_SPC_Jenny/i;
	$s =~ s/Jesse_SPC_Byrd/Jesse_SPC_B/i;
	$s =~ s/Jessi*c*a*_SPC_Mlotkowski/Jessica_SPC_M/i;		#should use full name now!
	$s =~ s/Joe_SPC_Maroun/Joe_SPC_M/i;
	$s =~ s/Joy_SPC_McDonald/Joy_SPC_M/i;
	$s =~ s/John_SPC_Schuler/John_SPC_S/i;
	$s =~ s/Jordan_SPC_Sawyer/J_SPC_Gerard_SPC_Sawyer/i;
	$s =~ s/Julie[- ]Anne_SPC_Watko/Julie-Anne_SPC_W/i;		#cheating and also re-hyph3nating here as well, despite having a dedicated section for that
	$s =~ s/Julie_SPC_Todaro/Julie_SPC_To/i;				#she sucks too much to waste "Julie T" on!
	$s =~ s/Julie_SPC_Snyder/Julie_SPC_S/i;	
	$s =~ s/Justin_SPC_Church/Justin_SPC_C/i;
	$s =~ s/Jsun_SPC_Bruner/JSun_SPC_B/ig;
	$s =~ s/Kuliecza_SPC_John/John_SPC_Kuliecza/i;			#Not a censored tag, but lazy programming. Triple birthday parties don't flip the 3rd person, but this has only happened once, so I'm manually flipping it here.
	$s =~ s/Kali_SPC_Katz/Kali_SPC_K/i;
	$s =~ s/Katina_SPC_Manos/Katina_SPC_M/i;
	$s =~ s/Ken_SPC_Deckard/Ken_SPC_De/i;
	$s =~ s/Ken_SPC_Michalzuk/Ken_SPC_Michalzuk/i;
	$s =~ s/Keith_SPC_Bridges/Keith_SPC_B/i;
	$s =~ s/Kim_SPC_Ingebretsen/Kim_SPC_I/i;				#Kim Meister -> Kim Garnavish -> Kim Ingebretsen
	$s =~ s/Kim_SPC_Meister/Kim_SPC_I/i;					#Kim Meister -> Kim Garnavish -> Kim Ingebretsen
	$s =~ s/Kim_SPC_Garnavish/Kim_SPC_I/i;					#Kim Meister -> Kim Garnavish -> Kim Ingebretsen
	$s =~ s/Kristin_SPC_Dellerman/Kristin_SPC_De/i;
	$s =~ s/Kate_SPC_Mattingly/Kate_SPC_M/i;
	$s =~ s/Keila_SPC_Workley/Keila_SPC_W/i;
	$s =~ s/Ken_SPC_Hurley/Ken_SPC_H/i;
	$s =~ s/Kier_SPC_Conroy/Kier_SPC_C/i;
	$s =~ s/Kipp_SPC_Elsbernd/Kipp_SPC_E/i;
	$s =~ s/Kristen_SPC_Hartmann/Kristen_SPC_H/i;
	$s =~ s/Lacey_SPC_Nelson/Lacey_SPC_N/i;
	$s =~ s/Laine_SPC_Bowen/Laine/i;
	$s =~ s/Laura_SPC_Neigh/Laura_SPC_N/i;
	$s =~ s/Lauren_SPC_Julien/Lauren_SPC_J/i;
	$s =~ s/Lauren_SPC_Wright/Lauren_SPC_Dubs/i;
	$s =~ s/Lauren_SPC_Susinno/Lauren_SPC_S/i;
	$s =~ s/Lawrence_SPC_Overton/Lawrence_SPC_Ov/i;
	$s =~ s/Lemonjello_SPC_Lipinski/Lemonjello/i;
	$s =~ s/Lincoln_SPC_Neigh/Lincoln_SPC_N/i;
	$s =~ s/Linda_SPC_Delaney/Linda_SPC_D/i;
	$s =~ s/Lisa_SPC_Larson/Lisa_SPC_L/i;
	$s =~ s/Lisa Mazur_SPC_M/Lisa_SPC_M/i;
#	$s =~ s/Lipinski_SPC_James/Grandad/i;		#this shouldn't happen	
	$s =~ s/Little_SPC_Girl_SPC_Cope/Little_SPC_Girl_SPC_C/i;					
	$s =~ s/MaryJane_SPC_Mooney/MaryJane_SPC_M/i;
	$s =~ s/Meschelle_SPC_Linjean/Meschelle_SPC_L/i;
	$s =~ s/Makepeace_SPC_Manor's_SPC_house/Makepeace_SPC_Manor/i;
	$s =~ s/Marcella_SPC_Simon/Marcella_SPC_S/i;
	$s =~ s/Mark_SPC_Ingebretsen/Mark_SPC_I/i;
	$s =~ s/Mark_SPC_Uttecht/Mark_SPC_U/i;
	$s =~ s/Mary_SPC_O'*Malley/Mary_SPC_O/i;
	$s =~ s/Matt_SPC_Dove/Matt_SPC_D/i;
	$s =~ s/Matt_SPC_Goldstein/Matt_SPC_G/i;
	$s =~ s/Marissa_SPC_Jamison/Marissa_SPC_J/i;
	$s =~ s/Matthew_SPC_Gminski/Matthew_SPC_G/i;
	$s =~ s/Meagan_SPC_Perkins/Meagan_SPC_P/i;
	$s =~ s/Megan_SPC_Wright/Megan_SPC_W/i;
	$s =~ s/Melanie_SPC_Beyer/Melanie_SPC_B/i;
	$s =~ s/Melanie_SPC_Byrd/Melanie_SPC_B/i;
	$s =~ s/Melanie_SPC_Sherman/Melanie_SPC_S/i;
	$s =~ s/Melissa_SPC_Wilson/Melissa_SPC_Wi/i;
	$s =~ s/Melissa_SPC_Chen/Melissa_SPC_C/i;
	$s =~ s/Michelle_SPC_Cloutier/Michelle_SPC_C/i;
	$s =~ s/Michelle_SPC_Torres/Michelle_SPC_To/i;			#don't want to waste "Michelle T" on someone I'll only ever have 1 picture of
	$s =~ s/Michelle_SPC_Beauregard/Michelle_SPC_B/i;
	$s =~ s/Misfit_SPC_Lipinski/Misfit/i;					
	$s =~ s/Mike_SPC_and_SPC_Beth_SPC_Bowen's_SPC_house/Beth_SPC_and_SPC_Mike's_SPC_house/i;
	$s =~ s/Mike_SPC_Rafter/Mike_SPC_R/i;
	$s =~ s/Javier_SPC_Molina/Javier_SPC_M/i;				#201606
	$s =~ s/Nancy_SPC_Baer/Nancy_SPC_B/i;					
	$s =~ s/Neena_SPC_Shreshtha/Neena_SPC_S/i;
	$s =~ s/Nicole_SPC_Kinzer/Nicole_SPC_Z/i;				#meta rules should keep this from ever happening, but just in case, since I'm here already...
	$s =~ s/Nicole_SPC_Zumbrook/Nicole_SPC_Z/i;
	$s =~ s/Nikki_SPC_LeRiche/Nikki_SPC_LeBitch/i;
	$s =~ s/Oranjello_SPC_Lipinski/Oranjello/i;
	$s =~ s/Pame*l*a*_SPC_Trangenstein/Pam_SPC_T/i;
	$s =~ s/Parthena_SPC_Kydes/Parthena/i;					#wont use a last name initial, because her name is so unique
	$s =~ s/parent_SPC_Goldstein/Evan's parent/i;	
	$s =~ s/parents_SPC_Goldstein/Evan's parents/i;	
	$s =~ s/Paul_SPC_Jobson/Paul_SPC_J/i;					
	$s =~ s/Phoebe_SPC_Buckwalter/Phoebe_SPC_B/i;
	$s =~ s/Phyllis_SPC_Prophet's_SPC_house/Grandmas'_SPC_house/i;
	$s =~ s/Phil_SPC_Warren/Phil_SPC_W/i;
	$s =~ s/Rachel_SPC_Rodes/Rachel_SPC_R/i;
	$s =~ s/Rebekah_SPC_Tansey/Rebekah_SPC_T/i;
	$s =~ s/Rich_SPC_Parrish/Rich_SPC_P/i;
	$s =~ s/Robert_SPC_Ruble/Robert_SPC_R/i;
	$s =~ s/Roger_SPC_Neigh/Roger_SPC_N/i;
	$s =~ s/Rose_SPC_Stidman/Rose_SPC_S/i;
	$s =~ s/Ryan_SPC_Katz/Ryan_SPC_K/i;
	$s =~ s/Samhain_SPC_Lipinski/Samhain the cat/i;
	$s =~ s/Sean_SPC_Regan/Sean_SPC_R/i;
	$s =~ s/Sean_SPC_Katz/Sean_SPC_K/i;
	$s =~ s/Sam_SPC_Chung/Sam_SPC_C/i;
	$s =~ s/Sam_SPC_Lipinski/Sam/i;
#	$s =~ s/Scott*_SPC_Braunfeld/Skot_SPC_B/i;
#	$s =~ s/Skott*_SPC_Braunfeld/Skot_SPC_B/i;
#	$s =~ s/Skott*_SPC_Braunfeld/Skot_SPC_B/i;
	$s =~ s/Scott_SPC_Kerr/Scott_SPC_K/i;
	$s =~ s/Scott_SPC_Shaheen/Scott_SPC_S/i;
	$s =~ s/Shane_SPC_Lipinski/Shane/i;
	$s =~ s/Shannon_SPC_McWilliams/Shannon_SPC_McW/i;
	$s =~ s/Shasta_SPC_Ruble/Shasta_SPC_R/i;
	$s =~ s/Shehab_SPC_Moustafa/Shehab_SPC_M/i;
	$s =~ s/Sonja_SPC_Milutinovic/Sonja_SPC_M/i;
	$s =~ s/Stephanie_SPC_O'Chap/Stephanie_SPC_O/i;
	$s =~ s/Susan_SPC_Etheridge/Susan_SPC_E/i;
	$s =~ s/Buck_SPC_Lipinski/Buck/i;
	$s =~ s/Scott_SPC_Obenhein/Scott_SPC_O/i;			
	$s =~ s/Scott_SPC_Smith/Scott_SPC_S/i;			
	$s =~ s/Shannon_SPC_Diaz/Shannon_SPC_D/i;
	$s =~ s/Shannon_SPC_Katz/Shannon_SPC_D/i;
	$s =~ s/Summer_SPC_Katz/Summer_SPC_K/i;
	$s =~ s/Josh_SPC_WarnerBurke/Josh_SPC_W-B/;
	$s =~ s/Susan_SPC_Shafrik/Susan_SPC_Sh/i;
	$s =~ s/Stacy_SPC_and_SPC_Louise_SPC_McMahon's_SPC_house/Stacy_SPC_and_SPC_Louise's_SPC_house/i;
	$s =~ s/Steve_SPC_Wilkinson/Steve_SPC_Wi/i;				#don't want to waste "Steve W" on somebody we'll never see again, haha (mullet-kitten-dude)
	$s =~ s/Stephen_SPC_Leeb/Stephen_SPC_L/i;
	$s =~ s/Svetlana_SPC_Shargorodskaya/Svetlana_SPC_S/i;
	$s =~ s/Tabbitha_SPC_MacDicken/Tabbitha/i;				
	$s =~ s/Tim_SPC_Houston/Tim_SPC_Ho/i;					#don't want to waste "Tim H"   on somebody I     never typically photograph
	$s =~ s/Tiffany_SPC_Obenhein/Tiffany_SPC_O/i;			
	$s =~ s/Todd_SPC_Pierce/Todd_SPC_P/i;					
	$s =~ s/Tom_SPC_Mundell/Tom_SPC_M/i;
	$s =~ s/Tiffany_SPC_Dearie/Tiffany_SPC_De/i;			#don't want to waste "TIffany D" on somebody I don't plan to ever see again
	$s =~ s/Vic_SPC_and_SPC_Mom's/Mom_SPC_and_SPC_Dad's/i;
	$s =~ s/Vic_SPC_Lipinski/Dad/i;
	$s =~ s/Vicky_SPC_Herrala/Vicky/i;						#brother/sister-in-laws are firstname only
	$s =~ s/Vicky_SPC_Sawyer/Vicky/i;						#brother/sister-in-laws are firstname only
	$s =~ s/Vicky_SPC_Somma/Vicky/i;						#brother/sister-in-laws are firstname only
	$s =~ s/Victoria_SPC_Subercaseaux/Victoria S/i;	
	$s =~ s/Vlad_SPC_Diaz/Vlad_SPC_D/i;	
	$s =~ s/Virginia_SPC_Cylke/Virginia_SPC_C/i;
	$s =~ s/Wayne_SPC_Howard/Wayne_SPC_H/i;
	$s =~ s/Wendell_SPC_Adkins/Wendell_SPC_A/i;
	$s =~ s/Wix_SPC_Terrill/Wix_SPC_T/i;
	$s =~ s/Zakiya_SPC_Stuart_SPC_St\._SPC_*Rose/Zee/i;
	$s =~ s/Zakiya_SPC_Stuart_SPC_St\.Rose/Zee/i;

	##### THINGS THAT ARE GOOD TO FIX RIGHT HERE (SELF-CENSORSHIP KLUDGES AND THE LIKE):
	$s =~ s/Lipinski_SPC_Clint/Clint/i;
	$s =~ s/Lipinski_SPC_Clio/Clio/i;
	$s =~ s/Sawyer_SPC_Clio/Clio/i;
	$s =~ s/Sawyer_SPC_Claire/Claire/i;
	$s =~ s/Vic_SPC_And_SPC_Mom/Mom and Dad/i;
	$s =~ s/L_SPC_Vic/Dad/i;

	##### LASTNAME CENSORS DUE TO PETS AND SUCH - ONLY USE UNCOMMON NAMES HERE:
	$s =~ s/Goldstein/G/i;	
	$s =~ s/Kinzer/K/;
	$s =~ s/Lipinski/L/;
	$s =~ s/Neigh([^a-z])/N$1/;	#to avoid "My Neighbor Totoro" becoming "My Nbor Totoro"
	$s =~ s/Trangenstein/T/;
	$s =~ s/Zumbrook/Z/;



	##### EMPLOYER CENSORS:									#will have to add these(with " " instead of _SPC_) to censor-caption a well
	$s =~ s/WindWalker/TODO_SPC_TAG_SPC_2004-2008_SPC_EMPLOYER_SPC_NAME/ig;		
	$s =~ s/iWorks/TODO_TAG_2012_thru_2015_EMPLOYER_NAME/ig;
	$s =~ s/Miller's Office Products/TODO_SPC_TAG_SPC_CAROLYN_SPC_2000-2007_SPC_EMPLOYER_SPC_NAME/ig;		
	$s =~ s/Grainger/TODO_SPC_TAG_SPC_CAROLYN_SPC_2010_SPC_EMPLOYER_SPC_NAME/ig;		
	#NO LONGER NEED TO CENSOR $s =~ s/United_SPC_States_SPC_Postal_SPC_Inspection_SPC_Service/TODO_SPC_tag_SPC_organization_SPC_#1_SPC_name/i;

	##### PLACE CENSORS:
	#fuck this:	$s =~ s/Brushwood/Bwood/i;
	$s =~ s/Braddock_SPC_Ro*a*d/B_SPC_Road/i;

	##### JOB CLIENT CENSORS:
	$s =~ s/Census/TODO_SPC_TAG_SPC_2007_CLIENT_SPC_NAME/i;

	#DEBUG:print "censor tag $_[0] is $s\n";
	return($s);
}#endsub censor_tag
###########################################################################

#############################################################################
sub make_caption_safe_for_command_line {
	my $s=$_[0];

#	$s =~ s/\</%=</g;
#	$s =~ s/\>/%=>/g;

	#This turned out to possibly be too broad, corrupting links:
	#$s =~ s/\"/&quot;/g;
	#We'll try this more-specific, but harder-to-get-working revision:
	#Okay, let's try that AGAIN.  heh.
	$s =~ s/^\"/\\"/g;
	$s =~ s/([^\\])\"/$1\\"/g;


	#used to not have a space before "&", but we don't want to mess up links:
	$s =~ s/ \&([^a-z])/ &amp;$1/gi;
	$s =~ s/\n/_ENT_/g;

	#20080722: possible solution to the "missing right parenthesis" bug -- change all % to %%
#	$s =~ s/\%/%%/g;

	return($s);
}#endsub make_safe_for_command_line
#############################################################################


#####################################################################################################################################
sub fix_name { return(&fix_name_of_any_form($_[0])); }
sub fix_name_of_any_form {		                   #fixname	#cleanname	#fix_name
	my $s=$_[0];
	#ASSUME GLOBAL $JUNIOR can be used as a temp variable to hold whether they are a Jr. eq " Jr.") or not (eq "")

	##### DEBUG:
	if ($DEBUG_FIXNAME) { print "<BR>\n<B>[[[FIXNAME 01: $s]]]</B> <br>\n"; }

	##### KLUDGES: INPUT THAT IS ALREADY FIXED BUT LOOKS BROKEN AND SO WE MUST SPECIFICALLY IGNORE IT:
	if ($s =~ /Sawyer Claire/i)                { return "Claire";                       }			
	if ($s =~ /Claire Sawyer/i)                { return "Claire";                       }			
	if ($s =~ /Tim And Eric/)                  { return $s;                             }			#perhaps expand this to any name where the middle name is "and" ?
	if ($s =~ /Mercogliano 808 and Christie/i) { return "808 and Christie Mercogliano"; }
	if ($s =~ /Prophet Mark and Phyllis/i)     { return "Grandad and Grandma";          }

	##### DEBUG:
	if ($DEBUG_FIXNAME) { print "<BR>\n<B>[[[FIXNAME 02: $s]]]</B> <br>\n"; }

	##### Kind of a strange exception; putting a TV show name into a stand-up comedy tag where a name would NORMALLY go:
	if ($s =~ /^Aqua Teen Hunger Force$/i) { return($s); }

	##### Deal with "Van Gogh" type names by squishing the "Van" into the last name before processing:
	$s =~ s/^Van */Van_SPC_/i;
	$s =~ s/^De */De_SPC_/i;
	if ($DEBUG_FIXNAME) { print "<BR>\n<B>[[[FIXNAME 0001A: $s]]]</B> <br>\n"; }

	##### Deal with Jr names:
	if ($s =~  /\s+Jr\.?\s+/i) {					
		$s =~ s/Jr\.//i;
		$s =~ s/  / /g;
		$JUNIOR = " Jr."; 
		if ($DEBUG_FIXNAME) { print "[[FIXNAME: JR. DETECTED: s is now $s]] <br>\n"; }
	} else { 
		$JUNIOR = ""; 
	}

	##### Deal with titles, because SubGenii and such have so many various titles:												#### This code is in 2 places! Future optimization project?
	if   ( ($s =~ /^(celebrity)-/i) || ($s =~ /^(character)-/i) || ($s =~ /^(politician)-/i) || ($s =~ /^(musician)-/i)
		|| ($s =~ /^(Reverend)-/i)  || ($s =~ /^(Popes*)-/i)    || ($s =~ /^(Dr\.)-/i)       || ($s =~ /^(Dokt*o*r*)-/i)		|| ($s =~ /^(Doc)-/i)  
		|| ($s =~ /^(Princes*)-/i)  || ($s =~ /^(King)-/i)      || ($s =~ /^(Lord)-/i)       || ($s =~ /^(Prieste*s*)-/i) 
		|| ($s =~ /^(Queen)-/i)		|| ($s =~ /^(Duchess)-/i)	|| ($s =~ /^(Agent)-/i)      || ($s =~ /^(Saint)-/i)	 
		|| ($s =~ /^(DJ)-/i)		|| ($s =~ /^(Admiral)-/i)	|| ($s =~ /^(Duke)-/i)		 || ($s =~ /^(Pontifex)-/i)
		|| ($s =~ /^(Sister)-/i)    || ($s =~ /^(Deacon)-/i)	|| ($s =~ /^(porn *star)-/i) || ($s =~ /^(ASDFASDF)-/i)
		) {
		$tmp1=$1;
		$s =~ s/^$tmp1-//i;
		$TITLE="$tmp1";
		if ($DEBUG_PERSON) { print "Setting title to $tmp1 and \$s is now \"$s\"...<BR>\n"; }
		if  ($tmp1 =~ /^celebrity$/i) { $CELEB=1; $TITLE=""; }																		#not sure about this; came from copied gode
		if (($tmp1 =~ /^character$/i) || ($tmp1 =~ /^politician$/i) || ($tmp1 =~ /^musician$/i) || ($tmp1 =~ /^porn *star$/i)) {	$TITLE .= ":";	}				#not sure about this; came from copied code
	}


	##### Deal with unknown names that are simply names like "flickr cliocjs"
	if ($s =~ /Makepeace Manor/i) {
		##### CAPITALIZED "NAMES" THAT ARE NOT ACTUALLY NAMES DO NOT GET FLIPPED!		
	} elsif ($s =~ /^flickr[ \-]([0-9a-z\-\s_]+)$/i) {
		$s = "flickr user $1";
	} elsif ($s =~ /^YouTube[ \-]([0-9a-z\-\s_]+)$/i) {
		$s = "YouTube user $1";
	} elsif ($s =~ /([a-z]+) ([a-z]+) and ([a-z]+) ([a-z]+)/i) {			#couple names where both have different last names need a different kind of inversion
		if ($DEBUG_FIXNAME) { print "[[FIXNAME CASE #2]] <br>\n"; }
		$s =~ s/([a-z]+) ([a-z]+) and ([a-z]+) ([a-z]+)/$2 $1 and $4 $3/i;
	} elsif ($s =~ /([a-z]+) ([a-z]+) and ([a-z]+)/i) {						#couple names where both have the same last name
		if ($DEBUG_FIXNAME) { print "[[FIXNAME CASE #3]] <br>\n"; }
		$s =~ s/([a-z]+) ([a-z]+) and ([a-z]+)/$2 and $3 $1/i;				
	} elsif ($s =~ /([a-z80]+) and ([a-z]+) ([a-z]+)/i) {					#couple names where both have the same last name - had to add '8' and '0' as valid characters for 808
		if ($DEBUG_FIXNAME) { print "[[FIXNAME CASE #4]] <br>\n"; }	
		$s =~ s/([a-z80]+) and ([a-z]+) ([a-z]+)/$1 and $3 $2/i;				
	} elsif ($s !~ / and /) {
		$s =~ s/([a-z\'_]+) ([a-z \.\']+)/$2 $1/i;							#invert name if only one name ... had to add a space/period to the $2 to compensate for Hunter S. Thompson / middle named people... had to add _ to compensate for _SPACE_ being put in due to "Van Gogh" style names
		if ($DEBUG_FIXNAME) { print "[[FIXNAME CASE #1]][\$1=$1/\$2=$2] <br>\n"; }
	} else {
		if ($DEBUG_FIXNAME) { print "[[FIXNAME FAIL!1]][\$1=$1/\$2=$2] <br>\n"; }
	}


	##### Finish dealing with name if it's a Jr.:
	$s .= $JUNIOR;

	##### Finish dealing with name if it's a "Van Gogh" type name:
	$s =~ s/_SPC_/ /g;

	##### Finish dealing with titles:
	if ($TITLE ne "") { $TITLE .= " "; }

	##### KLUDGES for odd exceptions:
	$s =~ s/Vic Lipinski/Dad/i;
	$s =~ s/In The Hall Kids/Kids In The Hall/;

	if ($DEBUG_FIXNAME) { print "[[[<B>FIXNAME END:</b> $s]]] <br>\n"; }

	return($TITLE . $s);
}#endsub fix_name_of_any_form
#####################################################################################################################################


##################################################################################################################################
sub countdownNoise {
	if ($STOP_LINKIFY) { return; }					#If we are stopping &linkify, we are in a rush, so don't do this system call
	my $item  = $_[0];
	my $total = $_[1];
	system("\"$ENV{COMSPEC}\" /H /C /D /IP /IX /Q audio-countdown-noise.bat $item $total 1 >nul");
}
##################################################################################################################################


#########################################################################################################################################
my %USED_FILENAMES=();
sub convert_filename_to_regex {
	my $DEBUG=0;										if ($ENV{DEBUG_CFTR}==1) { $DEBUG=1; }
	my $filename_original = $_[0];
	my $filename = $filename_original;
	$filename =~ s/\.jpe?g$//i;
	$filename =~ s/\.avi$//i;
	$filename =~ s/\.mpg$//i;
	$filename =~ s/\.gif$//i;
	$filename =~ s/\.png$//i;
	$filename =~ s/\.bmp$//i;
	$filename =~ s/\.ico$//i;
	$filename =~ s/\.tiff?$//i;
	$filename =~ s/\.pcx$//i;
	$filename =~ s/\.art$//i;
	$filename =~ s/\.cb[zr]$//i;
	$filename =~ s/\.mkv$//i;
	$filename =~ s/\.avi$//i;
	$filename =~ s/\.mp4$//i;
	$filename =~ s/\.flv$//i;
	$filename =~ s/\.mov$//i;
	$filename =~ s/\.wmv//i;
	$filename =~ s/\.mpe?g$//i;
	$filename =~ s/\.vob//i;
	$filename =~ s/\.bdmv//i;
	$filename =~ s/\.ts//i;
	$filename =~ s/\.m2ts//i;
	$filename =~ s/\.rm//i;
	$filename =~ s/\.qt//i;
	$filename =~ s/\.asf//i;
	$filename =~ s/\.asx//i;
	$filename =~ s/\.fli//i;
	$filename =~ s/\.swf//i;
	$filename =~ s/\.m4v//i;
	$filename =~ s/\.webm//i;
	$filename =~ s/-$//i;
	my $filename_original_noext = $filename;
	if ($DEBUG) { print "[0000] filename is now: $filename\n"; }
	my $filename = &regexquote($filename);

	if (0) {
		#just putting this here to make sections easier to move around	
	} elsif ($filename =~ /(IMG_[0-9][0-9][0-9][0-9]-diptych-IMG_[0-9][0-9][0-9][0-9])/) {
		if ($DEBUG) { print "* Checkpoint dyptich...\n"; }
		 $tmp1=$1; $filename = $tmp1;
		if ($DEBUG) { print "[A550] filename is now: $filename\n"; }		
	} elsif ($filename =~ /(IMG_[0-9][0-9][0-9][0-9])/) {
		if ($DEBUG) { print "* Checkpoint alpha...\n"; }
		 $tmp1=$1; $filename = $tmp1;
		if ($DEBUG) { print "[A740] filename is now: $filename\n"; }
	} elsif ($filename =~ /(\d{11}_[a-z0-9]{10}[_ ]o)/) {
		if ($DEBUG) { print "* Checkpoint flickr...\n"; }
		 $tmp1=$1; $filename = $tmp1;
		if ($DEBUG) { print "[A600] filename is now: $filename\n"; }
	} elsif ($filename =~ /(vlcsnap-\d+h\d+m\d+s\d+)/) {
		if ($DEBUG) { print "* Checkpoint VLCSnap...\n"; }
		 $tmp1=$1; $filename = $tmp1;
		if ($DEBUG) { print "[A720] filename is now: $filename\n"; }
	} elsif ($filename =~ /(\d{6}_\d{17}_\d{10}_n)/) {
		if ($DEBUG) { print "* Checkpoint santa...\n"; }
		 $tmp1=$1; $filename = $tmp1;
		if ($DEBUG) { print "[A750] filename is now: $filename\n"; }
	} elsif ($filename =~ /(MVI)[_ -]*([0-9][0-9][0-9][0-9])/) {
		if ($DEBUG) { print "* Checkpoint beta...\n"; }
		 $tmp1 = $1 . ".*" . $2;
		 $filename = $tmp1;
		if ($DEBUG) { print "[A800] filename is now: $filename\n"; }
	} elsif ($filename =~ /([12][0-9][0-9][0-9][01][0-9][0-3][0-9]_[0-9]{6})$/) {
		if ($DEBUG) { print "* Checkpoint beetleguise...\n"; }
		 $tmp1=$1; $filename = $tmp1;
	} elsif ($filename =~ / - ([A-Z0-9]{6,})$/) {				#if it ends with " - AB9243Z" with at least 6 CAP letters/numbers, then consider that a unique enough identifier
		if ($DEBUG) { print "* Checkpoint zoidberg...\n"; }	#this branch added 20091013
		$filename = $1;
		if ($DEBUG) { print "[A900] filename is now: $filename\n"; }
	} else {
		if ($DEBUG) { print "* Checkpoint gamma...\n"; }
		if ($DEBUG) { print "[A999] filename is now: $filename\n"; }

		#if ($filename =~ /([0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]_[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]_[ob])/i) { 	#	$tmp1 = $1;	#	$filename =~ s/^(.*)($tmp1)(.*$)/$2/i; 	#}

		if ($filename =~  /^[12][0-9][0-9][0-9][0-2][0-9][0-3][0-9]_?M?V?I?[ ]*-[ ]*([^\-]+) - /i) {
			$filename =~ s/^[12][0-9][0-9][0-9][0-2][0-9][0-3][0-9]_?M?V?I?[ ]*-[ ]*([^\-]+) - //i;
		}
		if ($DEBUG) { print "[B000] filename is now: $filename\n"; }
		if ($DEBUG) { print "[B500] filename is now: $filename\n"; }
		if ($filename =~ / - ([0-9]{10}_[0-9a-f]{10}_o)/i) { $filename = $1; }
		if ($DEBUG) { print "[B600] filename is now: $filename\n"; }


		$filename =~ s/(_MVI).*$/$1/i;
		$filename =~ s/[ \-]*\\\(by ([^\)]+)\\\)[ \-]*/.*/i;
		if ($DEBUG) { print "[B650] filename is now: $filename\n"; }

		if ($filename =~ /GEDC/) {
			$filename =~ s/^.*(GEDC[0-9]{4}).*$/$1/i;
		}
		if ($DEBUG) { print "[E000] filename is now: $filename\n"; }


		#turned out to be bad: if ($filename =~ /([^0-9])[0-9][0-9]? - /) { $filename =~ s/([^0-9])[0-9][0-9]? - /$1/; }
		#if ($DEBUG) { print "[F000] filename is now: $filename\n"; }

		##### remove things in parenthesis, since that gets into regex hell and they aren't generally what uniquely identifies something:
		#On second thought, sometimes stuff is ONLY in parens: $filename =~ s/\\\([^\)]*\\\)//g;

		if ($DEBUG) { print "[F400] filename is now: $filename\n"; }
		while (($filename =~  / - [a-z ,']*$/i) && (length($filename) > 14)) {
			$filename     =~ s/ - [a-z ,']*$//ig;		#stuff after numbres
			if ($DEBUG) { print "[F450] filename is now: $filename\n"; }
		}
		$filename =~ s/^ *//;			     	#trailing spaces
		if ($DEBUG) { print "[F500] filename is now: $filename\n"; }

		##### phrases that just seem silly to repeat:
		$filename =~ s/ with the /.*/g;

		##### comma lists are a big rigid, what if we add comments about the people in the filename later?
		$filename =~ s/, /.*/g;

		##### Remove 20fps, 30s, 1m30s and such:
		$filename =~ s/\\\([0-9]+fps\\\)/.*/i;
		$filename =~ s/\\\([0-9]+m[0-9]+s\\\)/.*/i;
		$filename =~ s/\\\([0-9]+s\\\)/.*/i;
		if ($DEBUG) { print "[F998] filename is now: $filename\n"; }

		#if ($filename =~ /[\s\-A-Z,\&\?\.\!\'\(\)\+\=\_]*$/i) { $filename =~ s/[\s\-A-Z,\&\?\.\!\'\(\)\+\=\_]*$//i; }
		#if ($DEBUG) { print "[F999] filename is now: $filename\n"; }

		##### NEW Transformations Go Here
		#if ($filename =~ //i) { $filename =~ s///; }


	}
	if ($DEBUG) { print "[G000] filename is now: $filename\n"; }

	##### Final scrubs:
	$filename =~ s/__+/.*/g;
	$filename =~ s/ [\-&] /.*/g;					if ($DEBUG) { print "[H100] filename is now: $filename\n"; }
	$filename =~ s/\\\[\\\]/.*/g;
	$filename =~ s/480[ip]/.*/i;
	$filename =~ s/546[ip]/.*/i;
	$filename =~ s/720[ip]/.*/i;					if ($DEBUG) { print "[H200] filename is now: $filename\n"; }
	$filename =~ s/1080[ip]/.*/i;
	$filename =~ s/\d{3,6}x\d{3,6}/.*/i;			#picture-resolution (good up to 999999x999999 which I think is awhile)
	$filename =~ s/\d{2,3}khz mono snd/.*/i;		if ($DEBUG) { print "[H300] filename is now: $filename\n"; }
	$filename =~ s/\d{2,3}khz [0-9\.]ch snd/.*/i;	if ($DEBUG) { print "[H300] filename is now: $filename\n"; }
	$filename =~ s/(\d) ([a-z])/$1.*$2/ig;
	$filename =~ s/([a-z]) (\d)/$1.*$2/ig;
	$filename =~ s/\\\(/.*/g;
	$filename =~ s/\\\)/.*/g;						if ($DEBUG) { print "[H400] filename is now: $filename\n"; }
	$filename =~ s/ ?\.\* ?/.*/g;
	$filename =~ s/'/./g;							if ($DEBUG) { print "[H500] filename is now: $filename\n"; }
	while ($filename =~  /\.\*\.\*/) { $filename =~ s/\.\*\.\*/.*/g; }
	while ($filename =~ /^\.\*/    ) { $filename =~ s/^\.\*//g;      }
	while ($filename =~  /\.\*$/   ) { $filename =~ s/\.\*$//g;      }
	$filename =~ s/ +$//g;
	$filename =~ s/\_+$//g;
	$filename =~ s/\\\././g;
	$filename =~ s/^\.*//g;
	$filename =~ s/\.\.\. */.*/g;
	$filename =~ s/\.\.\*/.*/g;

	##### If we arrive at the end, and the file is bad (like simply being "20131231", or being one that we've already used),
	##### then we just throw it all in the trash instead:
	my  $BAD=0;
	my  $FILENAME=uc($filename);			#capitalize it because case doesn't matter in our regex-attribute tagging language
	if ($USED_FILENAMES{$FILENAME} == 1)                         { $BAD=1; }		#2 files can't reduce to the same string!
	if ($filename =~ /^[12][0-9][0-9][0-9][01][0-9][0-3][0-9]$/) { $BAD=1; }		#a string that is just the date is WAY too general!
	if ($BAD) { $filename = &regexquote($filename_original_noext); }				#rest to the shitty/original version, if we must


	$USED_FILENAMES{$FILENAME}=1;
	return($filename);
}
#########################################################################################################################################


1;
