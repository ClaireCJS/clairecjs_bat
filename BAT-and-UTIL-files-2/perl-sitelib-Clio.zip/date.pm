#!/usr/local/bin/perl


$PROBLEMS = "ClioCJS\@gmail.edu";






#USAGE: use Clio::Date; &gettimeinfo;		<== populates all variables


use Clio::Math;		# to round
use Clio::String;	
use Clio::SysCall;	
my $DATESYSCALL="C:\\cygwin\\bin\\date.exe";			#may have to change to simply "date" on a unix machine
my $DEBUG_ERROR_M2=0;	#set to 1 to debug DATEERROR M2

#"1:30:45" = &convert_seconds_to_readable_length(5445,"HH:MM:SS");	#see below for info on formatting the result
#"Sun" = &convert_dow_number_to_DOW(0);							#converts dow number to readable name
#($yy,$mm,$dd)=&break_date($yymmdd);							#breaks YYMMDD date into YY, MM, and DD
#($yy,$mm,$dd)=&break_date_y2k($[yy]yymmdd);					#breaks YYYYMMDD *or* YYMMDD into YY, MM, DD
#($full_dow)=&convert_dow_to_full_lowercase_day_of_week("sat");	#returns "saturday" for "Sat", for example
#($newyymmdd)=&decrement_date_by_one_day($yymmdd);		#returns new YYMMDD date which is the input date subtracted by 1 day -- also works with YYYYMMDD type dates
#($yymmdd)=&decrement_date_by_x_days($oldyymmdd,$x);		#returns new YYMMDD date which is the input date subtracted by X days
#($new_dow)=&decrement_day_of_week("mon");			#in this case would return "sun" by decrementing "mon"
#($century)=&determine_century;					#returns "19" for the year "1997", for example
#($dow)=&determine_day_of_week_of_date("YYMMDD","991231");	#returns day of week of a YYMMDD-formatted date -- 1st YYMMDD is today, 2nd is target date
#($x)=&determine_how_many_days_until_last_monday($today_yymmdd);#returns how many days until last monday given an input YYMMDD-formatted date
#($dow)=&determine_todays_day_of_week;				#returns "mon","tue",etc
#($newyymmdd)=&increment_date_by_one_day($yymmdd);		#returns new YYMMDD date which is the input date added to by 1 day
#($new_dow)=&increment_day_of_week("mon");			#in this case would return "tue" by incrementing "mon"
#($new_date)=&increment_until_dow($date,$dow);			#returns YYMMDD of the next occurence of day of week $dow
#($day)=&last_day_of_month(2,1998);				#returns last day of month -- especially useful for Februaries/leap-year considerations
#($year,$yy,$mm,$dd)=&old_today; 				#returns 1998,98,09,01     for 9/1/1998
#($printing_date)=&reformat_date($[yy]yymmdd);			#returns nicely formatted date
#($year,$month,$day,$yy,$mm,$dd)=&today;			#returns 1998,9,1,98,09,01 for 9/1/1998




###############################################################################################################################
###############################################################################################################################
###############################################################################################################################

1;
###############################################################################################################################
###############################################################################################################################
###############################################################################################################################



############################################################################################################
sub determine_century {			#USAGE: ($century)=&determine_century;
	#$date=&do_system_call("date");       #Wed May 27 15:45:36 EDT 1998
	$date=&do_system_call($DATESYSCALL);
	#DEBUG: print "date is $date;";
	$junk="";
	$century="";
	
	chop $date;
	
	#Wed   May   27    15:45:36 EDT   1998
	($junk,$junk,$junk,$junk,   $junk,$century)=split(/\s+/,"$date");
	
	#I'm feeling VERY FREAKIN' LAZY, now that it's 2006 and suddenly I am having a problem:
	if ($century !~ /^\d\d\d\d$/) {
	        print "\n\nINTERNAL CENTURY ERROR: Year of \"$century\" does not make sense!!";
	        print "\n\tCONTACT $PROBLEMS IMMEDIATELY.\n\n";
	}#endif
	
	$century =~ s/^(..)..$/$1/;
	
	return($century);
}#endsub determine_century
############################################################################################################

#######################################################################
sub break_date {        #USAGE: ($yy[yy],$mm,$dd)=&break_date($yy[yy]mmdd);
	my $date=$_[0];		#assumes date is in YYMMDD format

	$date =~ s/\s+$//i;	#this has happened. spaces at beg have not happened yet :)
	
	if (length($date)==6) {
		if ($date =~ /^9/) {
			my ($year,$month,$day);
			$year=$date; $month=$date; $day=$date;
			$year  =~ s/^(..)....$/$1/;
			$month =~ s/^..(..)..$/$1/;
			$day   =~ s/^....(..)$/$1/;
			return($year,$month,$day);
		} elsif ($date =~ /^2/) {
			#200404
			my ($year,$month,$day)=("","","");
			$year=$date; $month=$date; $day=$date;
			$year  =~ s/^(....)..$/$1/;
			$month =~ s/^....(..)$/$1/;
			$day = "";
			return($year,$month,$day);
		} elsif ($date =~ /^1/) {
			#199402
			my ($year,$month,$day)=("","","");
			$year=$date; $month=$date; $day=$date;
			$year  =~ s/^(....)..$/$1/;
			$month =~ s/^....(..)$/$1/;
			$day = "";
			return($year,$month,$day);
		} else {
			print "[warning: breakdate generally thinks 6-digit dates should start with 1 or 2 or 9 -- \"$date\" ... its length is ".length($date)."]";
		}
	} elsif (length($date)==8) {
		my ($year,$month,$day);
		$year=$date; $month=$date; $day=$date;
		$year  =~ s/^(....)....$/$1/;
		$month =~ s/^....(..)..$/$1/;
		$day   =~ s/^......(..)$/$1/;
		#DEBUG:		print "return($year,$month,$day);<BR>";#
		return($year,$month,$day);
	} elsif ((length($date)==4) && ($date =~ /^(9[0-9])([0-1][0-9])$/)) {
		my $YYYY = 19 . $1;
		my $MM   =      $2;
		return($YYYY,$MM);
	} elsif ($date =~ /([0-9]{4})-([0-9]{2})-([0-9]{2}) ([0-9]{2}):([0-9]{2}):([0-9]{2}).([0-9]{3})/) {
		my $YYYY	= $1;
		my $MM	= $2;
		my $DD	= $3;
		my $hh	= $4;
		my $mm	= $5;
		my $ss	= $6;
		my $sss	= $7;		#partial seconds
		return($YYYY,$MM,$DD,$hh,$mm,$ss,$sss);
	}#endif
	print "[warning: breakdate could not determine the date type for \"$date\" ... its length is ".length($date)."]";
	return("","","","","","");
}#endsub break_date
#######################################################################



############################################################################################################################################
sub increment_date_by_one_day {		#USAGE: ($newyymmdd)=&increment_date_by_one_day($yymmdd);
$date = $_[0];
$year="";
$month="";
$temp_day="";
$last_day_of_month="";

$DEBUG=0;
if ($DEBUG) { print "<h2>Attempting to increment date \"$date\" by one day...</h2>\n"; }

($year,$month,$temp_day) = &break_date($date);
$last_day_of_month  = &last_day_of_month($month,$year);

$temp_day++;                         #increment day

if ($DEBUG) { print "<h4>temp_day++ is \"$temp_day\"</h4>\n"; }

if ($temp_day > $last_day_of_month) {                    #if temp_day is too high, increment month, set flag
        $temp_day="01";
        $month++;
}#endif

if ($month > 12) {                  #if month is 13, it's really january of the last year
        $year++;
        $month -= 12;
}#endif

if ($year == 100) { $year="00"; }  #if year is -1, it's really <century>99

if ($temp_day =~ /^[1-9]$/) { $temp_day = "0$temp_day";   }        #normalize values to have 0 in front of them if less than 10
if ($month    =~ /^[1-9]$/) { $month    = "0$month"; }
if ($year     =~ /^[1-9]$/) { $year     = "0$year";  }

if ($DEBUG) { print "<h3>RESULT: \"$year$month$temp_day\"...</h3>\n"; }

return "$year$month$temp_day";

}#endsub increment_date_by_one_day
############################################################################################################################################


#################################################################################################################################
sub decrement_date_by_one_day {		#USAGE: ($newyymmdd)=&decrement_date_by_one_day($yymmdd);
#USES last_day_of_month;
$date = $_[0];
$year="";
$month="";
$day="";
$MONTH_DECREMENTED=0;

#DEBUG: print "\n\ndate=$date,length(\$date) is ";print length($date);print "\n\n";

#FIRST let us define all the numbers and strings we will need:
if (length($date) == 8) {
	$year = $day = $month = $date;
	$year      =~ s/(....)..../$1/;
	$month     =~ s/....(..)../$1/;
	$day       =~ s/......(..)/$1/;
} else {
	$year = $day = $month = $date;
	$year      =~ s/(..)..../$1/;
	$month     =~ s/..(..)../$1/;
	$day       =~ s/....(..)/$1/;
}

$day--;                         #decrement day

if (!$day) {                    #if day is zero, decrement month, set flag
        $month--;
        $MONTH_DECREMENTED=1;
}#endif

if (!$month) {                  #if month is zero, it's really december of the last year
        $year--;
        $month=12;
}#endif

if ($year == -1) { $year=99; }  #if year is -1, it's really <century>99

if ($MONTH_DECREMENTED) {       #if month was decremented, set day to last day of month
        $day=&last_day_of_month($month,$year);
}#endif
if ($day   =~ /^[1-9]$/) { $day   = "0$day";   }        #normalize values to have 0 in front of them if less than 10
if ($month =~ /^[1-9]$/) { $month = "0$month"; }
if ($year  =~ /^[1-9]$/) { $year  = "0$year";  }

return "$year$month$day";

}#endsub decrement_date_by_one_day
#################################################################################################################################



###############################################################################################################
sub decrement_date_by_x_days {		#USAGE: ($yymmdd)=&decrement_date_by_x_days($oldyymmdd,$x);
#USES &decrement_date_by_one_day;
$date=$_[0];
$numdays=$_[1];
$numdays_sofar=0;
$retval=$date;

while ($numdays_sofar < $numdays) {
        $retval=&decrement_date_by_one_day($retval);
        $numdays_sofar++;
}#endwhile

return($retval);
}#endsub decrement_date_by_x_days
###############################################################################################################

###############################################################################################################################
sub determine_how_many_days_until_last_monday {		#USAGE: ($x)=&determine_how_many_days_until_last_monday($today_yymmdd);
$todays_day_of_week = $_[0];
$num_days=0;

if      ($todays_day_of_week =~ /^sun$/i) {
        $num_days = 6;
} elsif ($todays_day_of_week =~ /^mon$/i) {
        $num_days = 0;
} elsif ($todays_day_of_week =~ /^tue$/i) {
        $num_days = 1;
} elsif ($todays_day_of_week =~ /^wed$/i) {
        $num_days = 2;
} elsif ($todays_day_of_week =~ /^thu$/i) {
        $num_days = 3;
} elsif ($todays_day_of_week =~ /^fri$/i) {
        $num_days = 4;
} elsif ($todays_day_of_week =~ /^sat$/i) {
        $num_days = 5;
} else {
        $num_days = 0;
        print "\n\nINTERNAL ERROR WHEN_IS_LAST_MONDAY??: NOTIFY $PROBLEMS IMMEDIATELY!!\n\n";
}#endif

return($num_days);
}#endsubdetermine_how_many_days_until_last_monday
###############################################################################################################################




#########################################################################################################################
sub last_day_of_month {		#USAGE: ($day)=&last_day_of_month(2,1998);
my ($month)=$_[0];
my ($year)=$_[1];
my $day="";

        #### months with 31 days:
        if (($month==1) || ($month==3) || ($month==5) || ($month==7)
         || ($month==8) || ($month==10) || ($month==12)) {
                $day=31;
        #### months with 30 days:
        } elsif (($month==4) || ($month==6) || ($month==9) || ($month==11)) {
                $day=30;
        ### february is special:
        } elsif ($month==2) {
                if (($year % 4)==0) {
                        $day=29;
                } else {
                        $day=28;
                }#endif it's a leap year
				if ((($year % 4)==0) && (($year % 100)==0)) {				
						$day=28;
				}
				if ((($year % 4)==0) && (($year % 100)==0) && (($year % 400)==0)) {
						$day=29;
				}
				if ((($year % 4)==0) && (($year % 100)==0) && (($year % 400)==0) && (($year % 10000)==0)) {
						$day=28;
				}

        } else {
                $temp  = "\n\n******* INTERNAL ERROR MONTH_1_X: month=$month,year=$year *******\n";
                $temp .= "        (THIS SHOULD NEVER HAPPEN)\n\n";
                print $temp;
        }#endif

#print "<h1>Last day of month \"$month\" in year \"$year\" is \"$day\"</h1>\n\n";	#
 
return($day);
}#endsub last_day_of_month
#########################################################################################################################




##########################################################################################################################
sub determine_todays_day_of_week {			#USAGE: ($dow)=&determine_todays_day_of_week;
	my $retval="";  #return value will be the day of the week in mon/tue/wed/thu/fri/sat/sun format [as a string]
	
	$retval =  `date`;      #Fri May 29 13:49:32 EDT 1998\n
	chop $retval;           #Fri May 29 13:49:32 EDT 1998
	
	$retval =~ s/\s.*$//;   #Fri
	
	return($retval);
}#endif
##########################################################################################################################

##########################################################################################################################
sub convert_dow_to_full_lowercase_day_of_week {	#USAGE: ($full_lowercase_dow)=&determine_todays_full_lowercase_day_of_week("mon");
my $val=$_[0];
my $retval="";

if ($val =~ /mon/i) { $retval = "monday";    }
if ($val =~ /tue/i) { $retval = "tuesday";   }
if ($val =~ /wed/i) { $retval = "wednesday"; }
if ($val =~ /thu/i) { $retval = "thursday";  }
if ($val =~ /fri/i) { $retval = "friday";    }
if ($val =~ /sat/i) { $retval = "saturday";  }
if ($val =~ /sun/i) { $retval = "sunday";    }

return($retval);
}#endif
##########################################################################################################################

###################################################################
sub today {	#USAGE: ($year,$month,$day,$yy,$mm,$dd)=&today;
my $yr="";
my $mm,$month="";
my $dd,$day="";
my $junk="";
my $output=`date`;	#Sun Mar 15 15:49:07 EST 1998

($junk,$mm,$dd,$junk,$junk,$year)=split(/\s+/,"$output");

if    ($mm =~ /jan/i) { $mm="01"; $month="1"; }
elsif ($mm =~ /feb/i) { $mm="02"; $month="2"; }
elsif ($mm =~ /mar/i) { $mm="03"; $month="3"; }
elsif ($mm =~ /apr/i) { $mm="04"; $month="4"; }
elsif ($mm =~ /may/i) { $mm="05"; $month="5"; }
elsif ($mm =~ /jun/i) { $mm="06"; $month="6"; }
elsif ($mm =~ /jul/i) { $mm="07"; $month="7"; }
elsif ($mm =~ /aug/i) { $mm="08"; $month="8"; }
elsif ($mm =~ /sep/i) { $mm="09"; $month="9"; }
elsif ($mm =~ /oct/i) { $mm="10"; $month="10"; }
elsif ($mm =~ /nov/i) { $mm="11"; $month="11"; }
elsif ($mm =~ /dec/i) { $mm="12"; $month="12"; }
else { $mm = "-1 ERROR!!"; } #endi$mf

$yy =  $year;
$yy =~ s/..(..)/$1/;

$day =  $dd;
$day =~ s/^0+//;

if (($dd < 10) && ($dd !~ /^0/)) {
	$dd = "0$dd";
}#endif

return ($year,$month,$day,$yy,$mm,$dd);
}#endsub today
###################################################################




#########################################################
sub old_today {	#USAGE: ($year,$yy,$mm,$dd)=&old_today;
my $yr="";
my $mm="";
my $dd="";
my $junk="";
my $output=`date`;	#Sun Mar 15 15:49:07 EST 1998

($year,$junk,$junk,$yy,$mm,$dd)=&today;

return ($year,$yy,$mm,$dd);
}#endsub old_today
#########################################################





#####################################################################################################################
sub increment_day_of_week {	#USAGE: ($new_dow)=&increment_day_of_week("mon");
my $dow=$_[0];
if      ($dow =~ /^sun$/i) {
        return("mon");
} elsif ($dow =~ /^mon$/i) {
        return("tue");
} elsif ($dow =~ /^tue$/i) {
        return("wed");
} elsif ($dow =~ /^wed$/i) {
        return("thu");
} elsif ($dow =~ /^thu$/i) {
        return("fri");
} elsif ($dow =~ /^fri$/i) {
        return("sat");
} elsif ($dow =~ /^sat$/i) {
        return("sun");
} else {
        &error_print("INTERNAL ERROR IDOW1: cannot figure out what day \$dow=\"$dow\" is. NOTIFY $PROBLEMS.\n");
        exit;
        return("ERR");
}#endif
}#endsub increment_day_of_week
#####################################################################################################################


#####################################################################################################################
sub decrement_day_of_week {	#USAGE: ($new_dow)=&decrement_day_of_week($old_dow);
my $dow=$_[0];
if      ($dow =~ /^sun$/i) {
        return("sat");
} elsif ($dow =~ /^mon$/i) {
        return("sun");
} elsif ($dow =~ /^tue$/i) {
        return("mon");
} elsif ($dow =~ /^wed$/i) {
        return("tue");
} elsif ($dow =~ /^thu$/i) {
        return("wed");
} elsif ($dow =~ /^fri$/i) {
        return("thu");
} elsif ($dow =~ /^sat$/i) {
        return("fri");
} else {
        &error_print("INTERNAL ERROR IDOW55: cannot figure out what day \$dow=\"$dow\" is. NOTIFY $PROBLEMS.\n");
        exit;
        return("ERR");
}#endif
}#endsub decrement_day_of_week
#####################################################################################################################


###########################################################################################################################
sub increment_until_dow {					#USAGE: ($this_sunday)=&increment_until_dow($date);
my $date    = $_[0];
my $DOW_KEY = $_[1];
my $dow="";

#if (1) { print "<h1>Today ($date) is \"$dow\"</h1>\n\n"; }

$dow=&determine_day_of_week_of_date($date,$date);	

if ($dow =~ /^$DOW_KEY$/i) {
        #do nothing. date is already "incremented" to day of week we want
} else {
        while ($dow !~ /^$DOW_KEY$/i) {
                $date = &increment_date_by_one_day($date);
                $dow  = &increment_day_of_week    ($dow);
        }#endwhile
}#endif
return $date;
}#endsub increment_until_dow
###########################################################################################################################


#################################################################################################################################
sub determine_day_of_week_of_date {	#USAGE:	($dow)=&determine_day_of_week_of_day("YYMMDD-today","991231");
my $target_date    = $_[0];		#USES:	&determine_todays_day_of_week, &decrement_date_by_one_day, &decrement_day_of_week
my $current_date   = $_[1];		#USES:	&notify;
my $current_dow    = &determine_todays_day_of_week;
my $num_decrements = 0;

        #we are trying to figure out the target_dow, and we will do so by starting with today
        #and decrementing the date/dow until we get to the target_date, at which point current_dow
        #will not be the current day of week, but actually the target day of week, and then we'll
        #return it

if ($DEBUG_DOW) {
        print "\n\nDETERMINING day of week for date $target_date.\nTODAY is $current_date ($current_dow)\n";
}#endif DEBUG

while ($current_date ne $target_date) {
        $current_date = &decrement_date_by_one_day ($current_date);
        $current_dow  = &decrement_day_of_week     ($current_dow);
        if ($DEBUG_DOW) {
                print "\n\n$current_date is a $current_dow\n\n";
        }#endif DEBUG

        ##### Infinite loop protection from when people input future dates (bad input):
        $num_decrements++;
        if ($num_decrements > 10000) {
                #oops, infiloop
                &error_print("INTERNAL INFINITE LOOP ERROR: This would happen if the date you \n");
                &error_print("entered, \"$target_date\", is after today's date, \"$TODAY\".\n");
                &notify;        #exits
        }#endif
}#endwhile

return($current_dow);
}#endsub determine_day_of_week_of_date
#################################################################################################################################

###########################################################################################################################
sub error_print {
my $errmsg=$_[0];
print "$errmsg\n\n";
}#endsub error_print
###########################################################################################################################


####################################################################################################
sub remove_leading_zero {
my $s=$_[0];
$s =~ s/^0//;
return($s);
}#endsub remove_leading_zero
#####################################################################################################

###############################################################################
sub reformat_date {	#USAGE: $date_for_printing = &reformat_date($[yy]yymmdd);
	my $original_yymmdd = $_[0];    #year can be 2 OR 4 digits (Y2K)
	my $yy,$mm,$dd      = $_[1];
	my $options		    = $_[2];
	my $short_months    = $options->{short_months} || 0;
	my $prettymonth     = "";
	my $prettyyear      = "";
	my $prettyday       = "";
	my $retval          = "";
	my $century			= "";

	if ($DEBUG_ERROR_M2) { print qq[original_yymmdd=$original_yymmdd<BR>\n]; }

	#UGLY KLUDGE FOR MISTAKENLY PASSING 199412 TYPE ARGUMENTS INSTEAD OF 941231 -- just put 00 for DD in that case:
	if ($original_yymmdd =~ /^199[0-9]/) {	#no month can start with 9, so old-style 6-digit dates can be forced into it
		$century = "19";
		if ($original_yymmdd =~ /^199[0-9]$/) {$tmp="00"; } else { $tmp=""; }
		$original_yymmdd =~ s/^(19)(9[0-9])([0-1][0-9])/$2$3$tmp/i;
	}
	
	##### BREAK DOWN DATESTRING INTO COMPONENT VALUES:
	($yy,$mm,$dd) = &break_date($original_yymmdd);


	if ($DEBUG_ERROR_M2) { print qq[($yy,$mm,$dd) = &break_date($original_yymmdd);<BR>\n]; }
	#DEBUG OUTPUT DURING PROBLEMS: (9210,00,31) = &break_date(92100031);


	if ($DEBUG_ERROR_M2) { print "[YYYY] yy=$yy,mm=$mm,dd=$dd,original_yymmdd=$original_yymmdd<BR>\n"; }
	
	##### REFORMAT YEAR IF APPLICABLE:
	if ($yy =~ /^\d{4}$/) {
	        $prettyyear = $yy;
	} elsif ($yy =~ /^\d{2}$/) {
			if ($century eq "") {
		        $century = &determine_century;       #determines century
			}
	        $prettyyear = $century . $yy;
	}#endif
	
	
	##### REFORMAT MONTH:
	if ($short_months) {
		if    ($mm == 1)  { $prettymonth = "Jan"; }
		elsif ($mm == 2)  { $prettymonth = "Feb"; }
		elsif ($mm == 3)  { $prettymonth = "Mar"; }
		elsif ($mm == 4)  { $prettymonth = "Apr"; }
		elsif ($mm == 5)  { $prettymonth = "May"; }
		elsif ($mm == 6)  { $prettymonth = "Jun"; }
		elsif ($mm == 7)  { $prettymonth = "Jul"; }
		elsif ($mm == 8)  { $prettymonth = "Aug"; }
		elsif ($mm == 9)  { $prettymonth = "Sep"; }
		elsif ($mm == 10) { $prettymonth = "Oct"; }
		elsif ($mm == 11) { $prettymonth = "Nov"; }
		elsif ($mm == 12) { $prettymonth = "Dec"; }
		else {
			$prettymonth  = "[Non-Fatal error M1: could not determine what month ";
			$prettymonth .= "&quot;" . $mm . "&quot; is when attemping to reformat date...";
			$prettymonth .= "original_yymmmdd=$original_yymmdd,yy=$yy,mm=$mm,dd=$dd,prettyyear=$prettyyear]";
		}#endif
	} else {
		### This block is now duplicated below with GetCurrentMonthPretty.	#######################		This block should be replaced with a call to GetCurrentMonthPretty.
		if    ($mm == 1)  { $prettymonth = "January"; }											###		But out of laziness, I shall leave this here. 
		elsif ($mm == 2)  { $prettymonth = "February"; }										###		Leaving it here doesn't affect speed...
		elsif ($mm == 3)  { $prettymonth = "March"; }											###
		elsif ($mm == 4)  { $prettymonth = "April"; }											###
		elsif ($mm == 5)  { $prettymonth = "May"; }												###
		elsif ($mm == 6)  { $prettymonth = "June"; }											###
		elsif ($mm == 7)  { $prettymonth = "July"; }											###
		elsif ($mm == 8)  { $prettymonth = "August"; }											###
		elsif ($mm == 9)  { $prettymonth = "September"; }										###
		elsif ($mm == 10) { $prettymonth = "October"; }											###
		elsif ($mm == 11) { $prettymonth = "November"; }										###
		elsif ($mm == 12) { $prettymonth = "December"; }										###
		else {																					###
		     $prettymonth  = "[Non-Fatal error M2: could not determine what month ";			###
			$prettymonth .= "&quot;" . $mm . "&quot; is.]";										###
		}#endif																					###
		###########################################################################################
	}#endif
	
	##### REFORMAT DAY:
	$prettyday = $dd;
	$prettyday =~ s/^0+//;   #remove leading zeroes
	
	##### RETURN PRETTY DATE:
	$retval="";
	if ($prettymonth ne "") { $retval .=  "$prettymonth"; }
	if ($prettyday   ne "") { $retval .= " $prettyday"  ; }
	if ($retval      ne "") { $retval .= ", "           ; }
	$retval .= $prettyyear;
	return($retval);
}#endsub reformat_date
###############################################################################

#######################################################################
sub break_date_y2k { 	#USAGE: ($yy,$mm,$dd)=&break_date_y2k($[yy]yymmdd);
my $date  =  $_[0];  	#assumes date is in YYMMDD or YYYYMMDD format
my $year  =  $date;
my $month =  $date;
my $day   =  $date;

if ($date =~ /^\d{6}$/) {
        $year  =~ s/^(..)....$/$1/;
        $month =~ s/^..(..)..$/$1/;
        $day   =~ s/^....(..)$/$1/;
} elsif ($date =~ /^\d{8}$/) {  #4-digit year
        $year  =~ s/^(....)....$/$1/;
        $month =~ s/^....(..)..$/$1/;
        $day   =~ s/^......(..)$/$1/;
} else {
        return("$date","[Non-Fatal Error: Could not reformat the following date: &quot;$date&quot;]");
}#endif
return($year,$month,$day);
}#endsub break_date_y2k
#######################################################################

#####################################################################
sub convert_dow_number_to_DOW {
	#USAGE: "Sun" = &convert_dow_number_to_DOW(0);
	my $dow = $_[0];
	if ($dow == 0) { return "Sun"; }
	if ($dow == 1) { return "Mon"; }
	if ($dow == 2) { return "Tue"; }
	if ($dow == 3) { return "Wed"; }
	if ($dow == 4) { return "Thu"; }
	if ($dow == 5) { return "Fri"; }
	if ($dow == 6) { return "Sat"; }
}#endsub convert_dow_to_DOW
#####################################################################

###############################################################################
sub convert_seconds_to_readable_length {
	#USAGE: &convert_seconds_to_readable_length($seconds,"YEAR MONTH DAY YYYY MM DD HOUR HH MIN mm SEC ss",{leadingzerofields=>0,addabbrsuffix=>1});
	#USAGE: best & most-tested format string: "YEAR MONTH DAY HOUR MIN SEC",

	my $totalseconds	= $_[0];
	my $format		= $_[1];
	my $options	 	= $_[2];
	my $leadingzerofields 	= $options->{leadingzerofields}	|| 0;
	my $suffix			= $options->{addabbrsuffix}		|| 1;


	####### Options 
	# {leadingzerofields=>0}	#erases leading fields like 0000:00
	# {addabbrsuffix=>1}		#adds stuff like "1 yr 2 mo"
	####### Format 
	### specifies how to format the answer
	#SS=seconds with leading zero
	#SEC=seconds without leading zero
	#mm=minutes with leading zero	-- LOWERCASE!
	#MIN=minutes without leading zero
	#HH=hours with leading zero
	#HOUR=hours without leading zero
	#DD=days with leading zero
	#DAY=days without leading zero
	#MM=months with leading zero
	#MONTH=months without leading zero
	#YYYY=years with leading zero - 4 digits
	#YEAR=years without leading zero


	##### Set default format:
	if ($format eq "") { $format="YEAR MONTH DAY HOUR MIN SEC"; }
	my $retval = $format;


	##### THIS NEXT SECTION HAS BEEN PORTED TO THE &FORMAT_DATETIME functin

	##### Processnumerical values:
	my $totalminutes	= int($totalseconds / (60));
	my $totalhours	= int($totalseconds / (60*60));
	my $totaldays	= int($totalseconds / (60*60*24));
	my $totalweeks	= int($totalseconds / (60*60*24*7));
	my $totalmonths   = int($totalseconds / (60*60*24*30));
	my $totalyears    = int($totalseconds / (60*60*24*365));
	my $SEC		= $totalseconds % 60;
	my $SS		= sprintf("%02d",$SEC);
	my $MIN		= $totalminutes % 60;
	my $mm      	= sprintf("%02d",$MIN);
	my $HOUR		= $totalhours % 24;
	my $HH		= sprintf("%02d",$HOUR);
	my $DAY		= $totaldays % 30;
	my $DD		= sprintf("%02d",$DAY);
	my $MONTH		= $totalmonths % 12;
	my $MM		= sprintf("%02d",$MONTH);
	my $YEAR		= $totalyears;
	my $YYYY		= sprintf("%04d",$YEAR);

	##### Process suffix:
	my ($SFXYEAR,$SFXMONTH,$SFXDAY,$SFXHOUR,$SFXMIN,$SFXSEC)=("","","","","","");	
	if ($suffix) {
		($SFXYEAR,$SFXMONTH,$SFXDAY,$SFXHOUR,$SFXMIN,$SFXSEC)=("yr","mon","d","hr","min","sec");
		if ($YEAR==0)	{ $SFXYEAR=""; }
		if ($MONTH==0)	{ $SFXMONTH=""; }
		if ($DAY==0)	{ $SFXDAY=""; }
		if ($HOUR==0)	{ $SFXHOUR=""; }
		if ($MIN==0)	{ $SFXMIN=""; }
		if ($SEC==0)	{ $SFXSEC=""; }
		if ($leadingzerofields==0) {
			if ($YEAR==0)	{ $YEAR=""; }
			if ($MONTH==0)	{ $MONTH=""; }
			if ($DAY==0)	{ $DAY=""; }
			if ($HOUR==0)	{ $HOUR=""; }
			if ($MIN==0)	{ $MIN=""; }
			if ($SEC==0)	{ $SEC=""; }
		}
	}

	#print "Sfxyear is $SFXYEAR";
	##### Process format:
	$retval =~ s/YEAR/$YEAR$SFXYEAR/;	
	$retval =~ s/YYYY/$YYYY$SFXYEAR/;
	$retval =~ s/MONTH/$MONTH$SFXMONTH/;
	$retval =~ s/MM/$MM$SFXMONTH/;
	$retval =~ s/DAY/$DAY$SFXDAY/;
	$retval =~ s/DD/$DD$SFXDAY/;
	$retval =~ s/HOUR/$HOUR$SFXHOUR/;
	$retval =~ s/HH/$HH$SFXHOUR/;
	$retval =~ s/MIN/$MIN$SFXMIN/;
	$retval =~ s/mm/$mm$SFXMIN/;
	$retval =~ s/SEC/$SEC$SFXSEC/;
	$retval =~ s/SS/$SS$SFXSEC/;

	if ($leadingzerofields==0) {
		while ($retval =~ /^0+:?/) { 
			$retval =~ s/^0+:?//g; 
			#print "\nnow retval=$retval";
		}
	}

	##### Clean it up:
	$retval = &remove_leading_and_trailing_spaces($retval);
	$retval =~ s/\s\s/\s/g;

	return($retval);
}#endsub convert_seconds_to_readable_length
###############################################################################
#### Here is some code to test the above function:
#foreach my $tmptime (1,30,60,65,3500,3600,86300,86500,2591000,2592300,944000000,947000000) {
#	foreach my $tmpformat (
#		"YEAR MONTH DAY HOUR MIN SEC",
#		#"YYYYMMDDHHmmSS","YEAR:MONTH:DAY:HOUR:MIN:SEC","YYYY:MM:DD:HH:mm:SS"
#	) {
#		#$converted		= &convert_seconds_to_readable_length($tmptime,$tmpformat,{leadingzerofields=>1});
#		#$convertednolead	= &convert_seconds_to_readable_length($tmptime,$tmpformat);
#		$convertedwabbr	= &convert_seconds_to_readable_length($tmptime,$tmpformat,{addabbrsuffix=>1});
#		print "time=",  	sprintf("%-10s",$tmptime);
#		print "format=",	sprintf("%-29s",$tmpformat);
#		#print "lead=",	sprintf("%-20s",$converted);
#		print "wabbr=",	sprintf("%-20s",$convertedwabbr);
#		#print "nolead=",	sprintf("%-20s",$convertednolead);
#		print "\n";
#	}
#}
###############################################################################


###GOAT: document these 2 at top of file

#########################################
sub convert_mm_to_MON {
	my $mm=$_[0];
	if ($mm ==  1) { return "Jan"; }
	if ($mm ==  2) { return "Feb"; }
	if ($mm ==  3) { return "Mar"; }
	if ($mm ==  4) { return "Apr"; }
	if ($mm ==  5) { return "May"; }
	if ($mm ==  6) { return "Jun"; }
	if ($mm ==  7) { return "Jul"; }
	if ($mm ==  8) { return "Aug"; }
	if ($mm ==  9) { return "Sep"; }
	if ($mm == 10) { return "Oct"; }
	if ($mm == 11) { return "Nov"; }
	if ($mm == 12) { return "Dec"; }
	return "[mm of $mm is an unknown month]";
}#endsub convert_mm_to_MON
#########################################
###############################################################################################
sub niceyyyymm {
	my $yyyymm=$_[0];
	my $yyyy;
	my $mm;
	$yyyymm =~ /([0-9]{4})([0-9]{2})/;
	$yyyy = $1;
	$mm = $2;
	$mm = &convert_mm_to_MON($mm);
	my $retval = "$mm, $yyyy";	
	#DEBUG: print "niceyyyymm($yyyymm)=$retval<BR>\n";#
	return $retval;
}#endsub niceyyyymm
###############################################################################################
##################################################################################
sub niceyyyymmdd {
	my $yyyymmdd=$_[0];
	my $yyyy;
	my $mm;
	my $dd;
	$yyyymmdd =~ /([0-9]{4})([0-9]{2})([0-9]{2})/;
	$yyyy	= $1;
	$mm 	= $2;
	$dd 	= $3;
	$mm = &convert_mm_to_MON($mm);
	return "$mm $dd, $yyyy";	
}#endsub niceyyyymmdd
##################################################################################

###########################################################################
sub niceyyyymmddhh {
	my $yyyymmddhh=$_[0];
	my $yyyy;
	my $mm;
	my $dd;
	my $hh;
	$yyyymmddhh =~ /([0-9]{4})([0-9]{2})([0-9]{2})([0-9]{2})/;
	$yyyy	= $1;
	$mm 	= $2;
	$dd 	= $3;
	$hh	= $4;
	$mm = &convert_mm_to_MON($mm);
	my $AMPM="AM";
	if ($hh  > 11) { $AMPM="PM"; }
	if ($hh  > 12) { $hh  -= 12; }
	if ($hh == 0) { $hh="12"; }
	$hh =~ s/^0+//;
	$dd =~ s/^0+//;
	#my $hr2 = $hh+1;
	#if ($hr2 > 12) { $hr2 -= 12; }
	#my $retval = "$mm $dd, $yyyy ($hh" . "-" . "$hr2$AMPM" . ")";
	my $retval = "$mm $dd, $yyyy ($hh$AMPM" . ")";
	#DEBUG: print "yyyy=$yyyy,mm=$mm,dd=$dd,hh=$hh,hr2=$hr2,AMPM=$AMPM,retval=$retval<BR>\n";
	return $retval;
}#endsub niceyyyymmddhh
###########################################################################


###########################################################################
sub gettimeinfo {
	my $verbose=0;

	#### Get current date in YYYYMMDD format for timestampe:
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time); 
	$year+=1900; $mon+=1;

	if ($verbose) { print "\nRaw time[1X1]=$year/$mon/$mday/$hour/$min/$sec\n"; }

	$NOWYEAR=$year;
	$NOWMONTH=$mon;
	$NOWDAY=$mday;
	$NOWYYYYMMDDHHSS=sprintf("%04u%02u%02u%02u%02u",$year,$mon,$mday,$hour,$min);
	$NOWYYYYMMDD=sprintf("%04u%02u%02u",$year,$mon,$mday);
	$NOWYYYY=sprintf("%04u",$year);

	$yy = $year;
	$yy =~ s/^.*(..)$/$1/;
	$NOWYYMMDDHHSS=sprintf("%02u%02u%02u%02u%02u",$yy,$mon,$mday,$hour,$min);
	$NOWYYMMDD=sprintf("%02u%02u%02u",$yy,$mon,$mday);
	$NOWYY=sprintf("%02u",$yy);

	if ($verbose>0) { print "\n\n\n\n[1X1]nowyymmdd=$NOWYYMMDD\n\n\n\n"; }

	$NOWMM=sprintf("%02u",$mon);
	$NOWDD=sprintf("%02u",$mday);
	$NOWHH=sprintf("%02u",$hour);
	$NOWhh=$NOWHH;				#just in case
	$NOWmm=sprintf("%02u",$min);
	$NOWss=sprintf("%02u",$sec);
	$NOWmin=$min;
	$NOWsec=$sec;

	$NOWSQLSERVERTIMESTAMP = $NOWYYYY ."-". $NOWMM ."-". $NOWDD ." ". $NOWHH .":". $NOWmm .":". $NOWss . ".000";

	#DEBUG: print "\nNOW:YYYYMMDDHHSS=$NOWYYYYMMDDHHSS,YYYYMMDD=$NOWYYYYMMDD,YYYY=$NOWYYYY,MM=$NOWMM,DD=$NOWDD,HH=$NOWHH,min=$NOWmin\n";
}#endsub gettimeinfo
###########################################################################

#####################################################################################
sub reformat_time {
	my $options 		= $_[0];
	if ($options eq "") { return("reformat_time called incorrectly"); }
	my $hh 			= $options->{hh} 			|| "";
	my $mm 			= $options->{mm} 			|| "";
	my $ss 			= $options->{ss} 			|| "";
	my $civilian 		= $options->{civilian} 		|| "";
	my $usesuffix		= $options->{suffix}		|| "";
	my $leadingzeroes	= $options->{leadingzeroes}	|| "";
	my $suffix		= "";

	if ($usesuffix) {
		if ($hh >= 12)	{ $suffix="PM"; } 
		else			{ $suffix="AM"; }
	}#endif
	
	if (!($civilian==0)) {
		if ($hh > 12) { $hh-=12; }
		if ($hh == 0) { $hh=12;  }
	}#endif

	if ($option->{leadingzeroes}==0) { $hh =~ s/^0*//; }

	return("$hh:$mm$suffix");
}#endsub reformat_time
#####################################################################################

##########################################################################################
sub MakeSQLdatetimeNice {
	my $date = $_[0]; 	#2002-09-09 03:17:05.000
	$date =~ /(....)-(..)-(..) (..):(..):(..).(...)/;
	my ($yyyy,$MM,$dd,$hh,$mm,$ss,$sss)=($1,$2,$3,$4,$5,$6,$7);
	$s = &reformat_date("$yyyy$MM$dd","",{short_months=>1}) . " " . &reformat_time({hh=>$hh,mm=>$mm,civilian=>1,suffix=>1,leadingzeroes=>0});
	return($s);
}#endsub MakeSQLdatetimeNice
##########################################################################################

#############################################################################################
sub AddDateTime {
	#USAGE: $newtime = &AddDateTime({datetime=>"timestring",minutes=>20,seconds=>5});
	#FOR NOW, THIS ONLY SUPPORTS MILITARY TIME, AND ONLY RETURNS IN A SPECIFIED FORMAT.
	my $options	= $_[0];
	my $date 		= $options->{datetime};
	my $AddSeconds	= $options->{seconds}	|| 0;
	my $AddMinutes	= $options->{minutes}	|| 0;
	my $AddHours	= $options->{hours} 	|| 0;
	my $AddDays	= $options->{days}		|| 0;
	my $AddMonths	= $options->{months}	|| 0;
	my $AddYears	= $options->{years}		|| 0;
	my $tmp		= "";	
	my ($YYYY,$MM,$DD,$hh,$mm,$ss,$sss)=&break_date($date);

	#DEBUG:print "YYYY=$YYYY,MM=$MM,DD=$DD,hh=$hh,mm=$mm,ss=$ss,sss=$sss)=&break_date=($date);<BR>";#


	if ($AddSeconds > 0) {
		$ss += $AddSeconds;
		if ($ss > 59) { $ss-=60; $AddMinutes++; }
	}
	if ($AddMinutes > 0) {
		$mm += $AddMinutes;
		if ($mm > 59) { $mm-=60; $AddHours++; }
	}
	if ($AddHours > 0) {
		$hh += $AddHours;
		if ($hh > 23) { $hh-=24; $AddDays++; }
	}
	if ($AddDays > 0) {
		$DD += $AddDays;
		($tmp)=&last_day_of_month($MM,$YYYY);				#returns last day of month -- especially useful for Februaries/leap-year considerations
		if ($DD > $tmp) { $DD-=$tmp; $AddMonths++; }
	}
	if ($AddMonths > 0) {
		$MM += $AddMonths;
		if ($MM > 12) { $MM-=12; $AddYears++; }
	}
	if ($AddYears > 0) {
		$YYYY += $AddYears;
	}

	my $retval = &FormatDateTime({YYYY=>$YYYY,MONTH=>$MM,DAY=>$DD,HOUR=>$hh,MINUTE=>$mm,SECOND=>$ss,sss=>$sss,
		format=>"YYYY-MM-DD hh:mm:ss.sss"});

	#DEBUGprint "return(\"$YYYY-$MM-$DD $hh:$mm:$ss.$sss\");<BR>\n";#

	return("$retval");

}#endsub AddDateTime
#############################################################################################


#################################################################################################
sub FormatDateTime {
	my $options	= $_[0];
	my $YYYY		= $options->{YYYY}		|| "";
	my $YEAR		= $options->{YEAR}		|| "";
	my $MM		= $options->{MM}		|| "";
	my $MONTH		= $options->{MONTH}		|| "";
	my $DD		= $options->{DD}		|| "";
	my $DAY		= $options->{DAY}		|| "";
	my $hh		= $options->{hh}		|| "";
	my $HOUR		= $options->{HOUR}		|| "";
	my $mm		= $options->{mm}		|| "";
	my $MINUTE	= $options->{MINUTE}	|| "";
	my $ss		= $options->{ss}		|| "";
	my $SECOND	= $options->{SECOND}	|| "";
	my $sss		= $options->{sss}		|| "";
	my $format	= $options->{format}	|| "YYYY-MM-DD hh:mm:ss.sss";

	my $SFXYEAR	= "";		#currently unused
	my $SFXMONTH	= "";		#currently unused
	my $SFXDAY	= "";		#currently unused
	my $SFXHOUR	= "";		#currently unused
	my $SFXMIN	= "";		#currently unused
	my $SFXSS		= "";		#currently unused
	my $SFXSSS	= "";		#currently unused

	##### POPULATE FORMATED VARIABLES IF THEY DO NOT EXIST;
	if ($ss 	eq "")	{ $ss	= sprintf("%02d",$SECOND);	}
	if ($mm 	eq "")	{ $mm	= sprintf("%02d",$MINUTE);	}
	if ($HH 	eq "")	{ $HH	= sprintf("%02d",$HOUR);	}
	if ($DD 	eq "")	{ $DD	= sprintf("%02d",$DAY);		}
	if ($MM 	eq "")	{ $MM	= sprintf("%02d",$MONTH);	}
	if ($YYYY eq "")	{ $YYYY	= sprintf("%04d",$YEAR);	}

	##### POPULATE NON-FORMATTED VARIABLES IF THEY DO NOT EXIST:
	### OHOHOH - TODO - PENDING

	##### Format it:
	$retval = $format;
	$retval =~ s/YEAR/$YEAR$SFXYEAR/;	
	$retval =~ s/YYYY/$YYYY$SFXYEAR/;
	$retval =~ s/MONTH/$MONTH$SFXMONTH/;
	$retval =~ s/MM/$MM$SFXMONTH/;
	$retval =~ s/DAY/$DAY$SFXDAY/;
	$retval =~ s/DD/$DD$SFXDAY/;
	$retval =~ s/HOUR/$HOUR$SFXHOUR/;
	$retval =~ s/hh/$HH$SFXHOUR/;
	$retval =~ s/MIN/$MINUTE$SFXMIN/;
	$retval =~ s/mm/$mm$SFXMIN/;
	$retval =~ s/SEC/$SECOND$SFXSEC/;
	$retval =~ s/sss/$sss$SFXSSS/;
	#DEBUG: print "retval=[A]$retval .. ss=$ss<br>";#	
	$retval =~ s/ss/$ss$SFXSS/;
	#DEBUG: print "retval=[B]$retval<br>";#

	##### Clean it up:
	$retval = &remove_leading_and_trailing_spaces($retval);
	$retval =~ s/\s\s/\s/g;

	return($retval);
}#endsub FormatDateTime
#################################################################################################


#############################################################################################
sub SubtractDateTime {
	#USAGE: $newtime = &AddDateTime({datetime=>"timestring",minutes=>20,seconds=>5});
	#FOR NOW, THIS ONLY SUPPORTS MILITARY TIME, AND ONLY RETURNS IN A SPECIFIED FORMAT.
	my $options		= $_[0];
	my $date 			= $options->{datetime};
	my $SubtractSeconds	= $options->{seconds}	|| 0;
	my $SubtractMinutes	= $options->{minutes}	|| 0;
	my $SubtractHours	= $options->{hours} 	|| 0;
	my $SubtractDays	= $options->{days}		|| 0;
	my $SubtractMonths	= $options->{months}	|| 0;
	my $SubtractYears	= $options->{years}		|| 0;
	my $tmp			= "";	
	my $tmp2			= "";	
	my $tmp3			= "";	

	#DEBUG:print "Date=$date";#

	my ($YYYY,$MM,$DD,$hh,$mm,$ss,$sss)=&break_date($date);

	#DEBUG:print "YYYY=$YYYY,MM=$MM,DD=$DD,hh=$hh,mm=$mm,ss=$ss,sss=$sss)=&break_date=($date);<BR>subtractmonths is $SubtractMonths";#


	if ($SubtractSeconds > 0) {
		$ss -= $SubtractSeconds;
		if ($ss < 0) { $ss+=60; $SubtractMinutes++; }
	}
	if ($SubtractMinutes > 0) {
		$mm -= $SubtractMinutes;
		if ($mm < 0) { $mm+=60; $SubtractHours++; }
	}
	if ($SubtractHours > 0) {
		$hh -= $SubtractHours;
		if ($hh < 0) { $hh+=24; $SubtractDays++; }
	}
	if ($SubtractDays > 0) {
		$DD -= $SubtractDays;
		if ($DD < 1) { 
			$tmp2=$MM-1; 
			$tmp3=$YYYY;
			while ($tmp2<1) { 
				$tmp2+=12; 
				$tmp3--;
			}
			#DEBUG:print "tmp2=$tmp2,tmp3=$tmp3 while date=$date\n";#

			($tmp)=&last_day_of_month($tmp2,$YYYY);				#returns last day of month -- especially useful for Februaries/leap-year considerations
			$DD+=$tmp; $SubtractMonths++; 
		}
	}

	if ($SubtractMonths > 0) {
		#print "\nMM=$MM [a] subtractmonths is $SubtractMonths\n";#
		$MM -= $SubtractMonths;
		#print "MM=$MM [b]\n";#
		if ($MM < 1) { $MM+=12; $SubtractYears++; }
		#print "MM=$MM [c]\n";#
	}
	if ($SubtractYears > 0) {
		$YYYY -= $SubtractYears;
	}

	my $retval = &FormatDateTime({YYYY=>$YYYY,MONTH=>$MM,DAY=>$DD,HOUR=>$hh,MINUTE=>$mm,SECOND=>$ss,sss=>$sss,
		format=>"YYYY-MM-DD hh:mm:ss.sss"});

	#DEBUGprint "return(\"$YYYY-$MM-$DD $hh:$mm:$ss.$sss\");<BR>\n";#

	return("$retval");

}#endsub SubtractDateTime
#############################################################################################


######################################################################################################
sub GetCurrentMonthPretty {
	#USAGE: $month = &GetCurrentMonthPretty($optional_month_offset)		#can offset the month by -1 to get last month's name, for example
	my $offset=$_[0];
	my $prettymonth="";
	my ($year,$month,$day,$yy,$mm,$dd)=&today;			#returns 1998,9,1,98,09,01 for 9/1/1998

	if ($offset ne "") { 
		$mm += $offset;
		if ($mm  <  1) { $mm += 12; }
		if ($mm  > 12) { $mm -= 12; }
	}
	
	if    ($mm ==  1) { $prettymonth = "January";	}
	elsif ($mm ==  2) { $prettymonth = "February";	}
	elsif ($mm ==  3) { $prettymonth = "March";		}
	elsif ($mm ==  4) { $prettymonth = "April";		}
	elsif ($mm ==  5) { $prettymonth = "May";		}
	elsif ($mm ==  6) { $prettymonth = "June";		}
	elsif ($mm ==  7) { $prettymonth = "July";		}
	elsif ($mm ==  8) { $prettymonth = "August";	}
	elsif ($mm ==  9) { $prettymonth = "September"; }
	elsif ($mm == 10) { $prettymonth = "October";	}
	elsif ($mm == 11) { $prettymonth = "November";	}
	elsif ($mm == 12) { $prettymonth = "December";	}
	else {
		$prettymonth  = "[Non-Fatal error M2: could not determine what month &quot;" . $mm . "&quot; is.]";
	}#endif
	return($prettymonth);	
}#endsub
######################################################################################################
