#!/usr/local/bin/perl

##### This prints out nice tables that show you what your data "looks" like.


#USAGE: print &tabledump("cookies",\%cookies);	#can pass any type of varaible




###########################################################################################################
sub tabledump ($$) {
	#USAGE: print &tabledump("cookies",\%cookies);	#can pass any type of varaible

	local $varname = $_[0];
	my $var	   = $_[1];

	my $s="";

	#$s .= "<font size=5><B>$varname:</B></font><br>";#\n";
	$s .= &realdump($var);

	return($s);
}#endsub tabledump
###########################################################################################################

###########################################################################################################################################################
sub realdump ($;$$) {
	#ASSUMES local $varname from calling function is name of the variable we are dumping...
	my $objectsref = $_[0];
	my $levelparam = $_[1];
	my $isnotactuallyanarrayref = $_[2];
	my $level = 0 + $levelparam;
	my @objects=();
	my $i=0;
	my $mainref=ref($objectsref);
	my $html = "";
	my $SORT=1;
	my $ARRAY=0;


	my $CAPTION_ROW="";
	if ($levelparam<2) { $CAPTION_ROW=qq[<TR bgcolor="#CCCCCC"><TD colspan=2 align=center><B>$varname</B></TD></TR>]; }

	#$html .= "\n<!-- DUMP LEVEL $level - BEGIN -->\n<!-- objectsref is $objectsref -->\n<!-- ref(objectsref)/\$mainref is $mainref -->";
									   
	if ($mainref =~ /ARRAY/) {
		@objects = @$objectsref;
		$SORT=0; $ARRAY=1;
	} elsif ($mainref =~ /HASH|::/) {
		$html .= &realdump([$objectsref],$level+1,1);
		return($html);
	} elsif ($mainref =~ /SCALAR/) {
		#$html .= "<!-- TREATING AS SCALAR REF XXX -->\n";
		$html .= "<table align=\"center\" border=\"".($level+1)."\">";
		$html .= $CAPTION_ROW;
		$html .= "<tr bgcolor=\"\#DDDDDD\">";
		$html .= "<td align=\"center\"><b>Scalar ref:</b></td>";
		$html .= "<td align=\"center\">";
		$html .= &realdump($$objectsref,$level+1);
		$html .= "</td></tr></table>";
		return($html);	
	} else {
		#$html .= "<!-- TREATING AT LOCATION ZZZ -->\n";
		$html .= "<table align=\"center\" border=\"".($level+1)."\" cellspacing=\"0\" cellpadding=\"0\">";
		$html .= $CAPTION_ROW;
		$html .= "<tr bgcolor=\"\#DDDDDD\">";
		$html .= "<td align=\"center\"><B>Scalar:</B>&nbsp;</td>";

		#OLD: $html .= "<td align=\"center\">&nbsp;$objectsref</td></tr></table>";
		#NEW: $html .= "<td align=\"center\">&nbsp;" . &realdump($$objectsref,$level+1,0) . "</td>\n</tr>\n</table>\n";
		#COMBO:
		if ($objectsref =~ /SCALAR/) {
			#NEW:
			#$html.= "<td align=\"center\">&nbsp;" . &realdump($$objectsref,$level+1,0) . "</td></tr></table>";
			$html .= "<td align=\"center\">" . &realdump($$objectsref,$level+1,0) . "</td></tr></table>";
		} else {
			#OLD: 
			$html .= "<td align=\"center\">&nbsp;$objectsref</td></tr></table>";
		}#endif
		return($html);
	}#endif
				    
	#if (@objects > 0) { $html .= "<hr /><br/><font size=5><TT><B>There were ".@objects." objects returned from the gadget.</B></TT><br/><br/></font>"; }


	#maybe has to do with level:
	#if ($isnotactuallyanarrayref && $ARRAY) { $ARRAY=0; }

	#if ($SORT) { @objects=sort(@objects); }

	if ($ARRAY) { 
		#$html .= "\n<!-- TREATING AS ARRAY, ARRAY=$ARRAY, LOCATION YYY -->\n";
		$html .= "<table border=\"".($level+1)."\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\">";
		$html .= $CAPTION_ROW;
		$html .= "<TR valign=\"middle\" bgcolor=\"\#"."DDDDDD"."\">";
		if (!$isnotactuallyanarrayref) {
			$html .= "<TD align=\"center\" colspan=\"2\"><B>$objectsref<BR/>(has ".@$objectsref." elements)</B></td>";
		}#endif
		$html .= "</TR>";
	}#endif

	foreach my $elem (@objects) {
		#DEBUG: $html .= "<hr />elem is \"$elem\", ref(\$elem) is \"".ref($elem)."\"<br />";
		$i++;
		my $ref=ref($elem);
		#$html .= "\n<!-- [$level] elem is \"$elem\", ref(\$elem) is \"".ref($elem)."\" -->\n";
		if ($ref =~ /HASH|::/) {
			#$html .= "<!-- TREATING AS HASH, ARRAY=$ARRAY -->\n";
			my $j=0;

			my $colspan=2;
			if (!$ARRAY) { $colspan=1; }
			else		 { $html .= qq[<TR valign="middle">]; }

			$html .= "<TD align=\"left\" colspan=\"$colspan\">";

			#OHOH -- i added width=100% here because it looked better in one case, but it may not look better in all cases

			$html .= "<table width=\"100\%\" align=\"". ($level?"top":"center") ."\" border=\"$level\" cellspacing=\"0\" cellpadding=\"0\">";
			#$html .= $CAPTION_ROW;
			$html .= "<TR valign=\"middle\" bgcolor=\"\#DDDDDD\"><TD align=\"center\" colspan=\"2\">";
			$html .= "<font size=\"3\"><B>object ";

			if (@objects > 1) { $html .= " $i of ".@objects." "; }
			my @keys=keys %$elem;
			my $elementcount=@keys;
			$html .= "==&gt; \"$elem\"";
			$html .= "<br/>(has $elementcount elements)";
			$html .= "</B></font></TD></TR>";
			#OH: maybe we should sort these. maybe not.
			my $tmpref="";
			foreach my $key (sort @keys) {
				#$html .= "key=$key,val=".(defined($elem->{$key})?$elem->{$key}:"NULL")."";
				$html .= "<!-- TREATING AT LOCATION ZZZ -->";
				$html .= "<TR valign=\"middle\" bgcolor=\"\#".($j++%2?"FFFFFF":"EEEEEE")."\">";
				$html .= "<TD align=\"right\">$key&nbsp;</td><TD align=\"left\">";
				if (defined($elem->{$key})) {
					$tmpref = ref($elem->{$key});
					if ($tmpref =~ /ARRAY|HASH|::/) {
						$html .= &realdump($elem->{$key},$level+1,0);
					} elsif ($tmpref =~ /SCALAR/) {
						$html .= &realdump($elem->{$key},$level+1);
					} else {
					   $html .= "&nbsp" . $elem->{$key};
					}#endif
				} else {
					$html .= "&nbsp;<font color=\"\#AAAAAA\">NULL</font>";
				}#endif
				$html .= "</TD></TR>";
			}#endforeach
			$html .= "</table>";
			$html .= "</TD>";
			if ($ARRAY) { $html .= "</TR>"; }

			#if (!$level) { $html .= "<br/><hr/><br/>"; }

		} elsif ($ref =~ /ARRAY/) {
			
			#$html .= "\n<!-- TREATING AS ARRAY REF, ARRAY=$ARRAY -->\n";
			my $j=0;

			my $colspan=2;
			if (!$ARRAY) { $colspan=1; }
			$html .= "<TR valign=\"middle\"><TD align=\"left\" colspan=\"$colspan\">";
			$html .= "<table align=\"center\" border=\"$level\" cellspacing=\"0\" cellpadding=\"0\">";
			$html .= $CAPTION_ROW;
			$html .= "<TR valign=\"middle\" bgcolor=\"\#DDDDDD\"><TD align=\"center\" colspan=\"2\">";
			$html .= "<font size=\"\#DD0000\"><B>object $i of ".@objects." ==&gt; \"$elem\"</B></font></TD></TR>";
			my @tmpkeys=();
			if ($SORT) { @tmpkeys=sort @$elem; } else { @tmpkeys=@$elem; }
			foreach (@tmpkeys) {
				#$html .= "\n<!-- TREATING AT LOCATION BBB -->\n";
				$html .= "<TR valign=\"middle\" bgcolor=\"\#".($j++%2?"FFFFFF":"EEEEEE")."\">";
				$html .= "<TD align=\"right\">$j&nbsp;</td><TD align=\"left\">";
				#OLD: $html .= "$_";
				#TESTING: #$html .= &realdump([$objectsref],$level+1,1);

				if (ref($_) =~ /SCALAR/) {
					$html .= &realdump(${$_},$level+1);
				} elsif (ref($_) ne "") {
					$html .= &realdump($_,$level+1);
				} else {
					$html .= "$_";
				}#endif

				$html .= "</td></TR>";
			}#endforeach
			$html .= "</table>";
			$html .= "</TD></TR>";

			#if (!$level) { $html .= "<br/><hr/>\n<br/>\n"; }
			#} elsif ($ref =~ /SCALAR/) {
			#	$html .= "\n<!-- TREATING AS SCALAR REF -->\n";
			#	$html .= "\n<table border=\"".($level+1)."\" cellpadding=\"0\" cellspacing=\"0\">\n";
			#	$html .= $CAPTION_ROW;
			#	$html .= "<tr valign=\"middle\" bgcolor=\"\#DDDDDD\">";
			#	$html .= "<td align=\"center\"><B>Scalar Ref:</B></td>\n";
			#	$html .= "<td align=\"center\">$$elem</td>\n";
			#	$html .= "</tr>\n";
			#	$html .= "</table>\n";

		} else {

			if ($ARRAY) {
				#$html .= "\n<!-- TREATING AS SCALAR VALUE WITHIN ARRAY, ARRAY=$ARRAY -->\n";
				$html .= "<TR valign=\"middle\" bgcolor=\"\#".($i%2?"FFFFFF":"EEEEEE")."\">";
				$html .= "<TD align=\"right\">&nbsp;<B>" . $i . " of " . @objects . "</B>&nbsp;</TD>";
				$html .= "<TD align=\"left\">&nbsp;";
				if (ref($elem) =~ /SCALAR/) {
					$html .= &realdump($elem,$level+1);
				} else {
					$html .= $elem;
				}#endif
				$html .= "&nbsp;</TD>";
				$html .= "</TR>";
			} else {
				#$html .= "\n<!-- TREATING AS SCALAR VALUE **NOT** WITHIN ARRAY=$ARRAY -->\n";
				$html .= $elem;
			}#endif

		}#endif
	}#endforeach
	if ($ARRAY) { $html .= "</table>"; }
	#$html .= "\n<!-- DUMP LEVEL $level - END -->\n";
	return($html);
}#endsub realdump
###########################################################################################################################################################


1;

