my $DEBUG_SINGULAR=0;	#DEBUG_PLURAL



#!/usr/bin/local/perl
use strict;
#NO! use vars qw($TAGGING_PICTURES);					#this flag is set and at the very least alters how &singular returns results

#USAGE: $new_words = &capitalize_each_word($new_words);
#USAGE: $no_spaces=&remove_leading_and_trailing_spaces($spaces);
#USAGE: print &commaize("123456789");	#would print 123,456,789
#USAGE: print "You are the " . $num . &digitsuffix($num) . " visitor"; #prints 1st, 2nd, 3rd, 4th, 5th, etc
#USAGE: $pluralword=&plural("knife");		#returns "knives"
#USAGE: $singular_word=&singular("knives");	#returns "knife"


my @SINGULAR_WORDS_THAT_END_IN_S=("sunglasses","brass","glass","glasses","binoculars","debris","Priestess","Popess",
	"Princess","politics","toss","cordless","cyclops","mattress","buttress","heiress","priestess","tongs","grass",
	"BBS","glass","gross","crass","succubus","hubris","tennis",	"physics","class","business","jeans","piss",
	"ass","gas","downstairs","upstairs","stairs","Elvis","DOS","moss","boss","loss","floss","Apples To Apples","schnapps",
	"stairs","upstairs","downstairs","status","gloss","penis","clitoris","pajamas","pants","panties","bass","headdress",
	"dress","cross","Anonymous","SubGenius","circus","blinds","snus","success","harness","skis","scissors","pliers",
	"scallions","clothes","shotglass","Crocs","fungus","Jesus","James","bus","rights",	"sideways","dangerous","lens",
	"less","bios","couscous","press","wuss","delicious","pelvis","Christmas","hourglass","diatomaceous","wireless",
	"analysis","iWorks","tetris","news","Pegasus","express","clematis",
	"AliExpress",	#adding 'picture of pictures' because otherwise autotagging makes it be 'picture of picture' which is actually something completely different...
	"picture of pictures","praying mantis","fetus","completeness","holiness","wholeness","asparagus","parthenogenesis",
	"hibiscus","compass","us","fiberglass","address","always","Jones","hilarious","electrolysis","uterus","a mess",
	"trans","chess","Ladies",
	);	
my @PLURAL_WORDS_THAT_ARE_SAME_AS_SINGULAR=("people","audio","deer","fish","entertainment");
my @CAN_ACTUALLY_BE_SINGULARIZED=("Transformers","Autobots","Decepticons","Hokies");	#&singularize throws out anything capitalised, as people's names get passed to this function...singularizing "Los Angeles" doesn't make sense either. But SOME things are exceptions to this rule, and can UNEXPECTEDLY (because they are capitalized) be singularized.

##### GLOBAL VARIABLES FOR THIS LIBRARY:
my $singular_word="";
my $string="";				#a temp - why re-initialize a bazillion times?



###########################################################
sub singular {															#aka sub singularize
	#uses global $singular_word;
	my $s         = $_[0];						
	my $TURNTOSPC = $_[1];								

	##### Massage input data:
	$s =~ s/_SPC_/ /g;										#" " is stored as "_SPC_" for various reasons at certain times


	##### Irregular words that might actually follow a rule but I'm too lazy to think about it right now:
	if ($s =~  /^(.*)fetuses$/i) { return("$1fetus")   ; }				#also update "#irregular singulars need to happen here" in picturetag.pm
	##### Irregular words that I am deeming "just plain irregular and not worth thinking about":
	if ($s =~ /^school buses$/i) { return("school bus"); }				#also update "#irregular singulars need to happen here" in picturetag.pm
	if ($s =~        /^buses$/i) { return("bus")       ; }				#also update "#irregular singulars need to happen here" in picturetag.pm
	if ($s =~        /^teeth$/i) { return("tooth")     ; }				#also update "#irregular singulars need to happen here" in picturetag.pm
	if ($s =~        /^geese$/i) { return("goose")     ; }				#also update "#irregular singulars need to happen here" in picturetag.pm
	if ($s =~     /^tomatoes$/i) { return("tomato")    ; }				#also update "#irregular singulars need to happen here" in picturetag.pm
	#^need to convert this to for(@ARRAY) loop


	##### In general, in case this function gets sent items such as names or bylines, it's prudent to not singularize any input text that meets any of these rules:
	if  (  ($s =~ /^[A-Z\"\'\.][A-Za-z\.\'][a-z\"\'\.]* [A-Z\"\.\'][A-Za-z\.\'][a-z\"\'\.]*$/) 
		|| ($s =~ /^[A-Z\"\'\.][A-Za-z\.\'][a-z\"\'\.]* [A-Z\"\.\'][A-Za-z\.\'][a-z\"\'\.]* [A-Z\"\.\'][A-Za-z\.\']*[a-z\"\'\.]*$/) 
		|| ($s =~           /^by /i)								 #proper names follow 'by'						and     should not be singularized either
		|| ($s =~          /^for /i)								 #proper names follow 'for'						and     should not be singularized either
		|| ($s =~      /^funeral /i)								 #proper names follow 'funeral'					and		should not be singularized either
		|| ($s =~      /^wedding /i)								 #proper names follow 'wedding'					and		should not be singularized either
		|| ($s =~     /^birthday /i)								 #proper names follow 'birthday'					and		should not be singularized either
		|| ($s =~    /^musician: /i)								 #proper names follow 'musician'					and		should not be singularized either
		|| ($s =~   /^character: /i)								 #proper names follow 'character'				and		should not be singularized either
		|| ($s =~   /^graduation /i)								 #proper names follow 'graduation'				and		should not be singularized either
		|| ($s =~  /^cameraperson/i) 							     #proper names follow 'cameraperson'				and		should not be singularized either
		|| ($s =~      /^concert /i)								 #concert tags follow w/proper band names		and     should not be singularized either
		|| ($s =~ /^barbecue [A-Z0-9]/)						         #barbecue tags follow w/proper host names		and     should not be singularized either
		|| ($s =~    /^party [A-Z0-9]/)                              #concert  tags follow w/proper host names		and     should not be singularized either
		|| (($s =~ /^playing [A-Z]/)||($s =~ /^playing cards/))	     #activities    follow w/proper game names		and		should not be singularized either
		|| ($s =~            /'s$/i)								 #don't singularize:		possessive 's			EX: "Clio's" should not become "Clio'" or "Clio"
		|| ($s =~        /^doing /i)								 #don't singularize:		activities				EX: "doing shot" or "shooting hoop" is just kind of weird/lame/awkward-sounding
		|| ($s =~        /^[\"\']/i)                				 #don't singularize:		anything starting w/"	EX: ""Bob" Dobbs" - this rule mostly exists because of "Bob"
		|| ($s =~      /^[0-9]+s$/i)	) {							 #don't singularize:		numbers					EX: "1990s" should not become "1900" - in fact, adding 1900 to 1900s is bad; one implies a 100 year range; the other implies a 1 year range)
			return($s); 
	}
	##### PROPOSAL: Maybe anything that starts with a capital letter should not be singularized as it's a proper title? we'll test this out.??
	##### RESULT:   Turns out there are some exceptions (200810) happening....so let's not do that.


	##### A list of words that look plural, but really aren't, is maintained. Those words shall be returned without modification:
	foreach $singular_word (@SINGULAR_WORDS_THAT_END_IN_S) { if (($s =~ /^$singular_word$/i) || ($s =~ / $singular_word$/i)) { return($s); } }


	
	##### A list of words that look like proper/un-singularizable names, but really aren't, is maintained. Those words shall be returned with modification whereas most words like them wont:
	my $DO_ANYWAY=0;
	foreach $string (@CAN_ACTUALLY_BE_SINGULARIZED) { if (($s =~ /^$string$/i) || ($s =~ / $string$/i)) { $DO_ANYWAY=1; } }
	if ((!$DO_ANYWAY) && ($s =~ /^[A-Z]/)) { return($s); }
 


	##### I'm sure the next set could be optimized, but it's not like this was thought through. This code evolved as I ran into new input that would break it.

	#OLD: DO ALL OF THE BELOW WITH A SINGLE LINE: $s =~ s/^(.+)s$/$1/i;					#what a n00b things will work - he will be surprised very quickly

	if ($s       =~  /^(.+)(ye)s$/i) {										#...yes			#eyes becomes eye
		if ($DEBUG_SINGULAR) { print "* singular case 03 ($s)<BR>\n"; }
		$s       =~ s/^(.+)(ye)s$/$1$2/i;
	} elsif ($s  =~  /^(.+)ves$/i) {										#...ves			#leaves->leaf
		if ($DEBUG_SINGULAR) { print "* singular case 04 ($s)<BR>\n"; }
		$s       =~ s/^(.+)ves$/$1fe/i;
		#But some do not get a silent E at the end (wives vs leaf), and I can't tell what the rule is, so just fix them here:
		$s       =~  s/leafe$/leaf/i;
		$s       =~   s/wafe$/wave/i;
		$s       =~  s/peefe$/peeve/i;
		$s       =~ s/shelfe$/shelf/i;
		$s       =~  s/wolfe$/wolf/i;
		$s       =~  s/glofe$/glove/i;
		$s       =~  s/roofe$/roof/i;
	} elsif ($ s =~   /^(.+)[c]hes$/i) {									#...ches		#sandwiches->sandwich
		if ($DEBUG_SINGULAR) { print "* singular case 05 ($s)<BR>\n"; }
		$s       =~ s/^(.+)([c]h)es$/$1$2/i;
		$s       =~ s/^mustach$/mustache/i;			#EXCEPTION: mustache
	} elsif ($s  =~   /^(.+)[nlt]ies$/i) {									#...[nlt]ies	#ponies->pony/butterflies->butterfly/parties->party
		if ($DEBUG_SINGULAR) { print "* singular case 06 ($s)<BR>\n"; }
		$s       =~ s/^(.+)([lnt])ies$/$1$2y/i;
	} elsif ($s  =~ /^(.+)[eu]es$/i) {										#...ees			#trees->tree bees->bee / statues->statue
		if ($DEBUG_SINGULAR) { print "* singular case 07 ($s)<BR>\n"; }
		$s       =~ s/^(.+[eu]e)s$/$1/i;
	} elsif ($s  =~  /^(.+)(rr*)(ie)s$/i) {									#...rries		#berries is special because "es" after an rri is different than "es" after a typical I
		if ($DEBUG_SINGULAR) { print "* singular case 10 ($s)<BR>\n"; }						#20090201 added * after rr* to get words like batteries as well as berries
		$s       =~ s/^(.+)(rr*)(ie)s$/$1$2y/i;													
	} elsif ($s  =~  /^(.+)([io]e)s$/i) {									#...ies/oes		#cookies  is special because "es" after an i is different than "es" after other stuff
		if ($DEBUG_SINGULAR) { print "* singular case 20 ($s)<BR>\n"; }
		$s       =~ s/^(.+)([io]e)s$/$1$2/i;
		$s       =~ s/potatoe/potato/;				#EXCEPTION
		$s       =~ s/mangoe/mango/;				#EXCEPTION
		$s       =~ s/flamingoe/flamingo/;			#EXCEPTION
		#archipalego is not gonna come up lol
	} elsif ($s  =~  /^(.+)[a][k]es$/i) {									#...akes		#cupcakes is special because "es" after "akes" requires taking just the S off...
		if ($DEBUG_SINGULAR) { print "* singular case 30 ($s)<BR>\n"; }
		$s       =~ s/^(.+)s$/$1/i;
	} elsif ($s  =~   /s[s]es$/i) {											#...sses		#dresses->dress
		if ($DEBUG_SINGULAR) { print "* singular case 35 ($s)<BR>\n"; }
		$s       =~ s/(s[s])es$/$1/;
	} elsif (($s =~   /[bcdghklmnprtsz]es$/i) && ($s !~ /shes$/i)) {				        #...tes/res		#faCes, spiKes, coNes, pictuRes, quoTes, gaMes, horSes, ruLes, blaDes, striPes, cuBes, apostropHes, cartridGes, priZes
                                              #^^^^^^^^^^^^^^ "brushes" broke this rule, becmoing "brushe" - so it makes sense for /hes$/ but not /shes$/				
		if ($DEBUG_SINGULAR) { print "* singular case 36 ($s)<BR>\n"; }
		$s       =~ s/([bcdghklmnprtsz])es$/$1e/;
	} elsif ($s  =~  /^(.+)[bcdpot]les$/i) {								#...?les		#tables->table, apples->apple, games->game, testicles->testicle, candles->candle, poles->pole, bottles->bottle,  - unlike method 40 of shotglasses->shotglass which would give us tabl,appl
		if ($DEBUG_SINGULAR) { print "* singular case 37 ($s)<BR>\n"; }
		$s       =~ s/^(.+[bcdpot]le)s$/$1/i;
	} elsif ($s  =~  /^(.+)es$/i) {											#...es			#shotglasses->shotglass
		if ($DEBUG_SINGULAR) { print "* singular case 40 ($s)<BR>\n"; }
		$s       =~ s/^(.+)es$/$1/i;
	} else {																#...s			#generic/default case
		##### DEFAULT CASE: simply remove the s from the end
		if ($DEBUG_SINGULAR) { print "* singular case 00 [default] ($s)<BR>\n"; }
		$s =~ s/^(.+)s$/$1/i;
	}
	$s =~ s/\s+$//;
	if ($TURNTOSPC) { $s =~ s/ /_SPC_/g; }				#" " is stored as "_SPC_" for various reasons at certain times
	if ($DEBUG_SINGULAR) { print "* singular of [[[$_[0]]]] is [[[$s]]] [debug 1xu34] [TURNTOSPC=$TURNTOSPC]<BR><BR>\n\n"; }
	return($s);
}
###########################################################


############################################################################################################################################
sub plural {
	#USAGE: $pluralword=&plura("knife");	#returns "knives"
	#TO TEST: foreach my $word ("life","day","navy","gravy","knife","ass","fish","hippy","lip","face") { print $word . "=" . &plural($word) . "<BR>"; }
	#this just makes a word it's plural, for dynamic content purposes
	#it is expected that this owuld have to be updated periodically :)

	my $word   = $_[0];
	my $retval = "";	
		
	foreach my $tmpword (@PLURAL_WORDS_THAT_ARE_SAME_AS_SINGULAR) {	if ($word =~ /^$tmpword$/i) { return $tmpword; } }		#First process exceptions

	##### Then process by grammatical rules:
	if ($retval eq "") {
		my $extraparens;
		my $allbutlast2letters = $1;
		my $secondtolastletter = $2;
		my $rightletter = $3;
		my $allbutlastletter = $allbutlast2letters . $secondtolastletter;

		if ($word =~ /\)$/) {		#in case we get something like "date (day)" to make it "date (days)"
			$word =~ /^(.*)(.)(.)(\)+)$/;	#added last (\)*)
			$allbutlast2letters = $1;
			$secondtolastletter = $2;
			$rightletter        = $3;
			$extraparens        = $4;
			$allbutlastletter   = $allbutlast2letters . $secondtolastletter;
			$word =~ s/\)*$//;
		} else {
			$word =~ /^(.*)(.)(.)$/;
			$allbutlast2letters = $1;
			$secondtolastletter = $2;
			$rightletter        = $3;
			$allbutlastletter   = $allbutlast2letters . $secondtolastletter;
		}
		#DEBUG: print "2ndtolastletter=$secondtolastletter,rightletter=$rightletter,allbutlast=\"$allbutlastletter\",allbutlast2=\"$allbutlast2letters\",extraparens=\"$extraparens\"<BR>";	

		if	($secondtolastletter =~ /f/i)          { $retval = $allbutlast2letters . "ves"; }
		elsif	   ($rightletter =~ /s/i)          { $retval = $word               . "es" ; }
		elsif	   ($rightletter =~ /y/i)          { 
			if ($secondtolastletter =~ /[aeiou]/i) { $retval = $word               . "s"  ; }
			else                                   { $retval = $allbutlastletter   . "ies"; }
		} else                                     { $retval = $word               . "s"  ; }
		if ($extraparens) { $retval .= $extraparens; }
	}#endif

	return($retval);
}#endsub plural
############################################################################################################################################



##############################################################################################################
sub regexquote {						#can't believe I was doing this wrong for 20 years haha
	my $s = $_[0];

	$s =~ s/\\/\\\\/g;		

	$s =~ s/\(/\\(/g;
	$s =~ s/\)/\\)/g;
	$s =~ s/\[/\\[/g;
	$s =~ s/\]/\\]/g;

	$s =~ s/\./\\./g;
	$s =~ s/\+/\\+/g;
	$s =~ s/\*/\\*/g;

	$s =~ s/\^/\\^/g;
	$s =~ s/\$/\\\$/g;

	#any new additions also need to be propagated to generate-filelists-based-on-attributes.pl

	#DEBUG:	print "[[[quoted regex is $s]]]";#

	return($s);
}#endsub regexquote
##############################################################################################################


######################################################################################################################
sub digitsuffix {
	#USAGE: print "You are the " . $num . &digitsuffix($num) . " visitor"; #prints 1st, 2nd, 3rd, 4th, 5th, etc
	my $realcount 		= $_[0];
	my $suffix    		= "";		#return value
	my $lastdigit 		= $realcount;
	my $last2digits		= $realcount;
	$lastdigit 			=~ s/^.*(.)$/$1/;   
	$last2digits 		=~ s/^.*(..)$/$1/;   

	#DEBUG: print "<BR>realcount is $realcount<BR>lastdigit is $lastdigit<BR>";

	if    ($lastdigit eq "1")	{ $suffix="st"; }
	elsif ($lastdigit eq "2")	{ $suffix="nd"; }
	elsif ($lastdigit eq "3")	{ $suffix="rd"; }
	else						{ $suffix="th"; }
	if (($last2digits >= 11) && ($last2digits <= 13)) { $suffix="th"; }
	return($suffix);
}#endsub digitsufix        
######################################################################################################################
        

############################################################################
sub antihtml {			#I have a better version of this somewhere! MUCH MUCH Better! get that one and replace this with it....
	my $s = $_[0];

#####   1990-2009:
# Must do ampersands first as they are used in other tags!!:
#	$s =~ s/&/&amp;/g;
#
#	$s =~ s/</&lt;/g;
#	$s =~ s/>/&gt;/g;
#	$s =~ s/"/&quot;/g;
#   
#####   2009+

	return(&strip_HTML($s));
}#endsub antihtml
############################################################################
################################################################################################################################################
sub strip_HTML {
	my $s = $_[0];

	#copied from http://www.perl.com/doc/FMTEYEWTK/regexps.html - skipped comment strip and special-char-remapping because that wont apply to my activities

	# next we'll remove all the <tags>
	$s =~ 
		s{ <					# opening angle bracket 
			(?:					# Non-backreffing grouping paren 
				[^>'"] *		# 0 or more things that are neither > nor ' nor " 
					|			# or else 
				".*?"			# a section between double quotes (stingy match) 
					|			# or else '.*?' # a section between single quotes (stingy match) 
			) +					# repetire ad libitum 
								# hm.... are null tags <> legal? XXX 
			> 					# closing angle bracket 
		}{}gsx;					# mutate into nada, nothing, and niente

	return($s);
}
################################################################################################################################################



###########################################################################
sub commaize {		#adds commas to numbers
	#USAGE: print &commaize("123456789"); #would print 123,456,789
	my $s=$_[0];
	$s =~ s/([0-9]{3})$/,$1/g;
	while ($s =~ /[0-9]{4}/) { $s =~ s/([0-9]{3}),/,$1,/;	}
	$s =~ s/^,//;		#KLUDGE!
	return($s);
}#endsub commaize
###########################################################################

###############################################################################
sub remove_leading_and_trailing_spaces {
	#USAGE: $no_spaces=&remove_leading_and_trailing_spaces($spaces);
	my $s = $_[0];
	$s =~ s/^\s+//;
	$s =~ s/\s+$//;
	return($s);
}#endsub remove_leading_and_trailing_spaces
###############################################################################

############################################################
sub capitalize_each_word {
	#USAGE: $new_words = &capitalize_each_word($new_words);

	my $line = $_[0];
	$line =~ s/\b(\w)/\U$1/g;
	return $line;

	#my @words = split(/\s+/,$_[0]);
	#foreach my $word (@words) {
	#	#print "Word is $word<BR>";
	#	$word = "\L$word";
	#	$word = "\u$word ";
	#}
	#my $temp2 = join(/\s+/,@words);
	#return $temp2;
}#endsub capitalize_each_word
############################################################








1;
