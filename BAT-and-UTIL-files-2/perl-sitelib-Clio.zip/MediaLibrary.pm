use Clio::Constants;
use Clio::Date;
use strict;
use vars qw($MULTI_VALUE_FORM_DELIMITER $MASTER_VIDEO_LIST @REGEX_OF_INTERESTED_SHOWS $DIVX_URL $QUICKTIME_URL $DRIVE);

my $DELIMITER = $MULTI_VALUE_FORM_DELIMITER;		#from Clio::Constants, also used by Clio::Parse_Data
	

$DRIVE = "o";
if ($ENV{"machinemame"} !~ /^fire$/i) { $DRIVE = "i"; }

$DIVX_URL 			= "http://www.divx.com/divx/";
$QUICKTIME_URL		= "http://www.apple.com/quicktime/download/";
#$MASTER_VIDEO_LIST	= "d:/video/master-video-list.txt"; 
$MASTER_VIDEO_LIST	= $DRIVE . ":/video/master-video-list-including-newstuff.txt"; 


@REGEX_OF_INTERESTED_SHOWS=("cow.*chick","powerpuff","stupid.*dogs","dexter.*lab",
		"family.*guy","I Am Weasel","real.*adv.*quest","popeye","home.*movies","aqua.*teen",
		"grim.*evil","harvey.*birdman","home.*movies","i.*weas[ea]l","joh?nny.*bravo",
		"justice.*league","mission.*hill","samurai.*jack","sealab.*2021",
		"space.*ghost","superman","batman","brak.*show","oblongs","he-?man",
		"transformers","ripping.*friends","futurama","pirates.*darkwater","x.men",
		"reign.*conqueror","jackie.*chan","billy.*mandy","spider.*man",
		"clone.*wars");

my @STUFF_THAT_SHOULD_ALWAYS_BE_CAPITALIZED=("Claire", "Carolyn", "Sawyer", "Lipinski");

my @attribute_types = ("date","date-range","person","event","place","thing","mediatype",
				"comedy","activity","animal","other");	#will need to update &gettype and &nicetype
		#test - adding comedy





####################################################################################
sub niceattrib {
	my $attrib  = $_[0];
	my $options = $_[1];
	my $attriborig = $attrib;
	my $verbose=0;		
	my $logic = $options->{logic} || "";

	my $logic4print;
	my $tmp="";

	if ($logic eq "") { 
		$logic=","; 
		$logic4print=", ";
	} else {
		$logic4print=" $logic ";
	}

	##### Call self recursively if passed a delimited list of attributes:
	if ($attrib =~ /$DELIMITER/) {
		my @attribs = split(/$DELIMITER/,$attrib);
		my $retval = "";
		my $num_attr = @attribs;
		for (my $i=0; $i<$num_attr; $i++) {
			$retval .= &niceattrib($attribs[$i]);
			if ($i == ($num_attr-2)) { 
				if ($num_attr > 2) { $retval .= ","; }
				#$retval .= " " . $logic . " "; 
				$retval .= $logic4print;
			}
			elsif ($i < ($num_attr-1)) { 
				if ($logic ne ",") {
					$retval .= ", "; 





				} else {
					$retval .= $logic4print;
				}
			}
		}
		$retval =~ s/,,/,/g;			#KLUDGE!
		return $retval;
	}#endif

	if ($verbose) { print qq[&niceattrib($attrib) called...<BR>\n]; }


	##### Otherwise: Normal execution:
	$attrib =~ s/^attribute\-//i;


	##### For predetermined types, we change from "type-instance" to "type: instance":
	foreach my $tmptype (@attribute_types) {
		if ($attrib =~ /$tmptype/i) { 
			$attrib =~ s/($tmptype)\-/$1: /;
		}
	}

	if ($verbose) { print qq[attrib is now[1] $attrib...<BR>\n]; }


	##### For people we need to capitalize their name, and put a comma after the last name:
	if ($attrib =~ /person:/i) {
		my ($left,$name)=split(/:/,$attrib);
		my $newname = &capitalize_each_word($name);
		$attrib =~ s/$name/$newname/;
		$attrib =~ s/(person: [a-z]+)\s(.*)$/$1, $2/i;
	}	
	##### For dates we need to remove the letter prefix off of them...
	elsif ($attrib =~ /date:/) {	
		if ($attrib =~ /date: range-/) {
			$attrib =~ s/(date: range-)([a-z]\s+[:-])(.*)/$3/i; 
			#$attrib =~ s/(date: range-)\s*([a-z])\s*[:-]\s*([a-z]\s+[:-]\s+)/$3/i; 
		} else {
			if ($attrib =~ /date: (\d{6})$/) { 
				$tmp=&niceyyyymm($1);
				$attrib=~ s#date: \d{6}$#$tmp#;
			} elsif ($attrib =~ /date: (\d{4})$/) { 		#
				### NONE YET:$tmp=&niceyyyy($1);						#
				$attrib=~ s#date: (\d{4})$#$1#;			#
			} elsif ($attrib =~ /date: (\d{8})$/) { 
				$tmp=&niceyyyymmdd($1);
				$attrib=~ s#date: \d{8}$#$tmp#;
			} elsif ($attrib =~ /date: (\d{10})$/) { 
				$tmp=&niceyyyymmddhh($1);
				$attrib=~ s#date: \d{10}$#$tmp#;
				#DEBUG: print "Attrib is now $attrib";
			}#endif
		}#endif
		if ($verbose) { print qq[attrib is now[2] $attrib...<BR>\n]; }
	}
	##### For places we are tentatively going to capitalize each word, though I don't like capitalizing things like "Beach"
	elsif ($attrib =~ /place:/) {  $attrib = &capitalize_each_word($attrib); }
	##### For media types we just need to space out the word:
	elsif ($attrib =~ /mediatype:/i) { $attrib =~ s/mediatype/media type/; }

	##### In general, we need to change dashes to colons for prettiness:
	$attrib =~ s/-/: /g;
	if ($verbose) { print qq[attrib is now[3] $attrib...<BR>\n]; }

	##### And we need to strip X levels off the front, depending on the option sent by the calling function:
	if ($options->{strip_levels}) {
		for (my $i=1; $i<=$options->{strip_levels}; $i++) {
			$attrib =~ s/^([^:]*):\s+//;
		}
	}

	##### Certain things to always capitalize:
	foreach my $thing (@STUFF_THAT_SHOULD_ALWAYS_BE_CAPITALIZED) { $attrib =~ s/$thing/$thing/i; }

	#$verbose=1;#
	if ($verbose) { print "Returning $attrib for niceattr($attriborig)...<BR><BR>\n"; } 
	return($attrib);
}#endsub niceattrib
####################################################################################

####################################################################################
####################################################################################
####################################################################################
sub getattribtype {
	####### IMPORTANT NOTE: NEW TYPES MUST BE ADDED TO &ATTRIB_TYPES function!!!!!!!!!!!!!!!!!!!
	my $attr = $_[0];
	$attr =~ s/attribute-//;
	if ($attr =~ /^mediatype-/)				{ return "mediatype"; }
	if ($attr =~ /^date-\d\d\d\d$/)  			{ return "date (year)"; }
	if ($attr =~ /^date-\d\d\d\d\d\d$/)  		{ return "date (month)"; }
	if ($attr =~ /^date-\d\d\d\d\d\d\d\d$/)  		{ return "date (day)"; }
	if ($attr =~ /^date-\d\d\d\d\d\d\d\d\d\d$/)	{ return "date (hour)"; }
	if ($attr =~ /^person-/)				{ return "person"; }
	if ($attr =~ /^place-/)					{ return "place"; }
	if ($attr =~ /^activity-/)				{ return "activity"; }
	if ($attr =~ /^date-range-/)				{ return "date range"; }
	if ($attr =~ /^thing-animal-/)			{ return "animal"; }
	if ($attr =~ /^thing-/)					{ return "thing"; }
	if ($attr =~ /^comedy-/)				{ return "comedy"; }
	if ($attr =~ /^event-/)					{ return "event"; }
	if ($attr =~ /^entertainment-/)			{ return "entertainment"; }
	if ($attr =~ /^access-/) 				{ return "access level"; }
	#if ($attr =~ /^-)  { return ""; }			### NEW TYPES MUST BE ADDED TO &ATTRIB_TYPES function!!!!!!!!!
	return "other";
}#endsub getattribtype
####################################################################################
sub ATTRIB_TYPES {
	my @types=("mediatype","date (year)","date (month)","date (day)","date (hour)",
			"person","place","activity","date range","animal","thing","comedy",
			"event","entertainment","access level","other");
	return sort @types;
}#endsub ATTRIB_TYPES
####################################################################################
####################################################################################
####################################################################################




####################################################################################

BEGIN {
my @INDEX;
	sub vchk {
		my $regex   = $_[0];
		my $options = $_[1];
		my $quoteregex = $options->{quoteregex} || 0;
		if ($quoteregex) { $regex=&regexquote($regex); }
				
		my $line="";
		my $s="";
				
		##### Read the index into a static variable only once so subsequent calls don't have to read the file again and again:
		if (@INDEX == 0) {
			if (!-e $MASTER_VIDEO_LIST) { return "FATAL ERROR: master video list of $MASTER_VIDEO_LIST does not exist!"; }
			if (!open(LIST,"$MASTER_VIDEO_LIST")) { return "FATAL ERROR: could not open master video list $MASTER_VIDEO_LIST!"; } 
			@INDEX=<LIST>;
			close(LIST);
		}
				
		#DEBUG: print "[[[vck regex is $regex]]]";#GOAT
		foreach $line (@INDEX) {
			if ($line =~ /$regex/i) { $s .= "$line"; }
		}
		return($s);
	}#endsub vchk
}
####################################################################################


1;

