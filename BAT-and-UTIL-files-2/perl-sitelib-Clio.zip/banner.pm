use Clio::Constants;		#to get $WWWIMAGES= "$WWWROOT/Images";, $WWWIMAGESURL	= "/Images";
use Clio::File;
use Clio::HTML;
use strict;
use vars qw($WWWIMAGES $WWWIMAGESURL);

######################################################################################################################################################
######################################################################################################################################################
######################################################################################################################################################
######################################################################################################################################################
######################################################################################################################################################

my @BANNERS=();
my @banner_extensions=("jpg","gif");
my $BANNERDIR = "$WWWIMAGES/banners";
my $INITIALIZED=0;

1;

######################################################################################################################################################
######################################################################################################################################################
######################################################################################################################################################
######################################################################################################################################################
######################################################################################################################################################

#TO TEST:
#use Clio::Banner;
#&BannerTest;
################################################
sub BannerTest {
	use Clio::header;
	&Print_Header;
	&InitBanners;
	for (my $i=0; $i<@BANNERS; $i++) {
		print "Banner #$i:";
		&Banner({forced=>"$i"});
		print "<BR>";
	}#endfor
}#endsub BannerTest
################################################

################################################################################
BEGIN {
	sub Banner {
		#ASSUMES $WWWIMAGES (real dir), $WWWIMAGESURL (URL of real dir)
		if (!$INITIALIZED) { 
			&InitBanners;
			$INITIALIZED=1;
		}

		my $options	= $_[0];
		my $center	= $options->{center};
		my $forced	= $options->{forced};
		if ($center eq "") { $center=1; }
	
		my $url="";

		#print "forced is $forced";

		##### Pick a random file:
		my $rand = int rand @BANNERS;
		if ($forced ne "") { $rand=$forced; }
		my $file = $BANNERS[$rand];
	
		##### Generate the filename:
		my ($pathonly,$fileonly)=&GetPathAndFileFromFullFilename($file);
		my $bannerfilename	= "$WWWIMAGESURL/Banners/$fileonly";
		my $urlfilename	=    "$WWWIMAGES/Banners/$fileonly";
	
		#DEBUG:print &tabledump("banners (rand=$rand)",\@BANNERS);#
	
		##### Generate the image link:
		my $img=&img({src=>"$bannerfilename",border=>0,align=>"center"});

		##### Find, open, and read the sister URL file:
		$urlfilename =~ s/(...)$/url/;
		if (-e $urlfilename) {
			#DEBUG:print "$urlfilename exists!<BR>";#
			open(URL,"$urlfilename") or print "Warning: urlfilename of $urlfilename exists but could not be opened!<BR>\n";
			#DEBUG:print "$urlfilename opened!<BR>";#
			$url = <URL>;
			close(URL);
		} else {
			print "\n<!-- ";
			print "Warning: URL file $urlfilename for banner $bannerfilename does not exist!";
			print " -->\n";
		}#endif
	
		#DEBUG:print "url=$url,urlfilename=$urlfilename";
	
		##### Print our data now that we have it:
		if ($center) { print "<table border=0 cellspacing=0 cellpadding=0 align=center><tr valign=top><td align=center>"; }
		if ($url ne "") { print qq[<a target="_banner" href="$url">]; }
		print $img;
		if ($url ne "") { print qq[</a>]; }
		if ($center) { print "</td></tr></table>"; }
	}#endsub Banner
}#end static variable block for banner
################################################################################

##################################################################################################
sub InitBanners {
	##### Initialize banners:
	#DEBUG: print "Initializing Banners...<BR>\n";#
	my ($tmpref,$tmpref2) = &GetContentsOfDirectory($BANNERDIR,{extensions=>\@banner_extensions});
	@BANNERS=@$tmpref;
}#endsub InitBanners
##################################################################################################
