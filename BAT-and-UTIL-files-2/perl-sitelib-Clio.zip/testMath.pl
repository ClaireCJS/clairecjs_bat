use Clio::Math;


print "rand(1  )=".rand(1  )."\n";
print "rand(5.5)=".rand(5.5)."\n";

