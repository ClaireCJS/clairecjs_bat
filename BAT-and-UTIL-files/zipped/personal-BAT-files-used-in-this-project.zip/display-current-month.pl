use Clio::Date;
my $month=&GetCurrentMonthPretty;
print "$month\n";
