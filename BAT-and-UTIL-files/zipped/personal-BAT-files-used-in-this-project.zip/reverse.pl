@OUTPUT=<STDIN>;
print reverse @OUTPUT;