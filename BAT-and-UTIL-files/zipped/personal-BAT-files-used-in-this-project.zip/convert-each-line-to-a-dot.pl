# Turn on autoflush for STDOUT
$| = 1;

while (<>) { 
	print ".";
}
