use Clio::Date;
my $month=&GetCurrentMonthPretty(-1);		#Get last month's name, not this month's
print "$month";
